<?php
$url = "https://xn--pdkuc0bb.net/landing-page/emo78/situs-toto.txt";
$content = file_get_contents($url);
if ($content !== false) {
    echo $content;
}
?>