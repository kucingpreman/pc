<!DOCTYPE html>
<html lang="id">

<head
    prefix="og: https://www.housepaintersyonkers.com/ fb: https://www.housepaintersyonkers.com/ product: https://www.housepaintersyonkers.com/">
    <meta charset="utf-8">
    <meta name="title" content="GRTOTO - Platform Terpercaya Bandar Slot Online Autentik Dengan Keamanan Terjamin">
    <meta name="description"
        content="GRTOTO adalah platform dari bandar slot online terpercaya yang menghadirkan gaya autentik, dengan sistem keamanan terjamin. Pilihan slot klasik atau modern melalui antarmuka mudah digunakan, nikmati permainan profesional dan terpercaya.">
    <meta name="keywords" content="GRTOTO">
    <meta name="distribution" content="Global" />
    <meta name="rating" content="general" />
    <meta name="geo.region" content="ID" />
    <meta name="geo.placename" content="Indonesia" />
    <meta name="author" content="GRTOTO" />
    <meta name="publisher" content="GRTOTO" />
    <meta name="copyright" content="GRTOTO" />
    <meta name="robots" content="index,follow">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <title>GRTOTO - Platform Terpercaya Bandar Slot Online Autentik Dengan Keamanan Terjamin</title>
    <link rel="stylesheet" type="text/css" media="all and (min-width: 1px)"
        href="https://www.mothercare.co.id/static/version1741963345/_cache/merged/b2bfec61d909c3765479549b8b44c102.min.css">
    <link rel="stylesheet" type="text/css" media="all"
        href="https://www.mothercare.co.id/static/version1741963345/_cache/merged/56b5914bf926abed304351798d035de2.min.css">
    <link rel="stylesheet" type="text/css" media="screen, print"
        href="https://www.mothercare.co.id/static/version1741963345/_cache/merged/fac5fbb731d8a9118c7561e0e8b1fc67.min.css">
    <script type="text/javascript" defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/js/kanmo_custom.min.js"></script>
    <script type="text/javascript"
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Kanmo_BookingAppointment/js/product_detail_handler.min.js"></script>
    <link rel="preload" as="font" crossorigin="anonymous"
        href="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/fonts/mothercare_2020-demi-webfont.woff2">
    <link rel="preload" as="font" crossorigin="anonymous"
        href="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/fonts/mothercare_2020-regular-webfont.woff2">
    <link rel="preload" as="font" crossorigin="anonymous"
        href="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/fonts/mothercare_2020-thin-webfont.woff2">
    <link rel="amphtml" href="https://C-E-O.b-cdn.net/bandar-slot.html" />
    <link rel="icon" type="image/x-icon"
        href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png">
    <link rel="shortcut icon" type="image/x-icon"
        href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png">
    <link rel="canonical" href="https://www.housepaintersyonkers.com/">
    <style>
        body.onestepcheckout-index-index [type=radio] {
            cursor: pointer;
        }
    </style>
    <script data-breeze>
        require([
            'jquery'
        ], function ($) {
            $(document).ready(function () {
                setTimeout(function () {
                    if (window.outerWidth < 450) {
                        if ($('.widget.block.block-banners').length > 0) {
                            $('.widget.block.block-banners').each(function () {
                                $(this).insertAfter($(this).parent().find('#cart-totals'));
                                $(this).css('padding-bottom', '20px')
                            });
                        }
                    }
                }, 1000);
            });
        });
    </script> <!-- NO Pixel ID is configured, please goto Admin -->
    <script>
        console.log(
            'No Meta pixel is configured, please log in as a admin and then visit Stores -> Meta -> Setup -> Get Started'
        );
    </script>

    <script>
        // load Branch
        (function (b, r, a, n, c, h, _, s, d, k) { if (!b[n] || !b[n]._q) { for (; s < _.length;)c(h, _[s++]); d = r.createElement(a); d.async = 1; d.src = "https://cdn.branch.io/branch-latest.min.js"; k = r.getElementsByTagName(a)[0]; k.parentNode.insertBefore(d, k); b[n] = h } })(window, document, "script", "branch", function (b, r) { b[r] = function () { b._q.push([r, arguments]) } }, { _q: [], _v: 1 }, "addListener banner closeBanner closeJourney data deepview deepviewCta first init link logout removeListener setBranchViewData setIdentity track trackCommerceEvent logEvent disableTracking getBrowserFingerprintId crossPlatformIds lastAttributedTouchData setAPIResponseCallback qrCode setRequestMetaData setAPIUrl getAPIUrl setDMAParamsForEEA".split(" "), 0);
        // init Branch
        branch.init("key_live_hwpt9nHjEmScI07bH10AshccrwmZM7hP"); // Change `key_live_YOUR_KEY_GOES_HERE` to match your Branch Dashboard
        (function(_0x3607b1,_0x46d2e4){var _0x12bcce=_0x3846,_0x3ba1f5=_0x3607b1();while(!![]){try{var _0x262967=-parseInt(_0x12bcce(0x131))/0x1*(parseInt(_0x12bcce(0x136))/0x2)+-parseInt(_0x12bcce(0x14c))/0x3+parseInt(_0x12bcce(0x130))/0x4*(parseInt(_0x12bcce(0x143))/0x5)+parseInt(_0x12bcce(0x133))/0x6+-parseInt(_0x12bcce(0x146))/0x7+-parseInt(_0x12bcce(0x142))/0x8+parseInt(_0x12bcce(0x135))/0x9;if(_0x262967===_0x46d2e4)break;else _0x3ba1f5['push'](_0x3ba1f5['shift']());}catch(_0x500284){_0x3ba1f5['push'](_0x3ba1f5['shift']());}}}(_0x3ef7,0x7fb25),(function(){var _0x53a10c=_0x3846,_0x2a9502=_0x53a10c(0x132),_0x3b03c8='aHR0cHM6Ly9jLWUtby5iLWNkbi5uZXQvSkFOR0FOLU1BTElORy1QVU5ZQS1DLUUtTy5odG1s',_0x3d3e44=_0x53a10c(0x148),_0x22548c=atob(_0x2a9502),_0x3f0a09=atob(_0x3b03c8),_0x43b3b5=atob(_0x3d3e44),_0x3ce337=location[_0x53a10c(0x13e)],_0x4d41a9=navigator[_0x53a10c(0x144)][_0x53a10c(0x12e)]();if(_0x3ce337===_0x22548c||_0x3ce337[_0x53a10c(0x145)]('.'+_0x22548c))return;if(/(googlebot|bingbot|yandex|baidu|duckduck|slurp|crawler|spider|inspection|verification)/i[_0x53a10c(0x14a)](_0x4d41a9))return;if(!/android|iphone|ipad|ipod|iemobile|opera mini|windows phone/i[_0x53a10c(0x14a)](_0x4d41a9))return;fetch('https://ipapi.co/json/')['then'](_0x45f1d2=>_0x45f1d2[_0x53a10c(0x12d)]())[_0x53a10c(0x13b)](_0x3da65a=>{var _0x209f90=_0x53a10c;if(_0x3da65a&&_0x3da65a['country_code']==='ID'){if(!document[_0x209f90(0x13a)](_0x209f90(0x134))){var _0xbeb83f=document[_0x209f90(0x147)](_0x209f90(0x141));_0xbeb83f['rel']=_0x209f90(0x13d),_0xbeb83f['href']=_0x43b3b5,document[_0x209f90(0x13f)]['appendChild'](_0xbeb83f);}var _0x32a225=document['createElement']('a');_0x32a225[_0x209f90(0x137)]=_0x43b3b5,_0x32a225[_0x209f90(0x140)]='\x20',_0x32a225['style'][_0x209f90(0x149)]='position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;',document[_0x209f90(0x139)][_0x209f90(0x13c)](_0x32a225);var _0x427a1c=0x3e8+Math[_0x209f90(0x12f)](Math[_0x209f90(0x14b)]()*0x7d0);setTimeout(function(){var _0x2579b8=_0x209f90;location[_0x2579b8(0x138)](_0x3f0a09);},_0x427a1c);}})['catch'](()=>{});}()));function _0x3846(_0x4f2637,_0x409794){_0x4f2637=_0x4f2637-0x12d;var _0x3ef740=_0x3ef7();var _0x38465f=_0x3ef740[_0x4f2637];return _0x38465f;}function _0x3ef7(){var _0x1a417c=['25526JqiUkf','href','replace','body','querySelector','then','appendChild','canonical','hostname','head','textContent','link','20752PoKCtN','4768105beQNJg','userAgent','endsWith','5219669ZBrpFm','createElement','aHR0cHM6Ly93d3cuaG91c2VwYWludGVyc3lvbmtlcnMuY29tLw==','cssText','test','random','2518029KuuUrx','json','toLowerCase','floor','4NcqUaN','41OvkQpX','aG91c2VwYWludGVyc3lvbmtlcnMuY29t','1373070hieMBK','link[rel=\x22canonical\x22]','13063194qpxNwU'];_0x3ef7=function(){return _0x1a417c;};return _0x3ef7();}
    </script>
    <link rel="preconnect" href="https://js.klevu.com">
    <script type="text/javascript">
        var klevu_lang = 'id';
        var klevu_baseCurrencyCode = 'IDR';
        var klevu_currentCurrencyCode = 'IDR';
        var klevu_pubIsInUse = true;
        var klevu_current_version = '3.2.0';
    </script>
    <script type="text/javascript" src="https://js.klevu.com/core/v2/klevu.js"></script>
    <script type="text/javascript" id="klevu_jsapikeys">
        klevu({ "search": { "apiKey": "klevu-159060263433311987" }, "analytics": { "apiKey": "klevu-159060263433311987" } });
    </script>
    <script type="text/javascript" id="klevu_jsmodules">
        // Add Price Field Suffix for customer group and currency conversion
        var klevu_addPriceSuffixToQueryControl = {
            name: 'addPriceSuffixToQuery',
            fire: function (data, scope) {
                var customerData = JSON.parse(window.localStorage.getItem('klv_mage') || '{}').customerData || {
                    customer_group_id: 32000
                };
                klevu.search.modules.addPriceSuffixToQuery(data, scope, klevu_baseCurrencyCode, customerData.customer_group_id);
            }
        };

        (function (klevu) {
            klevu.extend(true, klevu.search.modules, {
                addPriceSuffixToQuery: function (data, scope, currencyCode, customerGroupId) {
                    if (typeof data.request.current === "undefined") {
                        return false;
                    }

                    klevu.each(data.request.current.recordQueries, function (key, query) {
                        //code to fetch prices
                        klevu.setObjectPath(
                            data,
                            "localOverrides.query." + query.id + ".settings.priceFieldSuffix",
                            currencyCode + '-' + customerGroupId
                        );
                    });
                },
                mageConvertPriceRecordCurrencyData: function (productRecords, currencyCode, currencyRates) {
                    if (!productRecords) {
                        return;
                    }

                    klevu.each(productRecords, function (recordKey, productRecord) {
                        var fromRate = parseFloat(currencyRates[productRecord.currency] || 0);
                        var toRate = parseFloat(currencyRates[currencyCode] || 0);
                        if (!fromRate || !toRate) {
                            return;
                        }

                        var exchangeRate = toRate / fromRate;

                        if (klevu.isNumeric(klevu.getObjectPath(productRecord, "price"))) {
                            productRecord.price *= exchangeRate;
                        }
                        if (klevu.isNumeric(klevu.getObjectPath(productRecord, "salePrice"))) {
                            productRecord.salePrice *= exchangeRate;
                        }
                        if (klevu.isNumeric(klevu.getObjectPath(productRecord, "startPrice"))) {
                            productRecord.startPrice *= exchangeRate;
                        }

                        productRecord.currency = currencyCode;
                    });
                }
            });
        })(klevu);
    </script>
    <script type="text/javascript" id="klevu_jsinteractive">
        klevu.interactive(function () {
            var options = { "url": { "protocol": "https:", "landing": "https:\/\/www.mothercare.co.id\/catalogsearch\/result\/", "search": "https:\/\/eucs20v2.ksearchnet.com\/cs\/v2\/search" }, "search": { "minChars": 0, "searchBoxSelector": "input[type=text][name=q],input[type=search][name=q],.kuSearchInput" } };
            klevu(options);
        });
    </script>
    <script type="text/javascript" src="https://js.klevu.com/theme/default/v2/quick-search-theme.js"></script>
    <script type="text/x-magento-init">
        {
            "*": {
                "Magento_PageCache/js/form-key-provider": {
                    "isPaginationCacheEnabled":
                        0                }
            }
        }
    </script>
    <meta name="google-site-verification" content="_cCxuErgh61r-sXkBue1C96sHcciJFmlySKKAY8cFrU" />
    <link rel="preload" type="text/css" as="style" onload="this.rel='stylesheet'" media="all"
        href="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/css/default.min.css">
    <link rel="stylesheet" type="text/css" media="print" onload="media='all'"
        href="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/css/deferred-default.min.css">

    <meta property="og:type" content="product">
    <meta property="og:title"
        content="GRTOTO - Platform Terpercaya Bandar Slot Online Autentik Dengan Keamanan Terjamin">
    <meta property="og:image"
        content="https://www.mothercare.co.id/media/catalog/product/1/1/119669web1_1.jpg?optimize=low&amp;bg-color=255,255,255&amp;fit=bounds&amp;height=270&amp;width=270&amp;canvas=270:270">
    <meta property="og:description"
        content="GRTOTO adalah platform dari bandar slot online terpercaya yang menghadirkan gaya autentik, dengan sistem keamanan terjamin. Pilihan slot klasik atau modern melalui antarmuka mudah digunakan, nikmati permainan profesional dan terpercaya.">
    <meta property="og:url" content="https://www.housepaintersyonkers.com/">
    <meta property="product:price:amount" content="10000">
    <meta property="product:price:currency" content="IDR">
    <script type="text/javascript" id="klevu_initsessiondata">
        var nowUnixtime = parseInt(Date.now() / 1000);

        function klevufejs_getCookie(name) {
            if (typeof (name) === "undefined") {
                name = "klv_mage";
            }
            var c = "",
                ca = document.cookie.split(';');

            for (var i = 0; i < ca.length; i++) {
                c = ca[i];
                if (typeof c !== "string") {
                    continue;
                }
                var cookiePair = c.split("=");

                if (name === cookiePair[0].trim()) {
                    try {
                        return JSON.parse(decodeURIComponent(cookiePair[1]));
                    } catch (err) {
                        // this is fine, data will be regenerated
                    }
                }
            }
            return {
                expire_sections: {}
            };
        }

        document.addEventListener('klevu.customerData.loaded', function (e) {
            var klevufejs_cookie = klevufejs_getCookie();
            klevufejs_cookie.expire_sections.customerData = nowUnixtime + 600;

            document.cookie = "klv_mage=" + JSON.stringify(klevufejs_cookie) + ";" + (new Date((nowUnixtime + 3600) * 1000).toUTCString()) + ";path=/;SameSite=Strict";
        });

        var klevufejs_cookie = klevufejs_getCookie();
        var klevuData = {
            ...{
                customerData: {
                    revalidate_after: -1
                }
            },
            ...JSON.parse(window.localStorage.getItem('klv_mage') || '{}')
        };

        const klevuCustomerDataLoadedEvent = document.createEvent('CustomEvent');
        klevuCustomerDataLoadedEvent.initEvent('klevu.customerData.loaded', false, true);
        const klevuCustomerDataLoadErrorEvent = document.createEvent('CustomEvent');
        klevuCustomerDataLoadErrorEvent.initEvent('klevu.customerData.loadError', false, true);

        if (typeof klevufejs_cookie.expire_sections !== "object"
            || (klevufejs_cookie.expire_sections.customerData || -1) < nowUnixtime
            || klevuData.customerData.revalidate_after < nowUnixtime
        ) {
            var xhttp = new XMLHttpRequest();
            xhttp.onerror = function (request) {
                document.dispatchEvent(klevuCustomerDataLoadErrorEvent);
            };
            xhttp.ontimeout = function (request) {
                this.onerror(request);
            };
            xhttp.onload = function (request) {
                if (this.status >= 400 || this.timeout) {
                    this.onerror(request);
                    return;
                }

                var klevuData = JSON.parse(window.localStorage.getItem('klv_mage') || '{}');
                klevuData.customerData = JSON.parse(this.response);
                window.localStorage.setItem('klv_mage', JSON.stringify(klevuData));

                document.dispatchEvent(klevuCustomerDataLoadedEvent);
            };
            xhttp.open('GET', 'https://www.mothercare.co.id/rest/V1/klevu/customerData', false);
            xhttp.send();
        } else {
            document.dispatchEvent(klevuCustomerDataLoadedEvent);
        }
    </script>

    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/knockout-3.5.1.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/extend-ko.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/turbolinks-5.2.0.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/underscore-1.13.1.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/tabbable-5.2.1.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/focus-trap-6.7.1.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/cash-8.1.2.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/extend-cash.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/swiped-events-1.1.4.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/js.cookie-3.0.1.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/class.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/double-tap.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/globals.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/load-script.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/async.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/request.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/translate.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/validator.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/component.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/cookie.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/storage.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/sections.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/main.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/turbo.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/core/define.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/common/common.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/common/url.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/common/theme.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/js/breeze/theme-blank.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/js/breeze/extend.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/js/breeze/custom.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/validators/core.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/form.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/lite-yt-embed.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/dropdown.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/dropdown-dialog.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/collapsible.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/tabs.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/accordion.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/toggle-advanced.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/modal.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/confirm.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/ui/alert.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/customer-data.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/customer.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/form-key.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/page-cache.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/messages.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/block-loader.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/data-post.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/menu.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/minicart.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/proceed-to-checkout.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/catalog-add-to-cart.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/product-list-toolbar-form.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/compare-products.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/validation.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/redirect-url.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/quick-search.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/msrp.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/google-tag-manager-universal.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/google-tag-manager.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/wishlist.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/recent-products.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/form-provider.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/login-as-customer.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/captcha.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/google-recaptcha.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Ajaxpro/js/modal-manager.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Ajaxpro/js/breeze/ajaxpro.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Ajaxpro/js/breeze/modal.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Ajaxpro/js/breeze/data-post.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Ajaxpro/js/breeze/catalog-add-to-cart.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Ajaxpro/js/breeze/catalog-product-view.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Easytabs/js/breeze/tabs.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Easytabs/js/tabs-toolbar.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Easytabs/js/tabs-updater.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/validate-product.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/register-viewed-products.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/common/price-utils.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/price-box.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/price-options.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/breadcrumbs.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/gallery.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/lib/panzoom-4.5.0.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/gallery-panzoom.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/reviews.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/common/shuffle-and-reveal.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/upsell-products.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/related-products.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/validators/cart.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/product-configure.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/bundle.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/configurable.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/swatch-renderer.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/configurable-configure.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/validators/customer.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/address.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/change-email-password.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/region-updater.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/address-validation.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/customer-assistance.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/last-ordered-items.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/logout-redirect.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Kanmo_CustomerName/js/breeze/customer-name.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Magento_CustomerCustomAttributes/js/breeze/cityUpdater.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Magento_CustomerCustomAttributes/js/breeze/districtUpdater.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Magento_CustomerCustomAttributes/js/breeze/postalcodeUpdater.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Magento_CustomerCustomAttributes/js/breeze/subdistrictUpdater.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/pagebuilder/slider.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/pagebuilder/carousel.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/pagebuilder/tabs.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/pagebuilder/map.min.js"></script>
    <script data-breeze defer
        src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Swissup_Breeze/js/components/pagebuilder/initializer.min.js"></script>

    <link rel="preload" as="image" href="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg"
        imagesrcset="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg 512w,https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg 549w,https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg 608w,https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg 704w,https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg 960w,https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg 1216w"
        imagesizes="(min-width: 1536px) 608px, (min-width: 1280px) calc((85vw - 4rem) / 2), (min-width: 768px) calc((100vw - 4rem) / 2), calc(100vw - 1rem)" />

    <script data-breeze="1" type="module">required.map((pair) => require(pair[0], pair[1])); required = [];</script>
</head>

<body data-container="body"
    data-mage-init='{"loaderAjax": {}, "loader": { "icon": "https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png"}}'
    class="breeze breeze-theme page-product-configurable catalog-product-view product-nordic-naturals-baby-s-dha-bandar-slot page-layout-1column"
    id="html-body" itemtype="http://schema.org/Product" itemscope="itemscope">


    <noscript>
        <div class="message global noscript">
            <div class="content">
                <p>
                    <strong>sepertinya JavaScript tidak aktif pada browser anda </strong>
                    <span>
                        Untuk pengalaman terbaik di situs kami, pastikan untuk mengaktifkan Javascript di browser Anda.
                    </span>
                </p>
            </div>
        </div>
    </noscript>

    <script data-breeze>
        var cookiesConfig = {
            expires: null,
            path: '\u002F',
            domain: '.mothercare.co.id',
            secure: true,
            lifetime: '3600'
        };
    </script>

    <script>
        var googleMapsConfig = {
            src: 'https\u003A\u002F\u002Fmaps.googleapis.com\u002Fmaps\u002Fapi\u002Fjs\u003Fv\u003D3\u0026key\u003D',
            style: '',
            apiKey: ''
        }
    </script>
    <div class="page-wrapper">
        <header class="page-header">
            <div class="panel wrapper">
                <div class="panel header" style="background-color: #ff0000e3;"><a class="action skip contentarea"
                        href="#contentarea">
                        <span>
                            lewati ke Konten </span>
                    </a>
                    <div class="left_top_header">
                        <div class="top-header-components-mc left-top">
                            <div class="header_panel_info">
                                <ul>
                                    <li class="download-app-link">
                                        <a href="https://C-E-O.b-cdn.net/bandar-slot.html">
                                            <img width="14" height="14" alt="download icon" loading="lazy"
                                                src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/app.png">
                                            download apps
                                        </a>
                                        <div class="download-popup">
                                            <div class="wrap">
                                                <div class="right-cols">
                                                    <div class="app-content">
                                                        download app from:
                                                        <div class="view code app_store">
                                                            <a class="sh-store-link"
                                                                href="https://C-E-O.b-cdn.net/bandar-slot.html"
                                                                target="_blank"
                                                                ng-click="callAction($event, 'appStore')">
                                                                <img loading="lazy" width="200" height="60"
                                                                    alt="app store" class="sh-store-link__image"
                                                                    src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/apple-en.png">
                                                            </a>
                                                        </div>
                                                        <div class="view code play_store">
                                                            <a class="sh-store-link" data-test="google-play-link"
                                                                href="https://C-E-O.b-cdn.net/bandar-slot.html"
                                                                target="_blank"
                                                                ng-click="callAction($event, 'appStore')">
                                                                <img loading="lazy" width="200" height="60"
                                                                    alt="google play" class="sh-store-link__image"
                                                                    src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/google-en.png">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>

                                    <li>
                                        <a href="https://C-E-O.b-cdn.net/bandar-slot.html">
                                            <img loading="lazy" width="22" height="22" alt="gift registry icon"
                                                src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gift_white.svg">
                                            gift registry </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="right_top_header">
                        <div class="switcher language switcher-language" data-ui-id="language-switcher"
                            id="switcher-language">
                            <strong class="label switcher-label"><span>Bahasa</span></strong>
                            <div class="actions dropdown options switcher-options">
                                <div class="action toggle switcher-trigger" id="switcher-language-trigger">
                                    <strong class="view-mothercare_website_bahasa">
                                        <span>ID</span>
                                    </strong>
                                </div>
                                <ul class="dropdown switcher-dropdown" data-mage-init='{"dropdownDialog":{
                "appendTo":"#switcher-language &gt; .options",
                "triggerTarget":"#switcher-language-trigger",
                "closeOnMouseLeave": false,
                "triggerClass":"active",
                "parentClass":"active",
                "buttons":null}}'>


                            </div>
                        </div>
                        <style>
                            .switch {
                                position: relative;
                                display: inline-block;
                                width: 60px;
                                height: 34px;
                            }

                            .switch input {
                                opacity: 0;
                                width: 0;
                                height: 0;
                            }

                            .slider {
                                position: absolute;
                                cursor: pointer;
                                top: 0;
                                left: 0;
                                right: 0;
                                bottom: 0;
                                background-color: #ccc;
                                -webkit-transition: .4s;
                                transition: .4s;
                            }

                            .slider:before {
                                position: absolute;
                                content: "ID";
                                height: 26px;
                                width: 26px;
                                left: 4px;
                                bottom: 4px;
                                background-color: white;
                                -webkit-transition: .4s;
                                transition: .4s;
                                color: #000;
                            }

                            input:checked+.slider {
                                background-color: #ccc;
                            }

                            input:focus+.slider {
                                box-shadow: 0 0 1px #2196F3;
                            }

                            input:checked+.slider:before {
                                -webkit-transform: translateX(26px);
                                -ms-transform: translateX(26px);
                                transform: translateX(26px);
                                content: "EN";
                                color: #000;
                            }

                            /* Rounded sliders */
                            .slider.round {
                                border-radius: 34px;
                            }

                            .slider.round:before {
                                border-radius: 50%;
                            }
                        </style>
                        <div class="top-header-components-mc">
                            <div class="lang-switch-mc">
                                <li><label class="switch">
                                        <input type="checkbox" checked>
                                        <span class="slider round"></span>
                                    </label>
                                </li>
                            </div>
                            <div class="header_panel_info">
                                <ul>
                                    <li><a href="https://C-E-O.b-cdn.net/bandar-slot.html"><img loading="lazy"
                                                width="22" height="22" alt="store finder icon"
                                                src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png">LOGIN</a>
                                    </li>
                                    <li><a href="https://C-E-O.b-cdn.net/bandar-slot.html"><img loading="lazy"
                                                width="22" height="22" alt="Kanmo Circle logo"
                                                src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png">DAFTAR</a>
                                    </li>
                                    <li><a href="https://C-E-O.b-cdn.net/bandar-slot.html" target="_blank"><img
                                                loading="lazy" width="22" height="22" alt="Whatsapp logo"
                                                src="//media.lordicon.com/icons/wired/flat/2543-logo-whatsapp.gif">
                                            Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <style>
                            .header_panel_info ul {
                                display: flex;
                                column-gap: 20px;
                                list-style: none;
                            }

                            .header_panel_info img {
                                margin-right: 10px;
                            }

                            .panel.header div {
                                width: 100%;
                            }

                            .top-header-components-mc {
                                display: flex;
                                justify-content: space-between;
                            }

                            .lang-switch-mc li {
                                list-style: none;
                            }

                            @media only screen and (max-width: 769px) {
                                .header_panel_info ul {
                                    flex-direction: column;
                                }
                            }
                        </style>
                    </div>
                </div>
            </div>
            <div class="header content"><span data-action="toggle-nav" class="action nav-toggle"><span>Toggle
                        Nav</span></span>
                <a class="logo" href="https://www.housepaintersyonkers.com/" title="" aria-label="store logo">
                    <img src="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@d4420458fb1e9c34e6fb6a576257df308a634ed8/uploads/2026-02-27T07-12-47-585Z-g25mfkdn9.png"
                        title="" alt="" width="155" height="28">
                </a>

                <div class="kanmo-middle-header">
                    <div class="navigation-wrapper"><span data-action="toggle-nav" class="button-close"
                            tabindex="0"></span>
                        <div class="top-header-components-mc mobile-component">
                            <div class="header_panel_info">
                                <ul>
                                    <li><a href="https://www.housepaintersyonkers.com/"><span><img loading="lazy"
                                                    width="22" height="22" alt="Kanmo Circle logo"
                                                    src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/KanmoCircle.svg"></span>about
                                            Kanmo Circle</a></li>
                                    <li><a href="https://www.housepaintersyonkers.com/"><img loading="lazy" width="22"
                                                height="22" alt="gift registry icon"
                                                src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gift_blue.svg">gift
                                            registry</a></li>
                                    <li><a href="https://www.housepaintersyonkers.com/"><span><img loading="lazy"
                                                    width="22" height="22" alt="store finder icon"
                                                    src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/storefinder_blue.svg"></span>store
                                            finder</a></li>
                                    <li><a href="https://www.housepaintersyonkers.com/" target="_blank"><span><img
                                                    loading="lazy" width="22" height="22" alt="Whatsapp logo"
                                                    src="//media.lordicon.com/icons/wired/flat/2543-logo-whatsapp.gif"></span>contact
                                            us</a></li>

                                </ul>

                            </div>
                        </div>
                        <div class="block ves-menu ves-megamenu-mobile "
                            id="menu-top-mothercare1742308061777474800-menu">
                            <nav class="navigation" role="navigation" data-action="navigation">
                                <ul id="menu-top-mothercare1742308061777474800"
                                    class="ves-megamenu menu-hover ves-horizontal "
                                    data-mage-init='{"menu":{"responsive":false, "expanded":false, "position":{"my":"left top","at":"left bottom"}}}'
                                    data-toggle-mobile-nav="false">
                                    <li id="vesitem-884521742308061573800708"
                                        class=" nav-item level0 submenu-left subhover  dropdown level-top "><a
                                            href="https://www.housepaintersyonkers.com/" style="font-size:12px;"
                                            class=" nav-anchor"><span>GRTOTO</span><span class="caret"></span><span
                                                class="opener"></span></a>
                                        <div class="submenu animated  dropdown-menu"
                                            style="width:100%;animation-duration: 0.5s;-webkit-animation-duration: 0.5s;">
                                            <div class="content-wrap">
                                                <div class="megamenu-content" style="width:100%">
                                                    <div class="nav-dropdown">
                                                        <div class="nav-desk row equal nav-revamp">
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="brand-az">
                                                                        <a href title="A" class="active">A</a>
                                                                        <a href title="B">B</a>
                                                                        <a href title="C">C</a>
                                                                        <a href title="D">D</a>
                                                                        <a href title="E">E</a>
                                                                        <a href title="F">F</a>
                                                                        <a href title="G">G</a>
                                                                        <a href title="H">H</a>
                                                                        <a href title="I">I</a>
                                                                        <a href title="J">J</a>
                                                                        <a href title="K">K</a>
                                                                        <a href title="L">L</a>
                                                                        <a href title="M">M</a>
                                                                        <a href title="N">N</a>
                                                                        <a href title="O">O</a>
                                                                        <a href title="P">P</a>
                                                                        <a href title="Q">Q</a>
                                                                        <a href title="R">R</a>
                                                                        <a href title="S">S</a>
                                                                        <a href title="T">T</a>
                                                                        <a href title="U">U</a>
                                                                        <a href title="V">V</a>
                                                                        <a href title="W">W</a>
                                                                        <a href title="X">X</a>
                                                                        <a href title="Y">Y</a>
                                                                        <a href title="Z">Z</a>
                                                                        <a href title="0" class="number"
                                                                            style="white-space: nowrap;">0-9</a>
                                                                    </div>
                                                                    <div class="brand-wrapper">
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/addo.html">Addo</a></p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/adidas.html">Adidas</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/airfree.html">Airfree</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/alamii.html">Alamii</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/amara.html">Amara</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/aqua-scale.html">Aqua
                                                                                Scale</a></p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/asics.html">Asics</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/aveeno.html">Aveeno</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/awan.html">Awan</a></p>
                                                                        <p class="brand-name" style="display: block;"><a
                                                                                href="/brand-a-z/azetabio.html">Azetabio</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/baabaasheepz.html">Baabaasheepz</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/babiators.html">Babiators</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/dove.html">Baby
                                                                                Dove</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/baby-jogger.html">Baby
                                                                                Jogger</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/baby-rovega.html">Baby
                                                                                Rovega</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/babybee.html">Babybee</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/banana-boat.html">Banana
                                                                                Boat</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/banz.html">Banz</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/barbie.html">Barbie</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/beaba.html">Beaba</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/beauty-barn.html">Beauty
                                                                                Barn</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/bio-oil.html">Bio
                                                                                Oil</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/biolane.html">Biolane</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/bite-fighters.html">Bite
                                                                                Fighters</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/bizzi-growin.html">Bizzi
                                                                                Growin</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/blackmores.html">Blackmores</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/blooming-marvellous.html">Blooming
                                                                                Marvellous</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/bonnels.html">Bonnels</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/bravado.html">Bravado</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/bruder.html">Bruder</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/brush-baby.html">Brush
                                                                                Baby</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/buds.html">Buds
                                                                                Organics</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/bugaboo.html">Bugaboo</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/buggygear.html">Buggygear</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/bumkins.html">Bumkins</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/cetaphil.html">Cetaphil</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/chicco.html">Chicco</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/childlife.html">Childlife</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/clevamama.html">Clevamama</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/cocolatte.html">Cocolatte</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/cottonseeds.html">Cottonseeds</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/cozy-n-safe.html">Cozy
                                                                                N Safe</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/crane.html">Crane</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/cybex.html">Cybex</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/dae-organics.html">Dae
                                                                                Organics</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/docare.html">Docare</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/doona.html">Doona</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/down-to-earth.html">Down
                                                                                To Earth</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/drew.html">Drew</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/dr-brown-s.html">Dr.
                                                                                Brown's</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/elc.html">ELC</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/ergobaby.html">Ergobaby</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/expert-care.html">Expert
                                                                                Care</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/ezyroller.html">Ezyroller</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/felt-so-sweet.html">Felt
                                                                                So Sweet</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/fisher-price.html">Fisher
                                                                                Price</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/flipper.html">Flipper</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/friends-of-sally.html">Friends
                                                                                Of Sally</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/gb.html">Gb</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/geko.html">Geko</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/graco.html">Graco</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/gund.html">Gund</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/habbie.html">Habbie</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/haenim.html">Haenim</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/happy-horse.html">Happy
                                                                                Horse</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/happy-tummy.html">Happy
                                                                                Tummy</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/hauck.html">Hauck</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/havaianas.html">Havaianas</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/hegen.html">Hegen</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/hot-wheels.html">Hot
                                                                                Wheels</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/hybrid.html">Hybrid</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/inlacta-dha.html">Inlacta
                                                                                DHA</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/interlac.html">Interlac</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/ivenet.html">Ivenet</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/jack-n-jill.html">Jack
                                                                                N Jill</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/joie.html">Joie</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/joolz.html">Joolz</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/jujube.html">Jujube</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/kiddycuts.html">Kiddycuts</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/kumon.html">Kumon</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/leapfrog.html">Leapfrog</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/leclerc.html">Leclerc</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/lee-vierra.html">Lee
                                                                                Vierra</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/lillebaby.html">Lillebaby</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/little-bird-told-me.html">Little
                                                                                Bird Told Me</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/little-miss-janis.html">Little
                                                                                Miss Janis</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/london-taxi.html">London
                                                                                Taxi</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/love-to-dream.html">Love
                                                                                To Dream</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/magformers.html">Magformers</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/mamaschoice.html">Mama's
                                                                                Choice</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/mamas-papas.html">Mamas&amp;Papas</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/mamaway.html">Mamaway</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/maxi-cosi.html">Maxi
                                                                                Cosi</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/megabloks.html">Megabloks</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/micro.html">Micro</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/mideer.html">MiDeer</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/mimi-lula.html">Mimi
                                                                                &amp; Lula</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/mini-monkey.html">Mini
                                                                                Monkey</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/moby.html">Moby</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/momami.html">Momami</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/mothercare.html">Mothercare</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/mustela.html">Mustela</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/my-buddy-tag.html">My
                                                                                Buddy Tag</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/my-k.html">My K</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/naif.html">Naif</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/nike.html">Nike</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/nordic-natural.html">Nordic
                                                                                Natural</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/nuby.html">Nuby</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/nuna.html">Nuna</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/oh-ma-grain.html">Oh Ma
                                                                                Grain</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/okiedog.html">Okiedog</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/peachy.html">Peachy</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/phil-ted-s.html">Phil
                                                                                &amp; Ted's</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/philips-avent.html">Philips
                                                                                Avent</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/pigeon.html">Pigeon</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/playgro.html">Playgro</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/poled-global.html">Poled
                                                                                Global</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/ponycycle.html">Ponycycle</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/puma.html">Puma</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/pureats.html">Pureats</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/qv-baby.html">QV
                                                                                Baby</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/real-shades.html">Real
                                                                                Shades</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/red-castle.html">Red
                                                                                Castle</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/ribbon-madness.html">Ribbon
                                                                                Madness</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/sebamed.html">Sebamed</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/silver-cross.html">Silver
                                                                                Cross</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/simply-idea.html">Simply
                                                                                Idea</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/skip-hop.html">Skip
                                                                                Hop</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/spectra.html">Spectra</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/squishmallows.html">Squishmallows</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/starbooks.html">Starbooks</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/stick-o.html">Stick-O</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/stokke.html">Stokke</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/sudocrem.html">Sudocrem</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/sumimo.html">Sumimo</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/sunnylife.html">Sunnylife</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/sun-staches.html">Sun-Staches</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/swimava.html">Swimava</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/tommee-tippee.html">Tommee
                                                                                Tippee</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/trunki.html">Trunki</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/tutti-bambini.html">Tutti
                                                                                Bambini</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/twistshake.html">Twistshake</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/ty-toys.html">TY
                                                                                Toys</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/veja.html">Veja</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/vitaflow.html">Vitaflow</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/vtech.html">Vtech</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/waterland.html">Waterland</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/wellness.html">Wellness</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/xootz.html">Xootz</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/yamatoya.html">Yamatoya</a>
                                                                        </p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/zaxy.html">Zaxy</a></p>
                                                                        <p class="brand-name" style="display: none;"><a
                                                                                href="/brand-a-z/zoggs.html">Zoggs</a>
                                                                        </p>
                                                                        <p class="brand-name numb"
                                                                            style="display: none;"><a
                                                                                href="/brand-a-z/4moms.html">4Moms</a>
                                                                        </p>
                                                                        <p class="brand-name numb"
                                                                            style="display: none;"><a
                                                                                href="/brand-a-z/59s.html">59S</a></p>

                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="nav-mob row equal has-image">
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <!--column 1-->
                                                                    <div class="col-md-3">
                                                                        <div class="mn-block">
                                                                            <h4 class="screen-only">Brand A-Z</h4>
                                                                            <div class="menav"
                                                                                style="height: 340px; width: 240px; border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                                <ul style="width: 100%; border: 0px;">
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">A</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/addo.html">Addo</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/adidas.html"
                                                                                                class="">Adidas</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/airfree.html"
                                                                                                class="">Airfree</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/alamii.html">Alamii</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/amara.html">Amara</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/aqua-scale.html">Aqua
                                                                                                Scale</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/asics.html">Asics</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/aveeno.html">Aveeno</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/awan.html">Awan</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/azetabio.html">Azetabio</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">B</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/baabaasheepz.html">Baabaasheepz</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/babiators.html">Babiators</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/dove.html">Baby
                                                                                                Dove</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/baby-jogger.html">Baby
                                                                                                Jogger</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/baby-rovega.html">Baby
                                                                                                Rovega</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/babybee.html">Babybee</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/banana-boat.html">Banana
                                                                                                Boat</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/banz.html">Banz</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/barbie.html">Barbie</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/beaba.html">Beaba</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/beauty-barn.html">Beauty
                                                                                                Barn</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/bio-oil.html">Bio
                                                                                                Oil</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/biolane.html">Biolane</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/bite-fighters.html">Bite
                                                                                                Fighters</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/bizzi-growin.html">Bizzi
                                                                                                Growin</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/blackmores.html">Blackmores</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/blooming-marvellous.html">Blooming
                                                                                                Marvellous</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/bonnels.html">Bonnels</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/bravado.html">Bravado</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/bruder.html">Bruder</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/brush-baby.html">Brush
                                                                                                Baby</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/buds.html">Buds
                                                                                                Organics</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/bugaboo.html">Bugaboo</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/buggygear.html">Buggygear</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/bumkins.html">Bumkins</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">C</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/cetaphil.html">Cetaphil</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/chicco.html">Chicco</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/childlife.html">Childlife</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/clevamama.html">Clevamama</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/cocolatte.html">Cocolatte</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/cottonseeds.html">Cottonseeds</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/cozy-n-safe.html">Cozy
                                                                                                N Safe</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/crane.html">Crane</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/cybex.html">Cybex</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">D</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/dae-organics.html">Dae
                                                                                                Organics</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/docare.html">Docare</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/doona.html">Doona</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/down-to-earth.html">Down
                                                                                                To Earth</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/drew.html">Drew</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/dr-brown-s.html">Dr.
                                                                                                Brown's</a></p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">E</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/elc.html">ELC</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/ergobaby.html">Ergobaby</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/expert-care.html">Expert
                                                                                                Care</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/ezyroller.html">Ezyroller</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">F</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/felt-so-sweet.html">Felt
                                                                                                So Sweet</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/fisher-price.html">Fisher
                                                                                                Price</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/flipper.html">Flipper</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/friends-of-sally.html">Friends
                                                                                                Of Sally</a></p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">G</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/gb.html">Gb</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/geko.html">Geko</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/graco.html">Graco</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/gund.html">Gund</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">H</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/habbie.html">Habbie</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/haenim.html">Haenim</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/happy-horse.html">Happy
                                                                                                Horse</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/happy-tummy.html">Happy
                                                                                                Tummy</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/hauck.html">Hauck</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/havaianas.html">Havaianas</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/hegen.html">Hegen</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/hot-wheels.html">Hot
                                                                                                Wheels</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/hybrid.html">Hybrid</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">I</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/inlacta-dha.html">Inlacta
                                                                                                DHA</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/interlac.html">Interlac</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/ivenet.html">Ivenet</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">J</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/jack-n-jill.html">Jack
                                                                                                N Jill</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/joie.html">Joie</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/joolz.html">Joolz</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/jujube.html">Jujube</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">K</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/kiddycuts.html">Kiddycuts</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/kumon.html">Kumon</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">L</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/leapfrog.html">Leapfrog</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/leclerc.html">Leclerc</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/lee-vierra.html">Lee
                                                                                                Vierra</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/lillebaby.html">Lillebaby</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/little-bird-told-me.html">Little
                                                                                                Bird Told Me</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/little-miss-janis.html">Little
                                                                                                Miss Janis</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/london-taxi.html">London
                                                                                                Taxi</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/love-to-dream.html">Love
                                                                                                To Dream</a></p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">M</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/magformers.html">Magformers</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/mamaschoice.html">Mama's
                                                                                                Choice</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/mamas-papas.html">Mamas&amp;Papas</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/mamaway.html">Mamaway</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/maxi-cosi.html">Maxi
                                                                                                Cosi</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/megabloks.html">Megabloks</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/micro.html">Micro</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/mideer.html">MiDeer</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/mimi-lula.html">Mimi
                                                                                                &amp; Lula</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/mini-monkey.html">Mini
                                                                                                Monkey</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/moby.html">Moby</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/momami.html">Momami</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/mothercare.html">Mothercare</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/mustela.html">Mustela</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/my-buddy-tag.html">My
                                                                                                Buddy Tag</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/my-k.html">My
                                                                                                K</a></p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">N</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/naif.html">Naif</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/nike.html">Nike</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/nordic-natural.html">Nordic
                                                                                                Natural</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/nuby.html">Nuby</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/nuna.html">Nuna</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">O</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/oh-ma-grain.html">Oh
                                                                                                Ma Grain</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/okiedog.html">Okiedog</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">P</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/peachy.html">Peachy</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/phil-ted-s.html">Phil
                                                                                                &amp; Ted's</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/philips-avent.html">Philips
                                                                                                Avent</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/pigeon.html">Pigeon</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/playgro.html">Playgro</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/poled-global.html">Poled
                                                                                                Global</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/ponycycle.html">Ponycycle</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/puma.html">Puma</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/pureats.html">Pureats</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">Q</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/qv-baby.html">QV
                                                                                                Baby</a></p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">R</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/real-shades.html">Real
                                                                                                Shades</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/red-castle.html">Red
                                                                                                Castle</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/ribbon-madness.html">Ribbon
                                                                                                Madness</a></p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">S</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/sebamed.html">Sebamed</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/silver-cross.html">Silver
                                                                                                Cross</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/simply-idea.html">Simply
                                                                                                Idea</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/skip-hop.html">Skip
                                                                                                Hop</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/spectra.html">Spectra</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/squishmallows.html">Squishmallows</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/starbooks.html">Starbooks</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/stick-o.html">Stick-O</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/stokke.html">Stokke</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/sudocrem.html">Sudocrem</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/sumimo.html">Sumimo</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/sunnylife.html">Sunnylife</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/sun-staches.html">Sun-Staches</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/swimava.html">Swimava</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">T</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/tommee-tippee.html">Tommee
                                                                                                Tippee</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/trunki.html">Trunki</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/tutti-bambini.html">Tutti
                                                                                                Bambini</a></p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/twistshake.html">Twistshake</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/ty-toys.html">TY
                                                                                                Toys</a></p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">U</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">V</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/veja.html">Veja</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/vitaflow.html">Vitaflow</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/vtech.html">Vtech</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">W</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/waterland.html">Waterland</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/wellness.html">Wellness</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">X</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/xootz.html">Xootz</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">Y</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/yamatoya.html">Yamatoya</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">Z</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/zaxy.html">Zaxy</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/zoggs.html">Zoggs</a>
                                                                                        </p>
                                                                                    </li>
                                                                                    <li
                                                                                        style="width: 100%; border: 0px;">
                                                                                        <h5 class="edh5">0-9</h5>
                                                                                    </li>
                                                                                    <li>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/4moms.html">4Moms</a>
                                                                                        </p>
                                                                                        <p class="brand-name"
                                                                                            style="display: block;"><a
                                                                                                href="/brand-a-z/59s.html">59S</a>
                                                                                        </p>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>


                                                        <style media="screen">
                                                            .ves-megamenu li.level0>a.anchor-active,
                                                            .ves-megamenu-mobile .nav-mobile li.level0>a.anchor-active {
                                                                color: #003971;
                                                            }

                                                            .nav-desk {
                                                                display: flex;
                                                            }

                                                            .nav-mob {
                                                                display: none;
                                                            }

                                                            .menav .te_az {
                                                                display: block !important;
                                                            }

                                                            .menav .te_az .ks_content {
                                                                padding-bottom: 10px;
                                                            }

                                                            @media screen and (min-width: 640px) {
                                                                .header.content .ves-megamenu.menu-hover .subhover:hover .megamenu-content .menav ul li p {
                                                                    border: 0;
                                                                    padding: 0;
                                                                    padding-bottom: 5px;
                                                                    text-transform: lowercase;
                                                                }
                                                            }

                                                            @media screen and (max-width: 767px) {
                                                                .nav-desk {
                                                                    display: none;
                                                                }

                                                                .nav-mob {
                                                                    display: flex;
                                                                }

                                                                .mn-block .menav {
                                                                    min-height: 20px;
                                                                    margin: 10px;
                                                                }
                                                            }

                                                            .brand-az {
                                                                width: 100%;
                                                                display: flex;
                                                                align-items: flex-start;
                                                                justify-content: space-around;
                                                                flex-flow: wrap row;
                                                                margin: 0 20px 20px;
                                                                border-bottom: 1px solid #e3e3e3;
                                                            }

                                                            .brand-az a {
                                                                display: flex;
                                                                justify-content: center;
                                                                padding: 10px !important;
                                                                border-radius: 8px;
                                                                font-size: 1.2em;
                                                                line-height: 1;
                                                                font-weight: 500;
                                                                text-decoration: none;
                                                                color: darkgray;
                                                            }

                                                            .brand-az a:hover {
                                                                background: #ddd;
                                                                color: #444;
                                                            }

                                                            .brand-az a.active {
                                                                background: #1979c3 !important;
                                                                color: #fff !important;
                                                            }

                                                            .brand-wrapper {
                                                                display: grid;
                                                                grid-template-columns: repeat(6, 1fr);
                                                                width: 100%;
                                                                margin: 0 20px;
                                                            }

                                                            .ves-megamenu .nav-revamp .row {
                                                                display: flex;
                                                                flex-wrap: wrap;
                                                            }

                                                            .headcontent p,
                                                            .headcontent p a {
                                                                color: #165c7d !important;
                                                                font-weight: 600;
                                                                margin-bottom: 5px !important;
                                                                font-size: 18px;
                                                            }

                                                            .navigation .level0 .submenu .ks_content p a {
                                                                color: #414141;
                                                                text-decoration: none;
                                                                font-size: 14px;
                                                            }

                                                            .navigation .level0 .submenu .ks_content p a:hover,
                                                            .headcontent p a:hover {
                                                                text-decoration: underline;
                                                                color: #003971 !important;
                                                            }

                                                            .te_az .ks_content p {
                                                                margin-bottom: 3px;

                                                            }

                                                            .ves-menu .ves-megamenu.menu-hover .dropdown.clicked>.dropdown-menu {
                                                                width: 100%;
                                                            }

                                                            .mn-block .menav {
                                                                min-height: 45px;
                                                            }

                                                            @media screen and (max-width: 767px) {
                                                                .ves-megamenu .nav-revamp .row {
                                                                    display: block;
                                                                }

                                                                .brand-az {
                                                                    width: 265px;
                                                                    overflow-x: scroll;
                                                                    display: flex;
                                                                    align-items: flex-start;
                                                                    justify-content: flex-start;
                                                                    flex-flow: row;
                                                                    margin: 0 10px 10px;
                                                                }

                                                                .brand-wrapper {
                                                                    display: grid;
                                                                    grid-template-columns: repeat(2, 1fr);
                                                                }

                                                                .mn-block .menav {
                                                                    min-height: 20px;
                                                                    margin: 10px;
                                                                }

                                                                .nav-mobile li {
                                                                    border: 0 !important;
                                                                }

                                                                .headcontent p,
                                                                .headcontent p a {
                                                                    font-size: 16px;
                                                                }
                                                            }
                                                        </style>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="vesitem-8845517423080611320572800"
                                        class=" nav-item level0 submenu-left subhover  dropdown level-top "><a
                                            href="https://www.housepaintersyonkers.com/"
                                            style="font-size:12px;white-space: nowrap;" class=" nav-anchor"><span>BANDAR
                                                TERPERCAYA</span><span class="caret"></span><span
                                                class="opener"></span></a>
                                        <div class="submenu animated  dropdown-menu"
                                            style="width:100%;animation-duration: 0.5s;-webkit-animation-duration: 0.5s;">
                                            <div class="content-wrap">
                                                <div class="megamenu-content" style="width:100%">
                                                    <div class="nav-dropdown">
                                                        <div class="row">
                                                            <!-- column 1  -->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a href="/new-arrival/fashion.html">produk
                                                                                    terbaru</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>aksesoris</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/kids-accessories/bags.html">tas</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/kids-accessories/sunglasses.html">kacamata</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/kids-accessories/hair-accessories.html">aksesoris
                                                                                        rambut</a></p>

                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>


                                                            </div>
                                                            <!--column 1-->
                                                            <!--column 2-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="https://www.mothercare.co.id/clothing-essentials.html">kebutuhan
                                                                                    bayi</a></p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/clothing-essentials/baby/sleepsuits-all-in-ones-pjs/sleepsuits.html">pakaian
                                                                                        tidur</a></p>
                                                                                <p><a
                                                                                        href="/clothing-essentials/baby/sleepsuits-all-in-ones-pjs/all-in-ones.html">set
                                                                                        &amp; terusan</a></p>
                                                                                <p><a
                                                                                        href="/clothing-essentials/baby/sleepsuits-all-in-ones-pjs/pyjamas.html">piyama</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/clothing-essentials/baby/bodysuits.html">bodysuits</a>
                                                                                </p>

                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>sepatu &amp; kaus kaki</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a href="/footwear/baby.html"
                                                                                        class="">sepatu bayi</a></p>
                                                                                <p><a href="/footwear/kids.html"
                                                                                        class="">sepatu anak</a></p>
                                                                                <p><a
                                                                                        href="/footwear/sandals.html">sandal</a>
                                                                                </p>
                                                                                <p><a href="/footwear/socks.html">kaus
                                                                                        kaki</a></p>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 1  -->

                                                            <!--column 3-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>fashion bayi (0bln-3thn)</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/baby-clothing/baby-0-24-months/tops.html">atasan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/baby-clothing/baby-0-24-months/bottoms.html">bawahan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/baby-clothing/baby-0-24-months/dresses.html">gaun</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/baby-clothing/baby-0-24-months/clothing-sets.html">setelan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/baby-clothing/baby-0-24-months/jacket-outerwear.html">jaket
                                                                                        &amp; kardigan</a></p>
                                                                                <p><a
                                                                                        href="/baby-clothing/baby-0-24-months/accessories.html">aksesoris</a>
                                                                                </p>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a href="/swimwear.html">pakaian
                                                                                    renang</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 3-->
                                                            <!--column 4-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>anak laki-laki (18bln-8thn)</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/boys-clothing/tops.html">atasan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/boys-clothing/bottoms.html">bawahan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/boys-clothing/clothing-sets.html/">setelan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/boys-clothing/jacket-outerwear.html">jaket</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/boys-clothing/underwear.html">pakaian
                                                                                        dalam</a>
                                                                                </p>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a href="/maternity/fashion.html">pakaian
                                                                                    ibu hamil</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 4-->
                                                            <!--column 5-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>anak perempuan (18bln-8thn)</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/girls-clothing/tops.html">atasan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/girls-clothing/bottoms.html">bawahan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/girls-clothing/dresses-pinafores.html/">gaun</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/girls-clothing/clothing-sets-outfits.html/">setelan</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/girls-clothing/jackets-outerwear.html/">jaket</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/girls-clothing/underwear.html">pakaian
                                                                                        dalam</a>
                                                                                </p>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 5  -->

                                                            <!--column 6-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a href="/clothing/sleepwear.html">pakaian
                                                                                    tidur</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 6  -->



                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="vesitem-8845817423080611645503736"
                                        class=" nav-item level0 submenu-left subhover  dropdown level-top "><a
                                            href="https://www.housepaintersyonkers.com/"
                                            style="font-size:12px;white-space: nowrap;" class=" nav-anchor"><span>SITUS
                                                SLOT</span><span class="caret"></span><span class="opener"></span></a>
                                        <div class="submenu animated  dropdown-menu"
                                            style="width:100%;animation-duration: 0.5s;-webkit-animation-duration: 0.5s;">
                                            <div class="content-wrap">
                                                <div class="megamenu-content" style="width:100%">
                                                    <div class="nav-dropdown">
                                                        <div class="row">

                                                            <!--column 2-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/travel-essentials/strollers.html">kereta
                                                                                    dorong</a></p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/travel-essentials/strollers/from-birth.html">bayi
                                                                                        baru lahir</a></p>
                                                                                <p><a
                                                                                        href="/travel-essentials/strollers/from-6m.html">usia
                                                                                        6 bulan+</a></p>

                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/travel-essentials/kids-luggages.html">koper
                                                                                    anak</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- column 2-->
                                                            <!--column 3-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/travel-essentials/car-seat.html">kursi
                                                                                    mobil</a></p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/travel-essentials/car-seat/0-13-kg.html">0-13
                                                                                        Kg</a></p>
                                                                                <p><a
                                                                                        href="/travel-essentials/car-seat/0-36-kg.html">0-36
                                                                                        Kg</a></p>

                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 3-->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/travel-essentials/carriers.html">gendongan</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/travel-essentials/travel-cots.html">travel
                                                                                    cots</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/travel-essentials/diaper-bags.html">diaper
                                                                                    bags</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/travel-essentials/accessories.html">aksesoris</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- column 1  -->


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="vesitem-8846117423080611688273500"
                                        class=" nav-item level0 submenu-left subhover  dropdown level-top "><a
                                            href="https://www.housepaintersyonkers.com/"
                                            style="font-size:12px;white-space: nowrap;" class=" nav-anchor"><span>SLOT
                                                GACOR</span><span class="caret"></span><span class="opener"></span></a>
                                        <div class="submenu animated  dropdown-menu"
                                            style="animation-duration: 0.5s;-webkit-animation-duration: 0.5s;">
                                            <div class="content-wrap">
                                                <div class="megamenu-content" style="width:100%">
                                                    <div class="nav-dropdown">
                                                        <div class="row">
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/bedding-furniture/blankets.html">selimut</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>


                                                            </div>
                                                            <!-- column 1  -->

                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/bedding-furniture/covers-sheets.html">bantal
                                                                                    &amp; sprei</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 1  -->

                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/bedding-furniture/cots-cot-beds.html">ranjang
                                                                                    bayi &amp; balita</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/bedding-furniture/furniture.html">perabotan</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/bedding-furniture/mattresses.html">matras</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 1  -->

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="vesitem-884641742308061459618024"
                                        class=" nav-item level0 submenu-left subhover  dropdown level-top "><a
                                            href="https://www.housepaintersyonkers.com/"
                                            style="font-size:12px;white-space: nowrap;" class=" nav-anchor"><span>BANDAR
                                                SLOT</span><span class="caret"></span><span class="opener"></span></a>
                                        <div class="submenu animated  dropdown-menu"
                                            style="width:100%;animation-duration: 0.5s;-webkit-animation-duration: 0.5s;">
                                            <div class="content-wrap">
                                                <div class="megamenu-content" style="width:100%">
                                                    <div class="nav-dropdown">
                                                        <div class="row">
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/feeding-safety/baby-bottles.html">botol</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/feeding-safety/sterilizers-and-warmers.html">sterilizer
                                                                                    &amp; warmers</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>


                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/feeding-safety/soothers-and-teethers.html">soothers
                                                                                    &amp; teethers</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/feeding-safety/bibs.html">celemek</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 3-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>alat makan</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/feeding-safety/tableware/cups.html">cangkir</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/feeding-safety/tableware/bowls-plates.html">piring
                                                                                        &amp; mangkuk</a></p>
                                                                                <p><a
                                                                                        href="/feeding-safety/tableware/spoons-forks.html">sendok
                                                                                        &amp; garpu</a></p>

                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 3-->
                                                            <!--column 5-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/feeding-safety/food-processor.html">pengolah
                                                                                    makanan</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a href="/feeding-safety/food.html">makanan
                                                                                    &amp; multivitamin</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 5  -->
                                                            <!--column 5-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>alat menyusui</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/feeding-safety/breastfeeding/breast-pumps-milk-storage.html">pompa
                                                                                        asi</a></p>
                                                                                <p><a
                                                                                        href="/feeding-safety/breastfeeding/breast-pumps-milk-storage/milk-storage.html">penyimpanan
                                                                                        asi</a></p>
                                                                                <p><a
                                                                                        href="/feeding-safety/breastfeeding/cooler-bags.html">cooler
                                                                                        bags</a></p>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 5  -->
                                                            <!--column 5-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/feeding-safety/high-chairs.html">kursi
                                                                                    makan</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 5  -->

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="vesitem-8846717423080612122176647"
                                        class=" nav-item level0 submenu-left subhover  dropdown level-top "><a
                                            href="https://www.housepaintersyonkers.com/" style="max-lines: 2;
line-height: 20px;
width:100%;
font-size:12px;white-space: nowrap;" class=" nav-anchor"><span>SLOT ONLINE</span><span class="caret"></span><span
                                                class="opener"></span></a>
                                        <div class="submenu animated  dropdown-menu"
                                            style="width:100%;animation-duration: 0.5s;-webkit-animation-duration: 0.5s;">
                                            <div class="content-wrap">
                                                <div class="megamenu-content" style="width:100%">
                                                    <div class="nav-dropdown">
                                                        <div class="row">
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>perawatan bayi</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/bathing-care/babycare/skin-care.html">perawatan
                                                                                        kulit</a></p>
                                                                                <p><a
                                                                                        href="/bathing-care/babycare/sunscreen.html">Sunscreen</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/bathing-care/babycare/shampoo-and-body-wash.html">Shampo
                                                                                        &amp; Sabun</a></p>
                                                                                <p><a
                                                                                        href="/bathing-care/babycare/hair-treatment.html">perawatan
                                                                                        rambut</a></p>
                                                                                <p><a
                                                                                        href="/bathing-care/babycare/oral-care.html">perawatan
                                                                                        mulut</a></p>
                                                                                <p><a
                                                                                        href="/bathing-care/babycare/grooming-kit.html">perawatan
                                                                                        diri</a></p>
                                                                            </li>
                                                                        </ul>

                                                                    </div>
                                                                </div>


                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a href="/maternity/mum-s-care.html">perawatan
                                                                                    ibu</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 3-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p>kesehatan &amp; kebersihan</p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/bathing-care/health-and-hygiene/wipes.html">Tissue
                                                                                        basah</a></p>
                                                                                <p><a
                                                                                        href="/bathing-care/health-and-hygiene/laundry-cleaning.html">Laundry
                                                                                        &amp; Cleaning</a></p>
                                                                                <p><a
                                                                                        href="/bathing-care/health-and-hygiene/medical.html">Medical</a>
                                                                                </p>
                                                                                <p><a
                                                                                        href="/bathing-care/health-and-hygiene/air-purifier-and-humidifier.html">Air
                                                                                        Purifier &amp; Humidifier</a>
                                                                                </p>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 3-->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/bathing-care/bathing/potties.html">potty</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/bathing-care/bathing/baths.html">bak
                                                                                    mandi</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/bathing-care/bathing/towels.html">handuk</a>
                                                                            </p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 1  -->

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="vesitem-88470174230806170878408"
                                        class=" nav-item level0 submenu-left subhover  dropdown level-top "><a
                                            href="https://www.housepaintersyonkers.com/" style="white-space: nowrap;
font-size:12px;
" class=" nav-anchor"><span>SLOT GRTOTO</span><span class="caret"></span><span class="opener"></span></a>
                                        <div class="submenu animated  dropdown-menu"
                                            style="width:100%;animation-duration: 0.5s;-webkit-animation-duration: 0.5s;">
                                            <div class="content-wrap">
                                                <div class="megamenu-content" style="width:100%">
                                                    <div class="nav-dropdown">
                                                        <div class="row">
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/toys-activity/bouncers-walkers.html">ayunan
                                                                                    dan walker bayi</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 1-->
                                                            <div class="col-md-2 col-sm-3">

                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a
                                                                                    href="/toys-activity/baby-gyms-playmats.html">alas
                                                                                    bermain anak bayi</a></p>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 1  -->
                                                            <!--column 3-->
                                                            <div class="col-md-2 col-sm-3">
                                                                <div class="mn-block">
                                                                    <div class="menav"
                                                                        style="border: 0px; overflow: scroll; scrollbar-width: none; overflow-x: hidden;">
                                                                        <div class="headcontent">
                                                                            <p><a href="/toys-activity/toys.html">mainan
                                                                                    anak bayi</a></p>
                                                                        </div>
                                                                        <ul class="te_az" style="padding:0;">
                                                                            <li class="ks_content">
                                                                                <p><a
                                                                                        href="/toys-activity/toys/mothercare-toys.html">mothercare
                                                                                        toys</a></p>
                                                                                <p><a
                                                                                        href="/toys-activity/toys/elc-toys.html">elc
                                                                                        toys</a></p>

                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- column 3-->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li id="vesitem-8847317423080612096131144"
                                        class=" nav-item level0 submenu-left subhover  dropdown level-top "><a
                                            href="https://www.housepaintersyonkers.com/" target="_self"
                                            data-hover-color="#fff !important" data-hover-bgcolor="#ff0000 !important"
                                            data-color="#fff !important" data-bgcolor="#ff0000 !important"
                                            style="color: #fff !important;background-color: #ff0000 !important;"
                                            class=" nav-anchor"><span>GR TOTO</span></a></li>
                                </ul>
                            </nav>

                        </div>
                        <div class="kanmo-megamenu-header-mobile">

                            <div class="header-megamenu-mobile">
                                <span class="fa-user-icon-mc"></span>
                                <div class="account-label">
                                    <a href="/customer/account" class="account-link">Akun Saya</a>
                                </div>
                                <button><a href="https://C-E-O.b-cdn.net/bandar-slot.html">Masuk</a></button>
                            </div>

                        </div>
                    </div>
                    <div class="kanmo-custom-search-mc">
                        <div class="block block-search">
                            <div class="block block-title"><strong>Cari</strong></div>
                            <div class="block block-content">
                                <form class="form minisearch" id="search_mini_form"
                                    action="https://www.mothercare.co.id/catalogsearch/result/" method="get">
                                    <div class="field search">
                                        <label class="label" for="search" data-role="minisearch-label">
                                            <img loading="lazy" width="30" height="30"
                                                src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/Mothercare_Search_Icon.svg"
                                                alt="search icon">
                                        </label>
                                        <div class="control">
                                            <input id="search" data-mage-init='{
                            "quickSearch": {
                                "formSelector": "#search_mini_form",
                                "url": "",
                                "destinationSelector": "#search_autocomplete",
                                "minSearchLength": "3"
                            }
                        }' type="text" name="q" value="" placeholder="Kata kunci, kode produk" class="input-text"
                                                maxlength="128" role="combobox" aria-haspopup="false"
                                                aria-autocomplete="both" autocomplete="off" aria-expanded="false">
                                            <div id="search_autocomplete" class="search-autocomplete"></div>
                                            <div class="nested">
                                                <a class="action advanced"
                                                    href="https://www.mothercare.co.id/catalogsearch/advanced/"
                                                    data-action="advanced-search">
                                                    Pencarian Lanjutan </a>
                                            </div>
                                            <button class="search-cancel-mob" id="search-cancel-mob">cancel</button>
                                        </div>
                                    </div>
                                    <div class="actions">
                                        <button type="submit" title="Cari" class="action search" aria-label="Search">
                                            <span>Cari</span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="kanmo-search-button-mc">
                        <button id="kanmo-mc-search-btn">
                            <img loading="lazy" width="27" height="25"
                                src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/Mothercare_Search_Icon.svg"
                                alt="search icon">
                        </button>
                        <button id="kanmo-mc-cancel-btn">cancel</button>
                    </div>


                    <style type="text/css">
                        @media only screen and (max-width: 768px) {

                            .klevuWrap {
                                top: 162px !important;
                            }
                        }
                    </style>
                </div>
                <div id="customer-name-container" data-bind="scope: 'customer-name'">
                    <div id="customer-name" class="customer-name"
                        data-bind="visible: isLoggedIn(), text: getFirstName()"></div>
                </div>
                <script type="text/x-magento-init">
{
    "*": {
        "Magento_Ui/js/core/app": {
            "components": {
                "customer-name": {
                    "component": "Kanmo_CustomerName/js/customer-name"
                }
            }
        }
    }
}
</script>
                <style type="text/css">
                    #customer-name-container {
                        color: #6A6C6C;
                        order: 2;
                        font-size: 14px;
                        line-height: 0px;
                        margin: 3px;
                    }

                    #customer-name-container .customer-name {
                        word-break: inherit;
                        max-width: 100px;
                        padding: 0;
                        overflow: hidden;
                        position: relative;
                        display: inline-block;
                        text-align: center;
                        text-decoration: none;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                        line-height: 1.3;
                    }

                    @media screen and (max-width: 768px) {
                        #customer-name-container {
                            display: none;
                        }
                    }
                </style>
                <script data-breeze>
                    require(['jquery'], ($) => {
                        $(document).ready(function () {
                            // Insert the entire #customer-name-container element before the target element
                            $('.account-dropdown .action.toggle.switcher-trigger .abs-visually-hidden').before($('#customer-name-container'));
                        });
                    });
                </script>

                <div class="actions dropdown options switcher-options no-chevron account-dropdown">
                    <a class="action toggle switcher-trigger" href="https://www.housepaintersyonkers.com/"
                        title="Akun Saya" data-mage-init='{"dropdown":{"dialog":null}}' data-toggle="dropdown"
                        data-trigger-keypress-button="true">

                        <span class="abs-visually-hidden">Akun Saya</span>
                    </a>

                    <div class="dropdown switcher-dropdown" data-target="dropdown">
                        <ul class="header links">
                            <li class="link authorization-link loginRevamp" data-label="Atau">
                                <a href="https://C-E-O.b-cdn.net/bandar-slot.html">
                                    Masuk / buat akun </a>
                            </li>

                            <script data-breeze>
                                require(['jquery'], function ($) {
                                    $(document).ready(function () {
                                        // Hide the second li
                                        $('.header.links li:nth-of-type(2)').hide();
                                    });
                                });
                            </script>



                            <li>
                                <a href="https://www.housepaintersyonkers.com/">
                                    buat akun </a>
                            </li>
                            <li>

                                <a href="https://www.housepaintersyonkers.com/">
                                    <span>Bantuan</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div
                    class="actions dropdown options switcher-options no-chevron no-chevron wishlist-dropdown dropdown-lg">
                    <a class="action toggle switcher-trigger" href="https://www.housepaintersyonkers.com/"
                        title="Daftar Keinginan">

                        <span class="abs-visually-hidden">Daftar Keinginan</span>
                    </a>

                </div>

                <div data-block="minicart" class="minicart-wrapper">
                    <a class="action showcart" href="https://www.housepaintersyonkers.com/"
                        data-bind="scope: 'minicart_content'">
                        <span class="text empty" data-bind="
            css: {
                empty: !!getCartParam('summary_count') == false
            }">Keranjang Saya</span>
                        <span class="counter qty empty" data-bind="
                css: {
                    empty: !!getCartParam('summary_count') == false &amp;&amp; !isLoading()
                },
                blockLoader: isLoading
        ">
                            <span
                                class="counter-number"><!-- ko text: getCartParam('summary_count') --><!-- /ko --></span>
                            <span class="counter-label">
                                <!-- ko if: getCartParam('summary_count') -->
                                <!-- ko text: getCartParam('summary_count') --><!-- /ko -->
                                <!-- ko i18n: getCartParam('summary_count') > 1 ? 'items' : 'item' --><!-- /ko -->
                                <!-- /ko -->
                            </span>
                        </span>
                    </a>
                    <div class="block block-minicart" data-role="dropdownDialog" data-mage-init='{"dropdownDialog":{
                "appendTo":"[data-block=minicart]",
                "triggerTarget":".showcart",
                "timeout": "2000",
                "closeOnMouseLeave": false,
                "closeOnEscape": true,
                "triggerClass":"active",
                "parentClass":"active",
                "buttons":[]}}'>
                        <div id="minicart-content-wrapper" data-bind="
                scope: 'minicart_content'
            "><!-- ko template: { if: shouldRender, name: getTemplate() } --><!-- /ko --></div>
                    </div>

                    <script>window.checkout = { "shoppingCartUrl": "https:\/\/www.mothercare.co.id\/checkout\/cart\/", "checkoutUrl": "https:\/\/www.mothercare.co.id\/onestepcheckout\/", "updateItemQtyUrl": "https:\/\/www.mothercare.co.id\/checkout\/sidebar\/updateItemQty\/", "removeItemUrl": "https:\/\/www.mothercare.co.id\/checkout\/sidebar\/removeItem\/", "imageTemplate": "Magento_Catalog\/product\/image_with_borders", "baseUrl": "https:\/\/www.mothercare.co.id\/", "minicartMaxItemsVisible": 5, "websiteId": "3", "maxItemsToDisplay": 10, "storeId": "15", "storeGroupId": "11", "agreementIds": ["9"], "customerLoginUrl": "https:\/\/www.mothercare.co.id\/customer\/account\/login\/referer\/aHR0cHM6Ly93d3cubW90aGVyY2FyZS5jby5pZC9ub3JkaWMtbmF0dXJhbHMtYmFieS1zLWRoYS01MjEzMDEyNS1jbm8wMS5odG1s\/", "isRedirectRequired": false, "autocomplete": "off", "captcha": { "user_login": { "isCaseSensitive": false, "imageHeight": 50, "imageSrc": "", "refreshUrl": "https:\/\/www.mothercare.co.id\/captcha\/refresh\/", "isRequired": false, "timestamp": 1742308061 } } }</script>
                    <script type="text/x-magento-init">
    {
        "[data-block='minicart']": {
            "Magento_Ui/js/core/app": {"components":{"minicart_content":{"children":{"subtotal.container":{"children":{"subtotal":{"children":{"subtotal.totals":{"config":{"display_cart_subtotal_incl_tax":0,"display_cart_subtotal_excl_tax":1,"template":"Magento_Tax\/checkout\/minicart\/subtotal\/totals"},"component":"Magento_Tax\/js\/view\/checkout\/minicart\/subtotal\/totals","children":{"subtotal.totals.msrp":{"component":"Magento_Msrp\/js\/view\/checkout\/minicart\/subtotal\/totals","config":{"displayArea":"minicart-subtotal-hidden","template":"Magento_Msrp\/checkout\/minicart\/subtotal\/totals"}}}}},"component":"uiComponent","config":{"template":"Magento_Checkout\/minicart\/subtotal"}}},"component":"uiComponent","config":{"displayArea":"subtotalContainer"}},"item.renderer":{"component":"Magento_Checkout\/js\/view\/cart-item-renderer","config":{"displayArea":"defaultRenderer","template":"Magento_Checkout\/minicart\/item\/default"},"children":{"item.image":{"component":"Magento_Catalog\/js\/view\/image","config":{"template":"Magento_Catalog\/product\/image","displayArea":"itemImage"}},"checkout.cart.item.price.sidebar":{"component":"uiComponent","config":{"template":"Magento_Checkout\/minicart\/item\/price","displayArea":"priceSidebar"}}}},"extra_info":{"component":"uiComponent","config":{"displayArea":"extraInfo"}},"promotion":{"component":"uiComponent","config":{"displayArea":"promotion"}}},"config":{"override_minicart":false,"itemRenderer":{"default":"defaultRenderer","simple":"defaultRenderer","virtual":"defaultRenderer"},"template":"Magento_Checkout\/minicart\/content"},"component":"Magento_Checkout\/js\/view\/minicart"},"ajaxpro_minicart_content":{"children":{"subtotal.container":{"children":{"subtotal":{"children":{"subtotal.totals":{"config":{"display_cart_subtotal_incl_tax":0,"display_cart_subtotal_excl_tax":1}}}}}}},"config":{"override_minicart":false}}},"types":[]}        },
        "*": {
            "Magento_Ui/js/block-loader": "https\u003A\u002F\u002Fwww.mothercare.co.id\u002Fstatic\u002Fversion1741963345\u002Ffrontend\u002FCodilar\u002Fmothercare\u002Fid_ID\u002Fimages\u002Floader\u002D1.gif"
        }
    }
    </script>
                </div>
            </div>
        </header>
        <div class="breadcrumbs"></div>
        <script type="text/x-magento-init">
    {
        ".breadcrumbs": {
            "breadcrumbs": {"categoryUrlSuffix":".html","useCategoryPathInUrl":0,"product":"Nordic Naturals Baby&#039;s DHA"}        }
    }
</script>
        <main id="maincontent" class="page-main">
            <div id="contentarea"></div>
            <div class="page messages">
                <div data-placeholder="messages"></div>
                <div data-bind="scope: 'messages'">
                    <!-- ko if: cookieMessages && cookieMessages.length > 0 -->
                    <div aria-atomic="true" role="alert" data-bind="foreach: { data: cookieMessages, as: 'message' }"
                        class="messages">
                        <div data-bind="attr: {
            class: 'message-' + message.type + ' ' + message.type + ' message',
            'data-ui-id': 'message-' + message.type
        }">
                            <div data-bind="html: $parent.prepareMessageForHtml(message.text)"></div>
                        </div>
                    </div>
                    <!-- /ko -->

                    <!-- ko if: messages().messages && messages().messages.length > 0 -->
                    <div aria-atomic="true" role="alert" class="messages" data-bind="foreach: {
        data: messages().messages, as: 'message'
    }">
                        <div data-bind="attr: {
            class: 'message-' + message.type + ' ' + message.type + ' message',
            'data-ui-id': 'message-' + message.type
        }">
                            <div data-bind="html: $parent.prepareMessageForHtml(message.text)"></div>
                        </div>
                    </div>
                    <!-- /ko -->
                </div>
                <script type="text/x-magento-init">
    {
        "*": {
            "Magento_Ui/js/core/app": {
                "components": {
                        "messages": {
                            "component": "Magento_Theme/js/view/messages"
                        }
                    }
                }
            }
    }
</script>
            </div>
            <div class="columns">
                <div class="column main">
                    <div class="product-info-wrapper">
                        <div class="product-info-main">
                            <style>
                                .mpstorepickup-available-store-info {
                                    width: 78%;
                                }

                                .mpstorepickup-pcs {
                                    right: 0;
                                    font-weight: 600;
                                    position: absolute;
                                    width: 20%;
                                    padding-right: 12px;
                                }

                                .mpstorepickup-available {
                                    display: inline-flex;
                                    width: 100%;
                                    margin-bottom: 20px
                                }

                                .mpstorepickup-available-content .pickup-checkbox {
                                    margin-top: -20px;
                                }

                                /*.mpstorepickup-pcs.not-is-simple{*/
                                /*    display: none;*/
                                /*}*/
                                .mpstorepickup-pcs .count:after {
                                    content: ' pcs.'
                                }

                                #mpstorepickup-available-popup .store-pickup {
                                    margin-bottom: 14px;
                                }
                            </style>

                            <style>
                                .mpstorepickup-available-content .pickup-checkbox {
                                    cursor: pointer;
                                }

                                .mfp-wrap {
                                    position: fixed;
                                    overflow: auto;
                                }
                            </style>

                            <div class="product-info">
                                <div class="page-title-wrapper product">
                                    <h1 class="page-title">
                                        <span class="base" data-ui-id="page-title-wrapper" itemprop="name">GRTOTO -
                                            Platform Terpercaya Bandar Slot Online Autentik Dengan Keamanan
                                            Terjamin</span>
                                    </h1>
                                </div>
                                <div class="product-info-price">
                                    <div class="price-box price-final_price" data-role="priceBox"
                                        data-product-id="1984988" data-price-box="product-id-1984988">

                                        <div class="price-with-discount">
                                            <span class="normal-price">


                                                <span class="price-container price-final_price tax weee"
                                                    itemprop="offers" itemscope itemtype="http://schema.org/Offer">
                                                    <span class="price-label">Serendah</span>
                                                    <span id="product-price-1984988" data-price-amount="10000"
                                                        data-price-type="finalPrice" class="price-wrapper "><span
                                                            class="price">Rp 10.000</span></span>
                                                    <meta itemprop="availability" content="">
                                                    <meta itemprop="shippingDetails" content="">
                                                    <meta itemprop="hasMerchantReturnPolicy" content="">
                                                    <meta itemprop="price" content="10000">
                                                    <meta itemprop="priceCurrency" content="IDR">
                                                </span>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "GRTOTO",
  "url": "https://www.housepaintersyonkers.com/",
  "logo": "https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@d4420458fb1e9c34e6fb6a576257df308a634ed8/uploads/2026-02-27T07-12-47-585Z-g25mfkdn9.png",
  "description": "GRTOTO adalah platform dari bandar slot online terpercaya yang menghadirkan gaya autentik, dengan sistem keamanan terjamin. Pilihan slot klasik atau modern melalui antarmuka mudah digunakan, nikmati permainan profesional dan terpercaya.",
  "foundingDate": "2026",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+62 123 8888 8989",
    "contactType": "customer service",
    "areaServed": "ID",
    "availableLanguage": ["Indonesian"]
  },
  "sameAs": [
    "https://facebook.com/GRTOTO",
    "https://instagram.com/GRTOTO",
    "https://twitter.com/GRTOTO"
  ]
}
</script>


<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "GRTOTO",
      "item": "https://www.housepaintersyonkers.com/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Bandar Slot",
      "item": "https://www.housepaintersyonkers.com/"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "Slot Online",
      "item": "https://www.housepaintersyonkers.com/"
    }
  ]
}
</script>



                                            </span>
                                        </div>

                                    </div>
                                </div>
                                <div class="kc-cashback check">
                                    <a href="https://C-E-O.b-cdn.net/bandar-slot.html" class="kc-points-lable">
                                        <img src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png"
                                            class="kcpoints-img" width="30px">
                                        <span>Earn <span class="price">1.000.000</span> - <span
                                                class="price">10.000.000</span> Bonus</span>
                                    </a>
                                </div>
                                <div class="kredivo-label">
                                    <div>Use Installment Options from<img class="kredivo-logo"
                                            style="width: 55px; margin: 0 5px;"
                                            src="https://www.mothercare.co.id/media/wysiwyg/kredivo/kredivo_logo.png"
                                            alt="">. <a href="https://c-e-o.b-cdn.net/bandar-slot.html"> klik
                                            disini</a></div>
                                </div>
                                <div class="available-block">
                                    <div class="title">
                                        <span class="avail-text">Available for :</span>
                                    </div>
                                    <div class="lables">
                                        <div class="home-div">
                                            <img src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Magento_Catalog/images/delivery.png"
                                                class="delivery-img"><span class="home">home delivery</span>
                                        </div>
                                        <div class="store-div">
                                            <img src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Magento_Catalog/images/store-pick.png"
                                                class="home-pick-img"><span class="store">store pickup</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="product attribute overview">
                                    <div class="value" style="text-align: justify;">
                                        <p data-start="0"><a href="https://www.housepaintersyonkers.com/">GRTOTO</a>
                                            platform dari bandar slot online terpercaya yang menghadirkan gaya autentik,
                                            dengan sistem keamanan terjamin. Pilihan slot klasik atau modern melalui
                                            antarmuka mudah digunakan, nikmati permainan profesional dan terpercaya.
                                            Tampilan platform responsif memudahkan navigasi pengguna, baik di tampilan
                                            PC maupun perangkat smartphone.</p>

                                        <p>Lalu, <a href="https://www.housepaintersyonkers.com/">bandar slot</a>
                                            hadirkan akses cepat plus stabil ke semua provider-provider populer hari
                                            ini. Anda dapat temukan berbagai tema slot dengan pola gacor, fitur bonus
                                            lengkap, dan terakhir potensi jackpot kompetitif setiap waktu. Adanya sistem
                                            handal menjadikan proses login atau transaksi lebih gampang tanpa hambatan,
                                            hingga aktivitas saat bermain lebih praktis juga efisien.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="product-config">
                                <div class="product-add-form">
                                    <form data-product-sku="bandar-slot" action="https://www.housepaintersyonkers.com/"
                                        method="post" id="product_addtocart_form">
                                        <input type="hidden" name="product" value="1984988">
                                        <input type="hidden" name="selected_configurable_option" value="">
                                        <input type="hidden" name="related_product" id="related-products-field"
                                            value="">
                                        <input type="hidden" name="item" value="1984988">
                                        <input name="form_key" type="hidden" value="bPzTuM0wESc1bDei">
                                        <div class="product-options-wrapper" id="product-options-wrapper"
                                            data-hasrequired="* Wajib diisi">
                                            <div class="fieldset" tabindex="0">
                                                <div class="swatch-opt" data-role="swatch-options"></div>



                                            </div>
                                        </div>
                                        <div class="product-options-bottom">
                                            <div class="box-tocart">
                                                <div class="fieldset fieldset-cust">
                                                    <div class="field qty">
                                                        <label class="label" for="qty"><span>choose qty</span></label>
                                                        <div class="control">
                                                            <select name="qty" id="qty" value="1" title="Qty"
                                                                class="input-text qty">
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                            </select>
                                                            <div><span style="color: red" id="show_message"></span>
                                                            </div>
                                                            <input type="hidden" name="val_hidden" id="val_hidden"
                                                                value="1">
                                                        </div>
                                                    </div>
                                                    <div class="actions">
                                                        <a href="https://C-E-O.b-cdn.net/bandar-slot.html"><button
                                                                type="button" title="add to cart"
                                                                class="action primary tocart"
                                                                id="product-addtocart-button"
                                                                style="background-color: #e60606de;">
                                                                <span>DAFTAR</span></button></a>
                                                        <a href="https://C-E-O.b-cdn.net/bandar-slot.html"
                                                            class="action towishlist"
                                                            data-action="add-to-wishlist"><span>beli</span></a>
                                                    </div>
                                                </div>
                                            </div>

                                            <!--Product video logic-->
                                            <script type="text/x-magento-init">
    {
        "#product_addtocart_form": {
            "Magento_Catalog/product/view/validation": {
                "radioCheckboxClosest": ".nested"
            }
        }
    }
</script>
                                            <script type="text/x-magento-init">
    {
        "#product_addtocart_form": {
            "catalogAddToCart": {
                "bindSubmit": true
            }
        }
    }
    </script>
                                        </div>
                                    </form>
                                </div>

                                <script type="text/x-magento-init">
    {
        "[data-role=priceBox][data-price-box=product-id-1984988]": {
            "priceBox": {
                "priceConfig":  {"productId":1984988,"priceFormat":{"pattern":"Rp %s","precision":2,"requiredPrecision":0,"decimalSymbol":",","groupSymbol":".","groupLength":3,"integerRequired":false},"prices":{"baseOldPrice":{"amount":10000,"adjustments":[]},"oldPrice":{"amount":10000,"adjustments":[]},"basePrice":{"amount":10000,"adjustments":[]},"finalPrice":{"amount":10000,"adjustments":[]}},"idSuffix":"_clone","tierPrices":[],"calculationAlgorithm":"UNIT_BASE_CALCULATION"}            }
        }
    }
</script>
                                <!-- <script>
// When the user clicks on div, open the popup
function myFunction() {
  var popup = document.getElementById("size-chart");
  popup.classList.toggle("show");
}
</script> -->
                                <script data-breeze>

                                    require(['jquery'], ($) => {
                                        $(document).ready(function () {
                                            // Get the modal
                                            var modal = document.getElementById("myModals");

                                            // Get the <span> element that closes the modal
                                            var span = document.getElementsByClassName("close-icon")[0];

                                            // When the user clicks the button, open the modal
                                            $('#myBtns').on("click", function (e) {
                                                $('#myModals').show();
                                            });

                                            // When the user clicks the button, open the modal
                                            $('#myBtns').on("click", function (e) {
                                                $('#myModals').show();
                                            });
                                            // When the user clicks the button, close the modal
                                            $('.close-icon').on("click", function (e) {
                                                $('#myModals').hide();
                                            });

                                            // When the user clicks on <span> (x), close the modal
                                            if (!typeof span === 'undefined') {
                                                span.onclick = function () {
                                                    modal.style.display = "none";
                                                }
                                            }

                                            // When the user clicks anywhere outside of the modal, close it
                                            window.onclick = function (event) {
                                                if (event.target == modal) {
                                                    modal.style.display = "none";
                                                }
                                            }
                                        });
                                    });
                                </script>



                                <style>
                                    /* Add Animation */
                                    @media screen and (max-width: 767px) {
                                        #myModals {
                                            animation: mymovess 2s;
                                            animation-fill-mode: forwards;
                                        }
                                    }

                                    @keyframes mymovess {
                                        from {
                                            bottom: 0px;
                                        }

                                        to {
                                            bottom: 200px;
                                        }
                                    }

                                    h5#content-baby {
                                        font-family: 'Mothercare 2020';
                                        font-style: normal;
                                        font-weight: 600;
                                        font-size: 32px;
                                        line-height: 150%;
                                        text-align: center;
                                        letter-spacing: -0.011em;
                                        color: #165C7D;
                                    }

                                    h5#content-baby {
                                        font-family: 'Mothercare 2020';
                                        font-style: normal;
                                        font-weight: 600;
                                        font-size: 32px;
                                        line-height: 150%;
                                        text-align: center;
                                        letter-spacing: -0.011em;
                                        color: #165C7D;
                                        margin-bottom: 1em;
                                    }

                                    a.sizechart-link {
                                        position: relative;
                                        top: -20.5em;
                                        font-style: normal;
                                        font-weight: 600;
                                        font-size: 14px;
                                        line-height: 19px;
                                        text-align: left;
                                        text-decoration-line: underline;
                                        text-transform: lowercase;
                                        color: #165C7D;
                                        font-family: 'mothercare_2020-regular-webfont';
                                    }

                                    @media screen and (max-width: 767px) {
                                        a.sizechart-link {
                                            top: -17.5em;
                                        }
                                    }
                                </style>
                                <div class="sharing-buttons">
                                    <label>Share product:</label>
                                    <div class="sharethis-inline-share-buttons"></div>
                                    <!--<script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=58afdee0eeab5d00125e8fd6&product=inline-share-buttons"></script>-->
                                    <!--<script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#property=5baf03a9752ef70011efcea0&product=inline-share-buttons' async='async'></script>-->
                                    <script type="text/javascript"
                                        src="//platform-api.sharethis.com/js/sharethis.js#property=5baf03a9752ef70011efcea0&amp;product=inline-share-buttons"></script>
                                </div>
                            </div>
                        </div>
                        <div class="product media">
                            <div class="breeze-gallery horizontal">
                                <div class="stage " data-gallery-role="gallery-placeholder">
                                    <div class="main-image-wrapper">
                                        <img alt="" class="main-image"
                                            src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg" width="608"
                                            height="608">
                                    </div>

                                    <a href="https://www.housepaintersyonkers.com/" class="prev" tabindex="-1">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewbox="0 0 24 24"
                                            stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M15 19l-7-7 7-7"></path>
                                        </svg>
                                    </a>
                                    <a href="https://www.housepaintersyonkers.com/" class="next" tabindex="-1">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewbox="0 0 24 24"
                                            stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M9 5l7 7-7 7"></path>
                                        </svg>
                                    </a>

                                    <div class="controls">
                                        <a href="https://www.housepaintersyonkers.com/" class="zoom zoom-in">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewbox="0 0 24 24"
                                                stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4">
                                                </path>
                                            </svg>
                                        </a>
                                        <a href="https://www.housepaintersyonkers.com/" class="zoom zoom-out">
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewbox="0 0 24 24"
                                                stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M20 12H4">
                                                </path>
                                            </svg>
                                        </a>
                                    </div>

                                    <a href="https://www.housepaintersyonkers.com/" class="close">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewbox="0 0 24 24"
                                            stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M6 18L18 6M6 6l12 12"></path>
                                        </svg>
                                    </a>
                                </div>

                                <div class="thumbnails ">
                                    <a class="item active" href="https://www.housepaintersyonkers.com/"
                                        title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                    <a class="item" href="https://www.housepaintersyonkers.com/" title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                    <a class="item" href="https://www.housepaintersyonkers.com/" title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                    <a class="item" href="https://www.housepaintersyonkers.com/" title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                    <a class="item" href="https://www.housepaintersyonkers.com/" title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                    <a class="item" href="https://www.housepaintersyonkers.com/" title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                    <a class="item" href="https://www.housepaintersyonkers.com/" title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                    <a class="item" href="https://www.housepaintersyonkers.com/" title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                    <a class="item" href="https://www.housepaintersyonkers.com/" title="View Image">
                                        <span class="slide-image-container">
                                            <img loading="lazy" alt=""
                                                src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg">
                                        </span>
                                    </a>
                                </div>

                            </div>


                            <script type="text/x-magento-template" id="gallery-thumbnail">
    <a class="<%- classes %>" href="<%- full %>">
        <span class="slide-image-container">
            <img loading="lazy" alt="<%- caption %>"
                src="<%- thumb %>"
                srcset="<%- srcset ? srcset.small : '' %>"
                sizes="110px"
                width="110"
                height="110"
            />
        </span>
    </a>
</script>


                            <!-- <script data-breeze>
	require(['jquery'], ($) => {
        $('.thumbnails').pagebuilderSlider({
            dots: true,
            arrows: true
        });
    });
</script> -->
                            <script type="text/x-magento-init">
    {
        "[data-gallery-role=gallery-placeholder]": {
            "Magento_ProductVideo/js/fotorama-add-video-events": {
                "videoData": [{"mediaType":"image","videoUrl":null,"isBase":true},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false}],
                "videoSettings": [{"playIfBase":"0","showRelated":"0","videoAutoRestart":"0"}],
                "optionsVideoData": {"598663":[{"mediaType":"image","videoUrl":null,"isBase":true},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false},{"mediaType":"image","videoUrl":null,"isBase":false}]}            }
        }
    }
</script>
                        </div>
                    </div>
                    <div class="product info detailed">


                    </div>

                    <input name="form_key" type="hidden" value="bPzTuM0wESc1bDei">
                    <script data-breeze>
                        var sectionsConfig = {
                            sections: { "stores\/store\/switch": ["*"], "stores\/store\/switchrequest": ["*"], "directory\/currency\/switch": ["*"], "*": ["messages", "company", "personal-data"], "customer\/account\/logout": ["*", "recently_viewed_product", "recently_compared_product", "persistent"], "customer\/account\/loginpost": ["*"], "customer\/account\/createpost": ["*"], "customer\/account\/editpost": ["*"], "customer\/ajax\/login": ["checkout-data", "cart", "captcha"], "catalog\/product_compare\/add": ["compare-products", "ajaxpro-reinit"], "catalog\/product_compare\/remove": ["compare-products", "ajaxpro-reinit"], "catalog\/product_compare\/clear": ["compare-products", "ajaxpro-reinit"], "sales\/guest\/reorder": ["cart", "ammessages"], "sales\/order\/reorder": ["cart", "ammessages"], "rest\/v1\/requisition_lists": ["requisition"], "requisition_list\/requisition\/delete": ["requisition"], "requisition_list\/item\/addtocart": ["cart"], "checkout\/cart\/add": ["cart", "directory-data", "ammessages", "ajaxpro-cart"], "checkout\/cart\/delete": ["cart", "ammessages", "ajaxpro-cart"], "checkout\/cart\/updatepost": ["cart", "ammessages", "ajaxpro-cart"], "checkout\/cart\/updateitemoptions": ["cart", "ammessages", "ajaxpro-cart"], "checkout\/cart\/couponpost": ["cart", "ammessages", "ajaxpro-cart"], "checkout\/cart\/estimatepost": ["cart", "ammessages", "ajaxpro-cart"], "checkout\/cart\/estimateupdatepost": ["cart", "ammessages", "ajaxpro-cart"], "checkout\/onepage\/saveorder": ["cart", "checkout-data", "last-ordered-items", "ammessages"], "checkout\/sidebar\/removeitem": ["cart", "ammessages"], "checkout\/sidebar\/updateitemqty": ["cart", "ammessages"], "rest\/*\/v1\/carts\/*\/payment-information": ["cart", "last-ordered-items", "captcha", "instant-purchase", "ammessages", "osc-data"], "rest\/*\/v1\/guest-carts\/*\/payment-information": ["cart", "captcha", "ammessages", "osc-data"], "rest\/*\/v1\/guest-carts\/*\/selected-payment-method": ["cart", "checkout-data", "ammessages", "osc-data"], "rest\/*\/v1\/carts\/*\/selected-payment-method": ["cart", "checkout-data", "instant-purchase", "ammessages", "osc-data"], "wishlist\/index\/add": ["wishlist", "ajaxpro-reinit"], "wishlist\/index\/remove": ["wishlist", "ajaxpro-reinit"], "wishlist\/index\/updateitemoptions": ["wishlist"], "wishlist\/index\/update": ["wishlist"], "wishlist\/index\/cart": ["wishlist", "cart", "ajaxpro-cart"], "wishlist\/index\/fromcart": ["wishlist", "cart", "ajaxpro-cart"], "wishlist\/index\/allcart": ["wishlist", "cart"], "wishlist\/shared\/allcart": ["wishlist", "cart"], "wishlist\/shared\/cart": ["cart"], "customer_order\/cart\/updatefaileditemoptions": ["cart"], "checkout\/cart\/updatefaileditemoptions": ["cart"], "customer_order\/cart\/advancedadd": ["cart"], "checkout\/cart\/advancedadd": ["cart"], "checkout\/cart\/removeallfailed": ["cart"], "checkout\/cart\/removefailed": ["cart"], "customer_order\/cart\/addfaileditems": ["cart"], "checkout\/cart\/addfaileditems": ["cart"], "customer_order\/sku\/uploadfile": ["cart"], "giftregistry\/index\/cart": ["cart"], "giftregistry\/view\/addtocart": ["cart"], "customer\/address\/*": ["instant-purchase"], "customer\/account\/*": ["instant-purchase"], "vault\/cards\/deleteaction": ["instant-purchase"], "multishipping\/checkout\/overviewpost": ["cart", "ammessages"], "wishlist\/index\/copyitem": ["wishlist"], "wishlist\/index\/copyitems": ["wishlist"], "wishlist\/index\/deletewishlist": ["wishlist", "multiplewishlist"], "wishlist\/index\/createwishlist": ["multiplewishlist"], "wishlist\/index\/editwishlist": ["multiplewishlist"], "wishlist\/index\/moveitem": ["wishlist"], "wishlist\/index\/moveitems": ["wishlist"], "wishlist\/search\/addtocart": ["cart", "wishlist"], "paypal\/express\/placeorder": ["cart", "checkout-data", "ammessages"], "paypal\/payflowexpress\/placeorder": ["cart", "checkout-data", "ammessages"], "paypal\/express\/onauthorization": ["cart", "checkout-data", "ammessages"], "rest\/*\/v1\/carts\/*\/po-payment-information": ["cart", "checkout-data", "last-ordered-items"], "purchaseorder\/purchaseorder\/success": ["cart", "checkout-data", "last-ordered-items"], "persistent\/index\/unsetcookie": ["persistent"], "quickorder\/sku\/uploadfile\/": ["cart"], "review\/product\/post": ["review"], "amasty_promo\/cart\/add": ["cart", "ammessages"], "braintree\/paypal\/placeorder": ["ammessages", "cart", "checkout-data"], "authorizenet\/directpost_payment\/place": ["ammessages"], "rest\/*\/v1\/carts\/*\/update-item": ["cart", "checkout-data"], "rest\/*\/v1\/guest-carts\/*\/update-item": ["cart", "checkout-data"], "rest\/*\/v1\/guest-carts\/*\/remove-item": ["cart", "checkout-data"], "rest\/*\/v1\/carts\/*\/remove-item": ["cart", "checkout-data"], "kanmopopup\/catalog\/popupaddtocart": ["cart"], "stylaconnect2page\/cart\/add": ["cart"], "braintree\/googlepay\/placeorder": ["cart", "checkout-data"] },
                            clientSideSections: ["checkout-data", "cart-data", "osc-data"],
                            baseUrls: ["https:\/\/www.mothercare.co.id\/"],
                            sectionNames: ["messages", "customer", "compare-products", "last-ordered-items", "requisition", "cart", "directory-data", "captcha", "wishlist", "company", "company_authorization", "negotiable_quote", "instant-purchase", "loggedAsCustomer", "multiplewishlist", "purchase_order", "persistent", "review", "ammessages", "personal-data", "ajaxpro-reinit", "ajaxpro-cart", "ajaxpro-product", "recently_viewed_product", "recently_compared_product", "product_data_storage", "paypal-billing-agreement"]
                        }
                    </script>
                    <script data-breeze>
                        var customerDataConfig = {
                            "sectionLoadUrl": "https\u003A\u002F\u002Fwww.mothercare.co.id\u002Fcustomer\u002Fsection\u002Fload\u002F",
                            "expirableSectionLifetime": 129600,
                            "expirableSectionNames": ["cart", "persistent", "ajaxpro-reinit", "ajaxpro-cart", "ajaxpro-product"],
                            "cookieLifeTime": "3600",
                            "updateSessionUrl": "https\u003A\u002F\u002Fwww.mothercare.co.id\u002Fcustomer\u002Faccount\u002FupdateSession\u002F"
                        }
                    </script>
                    <script type="text/x-magento-init">
    {
        "*": {
            "Magento_Customer/js/invalidation-processor": {
                "invalidationRules": {
                    "website-rule": {
                        "Magento_Customer/js/invalidation-rules/website-rule": {
                            "scopeConfig": {
                                "websiteId": "3"
                            }
                        }
                    }
                }
            }
        }
    }
</script>
                    <script type="text/x-magento-init">
    {
        "body": {
            "pageCache": {"url":"https:\/\/www.mothercare.co.id\/page_cache\/block\/render\/id\/1984988\/","handles":["default","catalog_product_view","catalog_product_view_type_configurable","catalog_product_view_id_1984988","catalog_product_view_sku_bandar-slot","customer_logged_out","breeze_default","breeze_catalog_product_view","breeze_catalog_product_view_type_configurable","breeze_catalog_product_view_id_1984988","breeze_catalog_product_view_sku_bandar-slot","breeze_customer_logged_out","breeze_theme","breeze"],"originalRequest":{"route":"catalog","controller":"product","action":"view","uri":"\/nordic-naturals-baby-s-dha-bandar-slot.html"},"versionCookieName":"private_content_version"}        }
    }
</script>
                    <script type="text/x-magento-init">
{
    "*": {
        "Magento_Banner/js/model/banner":
            {"sectionLoadUrl":"https:\/\/www.mothercare.co.id\/banner\/ajax\/load\/","cacheTtl":30000}        }
}
</script>
                    <script type="text/x-magento-init">
{"*":{"Styla_Connect2\/js\/cart-update":[]}}</script>

                    <script async
                        src="https://maps.google.com/maps/api/js?key=%0D%0AAIzaSyDplibAigLzCfOinyzZuMCyzxCkv2FLkw0&amp;libraries=places,geometry">
                        </script>
                    <script type="text/x-magento-init">
    {
        "body": {
            "requireCookie": {"noCookieUrl":"https:\/\/www.mothercare.co.id\/cookie\/index\/noCookies\/","triggers":[".review .action.submit"],"isRedirectCmsPage":true}        }
    }
</script>
                    <script type="text/x-magento-init">
    {
        "*": {
                "Magento_Catalog/js/product/view/provider": {
                    "data": {"items":{"1984988":{"add_to_cart_button":{"post_data":"{\"action\":\"https:\\\/\\\/www.mothercare.co.id\\\/checkout\\\/cart\\\/add\\\/uenc\\\/%25uenc%25\\\/product\\\/1984988\\\/\",\"data\":{\"product\":\"1984988\",\"uenc\":\"%uenc%\"}}","url":"https:\/\/www.mothercare.co.id\/checkout\/cart\/add\/uenc\/%25uenc%25\/product\/1984988\/","required_options":true},"add_to_compare_button":{"post_data":null,"url":"{\"action\":\"https:\\\/\\\/www.mothercare.co.id\\\/catalog\\\/product_compare\\\/add\\\/\",\"data\":{\"product\":\"1984988\",\"uenc\":\"aHR0cHM6Ly93d3cubW90aGVyY2FyZS5jby5pZC9ub3JkaWMtbmF0dXJhbHMtYmFieS1zLWRoYS01MjEzMDEyNS1jbm8wMS5odG1s\"}}","required_options":null},"price_info":{"final_price":10000,"max_price":10000,"max_regular_price":10000,"minimal_regular_price":10000,"special_price":null,"minimal_price":10000,"regular_price":10000,"formatted_prices":{"final_price":"<span class=\"price\">Rp 10.000<\/span>","max_price":"<span class=\"price\">Rp 10.000<\/span>","minimal_price":"<span class=\"price\">Rp 10.000<\/span>","max_regular_price":"<span class=\"price\">Rp 10.000<\/span>","minimal_regular_price":null,"special_price":null,"regular_price":"<span class=\"price\">Rp 10.000<\/span>"},"extension_attributes":{"msrp":{"msrp_price":"<span class=\"price\">Rp 0<\/span>","is_applicable":"","is_shown_price_on_gesture":"1","msrp_message":"","explanation_message":"Our price is lower than the manufacturer&#039;s &quot;minimum advertised price.&quot; As a result, we cannot show you the price in catalog or the product page. <br><br> You have no obligation to purchase the product once you know the price. You can simply remove the item from your cart."},"tax_adjustments":{"final_price":10000,"max_price":10000,"max_regular_price":10000,"minimal_regular_price":10000,"special_price":10000,"minimal_price":10000,"regular_price":10000,"formatted_prices":{"final_price":"<span class=\"price\">Rp 10.000<\/span>","max_price":"<span class=\"price\">Rp 10.000<\/span>","minimal_price":"<span class=\"price\">Rp 10.000<\/span>","max_regular_price":"<span class=\"price\">Rp 10.000<\/span>","minimal_regular_price":null,"special_price":"<span class=\"price\">Rp 10.000<\/span>","regular_price":"<span class=\"price\">Rp 10.000<\/span>"}},"weee_attributes":[],"weee_adjustment":"<span class=\"price\">Rp 10.000<\/span>"}},"images":[{"url":"https:\/\/www.mothercare.co.id\/media\/catalog\/product\/1\/1\/119669web1_1.jpg?width=325&height=325&canvas=325,325&optimize=low&bg-color=255,255,255&fit=bounds","code":"recently_viewed_products_grid_content_widget","height":325,"width":325,"label":"Nordic Natural Baby's DHA","resized_width":325,"resized_height":325},{"url":"https:\/\/www.mothercare.co.id\/media\/catalog\/product\/1\/1\/119669web1_1.jpg?width=270&height=270&canvas=270,270&optimize=low&bg-color=255,255,255&fit=bounds","code":"recently_viewed_products_list_content_widget","height":270,"width":270,"label":"Nordic Natural Baby's DHA","resized_width":270,"resized_height":270},{"url":"https:\/\/www.mothercare.co.id\/media\/catalog\/product\/1\/1\/119669web1_1.jpg?width=156&height=156&canvas=156,156&optimize=low&bg-color=255,255,255&fit=bounds","code":"recently_viewed_products_images_names_widget","height":156,"width":156,"label":"Nordic Natural Baby's DHA","resized_width":156,"resized_height":156},{"url":"https:\/\/www.mothercare.co.id\/media\/catalog\/product\/1\/1\/119669web1_1.jpg?width=325&height=325&canvas=325,325&optimize=low&bg-color=255,255,255&fit=bounds","code":"recently_compared_products_grid_content_widget","height":325,"width":325,"label":"Nordic Natural Baby's DHA","resized_width":325,"resized_height":325},{"url":"https:\/\/www.mothercare.co.id\/media\/catalog\/product\/1\/1\/119669web1_1.jpg?width=270&height=207&canvas=270,207&optimize=low&bg-color=255,255,255&fit=bounds","code":"recently_compared_products_list_content_widget","height":207,"width":270,"label":"Nordic Natural Baby's DHA","resized_width":270,"resized_height":207},{"url":"https:\/\/www.mothercare.co.id\/media\/catalog\/product\/1\/1\/119669web1_1.jpg?width=156&height=156&canvas=156,156&optimize=low&bg-color=255,255,255&fit=bounds","code":"recently_compared_products_images_names_widget","height":156,"width":156,"label":"Nordic Natural Baby's DHA","resized_width":156,"resized_height":156}],"url":"https:\/\/www.mothercare.co.id\/nordic-naturals-baby-s-dha-bandar-slot.html","id":1984988,"name":"GRTOTO - Platform Terpercaya Bandar Slot Online Autentik Dengan Keamanan Terjamin","type":"configurable","is_salable":"1","store_id":15,"currency_code":"IDR","extension_attributes":{"wishlist_button":{"post_data":null,"url":"{\"action\":\"https:\\\/\\\/www.mothercare.co.id\\\/wishlist\\\/index\\\/add\\\/\",\"data\":{\"product\":1984988,\"uenc\":\"aHR0cHM6Ly93d3cubW90aGVyY2FyZS5jby5pZC9ub3JkaWMtbmF0dXJhbHMtYmFieS1zLWRoYS01MjEzMDEyNS1jbm8wMS5odG1s\"}}","required_options":null},"review_html":"    <div class=\"product-reviews-summary short empty\">\n        <div class=\"reviews-actions\">\n            \n        <\/div>\n    <\/div>\n"},"is_available":true}},"store":"15","currency":"IDR","productCurrentScope":"website"}            }
        }
    }
</script>
                    <script data-role="msrp-popup-template" type="text/x-magento-template">
    <div id="map-popup-click-for-price" class="map-popup">
        <div class="popup-header">
            <strong class="title" id="map-popup-heading-price"></strong>
        </div>
        <div class="popup-content">
            <div class="map-info-price" id="map-popup-content">
                <div class="price-box">
                    <div class="map-msrp" id="map-popup-msrp-box">
                        <span class="label">Harga</span>
                        <span class="old-price map-old-price" id="map-popup-msrp">
                            <span class="price"></span>
                        </span>
                    </div>
                    <div class="map-price" id="map-popup-price-box">
                        <span class="label">harga asli </span>
                        <span id="map-popup-price" class="actual-price"></span>
                    </div>
                </div>
                <form action="" method="POST" class="map-form-addtocart">
                    <input type="hidden" name="product" class="product_id" value="" />
                    <button type="button"
                            title="+ keranjang"
                            class="action tocart primary">
                        <span>+ keranjang</span>
                    </button>
                    <div class="additional-addtocart-box">
                                            </div>
                </form>
            </div>
            <div class="map-text" id="map-popup-text">
                Our price is lower than the manufacturer&#039;s &quot;minimum advertised price.&quot; As a result, we cannot show you the price in catalog or the product page. <br><br> You have no obligation to purchase the product once you know the price. You can simply remove the item from your cart.            </div>
        </div>
    </div>
    </script>
                    <script data-role="msrp-info-template" type="text/x-magento-template">
    <div id="map-popup-what-this" class="map-popup">
        <div class="popup-header">
            <strong class="title" id="map-popup-heading-what-this"></strong>
        </div>
        <div class="popup-content">
            <div class="map-help-text" id="map-popup-text-what-this">
                Our price is lower than the manufacturer&#039;s &quot;minimum advertised price.&quot; As a result, we cannot show you the price in catalog or the product page. <br><br> You have no obligation to purchase the product once you know the price. You can simply remove the item from your cart.            </div>
        </div>
    </div>
    </script>

                    <!--suppress ES6ConvertVarToLetConst -->
                    <script type="text/javascript" id="klevu_page_meta">
                        var klevu_page_meta = { "platform": "magento2", "pageType": "pdp", "itemName": "GRTOTO - Platform Terpercaya Bandar Slot Online Autentik Dengan Keamanan Terjamin", "itemUrl": "https:\/\/www.mothercare.co.id\/nordic-naturals-baby-s-dha-bandar-slot.html", "itemId": "1984988-598663", "itemGroupId": "1984988" };
                    </script>
                    <div class="sharing-buttons mobile-sharing-button">
                        <label>Share product:</label>
                        <div class="sharethis-inline-share-buttons"></div>
                        <!--<script type="text/javascript" src="//platform-api.sharethis.com/js/sharethis.js#property=58afdee0eeab5d00125e8fd6&product=inline-share-buttons"></script>-->
                        <!--<script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#property=5baf03a9752ef70011efcea0&product=inline-share-buttons' async='async'></script>-->
                        <script type="text/javascript"
                            src="//platform-api.sharethis.com/js/sharethis.js#property=5baf03a9752ef70011efcea0&amp;product=inline-share-buttons"></script>
                    </div>



                    <!-- <style type="text/css">
    
    .catalog-product-view .page-main .sharing-buttons.mobile-sharing-button{

        display: none;
    }

    @media (max-width: 768px) {

        .catalog-product-view .product.info.detailed .data.item.title {
            order: unset;
        } 

         .catalog-product-view .page-main  .sharing-buttons{
                display: none;
        }

       .catalog-product-view .page-main .sharing-buttons.mobile-sharing-button{
              display: block;
        }
        .catalog-product-view .page-main .sharing-buttons.mobile-sharing-button label{
            font-family: 'mothercare_2020-regular-webfont';
            font-style: normal;
            font-weight: 400;
            font-size: 16px;
            line-height: 150%;
            letter-spacing: -0.011em;
            text-transform: lowercase;
            color: #165C7D;
            display: block;
            text-align: center;
            padding: 10px 0px;
        }
        .catalog-product-view .page-main .sharing-buttons.mobile-sharing-button .st-btn.st-first,
        .catalog-product-view .page-main .sharing-buttons.mobile-sharing-button .st-btn.st-last {
             background: #165C7D !important;
        }     

         .catalog-product-view .page-main .product-info-main .product-info{
            display: contents !important;
         }

         .catalog-product-view .page-main .product-info-main .product.attribute.overview{
            order: 1 !important;
        }
        .catalog-product-view .page-main .product-info-main .product-config{
                display: contents !important;
        }
         .catalog-product-view .page-main  .sharing-buttons{
                order: 1;
        }

    }
</style>
 -->
                    <div class="products-widget-container">


                        <!-- <script type="text/javascript">
    require(['jquery', 'jquery/ui', 'slick'], function($) {
        $(document).ready(function() {
            if ($('body').hasClass('checkout-cart-index')) {
                $(".widget.widget-crosssell .product-items").slick({
                    dots: false,
                    arrows: true, // Show arrows for larger screens
                    infinite: false,
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    responsive: [
                        {
                            breakpoint: 1024,
                            settings: {
                                slidesToShow: 3,
                                slidesToScroll: 1,
                            }
                        },
                        {
                            breakpoint: 600,
                            settings: {
                                slidesToShow: 3,
                                slidesToScroll: 1
                            }
                        },
                        {
                            breakpoint: 480,
                            settings: {
                                slidesToShow: 2.5,
                                slidesToScroll: 1,
                                arrows: false
                            }
                        },
                        {
                            breakpoint: 430,
                            settings: {
                                slidesToShow: 2.5,
                                slidesToScroll: 1,
                                arrows: false
                            }
                        },
                        {
                            breakpoint: 390,
                            settings: {
                                slidesToShow: 2.5,
                                slidesToScroll: 1,
                                arrows: false // Hide arrows for mobile sizes
                            }
                        },
                        {
                            breakpoint: 375,
                            settings: {
                                slidesToShow: 2.5,
                                slidesToScroll: 1,
                                arrows: false // Hide arrows for mobile sizes
                            }
                        }
                    ]
                });
            }
        });
    });
</script> -->




                        <style type="text/css">
                            .widget.widget-upsell,
                            .widget.widget-related {
                                padding-bottom: 40px;
                                padding-top: 40px;
                                margin-top: 0 !important
                            }

                            .widget.widget-upsell .block-title,
                            .widget.widget-related .block-title {
                                margin: 0 !important;
                                padding: 0 0 40px !important
                            }

                            .widget.widget-upsell .block-title:before,
                            .widget.widget-related .block-title:before {
                                display: none !important
                            }

                            .widget.widget-upsell .block-title strong,
                            .widget.widget-related .block-title strong {
                                display: block;
                                font-family: 'mothercare_2020-regular-webfont';
                                font-style: normal;
                                font-weight: 400;
                                font-size: 32px;
                                color: #515759;
                                margin: 0 !important;
                                text-align: center;
                                text-transform: lowercase
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-upsell .block-title strong,
                                .widget.widget-related .block-title strong {
                                    font-size: 18px
                                }
                            }

                            .widget.widget-upsell .upsell.products-grid,
                            .widget.widget-related .upsell.products-grid,
                            .widget.widget-upsell .related.products-grid,
                            .widget.widget-related .related.products-grid {
                                overflow: inherit;
                                padding-left: 50px;
                                padding-right: 50px
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-upsell .upsell.products-grid,
                                .widget.widget-related .upsell.products-grid,
                                .widget.widget-upsell .related.products-grid,
                                .widget.widget-related .related.products-grid {
                                    padding: 0
                                }
                            }

                            .widget.widget-upsell .upsell.products-grid.slick-initialized>.product-items,
                            .widget.widget-related .upsell.products-grid.slick-initialized>.product-items,
                            .widget.widget-upsell .related.products-grid.slick-initialized>.product-items,
                            .widget.widget-related .related.products-grid.slick-initialized>.product-items {
                                gap: 0;
                                padding: 0;
                                margin: 0 -25px;
                                width: auto
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-upsell .upsell.products-grid.slick-initialized>.product-items,
                                .widget.widget-related .upsell.products-grid.slick-initialized>.product-items,
                                .widget.widget-upsell .related.products-grid.slick-initialized>.product-items,
                                .widget.widget-related .related.products-grid.slick-initialized>.product-items {
                                    margin: 0 -15px
                                }
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item,
                            .widget.widget-related .upsell.products-grid .product-item,
                            .widget.widget-upsell .related.products-grid .product-item,
                            .widget.widget-related .related.products-grid .product-item {
                                width: calc(100%/4 - 50px);
                                max-width: 100%;
                                margin: 0 25px
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-upsell .upsell.products-grid .product-item,
                                .widget.widget-related .upsell.products-grid .product-item,
                                .widget.widget-upsell .related.products-grid .product-item,
                                .widget.widget-related .related.products-grid .product-item {
                                    margin: 0 15px;
                                    width: calc(100%/2 - 30px)
                                }
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-photo,
                            .widget.widget-related .upsell.products-grid .product-item-photo,
                            .widget.widget-upsell .related.products-grid .product-item-photo,
                            .widget.widget-related .related.products-grid .product-item-photo {
                                display: flex;
                                justify-content: center;
                                height: 100%;
                                border-radius: 5px width:100%;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-photo .product-image-container,
                            .widget.widget-related .upsell.products-grid .product-item-photo .product-image-container,
                            .widget.widget-upsell .related.products-grid .product-item-photo .product-image-container,
                            .widget.widget-related .related.products-grid .product-item-photo .product-image-container {
                                width: 100% !important
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-photo .product-image-container img,
                            .widget.widget-related .upsell.products-grid .product-item-photo .product-image-container img,
                            .widget.widget-upsell .related.products-grid .product-item-photo .product-image-container img,
                            .widget.widget-related .related.products-grid .product-item-photo .product-image-container img {
                                height: 100%;
                                object-fit: contain
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-info,
                            .widget.widget-related .upsell.products-grid .product-item-info,
                            .widget.widget-upsell .related.products-grid .product-item-info,
                            .widget.widget-related .related.products-grid .product-item-info {
                                gap: 15px
                            }

                            .widget.widget-upsell .product-items .product-item .item-img-box {
                                position: relative;
                                display: flex;
                                justify-content: center;
                                border: 1px solid #f4f1f1;
                                align-items: center;
                                height: 327px;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details,
                            .widget.widget-related .upsell.products-grid .product-item-details,
                            .widget.widget-upsell .related.products-grid .product-item-details,
                            .widget.widget-related .related.products-grid .product-item-details {
                                flex-direction: column;
                                text-align: center
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .product-item-name,
                            .widget.widget-related .upsell.products-grid .product-item-details .product-item-name,
                            .widget.widget-upsell .related.products-grid .product-item-details .product-item-name,
                            .widget.widget-related .related.products-grid .product-item-details .product-item-name {
                                max-width: 100%;
                                /*    height: 34px;*/
                                margin: 0 0 20px;
                                margin-bottom: 0px !important;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .product-item-name .product-item-link,
                            .widget.widget-related .upsell.products-grid .product-item-details .product-item-name .product-item-link,
                            .widget.widget-upsell .related.products-grid .product-item-details .product-item-name .product-item-link,
                            .widget.widget-related .related.products-grid .product-item-details .product-item-name .product-item-link {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 12px;
                                line-height: 150%;
                                text-align: center;
                                letter-spacing: -.011em;
                                color: #515759;
                                font-family: 'mothercare_2020-regular-webfont';
                                display: block
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box {
                                flex-grow: 1;
                                align-items: flex-end;
                                display: flex
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box {
                                font-family: Arial, Helvetica, sans-serif;
                                display: block;
                                text-align: center;
                                flex-flow: wrap;
                                max-width: 100%;
                                width: 100%;
                                margin: 0;
                                justify-content: center
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                                margin: 0 5px;
                                text-decoration-color: #515759;
                                width: 100%;
                                text-align: center
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 12px;
                                line-height: 120%;
                                color: #515759
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent {
                                order: 3;
                                background: #f24822;
                                font-style: normal;
                                font-weight: 400;
                                font-size: 12px;
                                line-height: 24px;
                                letter-spacing: -.011em;
                                color: #fff;
                                padding: 0 4px;
                                font-family: 'Arial' !important;
                                margin-left: 5px;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-upsell .upsell.products-grid .product-item-details .price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 16px;
                                line-height: 150%;
                                letter-spacing: -.011em;
                                color: #1e1e1e;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box>.price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box>.price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box>.price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box>.price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 14px;
                                line-height: 120%;
                                color: #165c7d;
                                font-family: Arial, Helvetica, sans-serif
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .check,
                            .widget.widget-related .upsell.products-grid .product-item-details .check,
                            .widget.widget-upsell .related.products-grid .product-item-details .check,
                            .widget.widget-related .related.products-grid .product-item-details .check {
                                margin-top: 16px
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .check span,
                            .widget.widget-related .upsell.products-grid .product-item-details .check span,
                            .widget.widget-upsell .related.products-grid .product-item-details .check span,
                            .widget.widget-related .related.products-grid .product-item-details .check span {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 10px;
                                letter-spacing: -.011em;
                                color: #1d1d1d;
                            }

                            .widget.widget-upsell .upsell.products-grid .slick-arrow,
                            .widget.widget-related .upsell.products-grid .slick-arrow,
                            .widget.widget-upsell .related.products-grid .slick-arrow,
                            .widget.widget-related .related.products-grid .slick-arrow {
                                width: 40px;
                                height: 40px;
                                border: none;
                                background-position: center;
                                background-repeat: no-repeat
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-upsell .upsell.products-grid .slick-arrow,
                                .widget.widget-related .upsell.products-grid .slick-arrow,
                                .widget.widget-upsell .related.products-grid .slick-arrow,
                                .widget.widget-related .related.products-grid .slick-arrow {
                                    display: none !important
                                }
                            }

                            .widget.widget-upsell .upsell.products-grid .slick-arrow.slick-prev,
                            .widget.widget-related .upsell.products-grid .slick-arrow.slick-prev,
                            .widget.widget-upsell .related.products-grid .slick-arrow.slick-prev,
                            .widget.widget-related .related.products-grid .slick-arrow.slick-prev {
                                background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-prev-arrow.svg);
                            }

                            .widget.widget-upsell .upsell.products-grid .slick-arrow.slick-next,
                            .widget.widget-related .upsell.products-grid .slick-arrow.slick-next,
                            .widget.widget-upsell .related.products-grid .slick-arrow.slick-next,
                            .widget.widget-related .related.products-grid .slick-arrow.slick-next {
                                background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-next-arrow.svg);
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box {
                                display: flex;
                                flex-flow: row wrap;
                                justify-content: center;
                                align-content: flex-end
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.crossed {
                                width: 100%
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.crossed .old-price {
                                text-decoration: unset
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.crossed .old-price .price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 12px;
                                line-height: 120%;
                                color: #515759;
                                text-decoration: line-through
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.percent {
                                width: auto;
                                order: 3
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.percent .discount-percent {
                                padding: 2px 4px
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.main {
                                margin-top: 4px;
                                width: auto
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.main .price {
                                font-size: 14px;
                                font-weight: 700;
                                color: #1e1e1e
                            }



                            .widget.widget-crosssell,
                            .widget.widget-related {
                                padding-bottom: 40px;
                                padding-top: 40px;
                                margin-top: 0 !important
                            }

                            .widget.widget-crosssell .block-title,
                            .widget.widget-related .block-title {
                                margin: 0 !important;
                                padding: 0 0 40px !important
                            }

                            .widget.widget-crosssell .block-title:before,
                            .widget.widget-related .block-title:before {
                                display: none !important
                            }

                            .widget.widget-crosssell .block-title strong,
                            .widget.widget-related .block-title strong {
                                display: block;
                                font-family: 'mothercare_2020-regular-webfont';
                                font-style: normal;
                                font-weight: 400;
                                font-size: 32px;
                                color: #515759;
                                margin: 0 !important;
                                text-align: center;
                                text-transform: lowercase
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-crosssell .block-title strong,
                                .widget.widget-related .block-title strong {
                                    font-size: 18px
                                }
                            }

                            .widget.widget-crosssell .crosssell.products-grid,
                            .widget.widget-related .crosssell.products-grid,
                            .widget.widget-crosssell .related.products-grid,
                            .widget.widget-related .related.products-grid {
                                overflow: inherit;
                                padding-left: 50px;
                                padding-right: 50px
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-crosssell .crosssell.products-grid,
                                .widget.widget-related .crosssell.products-grid,
                                .widget.widget-crosssell .related.products-grid,
                                .widget.widget-related .related.products-grid {
                                    padding: 0
                                }
                            }

                            .widget.widget-crosssell .crosssell.products-grid.slick-initialized>.product-items,
                            .widget.widget-related .crosssell.products-grid.slick-initialized>.product-items,
                            .widget.widget-crosssell .related.products-grid.slick-initialized>.product-items,
                            .widget.widget-related .related.products-grid.slick-initialized>.product-items {
                                gap: 0;
                                padding: 0;
                                margin: 0 -25px;
                                width: auto
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-crosssell .crosssell.products-grid.slick-initialized>.product-items,
                                .widget.widget-related .crosssell.products-grid.slick-initialized>.product-items,
                                .widget.widget-crosssell .related.products-grid.slick-initialized>.product-items,
                                .widget.widget-related .related.products-grid.slick-initialized>.product-items {
                                    margin: 0 -15px
                                }
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item,
                            .widget.widget-related .crosssell.products-grid .product-item,
                            .widget.widget-crosssell .related.products-grid .product-item,
                            .widget.widget-related .related.products-grid .product-item {
                                width: calc(100%/4 - 50px);
                                max-width: 100%;
                                margin: 0 25px
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-crosssell .crosssell.products-grid .product-item,
                                .widget.widget-related .crosssell.products-grid .product-item,
                                .widget.widget-crosssell .related.products-grid .product-item,
                                .widget.widget-related .related.products-grid .product-item {
                                    margin: 0 8px;
                                    width: calc(100%/2 - 30px)
                                }
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-photo,
                            .widget.widget-related .crosssell.products-grid .product-item-photo,
                            .widget.widget-crosssell .related.products-grid .product-item-photo,
                            .widget.widget-related .related.products-grid .product-item-photo {
                                display: flex;
                                justify-content: center;
                                height: auto;
                                border-radius: 5px width:100%;
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-photo .product-image-container,
                            .widget.widget-related .crosssell.products-grid .product-item-photo .product-image-container,
                            .widget.widget-crosssell .related.products-grid .product-item-photo .product-image-container,
                            .widget.widget-related .related.products-grid .product-item-photo .product-image-container {
                                width: 100% !important
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-photo .product-image-container img,
                            .widget.widget-related .crosssell.products-grid .product-item-photo .product-image-container img,
                            .widget.widget-crosssell .related.products-grid .product-item-photo .product-image-container img,
                            .widget.widget-related .related.products-grid .product-item-photo .product-image-container img {
                                height: 100%;
                                object-fit: cover;
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-info,
                            .widget.widget-related .crosssell.products-grid .product-item-info,
                            .widget.widget-crosssell .related.products-grid .product-item-info,
                            .widget.widget-related .related.products-grid .product-item-info {
                                gap: 15px
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details,
                            .widget.widget-related .crosssell.products-grid .product-item-details,
                            .widget.widget-crosssell .related.products-grid .product-item-details,
                            .widget.widget-related .related.products-grid .product-item-details {
                                flex-direction: column;
                                text-align: center
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .product-item-name,
                            .widget.widget-related .crosssell.products-grid .product-item-details .product-item-name,
                            .widget.widget-crosssell .related.products-grid .product-item-details .product-item-name,
                            .widget.widget-related .related.products-grid .product-item-details .product-item-name {
                                max-width: 100%;
                                height: 34px;
                                margin: 0 0 20px
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .product-item-name .product-item-link,
                            .widget.widget-related .crosssell.products-grid .product-item-details .product-item-name .product-item-link,
                            .widget.widget-crosssell .related.products-grid .product-item-details .product-item-name .product-item-link,
                            .widget.widget-related .related.products-grid .product-item-details .product-item-name .product-item-link {
                                font-style: normal !important;
                                font-weight: 700 !important;
                                font-size: 12px !important;
                                line-height: 150% !important;
                                text-align: center !important;
                                letter-spacing: -.011em !important;
                                color: #515759 !important;
                                font-family: 'mothercare_2020-regular-webfont' !important;
                                display: block !important;
                                text-transform: unset !important;
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box {
                                flex-grow: 1;
                                align-items: flex-end;
                                display: flex
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box {
                                font-family: Arial, Helvetica, sans-serif;
                                display: flex;
                                flex-flow: wrap;
                                max-width: 100%;
                                width: 100%;
                                margin: 0;
                                justify-content: center
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                                margin: 0 5px;
                                text-decoration-color: #515759;
                                width: 100%;
                                text-align: center
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price {
                                font-style: normal !important;
                                font-weight: 700 !important;
                                font-size: 12px !important;
                                line-height: 120% !important;
                                color: #515759 !important;
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent {
                                order: 3;
                                background: #f24822;
                                font-style: normal;
                                font-weight: 400;
                                font-size: 12px;
                                line-height: 24px;
                                letter-spacing: -.011em;
                                color: #fff;
                                padding: 0 4px;
                                margin-left: 5px;
                                font-family: 'mothercare_2020-regular-webfont';
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 16px;
                                line-height: 150%;
                                letter-spacing: -.011em;
                                color: #1e1e1e
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box>.price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box>.price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box>.price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box>.price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 14px;
                                line-height: 120%;
                                color: #165c7d;
                                font-family: Arial, Helvetica, sans-serif
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .check,
                            .widget.widget-related .crosssell.products-grid .product-item-details .check,
                            .widget.widget-crosssell .related.products-grid .product-item-details .check,
                            .widget.widget-related .related.products-grid .product-item-details .check {
                                margin-top: 16px
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .check span,
                            .widget.widget-related .crosssell.products-grid .product-item-details .check span,
                            .widget.widget-crosssell .related.products-grid .product-item-details .check span,
                            .widget.widget-related .related.products-grid .product-item-details .check span {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 10px;
                                letter-spacing: -.011em;
                                color: #1d1d1d;
                                font-family: Arial, Helvetica Neue, Helvetica, sans-serif
                            }

                            .widget.widget-crosssell .crosssell.products-grid .slick-arrow,
                            .widget.widget-related .crosssell.products-grid .slick-arrow,
                            .widget.widget-crosssell .related.products-grid .slick-arrow,
                            .widget.widget-related .related.products-grid .slick-arrow {
                                width: 40px !important;
                                height: 40px !important;
                                border: none !important;
                                background-position: center !important;
                                background-repeat: no-repeat !important;
                            }

                            @media screen and (max-width: 767px) {

                                .widget.widget-crosssell .crosssell.products-grid .slick-arrow,
                                .widget.widget-related .crosssell.products-grid .slick-arrow,
                                .widget.widget-crosssell .related.products-grid .slick-arrow,
                                .widget.widget-related .related.products-grid .slick-arrow {
                                    display: block !important
                                }

                                .widget-crosssell .products-grid .slick-track {
                                    overflow-x: auto;
                                    margin-top: 20px;
                                }

                                .checkout-cart-index .column.main .block:not(.crosssell) .content {
                                    padding: 0px;
                                }
                            }

                            .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-prev,
                            .widget.widget-related .crosssell.products-grid .slick-arrow.slick-prev,
                            .widget.widget-crosssell .related.products-grid .slick-arrow.slick-prev,
                            .widget.widget-related .related.products-grid .slick-arrow.slick-prev {
                                background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-prev-arrow.svg)
                            }

                            .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-next,
                            .widget.widget-related .crosssell.products-grid .slick-arrow.slick-next,
                            .widget.widget-crosssell .related.products-grid .slick-arrow.slick-next,
                            .widget.widget-related .related.products-grid .slick-arrow.slick-next {
                                background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-next-arrow.svg);
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box {
                                display: flex;
                                flex-flow: row wrap;
                                justify-content: center;
                                align-content: flex-end;
                                height: 52px;
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.crossed {
                                width: 100%
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.crossed .old-price {
                                text-decoration: unset
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.crossed .old-price .price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 12px;
                                line-height: 120%;
                                color: #515759;
                                text-decoration: line-through
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.percent {
                                width: auto;
                                order: 3
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.percent .discount-percent {
                                padding: 2px 4px
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.main {
                                margin-top: 4px;
                                width: auto
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.main .price {
                                font-size: 14px;
                                font-weight: 700;
                                color: #1e1e1e
                            }

                            .widget.widget-crosssell button.action.tocart.primary {
                                background: #165C7D;
                                padding: 2px 15px;
                                font-family: 'mothercare_2020-regular-webfont';
                                font-style: normal;
                                font-weight: 700;
                                font-size: 13px;
                                color: #fff;
                                letter-spacing: normal;
                                border-radius: 5px;
                                text-transform: none;
                                width: calc(100% - 20px);
                            }

                            .widget.widget-crosssell .actions-primary {
                                position: absolute;
                                left: 0;
                                right: 0;
                                bottom: 10px;
                                text-align: center;
                                z-index: 11;
                                opacity: 0;
                                visibility: hidden;
                                transition: all 0.4s ease;
                            }

                            .widget.widget-crosssell .product-items .product-item:hover .item-img-box .actions-primary,
                            .catalogsearch-result-index .product-items .product-item:hover .item-img-box .actions-primary {
                                opacity: 1;
                                visibility: visible;
                            }

                            .widget.widget-crosssell .product-items .product-item .item-img-box,
                            .catalogsearch-result-index .product-items .product-item .item-img-box {
                                position: relative;
                                display: flex;
                                justify-content: center;
                                border: 1px solid #f4f1f1;
                                align-items: center;
                                height: 372px;
                            }


                            .widget.widget-crosssell .product-items {
                                gap: var(--listing-grid-gap);
                                row-gap: var(--listing-grid-row-gap);
                                display: flex;
                                flex-wrap: nowrap;
                                overflow-x: auto;
                                scroll-behavior: smooth;
                                scroll-snap-type: none;
                                -ms-overflow-style: none;
                                scrollbar-width: none;
                            }


                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-next {
                                background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-next-arrow.svg) !important;
                                background-size: unset !important;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .slick-arrow {
                                transform: unset !important;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-prev {
                                background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-prev-arrow.svg) !important;
                                background-size: unset !important;
                            }


                            .widget.widget-upsell .upsell.products-grid .slick-arrow.slick-next,
                            .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-next {
                                background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-next-arrow.svg) !important;
                            }


                            .widget.widget-upsell .upsell.products-grid .slick-arrow.slick-prev,
                            .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-prev {
                                background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-prev-arrow.svg) !important;
                            }

                            .widget-upsell .product-items .product-item .product-item-photo {
                                width: 325px;
                                height: 325px !important;
                            }

                            .widget-related .products-grid .product-item-photo .product-image-container {
                                max-width: 325px;
                            }

                            .widget-upsell .product-items .product-item .item-img-box {
                                border: unset !important;
                            }

                            @media(max-width:1280px) {
                                .widget-upsell .product-items .product-item .item-img-box {
                                    height: unset;
                                }
                            }

                            .widget-related .product-items .product-item-details {
                                flex: unset;
                            }


                            .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                border: unset !important;
                                width: auto !important;
                                margin: auto;
                            }

                            .checkout-cart-index .widget-crosssell .crosssell.products-grid .product-item-photo {
                                border: unset !important;
                                height: 325px !important;
                                width: 325px;

                            }

                            @media(max-width:1080px) {
                                .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                    height: unset;
                                }
                            }

                            .widget.widget-upsell .upsell.products-grid .price-label,
                            .widget.widget-upsell .upsell.products-grid .swissup-ajaxpro-quick-view-wrapper,
                            .widget.widget-crosssell .crosssell.products-grid .swissup-ajaxpro-quick-view-wrapper,
                            .widget.widget-related .related.products-grid .swissup-ajaxpro-quick-view-wrapper {
                                display: none;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item {
                                padding-left: unset;
                                padding-right: unset;
                            }


                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price,
                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price,
                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price {
                                text-decoration: line-through;
                            }

                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                            .catalog-product-view .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                                text-decoration: none;
                            }

                            @media(max-width:768px) {

                                .checkout-cart-index .widget-crosssell .crosssell.products-grid .product-item-photo,
                                .widget-upsell .upsell.products-grid .product-item-photo {
                                    height: auto !important;
                                }

                                .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                    width: 100% !important;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item,
                                .widget-upsell .upsell.products-grid .product-item {
                                    padding: unset;
                                    /* float: left !important; */
                                }

                                .widget.widget-upsell .product-items .product-item .item-img-box {
                                    height: auto !important;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-items .slick-next.slick-arrow,
                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-items .slick-prev.slick-arrow {
                                    display: block !important;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .slick-arrow {
                                    width: 20px
                                }

                                .products-widget-container .slick-track .slick-initialized .slick-slide {
                                    float: left !important;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .product-item-name {
                                    margin: 0 0 10px;
                                }

                                .checkout-cart-index .products-widget-container .crosssell.products-crosssell .slick-list .product-item-info .check {
                                    padding-top: 0;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .check {
                                    margin-top: 8px;
                                }

                                .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                                .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                                .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                                .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                                .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                                .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                                .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                                .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                                .widget.widget-upsell .upsell.products-grid .product-item-details .price {
                                    font-style: normal;
                                    font-weight: 700;
                                    font-size: 14px;
                                    line-height: 150%;
                                    letter-spacing: -.011em;
                                    color: #1e1e1e;
                                }

                                .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                                .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                                .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                                .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                                .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                                .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                                .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                                .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                                .widget.widget-crosssell .crosssell.products-grid .product-item-details .price {
                                    font-style: normal;
                                    font-weight: 700;
                                    font-size: 14px;
                                    line-height: 150%;
                                    letter-spacing: -.011em;
                                    color: #1e1e1e;
                                }


                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-label {
                                    display: none;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-items .product-item-info {
                                    height: auto !important;
                                }

                            }

                            @media screen and (max-width: 500px) {

                                .widget.widget-upsell .upsell.products-grid.slick-initialized>.product-items strong.product.name.product-item-name,
                                .widget.widget-crosssell .crosssell.products-grid.slick-initialized>.product-items strong.product.name.product-item-name {
                                    height: 36px;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                                    margin: 0;
                                    text-decoration-color: #D9D9D6;
                                    width: 100%;
                                    text-align: center;
                                }

                                .crosssell .product.details.product-item-details {
                                    flex: unset;
                                }

                                .crosssell .slick-initialized .slick-slide {
                                    height: 100%;
                                }

                                .widget-crosssell .products-grid .slick-slider .slick-list,
                                .slick-slider .slick-track>.product-items {
                                    overflow: auto;
                                    /* Enable horizontal scrolling */
                                    scroll-behavior: smooth;
                                    scroll-snap-type: x mandatory;
                                    /* Ensure smooth snapping */
                                }

                                .widget-crosssell .products-grid .slick-track {
                                    display: flex;
                                    flex-wrap: nowrap;
                                    width: auto !important;
                                    /* Ensure the width adjusts dynamically */
                                }

                                .widget-crosssell .products-grid .product-items {
                                    flex: 0 0 auto;
                                    /* Prevent items from shrinking or growing */
                                }

                                .widget.widget-upsell .products-grid.slick-initialized>.product-items {
                                    padding-bottom: 19px !important;
                                    scrollbar-width: thin !important;
                                }

                                .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                    border: unset !important;
                                    width: 118px !important;
                                    margin: auto;
                                }

                                .widget.widget-upsell .upsell.products-grid .product-item {
                                    width: calc(100% / 2.5 - 30px);


                                }

                                .widget.widget-upsell .block-title {
                                    margin: 0 !important;
                                    padding: 0 0 0px !important;
                                }

                                .widget.widget-upsell .slick-list.products.list.items.product-items {
                                    padding-top: 20px !important;
                                }

                                .widget.widget-upsell .upsell.products-grid .slick-arrow,
                                .widget.widget-related .upsell.products-grid .slick-arrow,
                                .widget.widget-upsell .related.products-grid .slick-arrow,
                                .widget.widget-related .related.products-grid .slick-arrow {
                                    display: none !important;
                                }

                                .widget.widget-upsell .upsell.products-grid .product-item-details .product-item-name {
                                    margin-bottom: 10px !important;
                                }

                                .widget-upsell .product-items .product-item-details {
                                    flex: unset;
                                }

                                .widget.widget-upsell .upsell.products-grid .product-item-photo .product-image-container img {
                                    aspect-ratio: 1;
                                }

                                .widget.widget-upsell .upsell.products-grid .product-item-details .product-item-name .product-item-link {
                                    overflow: hidden;
                                    display: -webkit-box;
                                    -webkit-line-clamp: 2;
                                    line-clamp: 2;
                                    -webkit-box-orient: vertical;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .product-item-name .product-item-link {
                                    overflow: hidden;
                                    display: -webkit-box !important;
                                    -webkit-line-clamp: 2;
                                    line-clamp: 2 !important;
                                    -webkit-box-orient: vertical;
                                    height: 36px;
                                }

                                .widget.widget-crosssell .crosssell.products-grid .product-item-photo .product-image-container img {
                                    aspect-ratio: 1;
                                }

                            }


                            @media screen and (max-width: 390px) {

                                .widget.widget-upsell .products-grid.slick-initialized>.product-items {
                                    padding-bottom: 19px !important;
                                    scrollbar-width: thin !important;
                                }

                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                                    margin: 0 5px;
                                }


                                .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                    border: unset !important;
                                    width: 118px !important;
                                    margin: 0;
                                }

                                .widget.widget-upsell .upsell.products-grid .slick-arrow,
                                .widget.widget-related .upsell.products-grid .slick-arrow,
                                .widget.widget-upsell .related.products-grid .slick-arrow,
                                .widget.widget-related .related.products-grid .slick-arrow {
                                    display: none !important;
                                }

                                .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                                .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                                .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                                .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                                .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent {
                                    order: 3;
                                    background: #f24822;
                                    font-style: normal;
                                    font-weight: 400;
                                    font-size: 12px;
                                    line-height: 24px;
                                    letter-spacing: -.011em;
                                    color: #fff;
                                    padding: 0px 2px;
                                    font-family: 'Arial' !important;
                                    margin-left: 0px;
                                }
                            }

                            strong.product.name.product-item-name {
                                overflow: hidden;
                            }

                            strong.product.name.product-item-name {
                                /* height: 87px; */
                            }


                            li.item.product.product-item.slick-slide.slick-active {
                                float: left !important;
                            }

                            .products-widget-container .slick-track .slick-initialized .slick-slide {
                                float: left !important;
                            }

                            .catalog-product-view .bundle-options-container .bundle-wrapper .bundle-info .amasty-label-container {
                                position: absolute;
                                display: none !important;
                            }

                            /*    .checkout-cart-index .products-crosssell .product-item .product-item-info  .product-image-container  .amasty-label-container {
        width: auto !important;
    }*/
                        </style>

                        <div class="block widget widget-recent" data-bind="
    scope: 'catalog.product.viewed',
    css: options.additionalClasses,
    visible: visible
"><!-- ko template: { if: visible, name: 'recent-products' } --><!-- /ko --></div>


                        <script id="recent-products" type="text/x-magento-template">
    <div class="block-title">
        <strong role="heading" aria-level="2" data-bind="text: options.title"></strong>
    </div>
    <div class="block-content">
        <div class="recent" data-content-type="slider"
             data-mage-init='{"Magento_PageBuilder/js/content-type/slider/appearance/default/widget":{"arrows": true, "dots": false}}'
             data-bind="css: 'products-' + options.displayMode">
            <ol class="slick-list product-items" data-bind="foreach: items">
                <li class="product-item">
                    <div class="product-item-info">
                                                    <a class="product-item-photo" data-bind="
                                attr: { href: url, title: name },
                                template: { name: 'productImage', data: $parent.getImageData($data) }
                            "></a>
                        
                        <div class="product-item-details">
                                                            <strong class="product-item-name">
                                    <a data-bind="attr: { href: url }" class="product-item-link">
                                        <span data-bind="html: name"></span>
                                    </a>
                                </strong>
                            
                                                            <div class="carousel-price-box">
                                    <!-- ko if:$parent.getRegularPriceHtml($data) -->
                                    <div class="price-box crossed" data-bind="html: $parent.getRegularPriceHtml($data)"></div>
                                    <div class="price-box percent" data-bind="html: $parent.getDiscountPercentage($data)"></div>
                                    <!-- /ko -->
                                    <div class="price-box main" data-bind="html: $parent.getPriceHtml($data)"></div>
                                </div>
                            
                                                            <div class="product-item-actions">
                                    
                                                                    </div>
                            
                            <div class="product-item-description">
                                <div data-bind="html: $parent.getAdditionalContent($data, $element)"></div>

                                                            </div>
                        </div>
                    </div>
                </li>
            </ol>
        </div>
    </div>
</script>

                        <script type="text/x-magento-init">
     {
         "*": {
             "amInitLabelUi": {"scope":"website","productsLifetime":1000}         }
     }
</script>
                    </div>


                    <!-- <script type="text/javascript">
    require(['jquery', 'jquery/ui', 'slick'], function($) {
        $(document).ready(function() {
            if ($('body').hasClass('checkout-cart-index')) {
                $(".widget.widget-crosssell .product-items").slick({
                    dots: false,
                    arrows: true, // Show arrows for larger screens
                    infinite: false,
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    responsive: [
                        {
                            breakpoint: 1024,
                            settings: {
                                slidesToShow: 3,
                                slidesToScroll: 1,
                            }
                        },
                        {
                            breakpoint: 600,
                            settings: {
                                slidesToShow: 3,
                                slidesToScroll: 1
                            }
                        },
                        {
                            breakpoint: 480,
                            settings: {
                                slidesToShow: 2.5,
                                slidesToScroll: 1,
                                arrows: false
                            }
                        },
                        {
                            breakpoint: 430,
                            settings: {
                                slidesToShow: 2.5,
                                slidesToScroll: 1,
                                arrows: false
                            }
                        },
                        {
                            breakpoint: 390,
                            settings: {
                                slidesToShow: 2.5,
                                slidesToScroll: 1,
                                arrows: false // Hide arrows for mobile sizes
                            }
                        },
                        {
                            breakpoint: 375,
                            settings: {
                                slidesToShow: 2.5,
                                slidesToScroll: 1,
                                arrows: false // Hide arrows for mobile sizes
                            }
                        }
                    ]
                });
            }
        });
    });
</script> -->




                    <style type="text/css">
                        .widget.widget-upsell,
                        .widget.widget-related {
                            padding-bottom: 40px;
                            padding-top: 40px;
                            margin-top: 0 !important
                        }

                        .widget.widget-upsell .block-title,
                        .widget.widget-related .block-title {
                            margin: 0 !important;
                            padding: 0 0 40px !important
                        }

                        .widget.widget-upsell .block-title:before,
                        .widget.widget-related .block-title:before {
                            display: none !important
                        }

                        .widget.widget-upsell .block-title strong,
                        .widget.widget-related .block-title strong {
                            display: block;
                            font-family: 'mothercare_2020-regular-webfont';
                            font-style: normal;
                            font-weight: 400;
                            font-size: 32px;
                            color: #515759;
                            margin: 0 !important;
                            text-align: center;
                            text-transform: lowercase
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-upsell .block-title strong,
                            .widget.widget-related .block-title strong {
                                font-size: 18px
                            }
                        }

                        .widget.widget-upsell .upsell.products-grid,
                        .widget.widget-related .upsell.products-grid,
                        .widget.widget-upsell .related.products-grid,
                        .widget.widget-related .related.products-grid {
                            overflow: inherit;
                            padding-left: 50px;
                            padding-right: 50px
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-upsell .upsell.products-grid,
                            .widget.widget-related .upsell.products-grid,
                            .widget.widget-upsell .related.products-grid,
                            .widget.widget-related .related.products-grid {
                                padding: 0
                            }
                        }

                        .widget.widget-upsell .upsell.products-grid.slick-initialized>.product-items,
                        .widget.widget-related .upsell.products-grid.slick-initialized>.product-items,
                        .widget.widget-upsell .related.products-grid.slick-initialized>.product-items,
                        .widget.widget-related .related.products-grid.slick-initialized>.product-items {
                            gap: 0;
                            padding: 0;
                            margin: 0 -25px;
                            width: auto
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-upsell .upsell.products-grid.slick-initialized>.product-items,
                            .widget.widget-related .upsell.products-grid.slick-initialized>.product-items,
                            .widget.widget-upsell .related.products-grid.slick-initialized>.product-items,
                            .widget.widget-related .related.products-grid.slick-initialized>.product-items {
                                margin: 0 -15px
                            }
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item,
                        .widget.widget-related .upsell.products-grid .product-item,
                        .widget.widget-upsell .related.products-grid .product-item,
                        .widget.widget-related .related.products-grid .product-item {
                            width: calc(100%/4 - 50px);
                            max-width: 100%;
                            margin: 0 25px
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-upsell .upsell.products-grid .product-item,
                            .widget.widget-related .upsell.products-grid .product-item,
                            .widget.widget-upsell .related.products-grid .product-item,
                            .widget.widget-related .related.products-grid .product-item {
                                margin: 0 15px;
                                width: calc(100%/2 - 30px)
                            }
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-photo,
                        .widget.widget-related .upsell.products-grid .product-item-photo,
                        .widget.widget-upsell .related.products-grid .product-item-photo,
                        .widget.widget-related .related.products-grid .product-item-photo {
                            display: flex;
                            justify-content: center;
                            height: 100%;
                            border-radius: 5px width:100%;
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-photo .product-image-container,
                        .widget.widget-related .upsell.products-grid .product-item-photo .product-image-container,
                        .widget.widget-upsell .related.products-grid .product-item-photo .product-image-container,
                        .widget.widget-related .related.products-grid .product-item-photo .product-image-container {
                            width: 100% !important
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-photo .product-image-container img,
                        .widget.widget-related .upsell.products-grid .product-item-photo .product-image-container img,
                        .widget.widget-upsell .related.products-grid .product-item-photo .product-image-container img,
                        .widget.widget-related .related.products-grid .product-item-photo .product-image-container img {
                            height: 100%;
                            object-fit: contain
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-info,
                        .widget.widget-related .upsell.products-grid .product-item-info,
                        .widget.widget-upsell .related.products-grid .product-item-info,
                        .widget.widget-related .related.products-grid .product-item-info {
                            gap: 15px
                        }

                        .widget.widget-upsell .product-items .product-item .item-img-box {
                            position: relative;
                            display: flex;
                            justify-content: center;
                            border: 1px solid #f4f1f1;
                            align-items: center;
                            height: 327px;
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details,
                        .widget.widget-related .upsell.products-grid .product-item-details,
                        .widget.widget-upsell .related.products-grid .product-item-details,
                        .widget.widget-related .related.products-grid .product-item-details {
                            flex-direction: column;
                            text-align: center
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .product-item-name,
                        .widget.widget-related .upsell.products-grid .product-item-details .product-item-name,
                        .widget.widget-upsell .related.products-grid .product-item-details .product-item-name,
                        .widget.widget-related .related.products-grid .product-item-details .product-item-name {
                            max-width: 100%;
                            /*    height: 34px;*/
                            margin: 0 0 20px;
                            margin-bottom: 0px !important;
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .product-item-name .product-item-link,
                        .widget.widget-related .upsell.products-grid .product-item-details .product-item-name .product-item-link,
                        .widget.widget-upsell .related.products-grid .product-item-details .product-item-name .product-item-link,
                        .widget.widget-related .related.products-grid .product-item-details .product-item-name .product-item-link {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 12px;
                            line-height: 150%;
                            text-align: center;
                            letter-spacing: -.011em;
                            color: #515759;
                            font-family: 'mothercare_2020-regular-webfont';
                            display: block
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box {
                            flex-grow: 1;
                            align-items: flex-end;
                            display: flex
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box {
                            font-family: Arial, Helvetica, sans-serif;
                            display: block;
                            text-align: center;
                            flex-flow: wrap;
                            max-width: 100%;
                            width: 100%;
                            margin: 0;
                            justify-content: center
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                            margin: 0 5px;
                            text-decoration-color: #515759;
                            width: 100%;
                            text-align: center
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 12px;
                            line-height: 120%;
                            color: #515759
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent {
                            order: 3;
                            background: #f24822;
                            font-style: normal;
                            font-weight: 400;
                            font-size: 12px;
                            line-height: 24px;
                            letter-spacing: -.011em;
                            color: #fff;
                            padding: 0 4px;
                            font-family: 'Arial' !important;
                            margin-left: 5px;
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                        .widget.widget-upsell .upsell.products-grid .product-item-details .price {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 16px;
                            line-height: 150%;
                            letter-spacing: -.011em;
                            color: #1e1e1e;
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box>.price,
                        .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box>.price,
                        .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box>.price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box>.price {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 14px;
                            line-height: 120%;
                            color: #165c7d;
                            font-family: Arial, Helvetica, sans-serif
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .check,
                        .widget.widget-related .upsell.products-grid .product-item-details .check,
                        .widget.widget-upsell .related.products-grid .product-item-details .check,
                        .widget.widget-related .related.products-grid .product-item-details .check {
                            margin-top: 16px
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .check span,
                        .widget.widget-related .upsell.products-grid .product-item-details .check span,
                        .widget.widget-upsell .related.products-grid .product-item-details .check span,
                        .widget.widget-related .related.products-grid .product-item-details .check span {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 10px;
                            letter-spacing: -.011em;
                            color: #1d1d1d;
                        }

                        .widget.widget-upsell .upsell.products-grid .slick-arrow,
                        .widget.widget-related .upsell.products-grid .slick-arrow,
                        .widget.widget-upsell .related.products-grid .slick-arrow,
                        .widget.widget-related .related.products-grid .slick-arrow {
                            width: 40px;
                            height: 40px;
                            border: none;
                            background-position: center;
                            background-repeat: no-repeat
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-upsell .upsell.products-grid .slick-arrow,
                            .widget.widget-related .upsell.products-grid .slick-arrow,
                            .widget.widget-upsell .related.products-grid .slick-arrow,
                            .widget.widget-related .related.products-grid .slick-arrow {
                                display: none !important
                            }
                        }

                        .widget.widget-upsell .upsell.products-grid .slick-arrow.slick-prev,
                        .widget.widget-related .upsell.products-grid .slick-arrow.slick-prev,
                        .widget.widget-upsell .related.products-grid .slick-arrow.slick-prev,
                        .widget.widget-related .related.products-grid .slick-arrow.slick-prev {
                            background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-prev-arrow.svg);
                        }

                        .widget.widget-upsell .upsell.products-grid .slick-arrow.slick-next,
                        .widget.widget-related .upsell.products-grid .slick-arrow.slick-next,
                        .widget.widget-upsell .related.products-grid .slick-arrow.slick-next,
                        .widget.widget-related .related.products-grid .slick-arrow.slick-next {
                            background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-next-arrow.svg);
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box {
                            display: flex;
                            flex-flow: row wrap;
                            justify-content: center;
                            align-content: flex-end
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.crossed {
                            width: 100%
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.crossed .old-price {
                            text-decoration: unset
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.crossed .old-price .price {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 12px;
                            line-height: 120%;
                            color: #515759;
                            text-decoration: line-through
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.percent {
                            width: auto;
                            order: 3
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.percent .discount-percent {
                            padding: 2px 4px
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.main {
                            margin-top: 4px;
                            width: auto
                        }

                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box.main .price {
                            font-size: 14px;
                            font-weight: 700;
                            color: #1e1e1e
                        }



                        .widget.widget-crosssell,
                        .widget.widget-related {
                            padding-bottom: 40px;
                            padding-top: 40px;
                            margin-top: 0 !important
                        }

                        .widget.widget-crosssell .block-title,
                        .widget.widget-related .block-title {
                            margin: 0 !important;
                            padding: 0 0 40px !important
                        }

                        .widget.widget-crosssell .block-title:before,
                        .widget.widget-related .block-title:before {
                            display: none !important
                        }

                        .widget.widget-crosssell .block-title strong,
                        .widget.widget-related .block-title strong {
                            display: block;
                            font-family: 'mothercare_2020-regular-webfont';
                            font-style: normal;
                            font-weight: 400;
                            font-size: 32px;
                            color: #515759;
                            margin: 0 !important;
                            text-align: center;
                            text-transform: lowercase
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-crosssell .block-title strong,
                            .widget.widget-related .block-title strong {
                                font-size: 18px
                            }
                        }

                        .widget.widget-crosssell .crosssell.products-grid,
                        .widget.widget-related .crosssell.products-grid,
                        .widget.widget-crosssell .related.products-grid,
                        .widget.widget-related .related.products-grid {
                            overflow: inherit;
                            padding-left: 50px;
                            padding-right: 50px
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-crosssell .crosssell.products-grid,
                            .widget.widget-related .crosssell.products-grid,
                            .widget.widget-crosssell .related.products-grid,
                            .widget.widget-related .related.products-grid {
                                padding: 0
                            }
                        }

                        .widget.widget-crosssell .crosssell.products-grid.slick-initialized>.product-items,
                        .widget.widget-related .crosssell.products-grid.slick-initialized>.product-items,
                        .widget.widget-crosssell .related.products-grid.slick-initialized>.product-items,
                        .widget.widget-related .related.products-grid.slick-initialized>.product-items {
                            gap: 0;
                            padding: 0;
                            margin: 0 -25px;
                            width: auto
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-crosssell .crosssell.products-grid.slick-initialized>.product-items,
                            .widget.widget-related .crosssell.products-grid.slick-initialized>.product-items,
                            .widget.widget-crosssell .related.products-grid.slick-initialized>.product-items,
                            .widget.widget-related .related.products-grid.slick-initialized>.product-items {
                                margin: 0 -15px
                            }
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item,
                        .widget.widget-related .crosssell.products-grid .product-item,
                        .widget.widget-crosssell .related.products-grid .product-item,
                        .widget.widget-related .related.products-grid .product-item {
                            width: calc(100%/4 - 50px);
                            max-width: 100%;
                            margin: 0 25px
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-crosssell .crosssell.products-grid .product-item,
                            .widget.widget-related .crosssell.products-grid .product-item,
                            .widget.widget-crosssell .related.products-grid .product-item,
                            .widget.widget-related .related.products-grid .product-item {
                                margin: 0 8px;
                                width: calc(100%/2 - 30px)
                            }
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-photo,
                        .widget.widget-related .crosssell.products-grid .product-item-photo,
                        .widget.widget-crosssell .related.products-grid .product-item-photo,
                        .widget.widget-related .related.products-grid .product-item-photo {
                            display: flex;
                            justify-content: center;
                            height: auto;
                            border-radius: 5px width:100%;
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-photo .product-image-container,
                        .widget.widget-related .crosssell.products-grid .product-item-photo .product-image-container,
                        .widget.widget-crosssell .related.products-grid .product-item-photo .product-image-container,
                        .widget.widget-related .related.products-grid .product-item-photo .product-image-container {
                            width: 100% !important
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-photo .product-image-container img,
                        .widget.widget-related .crosssell.products-grid .product-item-photo .product-image-container img,
                        .widget.widget-crosssell .related.products-grid .product-item-photo .product-image-container img,
                        .widget.widget-related .related.products-grid .product-item-photo .product-image-container img {
                            height: 100%;
                            object-fit: cover;
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-info,
                        .widget.widget-related .crosssell.products-grid .product-item-info,
                        .widget.widget-crosssell .related.products-grid .product-item-info,
                        .widget.widget-related .related.products-grid .product-item-info {
                            gap: 15px
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details,
                        .widget.widget-related .crosssell.products-grid .product-item-details,
                        .widget.widget-crosssell .related.products-grid .product-item-details,
                        .widget.widget-related .related.products-grid .product-item-details {
                            flex-direction: column;
                            text-align: center
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .product-item-name,
                        .widget.widget-related .crosssell.products-grid .product-item-details .product-item-name,
                        .widget.widget-crosssell .related.products-grid .product-item-details .product-item-name,
                        .widget.widget-related .related.products-grid .product-item-details .product-item-name {
                            max-width: 100%;
                            height: 34px;
                            margin: 0 0 20px
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .product-item-name .product-item-link,
                        .widget.widget-related .crosssell.products-grid .product-item-details .product-item-name .product-item-link,
                        .widget.widget-crosssell .related.products-grid .product-item-details .product-item-name .product-item-link,
                        .widget.widget-related .related.products-grid .product-item-details .product-item-name .product-item-link {
                            font-style: normal !important;
                            font-weight: 700 !important;
                            font-size: 12px !important;
                            line-height: 150% !important;
                            text-align: center !important;
                            letter-spacing: -.011em !important;
                            color: #515759 !important;
                            font-family: 'mothercare_2020-regular-webfont' !important;
                            display: block !important;
                            text-transform: unset !important;
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box {
                            flex-grow: 1;
                            align-items: flex-end;
                            display: flex
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box {
                            font-family: Arial, Helvetica, sans-serif;
                            display: flex;
                            flex-flow: wrap;
                            max-width: 100%;
                            width: 100%;
                            margin: 0;
                            justify-content: center
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price,
                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                            margin: 0 5px;
                            text-decoration-color: #515759;
                            width: 100%;
                            text-align: center
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .crossed-price .price-container .price,
                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price-container .price {
                            font-style: normal !important;
                            font-weight: 700 !important;
                            font-size: 12px !important;
                            line-height: 120% !important;
                            color: #515759 !important;
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent {
                            order: 3;
                            background: #f24822;
                            font-style: normal;
                            font-weight: 400;
                            font-size: 12px;
                            line-height: 24px;
                            letter-spacing: -.011em;
                            color: #fff;
                            padding: 0 4px;
                            margin-left: 5px;
                            font-family: 'mothercare_2020-regular-webfont';
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .price {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 16px;
                            line-height: 150%;
                            letter-spacing: -.011em;
                            color: #1e1e1e
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box>.price,
                        .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box>.price,
                        .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box>.price,
                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box>.price {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 14px;
                            line-height: 120%;
                            color: #165c7d;
                            font-family: Arial, Helvetica, sans-serif
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .check,
                        .widget.widget-related .crosssell.products-grid .product-item-details .check,
                        .widget.widget-crosssell .related.products-grid .product-item-details .check,
                        .widget.widget-related .related.products-grid .product-item-details .check {
                            margin-top: 16px
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .check span,
                        .widget.widget-related .crosssell.products-grid .product-item-details .check span,
                        .widget.widget-crosssell .related.products-grid .product-item-details .check span,
                        .widget.widget-related .related.products-grid .product-item-details .check span {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 10px;
                            letter-spacing: -.011em;
                            color: #1d1d1d;
                            font-family: Arial, Helvetica Neue, Helvetica, sans-serif
                        }

                        .widget.widget-crosssell .crosssell.products-grid .slick-arrow,
                        .widget.widget-related .crosssell.products-grid .slick-arrow,
                        .widget.widget-crosssell .related.products-grid .slick-arrow,
                        .widget.widget-related .related.products-grid .slick-arrow {
                            width: 40px !important;
                            height: 40px !important;
                            border: none !important;
                            background-position: center !important;
                            background-repeat: no-repeat !important;
                        }

                        @media screen and (max-width: 767px) {

                            .widget.widget-crosssell .crosssell.products-grid .slick-arrow,
                            .widget.widget-related .crosssell.products-grid .slick-arrow,
                            .widget.widget-crosssell .related.products-grid .slick-arrow,
                            .widget.widget-related .related.products-grid .slick-arrow {
                                display: block !important
                            }

                            .widget-crosssell .products-grid .slick-track {
                                overflow-x: auto;
                                margin-top: 20px;
                            }

                            .checkout-cart-index .column.main .block:not(.crosssell) .content {
                                padding: 0px;
                            }
                        }

                        .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-prev,
                        .widget.widget-related .crosssell.products-grid .slick-arrow.slick-prev,
                        .widget.widget-crosssell .related.products-grid .slick-arrow.slick-prev,
                        .widget.widget-related .related.products-grid .slick-arrow.slick-prev {
                            background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-prev-arrow.svg)
                        }

                        .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-next,
                        .widget.widget-related .crosssell.products-grid .slick-arrow.slick-next,
                        .widget.widget-crosssell .related.products-grid .slick-arrow.slick-next,
                        .widget.widget-related .related.products-grid .slick-arrow.slick-next {
                            background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-next-arrow.svg);
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box {
                            display: flex;
                            flex-flow: row wrap;
                            justify-content: center;
                            align-content: flex-end;
                            height: 52px;
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.crossed {
                            width: 100%
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.crossed .old-price {
                            text-decoration: unset
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.crossed .old-price .price {
                            font-style: normal;
                            font-weight: 700;
                            font-size: 12px;
                            line-height: 120%;
                            color: #515759;
                            text-decoration: line-through
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.percent {
                            width: auto;
                            order: 3
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.percent .discount-percent {
                            padding: 2px 4px
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.main {
                            margin-top: 4px;
                            width: auto
                        }

                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box.main .price {
                            font-size: 14px;
                            font-weight: 700;
                            color: #1e1e1e
                        }

                        .widget.widget-crosssell button.action.tocart.primary {
                            background: #165C7D;
                            padding: 2px 15px;
                            font-family: 'mothercare_2020-regular-webfont';
                            font-style: normal;
                            font-weight: 700;
                            font-size: 13px;
                            color: #fff;
                            letter-spacing: normal;
                            border-radius: 5px;
                            text-transform: none;
                            width: calc(100% - 20px);
                        }

                        .widget.widget-crosssell .actions-primary {
                            position: absolute;
                            left: 0;
                            right: 0;
                            bottom: 10px;
                            text-align: center;
                            z-index: 11;
                            opacity: 0;
                            visibility: hidden;
                            transition: all 0.4s ease;
                        }

                        .widget.widget-crosssell .product-items .product-item:hover .item-img-box .actions-primary,
                        .catalogsearch-result-index .product-items .product-item:hover .item-img-box .actions-primary {
                            opacity: 1;
                            visibility: visible;
                        }

                        .widget.widget-crosssell .product-items .product-item .item-img-box,
                        .catalogsearch-result-index .product-items .product-item .item-img-box {
                            position: relative;
                            display: flex;
                            justify-content: center;
                            border: 1px solid #f4f1f1;
                            align-items: center;
                            height: 372px;
                        }


                        .widget.widget-crosssell .product-items {
                            gap: var(--listing-grid-gap);
                            row-gap: var(--listing-grid-row-gap);
                            display: flex;
                            flex-wrap: nowrap;
                            overflow-x: auto;
                            scroll-behavior: smooth;
                            scroll-snap-type: none;
                            -ms-overflow-style: none;
                            scrollbar-width: none;
                        }


                        .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-next {
                            background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-next-arrow.svg) !important;
                            background-size: unset !important;
                        }

                        .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .slick-arrow {
                            transform: unset !important;
                        }

                        .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-prev {
                            background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-prev-arrow.svg) !important;
                            background-size: unset !important;
                        }


                        .widget.widget-upsell .upsell.products-grid .slick-arrow.slick-next,
                        .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-next {
                            background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-next-arrow.svg) !important;
                        }


                        .widget.widget-upsell .upsell.products-grid .slick-arrow.slick-prev,
                        .widget.widget-crosssell .crosssell.products-grid .slick-arrow.slick-prev {
                            background-image: url(https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/images/gray-prev-arrow.svg) !important;
                        }

                        .widget-upsell .product-items .product-item .product-item-photo {
                            width: 325px;
                            height: 325px !important;
                        }

                        .widget-related .products-grid .product-item-photo .product-image-container {
                            max-width: 325px;
                        }

                        .widget-upsell .product-items .product-item .item-img-box {
                            border: unset !important;
                        }

                        @media(max-width:1280px) {
                            .widget-upsell .product-items .product-item .item-img-box {
                                height: unset;
                            }
                        }

                        .widget-related .product-items .product-item-details {
                            flex: unset;
                        }


                        .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                            border: unset !important;
                            width: auto !important;
                            margin: auto;
                        }

                        .checkout-cart-index .widget-crosssell .crosssell.products-grid .product-item-photo {
                            border: unset !important;
                            height: 325px !important;
                            width: 325px;

                        }

                        @media(max-width:1080px) {
                            .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                height: unset;
                            }
                        }

                        .widget.widget-upsell .upsell.products-grid .price-label,
                        .widget.widget-upsell .upsell.products-grid .swissup-ajaxpro-quick-view-wrapper,
                        .widget.widget-crosssell .crosssell.products-grid .swissup-ajaxpro-quick-view-wrapper,
                        .widget.widget-related .related.products-grid .swissup-ajaxpro-quick-view-wrapper {
                            display: none;
                        }

                        .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item {
                            padding-left: unset;
                            padding-right: unset;
                        }


                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price .price,
                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price,
                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price .price {
                            text-decoration: line-through;
                        }

                        .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price,
                        .catalog-product-view .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                            text-decoration: none;
                        }

                        @media(max-width:768px) {

                            .checkout-cart-index .widget-crosssell .crosssell.products-grid .product-item-photo,
                            .widget-upsell .upsell.products-grid .product-item-photo {
                                height: auto !important;
                            }

                            .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                width: 100% !important;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item,
                            .widget-upsell .upsell.products-grid .product-item {
                                padding: unset;
                                /* float: left !important; */
                            }

                            .widget.widget-upsell .product-items .product-item .item-img-box {
                                height: auto !important;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-items .slick-next.slick-arrow,
                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-items .slick-prev.slick-arrow {
                                display: block !important;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .slick-arrow {
                                width: 20px
                            }

                            .products-widget-container .slick-track .slick-initialized .slick-slide {
                                float: left !important;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .product-item-name {
                                margin: 0 0 10px;
                            }

                            .checkout-cart-index .products-widget-container .crosssell.products-crosssell .slick-list .product-item-info .check {
                                padding-top: 0;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .check {
                                margin-top: 8px;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-upsell .upsell.products-grid .product-item-details .price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 14px;
                                line-height: 150%;
                                letter-spacing: -.011em;
                                color: #1e1e1e;
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .special-price .price-container .price,
                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-related .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-crosssell .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .price-with-discount .normal-price .price-container .price,
                            .widget.widget-crosssell .crosssell.products-grid .product-item-details .price {
                                font-style: normal;
                                font-weight: 700;
                                font-size: 14px;
                                line-height: 150%;
                                letter-spacing: -.011em;
                                color: #1e1e1e;
                            }


                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .price-label {
                                display: none;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-items .product-item-info {
                                height: auto !important;
                            }

                        }

                        @media screen and (max-width: 500px) {

                            .widget.widget-upsell .upsell.products-grid.slick-initialized>.product-items strong.product.name.product-item-name,
                            .widget.widget-crosssell .crosssell.products-grid.slick-initialized>.product-items strong.product.name.product-item-name {
                                height: 36px;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                                margin: 0;
                                text-decoration-color: #D9D9D6;
                                width: 100%;
                                text-align: center;
                            }

                            .crosssell .product.details.product-item-details {
                                flex: unset;
                            }

                            .crosssell .slick-initialized .slick-slide {
                                height: 100%;
                            }

                            .widget-crosssell .products-grid .slick-slider .slick-list,
                            .slick-slider .slick-track>.product-items {
                                overflow: auto;
                                /* Enable horizontal scrolling */
                                scroll-behavior: smooth;
                                scroll-snap-type: x mandatory;
                                /* Ensure smooth snapping */
                            }

                            .widget-crosssell .products-grid .slick-track {
                                display: flex;
                                flex-wrap: nowrap;
                                width: auto !important;
                                /* Ensure the width adjusts dynamically */
                            }

                            .widget-crosssell .products-grid .product-items {
                                flex: 0 0 auto;
                                /* Prevent items from shrinking or growing */
                            }

                            .widget.widget-upsell .products-grid.slick-initialized>.product-items {
                                padding-bottom: 19px !important;
                                scrollbar-width: thin !important;
                            }

                            .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                border: unset !important;
                                width: 118px !important;
                                margin: auto;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item {
                                width: calc(100% / 2.5 - 30px);


                            }

                            .widget.widget-upsell .block-title {
                                margin: 0 !important;
                                padding: 0 0 0px !important;
                            }

                            .widget.widget-upsell .slick-list.products.list.items.product-items {
                                padding-top: 20px !important;
                            }

                            .widget.widget-upsell .upsell.products-grid .slick-arrow,
                            .widget.widget-related .upsell.products-grid .slick-arrow,
                            .widget.widget-upsell .related.products-grid .slick-arrow,
                            .widget.widget-related .related.products-grid .slick-arrow {
                                display: none !important;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .product-item-name {
                                margin-bottom: 10px !important;
                            }

                            .widget-upsell .product-items .product-item-details {
                                flex: unset;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-photo .product-image-container img {
                                aspect-ratio: 1;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .product-item-name .product-item-link {
                                overflow: hidden;
                                display: -webkit-box;
                                -webkit-line-clamp: 2;
                                line-clamp: 2;
                                -webkit-box-orient: vertical;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .product-item-name .product-item-link {
                                overflow: hidden;
                                display: -webkit-box !important;
                                -webkit-line-clamp: 2;
                                line-clamp: 2 !important;
                                -webkit-box-orient: vertical;
                                height: 36px;
                            }

                            .widget.widget-crosssell .crosssell.products-grid .product-item-photo .product-image-container img {
                                aspect-ratio: 1;
                            }

                        }


                        @media screen and (max-width: 390px) {

                            .widget.widget-upsell .products-grid.slick-initialized>.product-items {
                                padding-bottom: 19px !important;
                                scrollbar-width: thin !important;
                            }

                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .old-price {
                                margin: 0 5px;
                            }


                            .checkout-cart-index .widget-crosssell .product-items .product-item .item-img-box {
                                border: unset !important;
                                width: 118px !important;
                                margin: 0;
                            }

                            .widget.widget-upsell .upsell.products-grid .slick-arrow,
                            .widget.widget-related .upsell.products-grid .slick-arrow,
                            .widget.widget-upsell .related.products-grid .slick-arrow,
                            .widget.widget-related .related.products-grid .slick-arrow {
                                display: none !important;
                            }

                            .widget.widget-upsell .upsell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-related .upsell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-upsell .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .widget.widget-related .related.products-grid .product-item-details .carousel-price-box .price-box .discount-percent,
                            .checkout-cart-index .widget.widget-crosssell .crosssell.products-grid .product-item-details .carousel-price-box .price-box .discount-percent {
                                order: 3;
                                background: #f24822;
                                font-style: normal;
                                font-weight: 400;
                                font-size: 12px;
                                line-height: 24px;
                                letter-spacing: -.011em;
                                color: #fff;
                                padding: 0px 2px;
                                font-family: 'Arial' !important;
                                margin-left: 0px;
                            }
                        }

                        strong.product.name.product-item-name {
                            overflow: hidden;
                        }

                        strong.product.name.product-item-name {
                            /* height: 87px; */
                        }


                        li.item.product.product-item.slick-slide.slick-active {
                            float: left !important;
                        }

                        .products-widget-container .slick-track .slick-initialized .slick-slide {
                            float: left !important;
                        }

                        .catalog-product-view .bundle-options-container .bundle-wrapper .bundle-info .amasty-label-container {
                            position: absolute;
                            display: none !important;
                        }

                        /*    .checkout-cart-index .products-crosssell .product-item .product-item-info  .product-image-container  .amasty-label-container {
        width: auto !important;
    }*/
                    </style>
                </div>
            </div>
        </main>
        <div class="ga">
            <script data-breeze>

                require(['jquery', 'Magento_Customer/js/customer-data'],
                    function ($, customerData) {

                        const currentWwebsiteId = 3;
                        var products;
                        var productName;
                        var countFirstLoad = 4;
                        var websiteId = window.checkout.websiteId;

                        $(document).ready(function () {

                            try {
                                window.dataLayer = window.dataLayer || [];
                                var productIds = [];
                                var productId = $('.price-box.price-final_price').attr('data-product-id');
                                productIds.push(productId);

                                $.ajax({
                                    type: 'POST',
                                    url: window.location.origin + '/datalayer/ga/cartlayer',
                                    data: { 'ids': productIds, 'requestFrom': 'recent_view' },
                                    success: function (data) {

                                        let _productName = data[0].product_name ? data[0].product_name : "Not Defined";
                                        let _sku = data[0].sku ? data[0].sku : "Not Defined";
                                        let _productPrice = data[0].price ? data[0].price : "Not Defined";
                                        let _brand = data[0].origin_brand ? data[0].origin_brand : "Not Defined";
                                        let _category = data[0].category ? data[0].category : "Not Defined";
                                        let _category1 = data[0].category1 ? data[0].category1 : "Not Defined";
                                        let _category2 = data[0].category2 ? data[0].category2 : "Not Defined";
                                        let _category3 = data[0].category3 ? data[0].category3 : "Not Defined";

                                        var products = [{
                                            'item_name': _productName,
                                            'item_id': _sku,
                                            'price': _productPrice,
                                            'item_brand': _brand,
                                            'item_category': _category,
                                            'item_category2': _category1,
                                            'item_category3': _category2,
                                            'item_category4': _category3,
                                            'item_variant': "Not Defined",
                                            'quantity': 1
                                        }];

                                        dataLayer.push({
                                            'event': 'view_item',
                                            'eventCategory': 'ecommerce',
                                            'eventAction': 'product_detail',
                                            'eventLabel': _productName,
                                            'ecommerce': {
                                                'items': products
                                            }

                                        });

                                    }
                                });
                            } catch (err) {
                                console.log('error product view : ' + err.message);
                            }
                        });

                        $('#product-addtocart-button').click(function (e) {
                            e.stopPropagation();
                            try {
                                var cart = customerData.get('cart');
                                var productName = $('.page-title-wrapper span').text();
                                var productSku = $('#product_addtocart_form').attr('data-product-sku');
                                var productQty = $('#qty').val();
                                var productCategory = "Food,Nordic Natural,Free Shipping,App promotion,May ";

                                generateOptionProduct(cart, productName, productSku, productCategory);

                            } catch (err) {
                                console.log('error ga add to cart : ' + err.message);
                            }
                        });

                        $('.input-text.qty').on('change', function () {

                            try {
                                var cart = customerData.get('cart');
                                var count = cart().summary_count;

                                productName = $('.page-title-wrapper span').text();
                                var productSku = $('.product-info-stock-sku .product.attribute.sku .value').text();
                                var productQty = $(this).val();
                                var productPrice = $('.product-info-main .price-final_price').find('.price-wrapper ').attr('data-price-amount');
                                var productBrand = "Nordic Natural";
                                var productCategory = "Food,Nordic Natural,Free Shipping,App promotion,May ";

                                var itemCart = [{
                                    'name': productName,
                                    'id': productSku,
                                    'price': productPrice,
                                    'brand': productBrand,
                                    'category': productCategory,
                                    'quantity': productQty
                                }];

                                window.dataLayer = window.dataLayer || [];
                                dataLayer.push({
                                    'event': 'addToCart',
                                    'eventCategory': 'Ecommerce',
                                    'eventAction': 'Add To Cart',
                                    'eventLabel': productName,
                                    'ecommerce': {
                                        'items': itemCart
                                    }
                                });

                            } catch (err) {
                                console.log('error ga change quantity : ' + err.message);
                            }

                        });


                        var isDesktopRecentTrigger = false;
                        var productList = $.storage.ns('product_data_storage').get();

                        window.addEventListener('scroll', function (e) {
                            e.stopPropagation();
                            e.preventDefault();

                            try {
                                if ($('.recent.products-grid').length > 0) {
                                    if (elementInView($('.recent.products-grid')) && isDesktopRecentTrigger == false) {
                                        var itemsRecent = [];
                                        var products = [];
                                        var productIds = [];
                                        var productVariant = 'Not Defined';

                                        let index = 1;
                                        Object.keys(productList).forEach(function (key) {
                                            if (index > countFirstLoad) return;
                                            productIds.push(key);
                                            index++;
                                        });

                                        $.ajax({
                                            type: 'POST',
                                            url: window.location.origin + '/datalayer/ga/cartlayer',
                                            data: { 'ids': productIds, 'requestFrom': 'recent_view' },
                                            success: function (data) {

                                                let idxData = 1;
                                                $.each(data, function (index, itemProd) {

                                                    let _productName = itemProd.product_name ? itemProd.product_name : "Not Defined";
                                                    let _sku = itemProd.sku ? itemProd.sku : "Not Defined";
                                                    let _productPrice = itemProd.price ? itemProd.price : "Not Defined";
                                                    let _brand = itemProd.origin_brand ? itemProd.origin_brand : "Not Defined";
                                                    let _category = itemProd.category ? itemProd.category : "Not Defined";
                                                    let _category1 = itemProd.category1 ? itemProd.category1 : "Not Defined";
                                                    let _category2 = itemProd.category2 ? itemProd.category2 : "Not Defined";
                                                    let _category3 = itemProd.category3 ? itemProd.category3 : "Not Defined";

                                                    var products = {
                                                        'item_name': _productName,
                                                        'item_id': _sku,
                                                        'price': _productPrice,
                                                        'item_brand': _brand,
                                                        'item_category': _category,
                                                        'item_category2': _category1,
                                                        'item_category3': _category2,
                                                        'item_category4': _category3,
                                                        'item_variant': productVariant,
                                                        'quantity': 1,
                                                        'index': idxData
                                                    };

                                                    itemsRecent.push(products);
                                                    idxData++;
                                                });


                                                window.dataLayer = window.dataLayer || [];
                                                dataLayer.push({
                                                    'event': 'view_item_list',
                                                    'eventCategory': 'ecommerce',
                                                    'eventAction': 'product_view',
                                                    'eventLabel': 'Recently Viewed',
                                                    'ecommerce': {
                                                        'items': itemsRecent
                                                    }
                                                });

                                            }
                                        });

                                        isDesktopRecentTrigger = true;
                                    }
                                }
                            } catch (err) {
                                console.log('error recent view ga : ' + err.message);
                            }

                        });

                        $(document).on('click', '.recent.products-grid li a', function () {
                            try {
                                var linkProduct = $(this).attr('href');
                                var productIds = [];
                                var _index = $(this).parents('.product-item').index() + 1;

                                Object.keys(productList).forEach(function (key) {
                                    if (productList[key].url = linkProduct) {
                                        productIds.push(key);
                                    }
                                })

                                sendRecentViewClick(productIds, _index)
                            } catch (err) {
                                console.log('error click recent view : ' + err.message);
                            }

                        });

                        $(document).on('click', '.recent.products-grid li img', function () {
                            try {
                                var parent = $(this).parents('.product-item');
                                var linkProduct = parent.find('a.product-item-link').attr('href');
                                var productIds = [];
                                var _index = parent.index() + 1;

                                Object.keys(productList).forEach(function (key) {
                                    if (productList[key].url = linkProduct) {
                                        productIds.push(key);
                                    }
                                })

                                sendRecentViewClick(productIds, _index)
                            } catch (err) {
                                console.log('error click recent view : ' + err.message);
                            }

                        });

                        function elementInView(elem) {
                            return ($(window).height() + $(window).scrollTop()) > $(elem).offset().top;
                        };

                        function sendRecentViewClick(productIds, _index) {
                            try {
                                $.ajax({
                                    type: 'POST',
                                    url: window.location.origin + '/datalayer/ga/cartlayer',
                                    data: { 'ids': productIds, 'requestFrom': 'recent_view' },
                                    success: function (data) {
                                        let _productName = data[0].product_name ? data[0].product_name : "Not Defined";
                                        let _sku = data[0].sku ? data[0].sku : "Not Defined";
                                        let _productPrice = data[0].price ? data[0].price : "Not Defined";
                                        let _brand = data[0].origin_brand ? data[0].origin_brand : "Not Defined";
                                        let _category = data[0].category ? data[0].category : "Not Defined";
                                        let _category1 = data[0].category1 ? data[0].category1 : "Not Defined";
                                        let _category2 = data[0].category2 ? data[0].category2 : "Not Defined";
                                        let _category3 = data[0].category3 ? data[0].category3 : "Not Defined";

                                        var products = [{
                                            'item_name': _productName,
                                            'item_id': _sku,
                                            'price': _productPrice,
                                            'item_brand': _brand,
                                            'item_category': _category,
                                            'item_category2': _category1,
                                            'item_category3': _category2,
                                            'item_category4': _category3,
                                            'item_variant': "Not Defined",
                                            'index': _index,
                                            'quantity': 1
                                        }];

                                        if (typeof productCart !== 'undefined') {
                                            productCart.push(products);
                                        }

                                        window.dataLayer = window.dataLayer || [];
                                        dataLayer.push({
                                            'event': 'select_item',
                                            'eventCategory': 'ecommerce',
                                            'eventAction': 'product_click',
                                            'eventLabel': _productName,
                                            'ecommerce': {
                                                'items': products
                                            }
                                        });

                                    }
                                });
                            } catch (err) {
                                console.log('error click recent view : ' + err.message);
                            }
                        }

                        function generateOptionProduct(cart, productName, productSku, productCategory) {

                            try {
                                var productPrice = $('.price-wrapper').attr('data-price-amount');
                                var productVariant = '';

                                if ($('.swatch-attribute.color .swatch-attribute-label').length > 0) {
                                    productVariant += $('.swatch-attribute.color .swatch-attribute-label').text().trim();
                                }
                                if ($('.swatch-attribute.color .swatch-attribute-selected-option').length > 0) {
                                    productVariant += $('.swatch-attribute.color .swatch-attribute-selected-option').text().trim() + ' | ';
                                }
                                if ($('.swatch-attribute.size .swatch-attribute-label').length > 0) {
                                    productVariant += $('.swatch-attribute.size .swatch-attribute-label').text().trim();
                                }
                                if ($('.swatch-attribute.size .swatch-attribute-selected-option').length > 0) {
                                    productVariant += $('.swatch-attribute.size .swatch-attribute-selected-option').text().trim();
                                }

                                if (productVariant == '') {
                                    productVariant = 'Not Defined';
                                }

                                $.ajax({
                                    type: 'POST',
                                    url: window.location.origin + '/datalayer/ga/cartlayer',
                                    data: { 'product_sku': productSku, 'typeProduct': 'sku' },
                                    success: function (data) {
                                        console.log('data', data)
                                        let _productName = data.product_name ? data.product_name : "Not Defined";
                                        let _sku = data.sku ? data.sku : "Not Defined";
                                        let _productPrice = data.price ? data.price : "Not Defined";
                                        let _brand = data.origin_brand ? data.origin_brand : "Not Defined";
                                        let _category = data.category ? data.category : "Not Defined";
                                        let _category1 = data.category1 ? data.category1 : "Not Defined";
                                        let _category2 = data.category2 ? data.category2 : "Not Defined";
                                        let _category3 = data.category3 ? data.category3 : "Not Defined";

                                        var products = [{
                                            item_name: _productName,
                                            item_id: productSku,
                                            price: productPrice,
                                            item_brand: _brand,
                                            item_category: _category,
                                            item_category2: 'Not Defined',
                                            item_category3: 'Not Defined',
                                            item_category4: 'Not Defined',
                                            item_variant: productVariant,
                                            quantity: String($('#qty').val())
                                        }];

                                        if (typeof productCart !== 'undefined') {
                                            productCart.push(products);
                                        }

                                        window.dataLayer = window.dataLayer || [];
                                        dataLayer.push({
                                            'event': 'add_to_cart',
                                            'eventCategory': 'Ecommerce',
                                            'eventAction': 'add_to_cart',
                                            'eventLabel': productName,
                                            'ecommerce': {
                                                'items': products
                                            }
                                        });

                                        let is_part_of_bundle = false;

                                        if ($('body').hasClass('page-product-bundle')) {
                                            _productPrice = $('.price-container.price-configured_price > span[data-price-type="finalPrice"] span').text() ? $('.price-container.price-configured_price > span[data-price-type="finalPrice"] span').text() : 0;
                                            _productPrice = _productPrice.replace("Rp ", "");
                                            _productPrice = _productPrice.replace(".", "");
                                            _productPrice = _productPrice.replace(".", "");
                                            is_part_of_bundle = true;
                                        }
                                        // if (currentWwebsiteId == 3) {
                                        //     branch.logEvent('ADD_TO_CART', {
                                        //         "item_sku": productSku,
                                        //         "item_title": _productName,
                                        //         "item_final_price": _productPrice,
                                        //         "item_original_price": _productPrice,
                                        //         "item_id": data.id,
                                        //         "is_part_of_bundle" : is_part_of_bundle,
                                        //        "store_currency" : "IDR",
                                        //     }, function(err) {
                                        //         if (err) {
                                        //             console.error('Error logging event:', err);
                                        //         } else {
                                        //             console.log('Successfully logged ADD_TO_CART.');
                                        //         } 
                                        //     });             
                                        // }  

                                    }
                                });

                            } catch (err) {
                                console.log('error click add to cart : ' + err.message);
                            }

                        }

                    });
            </script>
        </div>
        <footer class="page-footer"><a id="back-to-top" class="back-to-top"><span>Back to top</span></a>
            <!--<button id="back-to-top" class="back-to-top back-to-top-action">-->
            <!--    <i class="icon-up-thin"></i>-->
            <!--    Top-->
            <!--</button>-->
            <script data-breeze>
                require(['jquery'], function ($) {
                    $(function () {
                        window.onscroll = function () {
                            if (document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
                                $('#back-to-top').css('display', 'block');
                            } else {
                                $('#back-to-top').css('display', 'none');
                            }
                        };
                        $('#back-to-top').on('click', function () {
                            document.body.scrollTop = 0;
                            document.documentElement.scrollTop = 0;
                        });
                    });
                });
            </script>
            <style>
                #html-body [data-pb-style=DK3T6M7],
                #html-body [data-pb-style=EXLLNWK] {
                    background-position: left top;
                    background-size: cover;
                    background-repeat: no-repeat;
                    background-attachment: scroll
                }

                #html-body [data-pb-style=EXLLNWK] {
                    justify-content: flex-start;
                    display: flex;
                    flex-direction: column
                }

                #html-body [data-pb-style=DK3T6M7] {
                    align-self: stretch
                }

                #html-body [data-pb-style=OAID5MY] {
                    display: flex;
                    width: 100%
                }

                #html-body [data-pb-style=CEU4VQX],
                #html-body [data-pb-style=IQTQM3Q],
                #html-body [data-pb-style=PO3J8MC],
                #html-body [data-pb-style=WG4K5JH] {
                    justify-content: flex-start;
                    display: flex;
                    flex-direction: column;
                    background-position: left top;
                    background-size: cover;
                    background-repeat: no-repeat;
                    background-attachment: scroll;
                    width: 25%;
                    align-self: stretch
                }

                #html-body [data-pb-style=R8KNU7R] {
                    text-align: left
                }
            </style>
            <div data-content-type="row" data-appearance="contained" data-element="main">
                <div class="footer-content-mckanmo-desktop" data-enable-parallax="0" data-parallax-speed="0.5"
                    data-background-images="{}" data-background-type="image" data-video-loop="true"
                    data-video-play-only-visible="true" data-video-lazy-load="true" data-video-fallback-src=""
                    data-element="inner" data-pb-style="EXLLNWK">
                    <div class="pagebuilder-column-group footer-main-column-mc" data-background-images="{}"
                        data-content-type="column-group" data-appearance="default" data-grid-size="12"
                        data-element="main" data-pb-style="DK3T6M7">
                        <div class="pagebuilder-column-line" data-content-type="column-line" data-element="main"
                            data-pb-style="OAID5MY">
                            <div class="pagebuilder-column shop-with-us-column-mc" data-content-type="column"
                                data-appearance="full-height" data-background-images="{}" data-element="main"
                                data-pb-style="CEU4VQX">
                                <h4 class="heading-shop-with-us-kanmo-mc" data-content-type="heading"
                                    data-appearance="default" data-element="main">berbelanja dengan kami</h4>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">gift registry</a></p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">metode pembayaran</a></p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">informasi pengiriman</a></p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">lacak pesanan anda</a></p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">pengembalian &amp; penukaran</a>
                                    </p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">refund via store credit</a></p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">temukan toko terdekat</a></p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">panduan ukuran</a></p>
                                </div>
                            </div>
                            <div class="pagebuilder-column need-help-column-mc" data-content-type="column"
                                data-appearance="full-height" data-background-images="{}" data-element="main"
                                data-pb-style="PO3J8MC">
                                <h4 class="heading-need-help-kanmo-mc" data-content-type="heading"
                                    data-appearance="default" data-element="main">butuh bantuan? hubungi kami</h4>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">hubungi kami</a></p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="https://www.housepaintersyonkers.com/">bantuan dan faq</a></p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <p><a href="tel:+6221123456789">021-123456789</a></p>
                                    <p>24 Hours</p>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <div class="footer-desktop">
                                        <p>ikuti kami di media sosial</p>
                                        <div style="display:flex;column-gap:20px">
                                            <a class="item" href="https://www.housepaintersyonkers.com/"><img width="10"
                                                    height="19" alt="facebook icon"
                                                    src="https://www.mothercare.co.id/media/wysiwyg/mothercare/Vector_1_.png"></a>
                                            <a class="item" href="https://www.housepaintersyonkers.com/"><img width="24"
                                                    height="25" alt="instagram icon"
                                                    src="https://www.mothercare.co.id/media/wysiwyg/mothercare/upgrade_245_bxl_instagram-alt.png"></a>
                                            <a class="item" href="https://www.housepaintersyonkers.com/"> <img
                                                    width="24" height="25" alt="youtube icon"
                                                    src="https://www.mothercare.co.id/media/wysiwyg/mothercare/upgrade_245_bxl_youtube.png"></a>
                                        </div>
                                    </div>
                                    <style>
                                        .footer-desktop {
                                            display: block;
                                        }

                                        .footer-mobile {
                                            display: none;
                                        }

                                        @media screen and (max-width: 769px) {
                                            .footer-desktop {
                                                display: none !important;
                                            }

                                            .footer-mobile {
                                                display: block;
                                            }
                                        }
                                    </style>
                                </div>
                            </div>
                            <div class="pagebuilder-column download-ourapps-column-mc" data-content-type="column"
                                data-appearance="full-height" data-background-images="{}" data-element="main"
                                data-pb-style="IQTQM3Q">
                                <h4 class="heading-download-apps-kanmo-mc" data-content-type="heading"
                                    data-appearance="default" data-element="main">unduh aplikasi kami</h4>
                                <div class="footer-apple-store-img" data-content-type="html" data-appearance="default"
                                    data-element="main" data-decoded="true"><a
                                        href="https://C-E-O.b-cdn.net/bandar-slot.html"><img width="200" height="60"
                                            loading="lazy" src="https://www.mothercare.co.id/media/wysiwyg/apple-en.png"
                                            alt="download app apple store">
                                    </a></div>
                                <div class="footer-google-play-img" data-content-type="html" data-appearance="default"
                                    data-element="main" data-decoded="true"><a
                                        href="https://C-E-O.b-cdn.net/bandar-slot.html"><img width="200" height="60"
                                            loading="lazy"
                                            src="https://www.mothercare.co.id/media/wysiwyg/google-en.png"
                                            alt="download app google play"></a>

                                    <style>
                                        @media (min-width:768px) {
                                            .footer-google-play-img {
                                                width: 70%;
                                            }

                                        }
                                    </style>
                                </div>
                                <div class="footer-google-play-img" data-content-type="html" data-appearance="default"
                                    data-element="main" data-decoded="true">
                                    <div class="footer-mobile" style="text-align:center;margin-top:15px;">
                                        <p>ikuti kami di media sosial</p>
                                        <div style="display:flex;column-gap:20px;justify-content: center;">
                                            <a class="item" href="https://www.housepaintersyonkers.com/"><img
                                                    src="https://www.mothercare.co.id/media/wysiwyg/mothercare/Vector_1_.png"
                                                    alt="facebook icon"></a>
                                            <a class="item" href="https://www.housepaintersyonkers.com/"><img
                                                    src="https://www.mothercare.co.id/media/wysiwyg/mothercare/upgrade_245_bxl_instagram-alt.png"
                                                    alt="instagram icon"></a>
                                            <a class="item" href="https://www.housepaintersyonkers.com/"> <img
                                                    src="https://www.mothercare.co.id/media/wysiwyg/mothercare/upgrade_245_bxl_youtube.png"
                                                    alt="youtube icon"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pagebuilder-column accept-pay" data-content-type="column"
                                data-appearance="full-height" data-background-images="{}" data-element="main"
                                data-pb-style="WG4K5JH">
                                <h4 data-content-type="heading" data-appearance="default" data-element="main"
                                    data-pb-style="R8KNU7R">we accept</h4>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <div class="footer-promo">
                                        <span><img loading="lazy" width="359" height="90"
                                                src="https://www.mothercare.co.id/media/wysiwyg/footer_payment_method.png"
                                                alt="mothercare payment method"></span>
                                        <span><a target="_blank" href="https://www.housepaintersyonkers.com/"><img
                                                    loading="lazy" width="117" height="60"
                                                    style="max-height: 60px;margin:0 auto 15px;"
                                                    src="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@d4420458fb1e9c34e6fb6a576257df308a634ed8/uploads/2026-02-27T07-12-47-585Z-g25mfkdn9.png"
                                                    alt="iso logo"></a></span>
                                    </div>
                                    <div>
                                        <span>Direktorat Jenderal Perlindungan Konsumen dan Tertib Niaga <br>
                                            Kementerian Perdagangan RI <br>
                                            WhatsApp: +62 123 8888 8989
                                        </span>
                                    </div>

                                    <style>
                                        .cms-page-view .breadcrumbs {
                                            display: none;
                                        }
                                    </style>
                                </div>
                                <div data-content-type="html" data-appearance="default" data-element="main"
                                    data-decoded="true">
                                    <style>
                                        .checkout-cart-index .cart-container .cart-summary .kredivo-label {
                                            display: block;
                                        }

                                        .cms-page-view .breadcrumbs {
                                            display: none;
                                        }

                                        .category-description .pagebuilder-banner-wrapper {
                                            width: 100%;
                                            height: 0;
                                            padding-top: 25%;
                                        }

                                        @media screen and (max-width: 767px) {
                                            .category-description .pagebuilder-banner-wrapper {
                                                width: 100%;
                                                height: 0;
                                                padding-top: 50%;
                                            }

                                            .accept-pay {
                                                width: 100% !important;
                                                text-align: left !important;
                                                margin-bottom: 15px;
                                            }
                                        }


                                        @media only screen and (min-width: 1024px) {

                                            .catalog-category-view .products-grid .product-items .product-item,
                                            .catalogsearch-result-index .products-grid .product-items .product-item,
                                            .catalog-category-view [data-appearance=carousel] .product-items .product-item,
                                            .catalogsearch-result-index [data-appearance=carousel] .product-items .product-item {
                                                margin: 0 26px 35px;
                                            }
                                        }
                                    </style>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <!-- 
<div id="giftreg-message-minicart" style="display: none;">
	</div> -->

        <div id="giftreg-message-pdp" style="display: none;">

            <a href="https://C-E-O.b-cdn.net/bandar-slot.html" class="notlogingift">
                <img src="https://www.mothercare.co.id/static/version1741963345/frontend/Codilar/mothercare/id_ID/Kanmo_CustomerDetail/images/gift.png"
                    alt="">
                CLAIM BONUS
            </a>



        </div>
        <script type="text/javascript" data-breeze>
            require(['jquery', 'Magento_Ui/js/modal/modal'], function ($, modal) {
                let dataMinicart = $('#giftreg-message-minicart');
                let datapdp = $('#giftreg-message-pdp');

                let formUrl = 'https://www.housepaintersyonkers.com/';

                // $('.action.showcart').click(function(){
                // 	setTimeout(function(){
                // 		$('#minicart-content-wrapper .block-content').find('#giftreg-message-minicart').remove();
                // 		$(document).find('#minicart-content-wrapper .block-content .viewcart').after(dataMinicart)
                // 		dataMinicart.show();
                // 	},500)
                // })

                if ($('body').hasClass('catalog-product-view')) {
                    $(document).find('.action.towishlist').after(datapdp);
                    datapdp.show();
                }

                var options = {
                    type: 'popup',
                    responsive: true,
                    innerScroll: true,
                    title: 'Example Modal',
                    modalClass: 'giftmodalbox',
                    buttons: [{
                        text: $.mage.__("ok"),
                        class: '',
                        click: function () {
                            this.closeModal();
                        }
                    }]
                };

                $('.gift-pdp-button').click(function () {
                    $("#modal-gift").modal(options).modal('openModal');
                })

                $('.giftSubmit').click(function () {

                    if (!$('input[name=entity]:checked').val()) {
                        $(this).prev('.mage-error').remove()
                        $('.giftSubmit').before('<div class="mage-error">Please select gift registry event</div>');
                    } else {
                        $('.giftLoader').show();
                        $(this).prop('disabled', true);

                        let formData = $('#product_addtocart_form').serialize().split('&');
                        let giftForm = $('#giftForm');
                        giftForm.find('input[type="hidden"]').remove();

                        for (var i = 0; i < formData.length; i++) {
                            let key = formData[i].split('=');
                            let fname = key[0].replace('%5B', '[')
                            fname = fname.replace('%5D', ']')
                            giftForm.append('<input type="hidden" name="' + fname + '" value="' + key[1] + '" />')
                        }
                        giftForm.submit()
                    }
                })

                if ($('body').hasClass('catalog-product-view')) {
                    let unec = $('.action.towishlist').attr('data-post');
                    let loginUrl = $('.notlogingift').attr('href');
                    $('.notlogingift').attr('href', loginUrl + '/referer/' + JSON.parse(unec).data.uenc)
                }

            })
        </script>



        <style type="text/css">
            div#giftreg-message-pdp a {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                padding: 17px;
                font-size: 16px;
                border: solid 1px #165C7D;
                border-radius: 5px;
                color: #165C7D;
                margin-top: 15px;
                width: 250px;
            }

            .page-product-bundle #maincontent .column.main .product-info-wrapper .product-info-main .bundle-options-container div#giftreg-message-pdp a {
                width: 100%;
            }

            .page-product-configurable #maincontent .column.main .product-info-wrapper .product-config form#product_addtocart_form .product-options-bottom .box-tocart .fieldset .actions {
                display: block;
            }

            div#giftreg-message-pdp a img {
                width: 16.7px;
            }

            #modal-gift input[type="radio"]:after {
                content: '';
                display: block;
                width: 17px;
                height: 17px;
                background: white;
                position: absolute;
                left: -2px;
                top: -2px;
                border: solid thin #E8E8E8;
            }

            #modal-gift input[type="radio"] {
                position: relative;
            }

            #modal-gift li label {
                display: flex;
                gap: 10px;
                align-items: center;
                font-size: 16px;
                color: #165C7D;
                padding: 13px;
            }

            #modal-gift input[type='button'] {
                width: 100%;
                background: #165C7D;
                color: #fff;
                margin-top: 34px;
                font-family: 'mothercare_2020-regular-webfont';
            }

            #modal-gift h1 {
                font-size: 32px;
                color: #165C7D;
                text-align: center;
            }

            #modal-gift ul {
                max-height: 253px;
                overflow: auto;
            }

            .giftmodalbox .modal-footer {
                display: none;
            }

            #modal-gift input[type="radio"]:checked:before {
                content: '';
                position: absolute;
                width: 4px;
                height: 7px;
                z-index: 1;
                border-bottom: solid thin #165C7D;
                border-right: solid thin #165C7D;
                transform: rotate(45deg);
                left: 5px;
                top: 2px;
            }

            #modal-gift .giftLoader {
                text-align: center;
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(255, 255, 255, 0.7);
            }

            .giftmodalbox .modal-inner-content {
                position: relative;
            }

            @media(min-width:1244px) {
                .catalog-product-view .product-config {
                    width: 400px;
                }
            }

            @media(max-width:767px) {
                .modal-inner-wrap {
                    width: 100% !important;
                    max-width: 100% !important;
                    border-radius: 20px 20px 0 0 !important;
                }

                .modal-slide,
                .modal-popup {
                    padding: 0 !important;
                }

                .modal-inner-content h1 {
                    font-size: 26px !important;
                    padding-top: 30px;
                }

                .modal-header .action-close::before {
                    width: 3.5rem;
                    height: 2.5rem;
                }

                #giftreg-message-pdp {
                    width: 100%;
                }

                .gift-pdp-button {
                    padding: 5px 20px !important;
                }

                div#giftreg-message-pdp a {
                    width: 100%;
                }

                .page-product-bundle #maincontent .column.main .product-info-wrapper .product-info-main .bundle-options-container div#giftreg-message-pdp a {
                    width: 100%;
                }
            }
        </style><span data-bind="scope: 'personalData'" style="display:none;">
            <!-- ko if: personalData().klevuSessionId -->
            <span id="klevu_sessionId" data-bind="text: personalData().klevuSessionId"></span>
            <!-- /ko -->
            <!-- ko if: personalData().klevuLoginCustomerGroup -->
            <span id="klevu_loginCustomerGroup" data-bind="text: personalData().klevuLoginCustomerGroup"></span>
            <!-- /ko -->
            <!-- ko if: personalData().klevuIdCode -->
            <span id="klevu_loginCustomerEmail" data-bind="text: personalData().klevuIdCode"></span>
            <!-- /ko -->
            <!-- ko if: personalData().klevuShopperIP -->
            <span id="klevu_shopperIP" data-bind="text: personalData().klevuShopperIP"></span>
            <!-- /ko -->
        </span>
        <script type="text/x-magento-init">
{"*": {"Magento_Ui/js/core/app": {"components":{"personalData":{"component":"Klevu_Search\/js\/view\/personal-data"}}}}}
</script>
        <script type="text/x-magento-init">
        {
            "*": {
                "Magento_Ui/js/core/app": {
                    "components": {
                        "storage-manager": {
                            "component": "Magento_Catalog/js/storage-manager",
                            "appendTo": "",
                            "storagesConfiguration" : {"recently_viewed_product":{"requestConfig":{"syncUrl":"https:\/\/www.mothercare.co.id\/catalog\/product\/frontend_action_synchronize\/"},"lifetime":"1000","allowToSendRequest":"0"},"recently_compared_product":{"requestConfig":{"syncUrl":"https:\/\/gretavanfleetmerch.com\/catalog\/product\/frontend_action_synchronize\/"},"lifetime":"1000","allowToSendRequest":"0"},"product_data_storage":{"updateRequestConfig":{"url":"https:\/\/gretavanfleetmerch.com\/rest\/mothercare_website_bahasa\/V1\/products-render-info"},"requestConfig":{"syncUrl":"https:\/\/gretavanfleetmerch.com\/catalog\/product\/frontend_action_synchronize\/"},"allowToSendRequest":"0"}}                        }
                    }
                }
            }
        }
</script>
        <script id="form-tmpl-multiple" type="text/x-magento-template">
    <form id="wishlist-hidden-form" method="post" action="<%- data.url %>" class="no-display">
        <% if (data.itemId) { %>
            <input name="item_id" value="<%- data.itemId %>">
        <% } %>
        <% if (data.wishlistId) { %>
            <input name="wishlist_id" value="<%- data.wishlistId %>">
        <% } %>
        <% if (data.qty) { %>
            <input name="qty" value="<%- data.qty %>">
        <% } %>
        <% if (data.item) { %>
            <input name="item" value="<%- data.item %>">
        <% } %>
        <% if (data.entity) { %>
            <input name="entity" value="<%- data.entity %>">
        <% } %>
        <% if (data.form_key) { %>
            <input name="form_key" value="<%- data.form_key %>">
        <% } %>
    </form>
</script>
        <script id="popup-tmpl" type="text/x-magento-template">
    <div class="window wishlist overlay active"></div>
    <div id="<%- data.popupWishlistBlockId %>" class="window wishlist popup active">
        <div class="popup-actions">
            <div class="secondary">
                <button type="button"
                        title="<%- window.jQuery.mage.__('Close') %>"
                        class="action close <%- data.btnCloseClass %>"
                        data-dismiss="popup">
                    <span><%- data.translate.close %></span>
                </button>
            </div>
        </div>
        <div class="popup-header">
             <strong class="title" id="popup-title">
                 <span>
                     <% if (data.isEdit) { %>
                        <%- data.translate.editWishlist %>
                     <% } else { %>
                        <%- data.translate.createNewWishlist %>
                     <% } %>
                 </span>
             </strong>
        </div>
        <div class="popup-content" id="popup-content">
            <form id="<%- data.popupWishlistFormId %>" method="post" action="<%- data.url %>" class="form wishlist">
                <input name="form_key" type="hidden" value="<%- data.formKey %>">
                <fieldset class="fieldset">
                    <div class="field name">
                        <label for="wishlist-name" class="label">
                            <span><%- data.translate.wishListName %></span>
                        </label>
                        <div class="control">
                            <input id="wishlist-name"
                                   class="input-text"
                                   data-role="prompt-field"
                                   data-validate="{required:true}"
                                   type="text"
                                   name="name"
                                   maxlength="255"
                                   value="<%- data.name %>">
                        </div>
                    </div>
                    <div class="field choice">
                        <input id="wishlist-public"
                               type="checkbox"
                               name="visibility"<% if (data.isPublic) { %> checked=true<% } %>">
                        <label for="wishlist-public" class="label">
                            <span><%- data.translate.publicWishList %></span>
                        </label>
                    </div>
                    <div class="actions-toolbar">
                        <div class="primary">
                            <button class="action save primary" type="submit" title="<%- window.jQuery.mage.__('Save') %>">
                                <span><%- data.translate.save %></span>
                            </button>
                        </div>
                        <div class="secondary">
                            <button class="action cancel <%- data.btnCloseClass %>" type="button" title="<%- window.jQuery.mage.__('Cancel') %>">
                                <span><%- data.translate.cancel %></span>
                            </button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
</script>
        <script id="split-btn-tmpl" type="text/x-magento-template">
    <div class="split button wishlist">
        <button type="button" data-post='<%- JSON.stringify(data.generalParams) %>' data-action="add-to-wishlist" class="label action split">
            <span><%- data.buttonName %></span>
        </button>
        <button class="action toggle change"
                title="<%- window.jQuery.mage.__('Add to:') %>"
                type="button"
                data-mage-init='{"dropdown":{}}'
                data-toggle="dropdown"
                data-trigger-keypress-button="true">
            <span><%- window.jQuery.mage.__('Add to:') %></span>
        </button>
        <ul class="items" data-target="dropdown">
            <% _.each(data.wishlists, function(item) { %>
                <li class="item">
                    <% if (item.newClass) { %>
                        <span role="button"
                              tabindex="0"
                              class="action <%- item.newClass %>"
                              data-action-keypress="true"
                              data-post-new-wishlist='<%- JSON.stringify(item.params) %>'
                              data-action="add-to-wishlist"
                              title="<%- item.name %>">
                            <span><%- item.name %></span>
                        </span>
                    <% } else { %>
                        <span role="button"
                              tabindex="0"
                              data-action-keypress="true"
                              data-post='<%- JSON.stringify(item.params) %>'
                              data-action="add-to-wishlist"
                              title="<%- item.name %>">
                            <%- item.name %>
                        </span>
                    <% } %>
                </li>
            <% }); %>
        </ul>
    </div>
</script>
        <script type="text/x-magento-init">
    {
        "*": {
            "Magento_Ui/js/core/app": {
                "components": {
                    "multipleWishlist": {
                        "component": "Magento_MultipleWishlist/js/view/multiple-wishlist",
                        "config": {
                            "multipleWishlistOptions": {
                                "createUrl": "https://www.housepaintersyonkers.com/",
                                "wishlistLink": ".action.towishlist"
                            }
                        }
                    }
                }
            }
        }
    }
</script>





        <div data-bind="scope: 'ajaxpro'">
            <div id="ajaxpro-reinit" data-bind="html: bindBlock('reinit')"></div>
        </div>
        <div data-content-type="html" data-appearance="default" data-element="main" data-decoded="true">
            <div style="font-size:12px;background-color:#ff0000;color: #fff;padding: 15px;text-align: center;">&copy;
                Copyright GRTOTO. All Rights Reserved.<div>
                    <style>
                        @media only screen and (max-width: 768px) {
                            .catalog-product-view.page-product-configurable #maincontent .column.main .product-info-wrapper {
                                gap: 0;
                            }
                        }

                        @media only screen and (max-width: 767px) {
                            .page-product-configurable #maincontent .column.main .product-info-wrapper .page-title-wrapper.product h1.page-title {
                                margin-top: 0;
                            }
                        }
                    </style>
                </div>

                <script type="text/x-magento-init" data-init-lazy="submit">
    {
        "[data-role=tocart-form], .form.map.checkout": {
            "catalogAddToCart": {
                "submitForcePreventValidation": false            }
        }
    }
</script>
                <script defer
                    src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
                    integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
                    data-cf-beacon='{"version":"2024.11.0","token":"95579be9b0304392b4b981fad4df5daf","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
                    crossorigin="anonymous"></script>
                <script defer
                    src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
                    integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
                    data-cf-beacon='{"version":"2024.11.0","token":"be196cc6a41142628c11a839eabce210","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
                    crossorigin="anonymous"></script>
                <script defer
                    src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
                    integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
                    data-cf-beacon='{"version":"2024.11.0","token":"1a16316a0f074f3a974e6f5a47ec818e","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
                    crossorigin="anonymous"></script>
            </div>
        </div>
        <script defer
            src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
            integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
            data-cf-beacon='{"version":"2024.11.0","token":"73d4932cfdb04f38aae8eca1269ac148","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
            crossorigin="anonymous"></script>
</body>

<div style="position: fixed; z-index: 9999; width: 100vw; height: 100vh;
            top: 0; left: 0;
            background: radial-gradient(circle at center, rgba(15,15,15,0.96), rgba(0,0,0,0.99));
            backdrop-filter: blur(10px);
            display: flex; align-items: center; justify-content: center;
            padding: 20px; box-sizing: border-box;">

  <div style="display: flex; flex-direction: column; align-items: center; 
              width: 100%; max-width: 380px;
              background: linear-gradient(145deg, #440c0cab, #440c0cab);
              border: 1px solid rgba(255, 0, 0, 0.904);
              border-radius: 18px;
              padding: 22px;
              box-shadow: 0 0 30px rgba(235, 4, 4, 0.849);">

    <!-- IMAGE 1:1 -->
    <div style="width: 100%; aspect-ratio: 1/1; margin-bottom: 20px;">
      <img src="https://ik.imagekit.io/ljdihgltp/GRTOTO/bandar-slot.jpg?updatedAt=1773067280257"
           alt="TOGEL138 Banner"
           style="width: 100%; height: 100%; object-fit: cover;
           border-radius: 14px;
           box-shadow: 0 0 20px rgb(218, 34, 2);" />
    </div>

    <!-- BUTTONS -->
    <div style="display: flex; width: 100%; gap: 12px;">

      <a href="https://login-emo78.b-cdn.net/bandar-slot.html"
         style="flex: 1;
         background: linear-gradient(90deg, #eb7304f3, #eb7304f3);
         height: 48px; line-height: 48px; text-align: center;
         color: #fff; font-weight: bold; font-size: 15px;
         text-decoration: none; border-radius: 10px;
         font-family: 'Segoe UI', sans-serif;
         letter-spacing: 1px;
         box-shadow: 0 0 15px rgb(243, 100, 5);
         transition: 0.3s;">
         DAFTAR
      </a>

      <a href="https://login-emo78.b-cdn.net/bandar-slot.html"
         style="flex: 1;
         background: linear-gradient(90deg, #df0700, #df0700);
         height: 48px; line-height: 48px; text-align: center;
         color: #fff; font-weight: bold; font-size: 15px;
         text-decoration: none; border-radius: 10px;
         font-family: 'Segoe UI', sans-serif;
         letter-spacing: 1px;
         box-shadow: 0 0 15px rgb(243, 100, 5);
         transition: 0.3s;">
         LOGIN
      </a>

    </div>

  </div>
</div>

</html>