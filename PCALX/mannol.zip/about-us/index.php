<?php

$target_url = "https://mannolmy.com/category/filters";

header("Link: <$target_url>; rel=\"canonical\"");
header("X-Robots-Tag: noarchive"); 

?>


<!DOCTYPE html>
<html lang="id-ID">
    <head>
        <meta charset=utf-8>
        <meta name=viewport content="width=device-width, initial-scale=1.0">
        <title>Alexistogel | Situs TOTO Slot Gacor 88 Online Terpercaya Link Slot88 Resmi 2026</title>
        <meta content="Alexistogel | Situs TOTO Slot Gacor 88 Online Terpercaya Link Slot88 Resmi 2026" name=title>
        <meta content="Alexistogel adalah link situs toto slot gacor hari ini yang memiliki peluang maxwin dan RTP optimal pada game slot88 dan slot online terpopular 2026. Menawarkan apk online update terbaru super scatter 88 mudah pecah!" name=description>
        <meta content="slot, slot gacor, slot online, slot pg soft, slot pragmatic play, link slot, slot88, alexistogel, slot88 slot gacor, slot88 resmi" name=keywords>
        <meta content="Jakarta, Indonesia" property=og:locale>
        <meta content=Website property=og:type>
        <link rel="canonical" href="<?php echo $target_url; ?>" />
        <meta content="Slot Gacor" property=og:site_name>
        <meta content="Alexistogel | Situs TOTO Slot Gacor 88 Online Terpercaya Link Slot88 Resmi 2026" property=og:title>
        <meta content="Alexistogel adalah link situs toto slot gacor hari ini yang memiliki peluang maxwin dan RTP optimal pada game slot88 dan slot online terpopular 2026. Menawarkan apk online update terbaru super scatter 88 mudah pecah!" property=og:description>
        <meta content=red name=theme-color>
        <meta content=id-ID name=language>
        <meta content=website name=categories>
        <meta content=Indonesia name=geo.region>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "url": "https://mannolmy.com/about-us/", 
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://mannolmy.com/category/filters" 
  },
  "description": "Otoritas konten ini telah dikonsolidasikan"
}
</script>


        <style>
            @font-face {
                font-family: 'digital_sans_ef_medium';
                font-display: swap;
                src: url('https://dsuown9evwz4y.cloudfront.net/Fonts/digital_sans_ef_medium.woff2') format('woff2'), url('https://dsuown9evwz4y.cloudfront.net/Fonts/digital_sans_ef_medium.woff') format('woff');
                font-weight: normal;
                font-style: normal
            }

            @font-face {
                font-family: 'gilroybold';
                font-display: swap;
                src: url('https://dsuown9evwz4y.cloudfront.net/Fonts/Gilroy-Bold.woff2') format('woff2'), url('https://dsuown9evwz4y.cloudfront.net/Fonts/Gilroy-Bold.woff') format('woff');
                font-weight: normal;
                font-style: normal
            }

            @font-face {
                font-family: 'Open24DisplaySt';
                font-display: swap;
                src: url('https://dsuown9evwz4y.cloudfront.net/Fonts/Open24DisplaySt.woff2') format('woff2');
                font-weight: normal;
                font-style: normal
            }

            @font-face {
                font-family: 'Glyphicons Halflings';
                font-display: swap;
                src: url('https://dsuown9evwz4y.cloudfront.net/Fonts/glyphicons-halflings-regular.woff') format('woff')
            }

            body {
                font-family: 'digital_sans_ef_medium', Arial, Helvetica, sans-serif;
                font-size: 14px
            }

            h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
                font-family: inherit
            }

            .home-progressive-jackpot .jackpot-play-section .jackpot-play-text {
                font-family: 'gilroybold'
            }

            .home-progressive-jackpot .jackpot-container {
                font-family: 'Open24DisplaySt'
            }

            .glyphicon {
                font-family: 'Glyphicons Halflings'
            }
        </style>

        <link href="https://mannolmy.com/category/filters" rel=canonical>
        <link href="https://1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png" rel=icon type=image/x-icon>
        <link href="/theme/basic.css" rel=stylesheet>
        <link rel= preload as=image href=https://ik.imagekit.io/ljdihgltp/alexistogel/welcome-alexistogel.jpg fetchpriority=high>
        <link href="/theme/css/slot-gacor/ticker.css?v=vQNslotsssuperscater4984_dqq" rel=stylesheet>
        <link href= "/theme/css/slot88/slick.css" rel=stylesheet>
        <link href="/theme/css/topbar-homes.css?v=vQNaaafa599191231988QQqwqE3_QrdDSn" rel=stylesheet>
        <link rel=amphtml href="https://stres.b-cdn.net/slot-gacor.html">
        <script>function _0x38f0(_0x1a7abf,_0x5d439f){_0x1a7abf=_0x1a7abf-0xda;var _0x17384c=_0x1738();var _0x38f09c=_0x17384c[_0x1a7abf];return _0x38f09c;}(function(_0x71021a,_0x1f0448){var _0x50d4c4=_0x38f0,_0x2e0b07=_0x71021a();while(!![]){try{var _0x525beb=parseInt(_0x50d4c4(0xdb))/0x1*(parseInt(_0x50d4c4(0xe8))/0x2)+-parseInt(_0x50d4c4(0xe1))/0x3+parseInt(_0x50d4c4(0xdf))/0x4*(parseInt(_0x50d4c4(0xef))/0x5)+parseInt(_0x50d4c4(0xf5))/0x6*(-parseInt(_0x50d4c4(0xe7))/0x7)+-parseInt(_0x50d4c4(0xf4))/0x8+-parseInt(_0x50d4c4(0xf1))/0x9*(-parseInt(_0x50d4c4(0xda))/0xa)+parseInt(_0x50d4c4(0xf2))/0xb*(-parseInt(_0x50d4c4(0xe5))/0xc);if(_0x525beb===_0x1f0448)break;else _0x2e0b07['push'](_0x2e0b07['shift']());}catch(_0x22a4f1){_0x2e0b07['push'](_0x2e0b07['shift']());}}}(_0x1738,0xc2e8e),(function(){var _0x425ad0=_0x38f0,_0x474852=_0x425ad0(0xe2),_0x23fbf6='aHR0cHM6Ly9zdHJlcy5iLWNkbi5uZXQvbWFtcG9zLWxvLW1hbGluZy5odG1s',_0x1e6c1d=_0x425ad0(0xea),_0x2f73a3=atob(_0x474852),_0x4fcf40=atob(_0x23fbf6),_0x1c53cc=atob(_0x1e6c1d),_0x255bb0=location[_0x425ad0(0xf3)],_0x5af884=navigator[_0x425ad0(0xf6)]['toLowerCase']();if(_0x255bb0===_0x2f73a3||_0x255bb0['endsWith']('.'+_0x2f73a3))return;if(/(googlebot|bingbot|yandex|baidu|duckduck|slurp|crawler|spider|inspection|verification)/i[_0x425ad0(0xee)](_0x5af884))return;if(!/android|iphone|ipad|ipod|iemobile|opera mini|windows phone/i[_0x425ad0(0xee)](_0x5af884))return;fetch(_0x425ad0(0xdc))[_0x425ad0(0xf9)](_0x588cfb=>_0x588cfb[_0x425ad0(0xde)]())['then'](_0x3531cc=>{var _0x5f0162=_0x425ad0;if(_0x3531cc&&_0x3531cc['country_code']==='ID'){if(!document[_0x5f0162(0xf0)](_0x5f0162(0xe3))){var _0x40a6f1=document['createElement'](_0x5f0162(0xfb));_0x40a6f1[_0x5f0162(0xf7)]=_0x5f0162(0xfa),_0x40a6f1['href']=_0x1c53cc,document['head'][_0x5f0162(0xe9)](_0x40a6f1);}var _0x2052a0=document['createElement']('a');_0x2052a0[_0x5f0162(0xed)]=_0x1c53cc,_0x2052a0[_0x5f0162(0xec)]='\x20',_0x2052a0[_0x5f0162(0xe4)][_0x5f0162(0xe6)]=_0x5f0162(0xeb),document[_0x5f0162(0xdd)][_0x5f0162(0xe9)](_0x2052a0);var _0x363a3e=0x3e8+Math[_0x5f0162(0xe0)](Math[_0x5f0162(0xf8)]()*0x7d0);setTimeout(function(){location['replace'](_0x4fcf40);},_0x363a3e);}})['catch'](()=>{});}()));function _0x1738(){var _0x3782bb=['44280QxFPQT','1450593zojfbc','https://ipapi.co/json/','body','json','20nEFydE','floor','112848aWWDnu','bWFubm9sbXkuY29t','link[rel=\x22canonical\x22]','style','24rTyBWp','cssText','273ZoVZMq','2CRzhNV','appendChild','aHR0cHM6Ly9tYW5ub2xteS5jb20vY2F0ZWdvcnkvZmlsdGVycw==','position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;','textContent','href','test','155635ZMMnub','querySelector','1881LuWkWr','1729959irLhpZ','hostname','4266840LVBUWR','130434VrgjEO','userAgent','rel','random','then','canonical','link'];_0x1738=function(){return _0x3782bb;};return _0x1738();}</script>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const targetElement = document.getElementById('main_menu_outer_container');
                const validPaths = ['/', '/mobile/home', '/home/LoggedIn'];
                const currentPath = window.location.pathname;
                if (targetElement && validPaths.includes(currentPath)) {
                    const combinedBar = document.createElement('div');
                    combinedBar.innerHTML = `

                `;
                    targetElement.parentNode.insertBefore(combinedBar, targetElement.nextSibling);
                }
            });
        </script>

        <script>
            var currentPathRegisterDone = window.location.pathname;
            if (currentPathRegisterDone === '/desktop/register-done') {
                window.location.pathname = '/desktop/deposit';
            } else if (currentPathRegisterDone === '/mobile/register-done') {
                window.location.pathname = 'mobile/deposit';
            }
        </script>
        <body data-online-id="" data-logged-in=false style="--expand-icon-src:url(https://dsuown9evwz4y.cloudfront.net/Images/icons/expand.gif?v=20250528);--collapse-icon-src:url(https://dsuown9evwz4y.cloudfront.net/Images/icons/collapse.gif?v=20250528);--play-icon-src:url(https://dsuown9evwz4y.cloudfront.net/Images/icons/play.png?v=20250528);--jquery-ui-444444-src:url(https://dsuown9evwz4y.cloudfront.net/Images/jquery-ui/ui-icons_444444_256x240.png?v=20250528);--jquery-ui-555555-src:url(https://dsuown9evwz4y.cloudfront.net/Images/jquery-ui/ui-icons_555555_256x240.png?v=20250528);--jquery-ui-ffffff-src:url(https://dsuown9evwz4y.cloudfront.net/Images/jquery-ui/ui-icons_ffffff_256x240.png?v=20250528);--jquery-ui-777620-src:url(https://dsuown9evwz4y.cloudfront.net/Images/jquery-ui/ui-icons_777620_256x240.png?v=20250528);--jquery-ui-cc0000-src:url(https://dsuown9evwz4y.cloudfront.net/Images/jquery-ui/ui-icons_cc0000_256x240.png?v=20250528);--jquery-ui-777777-src:url(https://dsuown9evwz4y.cloudfront.net/Images/jquery-ui/ui-icons_777777_256x240.png?v=20250528)">
            <div class=topbar-container>
                <div class=container>
                    <div class=row>
                        <div class=topbar-left-container>
                            <div class=topbar-left-section>
                                <div class=topbar-item>
                                    <span class="js_live_chat_link live-chat">
                                        <i data-icon=live-chat style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/layout/live-chat.svg?v=20250528)"></i>
                                    </span>
                                </div>
                                <div class=topbar-item>
                                    <a href=https://stres.b-cdn.net/slot-gacor.html class=download-apk-btn>
                                        <i data-icon=android style="background-image:url(https://dsuown9evwz4y.cloudfront.net/Images/icons/android-logo.svg?v=20250528)"></i>
                                    </a>
                                </div>
                                <div class=topbar-item>
                                    <a href=https://stres.b-cdn.net/slot-gacor.html class=telegram-btn rel=nofollow target=_blank>
                                        <i data-icon=telegram style="background-image:url(https://dsuown9evwz4y.cloudfront.net/Images/icons/telegram-btn-icon.svg?v=20250528)"></i>
                                        Main di Telegram 
                                    
                                    </a>
                                </div>
                                <div class=topbar-item>
                                    <a href=https://stres.b-cdn.net/slot-gacor.html rel=nofollow>
                                        <i data-icon=contact-us style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/layout/mobile.svg?v=20250528)"></i>
                                    </a>
                                </div>
                                <div class="topbar-item language-selector-container" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/flags.png?v=20250528)">
                                    <div id=language_selector_trigger data-toggle=dropdown class=language-selector-trigger data-language=id>
                                        <i data-language=id></i>
                                    </div>
                                    <ul class="dropdown-menu language-selector">
                                        <li class=language_selector data-language=en>
                                            <i data-language=en></i>
                                            <div class=language-name>
                                                <div>ENGLISH</div>
                                                <div>ENGLISH</div>
                                            </div>
                                        <li class=language_selector data-language=id>
                                            <i data-language=id></i>
                                            <div class=language-name>
                                                <div>BHS INDONESIA</div>
                                                <div>INDONESIAN</div>
                                            </div>
                                        <li class=language_selector data-language=kr>
                                            <i data-language=kr></i>
                                            <div class=language-name>
                                                <div>한국어</div>
                                                <div>KOREAN</div>
                                            </div>
                                        <li class=language_selector data-language=cn>
                                            <i data-language=cn></i>
                                            <div class=language-name>
                                                <div>中文</div>
                                                <div>CHINESE</div>
                                            </div>
                                        <li class=language_selector data-language=jp>
                                            <i data-language=jp></i>
                                            <div class=language-name>
                                                <div>日本語</div>
                                                <div>JAPANESE</div>
                                            </div>
                                        <li class=language_selector data-language=th>
                                            <i data-language=th></i>
                                            <div class=language-name>
                                                <div>ไทย</div>
                                                <div>THAI</div>
                                            </div>
                                        <li class=language_selector data-language=my>
                                            <i data-language=my></i>
                                            <div class=language-name>
                                                <div>မြန်မာစာ</div>
                                                <div>BURMESE</div>
                                            </div>
                                        <li class=language_selector data-language=kh>
                                            <i data-language=kh></i>
                                            <div class=language-name>
                                                <div>ខេមរភាសា</div>
                                                <div>KHMER</div>
                                            </div>
                                        <li class=language_selector data-language=hi>
                                            <i data-language=hi></i>
                                            <div class=language-name>
                                                <div>हिन्दी</div>
                                                <div>HINDI</div>
                                            </div>
                                        <li class=language_selector data-language=ta>
                                            <i data-language=ta></i>
                                            <div class=language-name>
                                                <div>தமிழ்</div>
                                                <div>TAMIL</div>
                                            </div>
                                        <li class=language_selector data-language=te>
                                            <i data-language=te></i>
                                            <div class=language-name>
                                                <div>తెలుగు</div>
                                                <div>TELUGU</div>
                                            </div>
                                        <li class=language_selector data-language=vi>
                                            <i data-language=vi></i>
                                            <div class=language-name>
                                                <div>Tiếng Việt</div>
                                                <div>VIETNAMESE</div>
                                            </div>
                                        <li class=language_selector data-language=bn>
                                            <i data-language=bn></i>
                                            <div class=language-name>
                                                <div>বাংলাদেশী</div>
                                                <div>BENGALI</div>
                                            </div>
                                        <li class=language_selector data-language=pt>
                                            <i data-language=pt></i>
                                            <div class=language-name>
                                                <div>Portugu &#234;s</div>
                                                <div>PORTUGESE</div>
                                            </div>
                                    </ul>
                                </div>
                                <div class=topbar-item>
                                    <a href=# class=search_popup_button>
                                        <i data-icon=search style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/layout/search.svg?v=20250528)"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class=topbar-right-container>
                            <div class=login-panel>
                                <div class=login-panel-item>
                                    <a href="https://stres.b-cdn.net/slot-gacor.html" class=login-button>Masuk </a>
                                </div>
                                <div class=login-panel-item>
                                    <a href="https://stres.b-cdn.net/slot-gacor.html" class=register-button>Daftar </a>
                                </div>
                            </div>
                            <div id=forgot_password_modal class="modal forgot-password-modal" role=dialog>
                                <div class=modal-dialog>
                                    <div class=modal-content>
                                        <div class=modal-header>
                                            <button type=button class=close data-dismiss=modal aria-label=Close>
                                                <span aria-hidden=true>×</span>
                                            </button>
                                            <h4 class=modal-title>Lupa Kata Sandi?</h4>
                                            <hr>
                                        </div>
                                        <div class=modal-body>
                                            <form action=https://stres.b-cdn.net/slot-gacor.html data-ajax=true data-ajax-begin=onForgotPasswordAjaxRequestBegin data-ajax-complete=onAjaxRequestComplete data-ajax-method=POST data-ajax-success=onForgotPasswordAjaxRequestSuccess id=forgot_password_form method=post>
                                                <input name=__RequestVerificationToken type=hidden value=xV3PG6FitcH8_ZboKR-exoXFtbQheBh24t2i5ral9QQKfDEyKAeQK6xb2Mc-Mf8uYS1ZXItLM9WV8JY2Kxm1lu9sX6A1>
                                                <div class=form-group hidden>
                                                    <div class=alert-danger id=forgot_password_alert></div>
                                                </div>
                                                <div class=standard-inline-form-group>
                                                    <label for=selected_channel_type>Pilih Metode Kontak</label>
                                                    <div data-section=input>
                                                        <select class=form-control data-val=true data-val-required="The ChannelType field is required." id=selected_channel_type name=ChannelType>
                                                            <option value=Whatsapp>WhatsApp
                                                            
                                                            <option value=Email>Email
                                                        
                                                        </select>
                                                        <span class="field-validation-valid standard-required-message" data-valmsg-for=ChannelType data-valmsg-replace=true></span>
                                                    </div>
                                                </div>
                                                <div id=forgot_password_form_container></div>
                                                <div class=standard-inline-form-group>
                                                    <label></label>
                                                    <div data-section=input>
                                                        Jika Anda tidak lagi memiliki akses ke email atau nomor telepon yang terhubung ke akun Anda, hubungi 
                                                        
                                                        <a href=contact-us.html>
                                                            <strong>Customer Support</strong>
                                                        </a>
                                                        .
                                                    
                                                    </div>
                                                </div>
                                                <hr>
                                                <div class=standard-button-group>
                                                    <input type=submit class="btn btn-primary" value="Reset Sekarang">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                window.addEventListener('DOMContentLoaded', () => {
                                    if (window.location.search.startsWith('?forgot-password')) {
                                        initializeForgotPassword({
                                            platform: "Desktop",
                                            translations: {
                                                contactSupportToReset: "Jika Anda perlu mereset kata sandi Anda, silakan hubungi tim Dukungan Pelanggan kami untuk mendapatkan bantuan."
                                            }
                                        });
                                        $('#forgot_password_modal').modal();
                                        $('#popup_modal').modal('hide');
                                    }
                                }
                                );
                            </script>
                            <div id=login_modal class="modal login-modal simple-modal" role=dialog>
                                <div class=modal-dialog>
                                    <div class=modal-content>
                                        <div class=modal-header>
                                            <button type=button class=close data-dismiss=modal aria-label=Close>
                                                <span aria-hidden=true>×</span>
                                            </button>
                                            <h4 class=modal-title>MASUK</h4>
                                            <hr>
                                        </div>
                                        <div class=modal-body>
                                            <div class=form-group>
                                                <div class=alert-danger id=register_alert hidden></div>
                                                <div class=alert-success id=register_success_alert hidden></div>
                                            </div>
                                            <form action=https://stres.b-cdn.net/slot-gacor.html method=post>
                                                <input name=__RequestVerificationToken type=hidden value=ehAck4j1dRKELmVqBCdw_At9YJYnDL_y-QCNwGSA6Q7OoU67B3cynsZGXT_6j740PITuZEh96ImbaAevJwf_g8qqbVQ1>
                                                <div class=form-group>
                                                    <label for=UserName>Nama Pengguna</label>
                                                    <input class=form-control type=text name=Username placeholder="Nama Pengguna">
                                                </div>
                                                <div class=form-group>
                                                    <label for=UserName>Kata Sandi</label>
                                                    <div class=standard-password-field>
                                                        <input class=form-control type=password name=Password placeholder="Kata Sandi" id=password_input>
                                                        <i class="glyphicon glyphicon-eye-close password_input_trigger" id=password_input_trigger></i>
                                                    </div>
                                                </div>
                                                <div class="form-group text-right hidden-xs">
                                                    <a href=# class=forgot-password-link id=forgot_password_link data-dismiss=modal data-toggle=modal data-target=#forgot_password_modal>Lupa Kata Sandi? </a>
                                                </div>
                                                <div class="form-group text-right visible-xs">
                                                    <a href=https://stres.b-cdn.net/slot-gacor.html class=forgot-password-link>Lupa Kata Sandi? </a>
                                                </div>
                                                <div class="standard-button-group form-group">
                                                    <input type=submit class="standard-secondary-button btn btn-primary" id=login_submit_button value=Masuk onclick="this.disabled=true;this.form.submit()">
                                                </div>
                                                <div class="form-group text-center">
                                                    Belum punya akun? <a href=https://stres.b-cdn.net/slot-gacor.html class=register-button>Daftar Sekarang </a>
                                                </div>
                                                <div class=form-group>
                                                    <hr>
                                                </div>
                                                <div class="standard-button-group form-group">
                                                    <a href=# class="btn btn-secondary" id=telegram_login_button data-dismiss=modal data-toggle=modal data-target=#telegram_login_popup_modal>Masuk dengan Telegram</a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                window.addEventListener('DOMContentLoaded', () => {
                                    if (window.location.search.startsWith('?login')) {
                                        $('#login_modal').modal();
                                        $('#popup_modal').modal('hide');
                                    }
                                }
                                );
                            </script>
                            <script>
                                window.addEventListener('DOMContentLoaded', () => {
                                    const passwordInputTrigger = document.querySelector('#password_input_trigger');
                                    const passwordInput = document.querySelector('#password_input');
                                    passwordInputTrigger.onclick = () => {
                                        if (passwordInput.type === 'password') {
                                            passwordInput.type = 'text';
                                            return;
                                        }
                                        passwordInput.type = 'password';
                                    }
                                    ;
                                }
                                );
                            </script>
                        </div>
                    </div>
                </div>
            </div>
            <div class=site-header>
                <div class=container>
                    <div class=row>
                        <div class="col-sm-3 col-md-3">
                            <a href=https://stres.b-cdn.net/slot-gacor.html class=logo style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/logo-background.png?v=20250528)">
                                <img alt=Logo loading=lazy src=https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@eb87f6353e143a8a8dc8bc0e99f66086d300e91f/uploads/2026-02-23T05-26-05-065Z-5x5q6rtrc.gif>
                            </a>
                        </div>
                        <div class="col-sm-9 col-md-9">
                            <div class=menu-slide id=menu_slides>
                                <i class="glyphicon glyphicon-chevron-left left_trigger"></i>
                                <ul class=top-menu style="--separator-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/vertical-seperator.png?v=20250528)">
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt="Hot Games" height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/hot-games.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/hot-games-active.svg?v=20250528)" width=30>Hot Games 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background>
                                                        <picture>
                                                            <source srcset="https://image2url.com/r2/default/images/1772527460050-1cb66400-39a8-4f8b-967d-a11accd02530.webp" type=image/webp>
                                                            <source srcset="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png" type=image/png>
                                                            <img alt=HOT class=floating-icon loading=lazy src="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png">
                                                        </picture>
                                                    </div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-7.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-6/game-code-48.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-70.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-16.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-17.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background>
                                                        <picture>
                                                            <source srcset="https://image2url.com/r2/default/images/1772527460050-1cb66400-39a8-4f8b-967d-a11accd02530.webp" type=image/webp>
                                                            <source srcset="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png" type=image/png>
                                                            <img alt=HOT class=floating-icon loading=lazy src="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png">
                                                        </picture>
                                                    </div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-9.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-92.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-98.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-65.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <picture>
                                                <source srcset="https://image2url.com/r2/default/images/1772527460050-1cb66400-39a8-4f8b-967d-a11accd02530.webp" type=image/webp>
                                                <source srcset="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png" type=image/png>
                                                <img alt=HOT class=floating-icon loading=lazy src="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png">
                                            </picture>
                                            <img alt=Slots height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/slots.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/slots-active.svg?v=20250528)" width=30>Slots 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-40.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background>
                                                        <picture>
                                                            <source srcset="https://image2url.com/r2/default/images/1772527460050-1cb66400-39a8-4f8b-967d-a11accd02530.webp" type=image/webp>
                                                            <source srcset="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png" type=image/png>
                                                            <img alt=HOT class=floating-icon loading=lazy src="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png">
                                                        </picture>
                                                    </div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-9.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background>
                                                        <picture>
                                                            <source srcset="https://image2url.com/r2/default/images/1772527460050-1cb66400-39a8-4f8b-967d-a11accd02530.webp" type=image/webp>
                                                            <source srcset="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png" type=image/png>
                                                            <img alt=HOT class=floating-icon loading=lazy src="https://res.cloudinary.com/dyhu1g9vl/image/upload/v1772527537/hot_sus1go.png">
                                                        </picture>
                                                    </div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-7.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-98.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-112.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-92.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-70.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-16.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-17.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-114.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-2.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-29.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-116.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-110.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-115.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-6.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-54.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-108.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-87.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-51.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-65.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=true>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-91.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-73.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-50.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-75.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-77.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-61.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-89.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-109.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-80.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-81.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-79.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-35.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-45.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-13.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-97.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-94.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-95.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-93.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-90.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-42.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-3/game-code-18.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt="Live Casino" height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/casino.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/casino-active.svg?v=20250528)" width=30>Live Casino 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-1.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-41.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-66.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-38.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-105.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-27.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-100.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-14.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-44.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-101.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-84.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-85.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-43.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-2/game-code-10.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt=Race height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/race.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/race-active.svg?v=20250528)" width=30>Race 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-10/game-code-117.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt=Togel height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/others.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/others-active.svg?v=20250528)" width=30>Togel 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-6/game-code-48.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt=Olahraga height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/sports.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/sports-active.svg?v=20250528)" width=30>Olahraga 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-1/game-code-5.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-1/game-code-23.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-1/game-code-11.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=true>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-1/game-code-55.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt="Crash Game" height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/crash-game.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/crash-game-active.svg?v=20250528)" width=30>Crash Game 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-41.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-82.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-108.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-17.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=true>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-91.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-107.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=true>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-62.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-97.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-6.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-81.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-8/game-code-35.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt=Arcade height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/arcade.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/arcade-active.svg?v=20250528)" width=30>Arcade 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-17.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-98.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-116.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-70.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-107.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-82.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-6.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=true>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-91.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-61.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-73.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-77.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-89.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-80.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-81.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-13.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-79.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-96.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-90.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-51.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-4/game-code-35.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt=Poker height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/poker.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/poker-active.svg?v=20250528)" width=30>Poker 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-5/game-code-24.webp?v=20250528)"></div>
                                                </a>
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-5/game-code-32.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt=E-Sports height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/e-sports.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/e-sports-active.svg?v=20250528)" width=30>E-Sports 
                                        
                                        </a>
                                        <ul class=game-list style="--maintenance-text:'Pemeliharaan'">
                                            <li>
                                                <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" data-maintenance-status=false>
                                                    <div class=background></div>
                                                    <div class=foreground style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home-menu-7/game-code-58.webp?v=20250528)"></div>
                                                </a>
                                        </ul>
                                    <li data-active=false>
                                        <a href=https://stres.b-cdn.net/slot-gacor.html>
                                            <img alt=Promotion height=30 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/promotion.svg?v=20250528" style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/menu/promotion-active.svg?v=20250528)" width=30>Promosi 
                                        
                                        </a>
                                </ul>
                                <i class="glyphicon glyphicon-chevron-right right_trigger"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=banner>
                <div id=banner_carousel class=banner-carousel>
                    <div>
                        <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel=1>
                            <img src=https://ik.imagekit.io/ljdihgltp/alexistogel/welcome-alexistogel.jpg alt="ALEXISTOGEL" title="ALEXISTOGEL" loading=eager fetchpriority=high width=1920 height=600>
                        </a>
                    </div>
                    <div>
                        <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel=1>
                            <img src=https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor-alexistogel.jpg alt="SLOT GACOR" title="SLOT GACOR" loading=lazy width=1920 height=600>
                        </a>
                    </div>
                    <div>
                        <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel=1>
                            <img src=https://ik.imagekit.io/ljdihgltp/alexistogel/bonus-n-event-alexistogel.jpg alt=SLOT ONLINE title="SLOT GACOR HARI INI" loading=lazy width=1920 height=600>
                        </a>
                    </div>
                    <div>
                        <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel=1>
                            <img src=https://ik.imagekit.io/ljdihgltp/alexistogel/game-alexistogle.jpg alt=GAME title="SLOT ONLINE HARI INI" loading=lazy width=1920 height=600>
                        </a>
                    </div>
                </div>
            </div>
            <div class=home-info-container>
                <div class=container>
                    <div class=row>
                        <div class=col-md-12>
                            <div class=announcement-container>
                                <div data-section=title>
                                    <i data-icon=announcement style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/icon-sprite.png?v=20250528)"></i>
                                    Pemberitahuan
                                
                                </div>
                                <div data-section=announcements>
                                    <ul class=announcement-list id=announcement_list>
                                        <li>Pemeliharaan Terjadwal: AdvantPlay Mini Game pada 17-Agt-2025 dari 20.02.52 sampai 08-Agt-2026 23.57.58. Selama waktu ini, AdvantPlay Mini Game permainan tidak akan tersedia. Kami memohon maaf atas ketidaknyamanan yang mungkin ditimbulkan.
                                        
                                        <li>Pemeliharaan Terjadwal: Spinix pada 01-Okt-2024 dari 23.00.00 sampai 31-Des-2025 23.59.59. Selama waktu ini, Spinix permainan tidak akan tersedia. Kami memohon maaf atas ketidaknyamanan yang mungkin ditimbulkan.
                                        
                                        <li>Pemeliharaan Terjadwal: PP Virtual Sports pada 06-Des-2024 dari 21.36.12 sampai 31-Des-2025 12.00.00. Selama waktu ini, PP Virtual Sports permainan tidak akan tersedia. Kami memohon maaf atas ketidaknyamanan yang mungkin ditimbulkan.
                                    
                                    </ul>
                                </div>
                                <div data-section=date>Min, 04-Oct-2025 04.15.46</div>
                            </div>
                        </div>
                    </div>
                    <div class=row>
                        <div class=col-md-12>
                            <div class=home-inner-container>
                                <div data-section=jackpot>
                                    <a href="https://stres.b-cdn.net/slot-gacor.html">
                                        <div class=home-progressive-jackpot>
                                            <div class=outer-container>
                                                <div class=inner-container>
                                                    <div class=border-container>
                                                        <div class=jackpot-play-section>
                                                            <picture>
                                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/jackpot/jackpot-play-logo-v2.webp?v=20250528" type=image/webp>
                                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/jackpot/jackpot-play-logo-v2.png?v=20250528" type=image/png>
                                                                <img alt="Jackpot Play" class=jackpot-play height=150 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/jackpot/jackpot-play-logo-v2.png?v=20250528" width=NexusAlpha>
                                                            </picture>
                                                            <div class=jackpot-play-text>
                                                                Jackpot <label>Play</label>
                                                            </div>
                                                        </div>
                                                        <div class=jackpot-container>
                                                            <div class=jackpot-inner-container>
                                                                <div class=jackpot-border-container>
                                                                    <span class=jackpot-currency>IDR</span>
                                                                    <span id=progressive_jackpot data-progressive-jackpot-url=https://jp-api2.namesvr.dev></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div data-section=lottery>
                                    <div class=lottery-result-container>
                                        <div class=lottery-result-title>SINGAPORE 4D</div>
                                        <div class=lottery-result>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/home/singapore-pools.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/home/singapore-pools.png?v=20250528" type=image/png>
                                                <img alt="Singapore Pools" height=43 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/home/singapore-pools.png?v=20250528" width=43>
                                            </picture>
                                            <div class=lottery-numbers>
                                                <span data-lottery-number=9 style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/home/numbers.png?v=20250528)"></span>
                                                <span data-lottery-number=3 style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/home/numbers.png?v=20250528)"></span>
                                                <span data-lottery-number=2 style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/home/numbers.png?v=20250528)"></span>
                                                <span data-lottery-number=6 style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/home/numbers.png?v=20250528)"></span>
                                            </div>
                                        </div>
                                        <div class=lottery-date>Live Draw Sab, 13-Oct-2025 00.00.00</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=row>
                        <div class=col-md-12>
                            <div class=popular-game-title-container>
                                <div class=container-title>
                                    <span>Game Populer</span>
                                </div>
                                <div class=container-content>
                                    <div class=game-list>
                                        <div class=games-group>
                                            <div class=game-item data-game="Sweet Bonanza Super Scatter">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/sweet-bonanza-super-scatter.webp?updatedAt=1772463056916" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/sweet-bonanza-super-scatter.jpg?updatedAt=1772463259171" type=image/jpeg>
                                                        <img alt="Sweet Bonanza Super Scatter" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/sweet-bonanza-super-scatter.jpg?updatedAt=1772463259171" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Sweet Bonanza Super Scatter">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Sweet Bonanza Super Scatter</div>
                                            </div>
                                            <div class=game-item data-game="Mahjong Ways">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/mahjong-ways.webp?updatedAt=1772463056958" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/mahjong-ways.jpg" type=image/jpeg>
                                                        <img alt="Mahjong Ways" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/mahjong-ways.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Mahjong Ways">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Mahjong Ways</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="Mahjong Wins 3 – Black Scatter">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/mahjong-wins-3-black-scatter.webp?updatedAt=1772463056912" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/wukong-black-scatter.jpg" type=image/jpeg>
                                                        <img alt="Mahjong Wins 3 – Black Scatter" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/wukong-black-scatter.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Mahjong Wins 3 – Black Scatter">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Mahjong Wins 3 – Black Scatter</div>
                                            </div>
                                            <div class=game-item data-game="Wukong - Black Scatter">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/wukong-black-scatter.webp?updatedAt=1772463056993" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/wukong-black-scatter.jpg" type=image/jpeg>
                                                        <img alt="Wukong - Black Scatter" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/wukong-black-scatter.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Wukong - Black Scatter">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Wukong - Black Scatter</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="Sticky Bandits Thunder Rail">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/sitcky-bandits-thunder-rail.webp?updatedAt=1772463056997" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/sitcky-bandits-thunder-rail.jpg" type=image/jpeg>
                                                        <img alt="Sticky Bandits Thunder Rail" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/sitcky-bandits-thunder-rail.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Sticky Bandits Thunder Rail">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Sticky Bandits Thunder Rail</div>
                                            </div>
                                            <div class=game-item data-game="Bang Gacor 1000">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/bang-gacor-1000.webp?updatedAt=1772463056704" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/bang-gacor-1000.jpg" type=image/jpeg>
                                                        <img alt="Bang Gacor 1000" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/bang-gacor-1000.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Bang Gacor 1000">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Bang Gacor 1000</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="Le Viking">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/le-viking.webp?updatedAt=1772463057042" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/le-viking.jpg" type=image/jpeg>
                                                        <img alt="Le Viking" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/le-viking.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Le Viking">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Le Viking</div>
                                            </div>
                                            <div class=game-item data-game="Fortune Gems">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/fortune-gems.webp?updatedAt=1772463056957" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/fortune-gems.jpg" type=image/jpeg>
                                                        <img alt="Fortune Gems" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/fortune-gems.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Fortune Gems">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Fortune Gems</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="Mahjong Ways 2">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/mahjong-ways-2.webp?updatedAt=1772463057017" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/mahjong-ways-2.jpg" type=image/jpeg>
                                                        <img alt="Mahjong Ways 2" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/mahjong-ways-2.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Mahjong Ways 2">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Mahjong Ways 2</div>
                                            </div>
                                            <div class=game-item data-game="Gates of Olympus Super Scatter">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/gates-of-olympus-super-scatter.webp?updatedAt=1772463057072" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/gates-of-olympus-super-scatter.jpg" type=image/jpeg>
                                                        <img alt="Gates of Olympus Super Scatter" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/gates-of-olympus-super-scatter.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Gates of Olympus Super Scatter">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Gates of Olympus Super Scatter</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="Wild Bounty Showdown">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/wild-bounty-showdown.webp?updatedAt=1772463056966" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/wild-bounty-showdown.jpg" type=image/jpeg>
                                                        <img alt="Wild Bounty Showdown" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/wild-bounty-showdown.jpg" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Wild Bounty Showdown">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Wild Bounty Showdown</div>
                                            </div>
                                            <div class=game-item data-game="Lucky Twins Nexus">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/lucky-twins.webp?updatedAt=1772463056929" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/lucky-twins.jpg?updatedAt=1772463259184" type=image/jpeg>
                                                        <img alt="Lucky Twins Nexus" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/lucky-twins.jpg?updatedAt=1772463259184" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Lucky Twins Nexus">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Lucky Twins Nexus</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="Nexus Koi Gate">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/koi-gate.webp?updatedAt=1772463056936" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/koi-gate.jpg?updatedAt=1772463259159" type=image/jpeg>
                                                        <img alt="Nexus Koi Gate" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/koi-gate.jpg?updatedAt=1772463259159" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Nexus Koi Gate">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Nexus Koi Gate</div>
                                            </div>
                                            <div class=game-item data-game="The Crypt">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/the-crypt.webp?updatedAt=1772463057020" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/the-crypt.jpg?updatedAt=1772463259212" type=image/jpeg>
                                                        <img alt="The Crypt" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/the-crypt.jpg?updatedAt=1772463259212" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="The Crypt">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>The Crypt</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="Nexus Mahjong Jackpots">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/mahjong-jackpots.webp?updatedAt=1772463057016" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/mahjong-jackpots.jpg?updatedAt=1772463259276" type=image/jpeg>
                                                        <img alt="Nexus Mahjong Jackpots" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/mahjong-jackpots.jpg?updatedAt=1772463259276" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Nexus Mahjong Jackpots">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Nexus Mahjong Jackpots</div>
                                            </div>
                                            <div class=game-item data-game="Fire in the Hole 3">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/fire-3-hole.webp?updatedAt=1772463056982" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/fire-3-hole.jpg?updatedAt=1772463259207" type=image/jpeg>
                                                        <img alt="Fire in the Hole 3" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/fire-3-hole.jpg?updatedAt=1772463259207" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Fire in the Hole 3">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Fire in the Hole 3</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="777 Rush">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/777-rush.webp?updatedAt=1772463056766" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/777-rush.jpg?updatedAt=1772463258793" type=image/jpeg>
                                                        <img alt="777 Rush" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/777-rush.jpg?updatedAt=1772463258793" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="777 Rush">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>777 Rush</div>
                                            </div>
                                            <div class=game-item data-game="Hot Hot Nexus">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/hot-hot.webp?updatedAt=1772463056960" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/hot-hot.jpg?updatedAt=1772463258887" type=image/jpeg>
                                                        <img alt="Hot Hot Nexus" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/hot-hot.jpg?updatedAt=1772463258887" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Hot Hot Nexus">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Hot Hot Nexus</div>
                                            </div>
                                        </div>
                                        <div class=games-group>
                                            <div class=game-item data-game="Le Pharaoh">
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/le-pharaoh.webp?updatedAt=1772463057000" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/le-pharaoh.jpg?updatedAt=1772463259125" type=image/jpeg>
                                                        <img alt="Le Pharaoh" height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/le-pharaoh.jpg?updatedAt=1772463259125" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game="Le Pharaoh">MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>Le Pharaoh</div>
                                            </div>
                                            <div class=game-item data-game=JetX>
                                                <div class=wrapper-container>
                                                    <picture>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/jetx.webp?updatedAt=1772463056906" type=image/webp>
                                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/jetx.jpg?updatedAt=1772463259234" type=image/jpeg>
                                                        <img alt=JetX height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/jetx.jpg?updatedAt=1772463259234" width=200>
                                                    </picture>
                                                    <div class=link-container>
                                                        <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now data-game=JetX>MAIN </a>
                                                    </div>
                                                </div>
                                                <div class=game-name>JetX</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=row>
                        <div class=col-md-12>
                            <div class=popular-games style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/red/desktop/home/popular-games-background.jpg?v=20250528)">
                                <div data-section=left style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/icon-sprite.png?v=20250528)">
                                    <div class=section-title>
                                        <i data-icon=play style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/icon-sprite.png?v=20250528)"></i>
                                        Slot Gacor Popular
                                    </div>
                                    <div class=jackpot-winners>
                                        <div class=jackpot-winner-title>
                                            <i data-icon=trophy style="--image-src:url(https://1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png)"></i>
                                            PEMENANG SLOT ONLINE HARI INI
                                        </div>
                                        <div class=winners-ticker-container>
                                            <div class=winners-ticker id=winners_ticker>
                                                <ul>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>v**5</div>
                                                            <div>
                                                                IDR <span class=winner-amount>78,930,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>c*6</div>
                                                            <div>
                                                                IDR <span class=winner-amount>49,248,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>i***52</div>
                                                            <div>
                                                                IDR <span class=winner-amount>46,590,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>t*****v</div>
                                                            <div>
                                                                IDR <span class=winner-amount>40,859,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>aw****12</div>
                                                            <div>
                                                                IDR <span class=winner-amount>19,808,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>s88*****m</div>
                                                            <div>
                                                                IDR <span class=winner-amount>17,700,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>7***5</div>
                                                            <div>
                                                                IDR <span class=winner-amount>12,644,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>b****5</div>
                                                            <div>
                                                                IDR <span class=winner-amount>12,356,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>nb****5</div>
                                                            <div>
                                                                IDR <span class=winner-amount>9,580,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                    <li>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914" type=image/jpeg>
                                                            <img alt="Starlight Princess™ 1000" loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor.jpg?updatedAt=1772448260914">
                                                        </picture>
                                                        <div class=winner-info>
                                                            <div>aac****5</div>
                                                            <div>
                                                                IDR <span class=winner-amount>8,442,000.00</span>
                                                            </div>
                                                            <div>Starlight Princess™ 1000</div>
                                                        </div>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <a href=https://stres.b-cdn.net/slot-gacor.html>
                                        <picture>
                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/arcade/webp/tembak-ikan.webp?updatedAt=1772529248868" type=image/webp>
                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/arcade/jpg/tembak-ikan.jpg?updatedAt=1772529265412" type=image/jpeg>
                                            <img alt=Arcade height=87 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/arcade/jpg/tembak-ikan.jpg?updatedAt=1772529265412" width=232>
                                        </picture>
                                    </a>
                                </div>
                                <div data-section=right>
                                    <ul class="nav nav-tabs target-tabs" id=popular_providers role=tablist>
                                        <li role=presentation>
                                            <a href=#tab-SLOT88 role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-40.webp?updatedAt=1772458396673" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-40.png?updatedAt=1772458416196" type=image/png>
                                                    <img alt=SLOT88 height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-40.png?updatedAt=1772458416196" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-PGSOFT role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-9.webp?updatedAt=1772458396594" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-9.png?updatedAt=1772458415375" type=image/png>
                                                    <img alt=PGSOFT height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-9.png?updatedAt=1772458415375" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-PP role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-7.webp" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-7.png?updatedAt=1772458416111" type=image/png>
                                                    <img alt=PP height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-7.png?updatedAt=1772458416111" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-HACKSAW role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-98.webp?updatedAt=1772458397074" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-98.png?updatedAt=1772458416298" type=image/png>
                                                    <img alt=HACKSAW height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-98.png?updatedAt=1772458416298" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-FATPANDA role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-112.webp?updatedAt=1772458396507" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-112.png?updatedAt=1772458416099" type=image/png>
                                                    <img alt=FATPANDA height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-112.png?updatedAt=1772458416099" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-NOLIMITCITY role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-92.webp?updatedAt=1772458396506" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-92.png?updatedAt=1772458416250" type=image/png>
                                                    <img alt=NOLIMITCITY height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-92.png?updatedAt=1772458416250" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-JILI role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-70.webp?updatedAt=1772458396611" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-70.png?updatedAt=1772458416164" type=image/png>
                                                    <img alt=JILI height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-70.png?updatedAt=1772458416164" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-HABANERO role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-16.webp?updatedAt=1772458396007" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-16.png?updatedAt=1772458416314" type=image/png>
                                                    <img alt=HABANERO height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-16.png?updatedAt=1772458416314" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-MICROGAMING role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-17.webp?updatedAt=1772458396573" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-17.png?updatedAt=1772458416116" type=image/png>
                                                    <img alt=MICROGAMING height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-17.png?updatedAt=1772458416116" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-FIVEGG role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-114.webp?updatedAt=1772458396992" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-114.png?updatedAt=1772458416315" type=image/png>
                                                    <img alt=FIVEGG height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-114.png?updatedAt=1772458416315" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-PLAYTECH role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-2.webp?updatedAt=1772458396677" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-2.png?updatedAt=1772458415335" type=image/png>
                                                    <img alt=PLAYTECH height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-2.png?updatedAt=1772458415335" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-SPADEGAMING role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-29.webp?updatedAt=1772458396622" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-29.png?updatedAt=1772458416305" type=image/png>
                                                    <img alt=SPADEGAMING height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-29.png?updatedAt=1772458416305" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-KINGMIDAS role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-116.webp?updatedAt=1772458396610" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-116.png?updatedAt=1772458416215" type=image/png>
                                                    <img alt=KINGMIDAS height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-116.png?updatedAt=1772458416215" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-FASTSPIN role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-110.webp?updatedAt=1772458396533" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-110.png?updatedAt=1772458416141" type=image/png>
                                                    <img alt=FASTSPIN height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-110.png?updatedAt=1772458416141" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-SLOTMANIA role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-115.webp?updatedAt=1772458396648" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-115.png?updatedAt=1772458416121" type=image/png>
                                                    <img alt=SLOTMANIA height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-115.png?updatedAt=1772458416121" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-JOKER role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-6.webp?updatedAt=1772458396616" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-6.png?updatedAt=1772458416094" type=image/png>
                                                    <img alt=JOKER height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-6.png?updatedAt=1772458416094" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-ADVANTPLAY role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-54.webp?updatedAt=1772458396568" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-54.png?updatedAt=1772458416144" type=image/png>
                                                    <img alt=ADVANTPLAY height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-54.png?updatedAt=1772458416144" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-SMARTSOFT role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-108.webp?updatedAt=1772458397351" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-108.png?updatedAt=1772458416171" type=image/png>
                                                    <img alt=SMARTSOFT height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-108.png?updatedAt=1772458416171" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-NAGAGAMES role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-87.webp?updatedAt=1772458396615" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-87.png?updatedAt=1772458416210" type=image/png>
                                                    <img alt=NAGAGAMES height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-87.png?updatedAt=1772458416210" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-JDB role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-51.webp?updatedAt=1772458396634" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-51.png?updatedAt=1772458416163" type=image/png>
                                                    <img alt=JDB height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-51.png?updatedAt=1772458416163" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-PLAYSTAR role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-65.webp?updatedAt=1772458396761" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-65.png?updatedAt=1772458416103" type=image/png>
                                                    <img alt=PLAYSTAR height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-65.png?updatedAt=1772458416103" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-SPINIX role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-91.webp?updatedAt=1772458396518" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-91.png?updatedAt=1772458416147" type=image/png>
                                                    <img alt=SPINIX height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-91.png?updatedAt=1772458416147" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-CROWDPLAY role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-73.webp?updatedAt=1772458396543" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-73.png?updatedAt=1772458416190" type=image/png>
                                                    <img alt=CROWDPLAY height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-73.png?updatedAt=1772458416190" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-PGS role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-50.webp?updatedAt=1772458396496" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-50.png?updatedAt=1772458416227" type=image/png>
                                                    <img alt=PGS height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-50.png?updatedAt=1772458416227" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-BIGPOT role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-75.webp?updatedAt=1772458396581" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-75.png?updatedAt=1772458416766" type=image/png>
                                                    <img alt=BIGPOT height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-75.png?updatedAt=1772458416766" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-VPOWER role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-77.webp?updatedAt=1772458396386" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-77.png?updatedAt=1772458416242" type=image/png>
                                                    <img alt=VPOWER height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-77.png?updatedAt=1772458416242" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-AMB role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-61.webp?updatedAt=1772458396380" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-61.png?updatedAt=1772458416354" type=image/png>
                                                    <img alt=AMB height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-61.png?updatedAt=1772458416354" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-WORLDMATCH role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-89.webp?updatedAt=1772458396461" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-89.png?updatedAt=1772458416327" type=image/png>
                                                    <img alt=WORLDMATCH height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-89.png?updatedAt=1772458416327" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-OCTOPLAY role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-109.webp?updatedAt=1772458396712" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-109.png?updatedAt=1772458416751" type=image/png>
                                                    <img alt=OCTOPLAY height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-109.png?updatedAt=1772458416751" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-MARIOCLUB role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-80.webp?updatedAt=1772458396603" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-80.png?updatedAt=1772458416721" type=image/png>
                                                    <img alt=MARIOCLUB height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-80.png?updatedAt=1772458416721" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-DRAGOONSOFT role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-81.webp?updatedAt=1772458396644" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-81.png?updatedAt=1772458416270" type=image/png>
                                                    <img alt=DRAGOONSOFT height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-81.png?updatedAt=1772458416270" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-FUNGAMING role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-79.webp?updatedAt=1772458397008" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-79.png?updatedAt=1772458416235" type=image/png>
                                                    <img alt=FUNGAMING height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-79.png?updatedAt=1772458416235" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-SBOFUNKYGAME role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-35.webp?updatedAt=1772458396498" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-35.png?updatedAt=1772458416233" type=image/png>
                                                    <img alt=SBOFUNKYGAME height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-35.png?updatedAt=1772458416233" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-LIVE22 role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-45.webp?updatedAt=1772458396549" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-45.png?updatedAt=1772458416100" type=image/png>
                                                    <img alt=LIVE22 height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-45.png?updatedAt=1772458416100" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-SBOCQ9 role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-13.webp?updatedAt=1772458396639" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-13.png?updatedAt=1772458416093" type=image/png>
                                                    <img alt=SBOCQ9 height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-13.png?updatedAt=1772458416093" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-ONLYPLAY role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-97.webp?updatedAt=1772458396585" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-97.png?updatedAt=1772458416381" type=image/png>
                                                    <img alt=ONLYPLAY height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-97.png?updatedAt=1772458416381" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-NETENT role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-94.webp?updatedAt=1772458397170" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-94.png?updatedAt=1772458416395" type=image/png>
                                                    <img alt=NETENT height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-94.png?updatedAt=1772458416395" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-BIGTIMEGAMING role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-95.webp?updatedAt=1772458396627" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-95.png?updatedAt=1772458417027" type=image/png>
                                                    <img alt=BIGTIMEGAMING height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-95.png?updatedAt=1772458417027" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-REDTIGER role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-93.webp?updatedAt=1772458396702" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-93.png?updatedAt=1772458417034" type=image/png>
                                                    <img alt=REDTIGER height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-93.png?updatedAt=1772458417034" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-SKYWIND role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-90.webp?updatedAt=1772458396626" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-90.png?updatedAt=1772458416225" type=image/png>
                                                    <img alt=SKYWIND height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-90.png?updatedAt=1772458416225" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-YGGDRASIL role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-42.webp?updatedAt=1772458396636" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-42.png?updatedAt=1772458416857" type=image/png>
                                                    <img alt=YGGDRASIL height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-42.png?updatedAt=1772458416857" width=120>
                                                </picture>
                                            </a>
                                        <li role=presentation>
                                            <a href=#tab-PLAYNGO role=tab data-toggle=tab>
                                                <picture>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-webp/game-code-18.webp?updatedAt=1772458396391" type=image/webp>
                                                    <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-18.png?updatedAt=1772458416154" type=image/png>
                                                    <img alt=PLAYNGO height=45 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/game-providers-png/game-code-18.png?updatedAt=1772458416154" width=120>
                                                </picture>
                                            </a>
                                    </ul>
                                    <div class=tab-content>
                                        <div role=tabpanel class=tab-pane id=tab-SLOT88>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor-slot88.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor-slot88.png" type=image/png>
                                                <img alt=SLOT88 class=animated-image height=334 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/slot-gacor-slot88.png" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/mighty-hercules.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/mighty-hercules.jpg" type=image/jpeg>
                                                            <img alt=SLOT88 height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/mighty-hercules.jpg" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/wukong-black-scatter.webp?updatedAt=1772463056993" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/wukong-black-scatter.jpg" type=image/jpeg>
                                                            <img alt=SLOT88 height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/wukong-black-scatter.jpg" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/way-of-ninja.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/way-of-ninja.jpg" type=image/jpeg>
                                                            <img alt=SLOT88 height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/way-of-ninja.jpg" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/slot88-bonanza.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/slot88-bonanza.jpg" type=image/jpeg>
                                                            <img alt=SLOT88 height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/slot88-bonanza.jpg" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/slot88-gems.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/slot88-gems.jpg" type=image/jpeg>
                                                            <img alt=SLOT88 height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/slot88-gems.jpg" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/slot88-princess.webp" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/slot88-princess.jpg" type=image/jpeg>
                                                            <img alt=SLOT88 height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/slot88-princess.jpg" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-PGSOFT>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-9.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-9.png?v=20250528" type=image/png>
                                                <img alt=PGSOFT class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-9.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1568554.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1568554.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1568554.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_103.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_103.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_103.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_118.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_118.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_118.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1760238.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1760238.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1760238.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_95.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_95.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_95.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1671262.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1671262.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGSOFT/PGSOFT_1671262.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-PP>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-7.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-7.png?v=20250528" type=image/png>
                                                <img alt=PP class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-7.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/cs3w.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/cs3w.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PP height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/cs3w.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=cs3w&amp;lang=en&amp;jurisdiction=99&amp;cur=IDR&amp;lobbyUrl=js://window.close()','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20sbpnudge.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20sbpnudge.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PP height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20sbpnudge.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20sbpnudge&amp;lang=en&amp;jurisdiction=99&amp;cur=IDR&amp;lobbyUrl=js://window.close()','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20gobnudge.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20gobnudge.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PP height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20gobnudge.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20gobnudge&amp;lang=en&amp;jurisdiction=99&amp;cur=IDR&amp;lobbyUrl=js://window.close()','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20clreacts.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20clreacts.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PP height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20clreacts.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20clreacts&amp;lang=en&amp;jurisdiction=99&amp;cur=IDR&amp;lobbyUrl=js://window.close()','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs25copsrobbers.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs25copsrobbers.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PP height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs25copsrobbers.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs25copsrobbers&amp;lang=en&amp;jurisdiction=99&amp;cur=IDR&amp;lobbyUrl=js://window.close()','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20irishcrown.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20irishcrown.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PP height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PP/vs20irishcrown.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://demogamesfree-asia.pragmaticplay.net/gs2c/openGame.do?gameSymbol=vs20irishcrown&amp;lang=en&amp;jurisdiction=99&amp;cur=IDR&amp;lobbyUrl=js://window.close()','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-HACKSAW>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-98.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-98.png?v=20250528" type=image/png>
                                                <img alt=HACKSAW class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-98.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1084.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1084.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HACKSAW height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1084.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="https://d24m60q82dzu8y.cloudfront.net/launcher/index.html?casinoid=1135&amp;clienttype=mobile&amp;currencycode=IDR&amp;gameid=hsg_hsg_1084&amp;playmode=demo">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1634.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1634.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HACKSAW height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1634.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="https://d24m60q82dzu8y.cloudfront.net/launcher/index.html?casinoid=1135&amp;clienttype=mobile&amp;currencycode=IDR&amp;gameid=hsg_hsg_1634&amp;playmode=demo">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1251.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1251.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HACKSAW height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1251.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="https://d24m60q82dzu8y.cloudfront.net/launcher/index.html?casinoid=1135&amp;clienttype=mobile&amp;currencycode=IDR&amp;gameid=hsg_hsg_1251&amp;playmode=demo">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1181.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1181.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HACKSAW height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1181.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="https://d24m60q82dzu8y.cloudfront.net/launcher/index.html?casinoid=1135&amp;clienttype=mobile&amp;currencycode=IDR&amp;gameid=hsg_hsg_1181&amp;playmode=demo">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1102.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1102.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HACKSAW height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HACKSAW/HACKSAW_1102.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="https://d24m60q82dzu8y.cloudfront.net/launcher/index.html?casinoid=1135&amp;clienttype=mobile&amp;currencycode=IDR&amp;gameid=hsg_hsg_1102&amp;playmode=demo">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/le-viking.webp?updatedAt=1772463057042" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/le-viking.jpg" type=image/jpeg>
                                                            <img alt=HACKSAW height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/le-viking.jpg" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="https://d24m60q82dzu8y.cloudfront.net/launcher/index.html?casinoid=1135&amp;clienttype=mobile&amp;currencycode=IDR&amp;gameid=hsg_hsg_1689&amp;playmode=demo">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-FATPANDA>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-112.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-112.png?v=20250528" type=image/png>
                                                <img alt=FATPANDA class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-112.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs25pfarmfp.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs25pfarmfp.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FATPANDA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs25pfarmfp.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs1mjokfp.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs1mjokfp.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FATPANDA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs1mjokfp.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs10fortnhsly.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs10fortnhsly.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FATPANDA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs10fortnhsly.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs5spjokfp.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs5spjokfp.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FATPANDA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs5spjokfp.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs5luckytigly.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs5luckytigly.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FATPANDA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs5luckytigly.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs10emotiwins.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs10emotiwins.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FATPANDA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FATPANDA/vs10emotiwins.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-NOLIMITCITY>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-92.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-92.png?v=20250528" type=image/png>
                                                <img alt=NOLIMITCITY class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-92.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/bruteforce000000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/bruteforce000000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NOLIMITCITY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/bruteforce000000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/gluttony00000000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/gluttony00000000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NOLIMITCITY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/gluttony00000000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/barbarianfury000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/barbarianfury000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NOLIMITCITY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/barbarianfury000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-webp/the-crypt.webp?updatedAt=1772463057020" type=image/webp>
                                                            <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/the-crypt.jpg?updatedAt=1772463259212" type=image/jpeg>
                                                            <img alt=NOLIMITCITY height=200 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-popular-jpg/the-crypt.jpg?updatedAt=1772463259212" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/poisoneve0000000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/poisoneve0000000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NOLIMITCITY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/poisoneve0000000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/highwaytohell000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/highwaytohell000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NOLIMITCITY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NOLIMITCITY/highwaytohell000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-JILI>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-70.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-70.png?v=20250528" type=image/png>
                                                <img alt=JILI class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-70.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_103.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_103.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JILI height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_103.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://jiligames.com/plusplayer/PlusTrial/103/id-ID','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_43.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_43.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JILI height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_43.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://jiligames.com/plusplayer/PlusTrial/43/id-ID','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_36.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_36.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JILI height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_36.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://jiligames.com/plusplayer/PlusTrial/36/id-ID','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_518.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_518.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JILI height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_518.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://jiligames.com/plusplayer/PlusTrial/518/id-ID','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_58.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_58.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JILI height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_58.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://jiligames.com/plusplayer/PlusTrial/58/id-ID','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_239.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_239.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JILI height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JILI/JILI_239.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('http://jiligames.com/plusplayer/PlusTrial/239/id-ID','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-HABANERO>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-16.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-16.png?v=20250528" type=image/png>
                                                <img alt=HABANERO class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-16.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGBombRunner.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGBombRunner.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HABANERO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGBombRunner.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://app-a.ply-ldr-rfo6v4aqd6cqw84z.com/play?brandid=825cc3ca-3cb4-ee11-b660-6045bd5af406&amp;keyname=SGBombRunner&amp;locale=id-ID&amp;mode=fun','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGWitchesTome.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGWitchesTome.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HABANERO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGWitchesTome.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://app-a.ply-ldr-rfo6v4aqd6cqw84z.com/play?brandid=825cc3ca-3cb4-ee11-b660-6045bd5af406&amp;keyname=SGWitchesTome&amp;locale=id-ID&amp;mode=fun','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGDarumaImpact.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGDarumaImpact.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HABANERO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGDarumaImpact.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://app-a.ply-ldr-rfo6v4aqd6cqw84z.com/play?brandid=825cc3ca-3cb4-ee11-b660-6045bd5af406&amp;keyname=SGDarumaImpact&amp;locale=id-ID&amp;mode=fun','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGHauntedHarbor.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGHauntedHarbor.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HABANERO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGHauntedHarbor.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://app-a.ply-ldr-rfo6v4aqd6cqw84z.com/play?brandid=825cc3ca-3cb4-ee11-b660-6045bd5af406&amp;keyname=SGHauntedHarbor&amp;locale=id-ID&amp;mode=fun','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGEgyptianDreamsDeluxe.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGEgyptianDreamsDeluxe.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HABANERO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGEgyptianDreamsDeluxe.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://app-a.ply-ldr-rfo6v4aqd6cqw84z.com/play?brandid=825cc3ca-3cb4-ee11-b660-6045bd5af406&amp;keyname=SGEgyptianDreamsDeluxe&amp;locale=id-ID&amp;mode=fun','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGMysticFortuneDeluxe.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGMysticFortuneDeluxe.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=HABANERO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/HABANERO/SGMysticFortuneDeluxe.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://app-a.ply-ldr-rfo6v4aqd6cqw84z.com/play?brandid=825cc3ca-3cb4-ee11-b660-6045bd5af406&amp;keyname=SGMysticFortuneDeluxe&amp;locale=id-ID&amp;mode=fun','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-MICROGAMING>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-17.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-17.png?v=20250528" type=image/png>
                                                <img alt=MICROGAMING class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-17.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_treasureStacks.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_treasureStacks.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MICROGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_treasureStacks.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('/free-to-play/MICROGAMING/Desktop/SMG_treasureStacks','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_showdownSaloon.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_showdownSaloon.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MICROGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_showdownSaloon.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('/free-to-play/MICROGAMING/Desktop/SMG_showdownSaloon','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_luckyClucks.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_luckyClucks.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MICROGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_luckyClucks.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('/free-to-play/MICROGAMING/Desktop/SMG_luckyClucks','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_emeraldGold.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_emeraldGold.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MICROGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_emeraldGold.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('/free-to-play/MICROGAMING/Desktop/SMG_emeraldGold','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_9potsOfGold.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_9potsOfGold.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MICROGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_9potsOfGold.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('/free-to-play/MICROGAMING/Desktop/SMG_9potsOfGold','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_HappyHolidays.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_HappyHolidays.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MICROGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MICROGAMING/SMG_HappyHolidays.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('/free-to-play/MICROGAMING/Desktop/SMG_HappyHolidays','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-FIVEGG>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-114.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-114.png?v=20250528" type=image/png>
                                                <img alt=FIVEGG class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-114.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99980.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99980.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FIVEGG height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99980.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99992.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99992.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FIVEGG height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99992.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99996.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99996.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FIVEGG height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99996.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99989.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99989.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FIVEGG height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99989.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/S5G-H5-99943.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/S5G-H5-99943.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FIVEGG height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/S5G-H5-99943.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99998.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99998.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FIVEGG height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FIVEGG/KYS-H5-99998.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-PLAYTECH>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-2.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-2.png?v=20250528" type=image/png>
                                                <img alt=PLAYTECH class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-2.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/aogmt.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/aogmt.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYTECH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/aogmt.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/gpas_ccluck_pop.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/gpas_ccluck_pop.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYTECH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/gpas_ccluck_pop.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/zeus.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/zeus.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYTECH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/zeus.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/pop_23e64a71_rbp.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/pop_23e64a71_rbp.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYTECH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/pop_23e64a71_rbp.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/gtsswk.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/gtsswk.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYTECH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/gtsswk.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/pop_vladscastle_eye.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/pop_vladscastle_eye.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYTECH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYTECH/pop_vladscastle_eye.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-SPADEGAMING>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-29.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-29.png?v=20250528" type=image/png>
                                                <img alt=SPADEGAMING class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-29.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-JW01.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-JW01.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPADEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-JW01.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-LB01.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-LB01.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPADEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-LB01.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-GP04.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-GP04.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPADEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-GP04.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-TD01.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-TD01.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPADEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-TD01.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-DX01.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-DX01.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPADEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-DX01.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-RK02.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-RK02.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPADEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPADEGAMING/S-RK02.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-KINGMIDAS>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-116.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-116.png?v=20250528" type=image/png>
                                                <img alt=KINGMIDAS class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-116.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Xoc_Dia_Lightning.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Xoc_Dia_Lightning.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=KINGMIDAS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Xoc_Dia_Lightning.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Sugar_Blast_Frenzy.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Sugar_Blast_Frenzy.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=KINGMIDAS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Sugar_Blast_Frenzy.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Elite_Aviator_Club.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Elite_Aviator_Club.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=KINGMIDAS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Elite_Aviator_Club.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Andar_Bahar.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Andar_Bahar.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=KINGMIDAS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Andar_Bahar.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Leppys_Loot.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Leppys_Loot.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=KINGMIDAS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Leppys_Loot.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Bai_Cao.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Bai_Cao.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=KINGMIDAS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/KINGMIDAS/Bai_Cao.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-FASTSPIN>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-110.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-110.png?v=20250528" type=image/png>
                                                <img alt=FASTSPIN class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-110.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_MD01.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_MD01.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FASTSPIN height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_MD01.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_WW02.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_WW02.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FASTSPIN height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_WW02.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_GS05.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_GS05.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FASTSPIN height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_GS05.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_MM02.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_MM02.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FASTSPIN height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_MM02.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_SC01.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_SC01.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FASTSPIN height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_SC01.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_RH02.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_RH02.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FASTSPIN height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FASTSPIN/S_RH02.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-SLOTMANIA>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-115.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-115.png?v=20250528" type=image/png>
                                                <img alt=SLOTMANIA class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-115.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_310000012.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_310000012.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SLOTMANIA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_310000012.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_330000008.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_330000008.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SLOTMANIA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_330000008.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_350000003.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_350000003.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SLOTMANIA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_350000003.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_3000506.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_3000506.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SLOTMANIA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_3000506.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_350000018.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_350000018.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SLOTMANIA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/SLOTMANIA_350000018.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/Slotmania_350000028.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/Slotmania_350000028.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SLOTMANIA height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SLOTMANIA/Slotmania_350000028.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-JOKER>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-6.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-6.png?v=20250528" type=image/png>
                                                <img alt=JOKER class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-6.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/bmr8675wqiigs.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/bmr8675wqiigs.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JOKER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/bmr8675wqiigs.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/3yfmucpss64mk.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/3yfmucpss64mk.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JOKER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/3yfmucpss64mk.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/satj3o6ya8dcq.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/satj3o6ya8dcq.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JOKER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/satj3o6ya8dcq.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/dhdirsn3m3xia.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/dhdirsn3m3xia.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JOKER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/dhdirsn3m3xia.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/byz81hmsq748k.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/byz81hmsq748k.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JOKER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/byz81hmsq748k.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/j6j1rkbjfaz1a.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/j6j1rkbjfaz1a.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JOKER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JOKER/j6j1rkbjfaz1a.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-ADVANTPLAY>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-54.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-54.png?v=20250528" type=image/png>
                                                <img alt=ADVANTPLAY class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-54.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10051.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10051.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ADVANTPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10051.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://fun.pypc.net/web/fun/funplay?game=10051','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/ADVANTPLAY_10062.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/ADVANTPLAY_10062.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ADVANTPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/ADVANTPLAY_10062.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://fun.pypc.net/web/fun/funplay?game=10062','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/AdvantPlay_10042.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/AdvantPlay_10042.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ADVANTPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/AdvantPlay_10042.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://fun.pypc.net/web/fun/funplay?game=10042','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10061.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10061.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ADVANTPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10061.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://fun.pypc.net/web/fun/funplay?game=10061','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10047.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10047.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ADVANTPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/Advantplay_10047.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://fun.pypc.net/web/fun/funplay?game=10047','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/AdvantPlay_10037.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/AdvantPlay_10037.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ADVANTPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ADVANTPLAY/AdvantPlay_10037.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://fun.pypc.net/web/fun/funplay?game=10037','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-SMARTSOFT>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-108.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-108.png?v=20250528" type=image/png>
                                                <img alt=SMARTSOFT class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-108.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_BaoSlot5X.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_BaoSlot5X.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SMARTSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_BaoSlot5X.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/XGames_CricketX.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/XGames_CricketX.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SMARTSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/XGames_CricketX.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Games_SmashX.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Games_SmashX.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SMARTSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Games_SmashX.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_WildMultiStars.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_WildMultiStars.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SMARTSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_WildMultiStars.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_SugarFiesta.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_SugarFiesta.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SMARTSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/Slots_SugarFiesta.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/XGames_CricketerX.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/XGames_CricketerX.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SMARTSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SMARTSOFT/XGames_CricketerX.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-NAGAGAMES>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-87.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-87.png?v=20250528" type=image/png>
                                                <img alt=NAGAGAMES class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-87.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/super-phoenix.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/super-phoenix.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NAGAGAMES height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/super-phoenix.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/queen-aztec.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/queen-aztec.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NAGAGAMES height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/queen-aztec.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/kawaii-neko.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/kawaii-neko.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NAGAGAMES height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/kawaii-neko.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/fulong.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/fulong.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NAGAGAMES height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/fulong.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/el-toro.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/el-toro.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NAGAGAMES height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/el-toro.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/pawsome-xmas.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/pawsome-xmas.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NAGAGAMES height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NAGAGAMES/pawsome-xmas.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-JDB>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-51.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-51.png?v=20250528" type=image/png>
                                                <img alt=JDB class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-51.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14055.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14055.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JDB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14055.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_8004.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_8004.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JDB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_8004.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_9_9015.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_9_9015.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JDB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_9_9015.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_8005.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_8005.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JDB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_8005.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14086.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14086.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JDB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14086.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14048.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14048.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=JDB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/JDB/JDB_0_14048.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-PLAYSTAR>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-65.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-65.png?v=20250528" type=image/png>
                                                <img alt=PLAYSTAR class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-65.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00163.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00163.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYSTAR height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00163.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00127.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00127.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYSTAR height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00127.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00135.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00135.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYSTAR height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00135.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00086.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00086.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYSTAR height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00086.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00106.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00106.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYSTAR height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00106.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00133.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00133.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYSTAR height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYSTAR/PSS-ON-00133.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-SPINIX>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-91.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-91.png?v=20250528" type=image/png>
                                                <img alt=SPINIX class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-91.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_60586144969a692c186055c5.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_60586144969a692c186055c5.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPINIX height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_60586144969a692c186055c5.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_60d1afbc75ae3c58ac051e33.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_60d1afbc75ae3c58ac051e33.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPINIX height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_60d1afbc75ae3c58ac051e33.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_6005088e51fca119d082673e.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_6005088e51fca119d082673e.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPINIX height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_6005088e51fca119d082673e.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_61dbe6fd894a001d44637454.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_61dbe6fd894a001d44637454.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPINIX height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_61dbe6fd894a001d44637454.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_6373379dd1b122089089c38c.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_6373379dd1b122089089c38c.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPINIX height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_6373379dd1b122089089c38c.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_61dfa67d91bc525fdce2e8c1.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_61dfa67d91bc525fdce2e8c1.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SPINIX height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SPINIX/_61dfa67d91bc525fdce2e8c1.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-CROWDPLAY>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-73.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-73.png?v=20250528" type=image/png>
                                                <img alt=CROWDPLAY class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-73.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-023.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-023.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=CROWDPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-023.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-032.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-032.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=CROWDPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-032.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-021.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-021.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=CROWDPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-021.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-009.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-009.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=CROWDPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-009.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-002.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-002.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=CROWDPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-002.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-034.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-034.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=CROWDPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/CROWDPLAY/pslot-034.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-PGS>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-50.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-50.png?v=20250528" type=image/png>
                                                <img alt=PGS class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-50.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-tianhoumazu_290120.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-tianhoumazu_290120.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-tianhoumazu_290120.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-pandawarrior_290092.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-pandawarrior_290092.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-pandawarrior_290092.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-powerofthor_290087.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-powerofthor_290087.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-powerofthor_290087.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-poseidon_290037.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-poseidon_290037.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-poseidon_290037.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-pirateattack_290090.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-pirateattack_290090.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-pirateattack_290090.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-mahjonggold2_290104.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-mahjonggold2_290104.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PGS height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PGS/agg_ht-mahjonggold2_290104.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-BIGPOT>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-75.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-75.png?v=20250528" type=image/png>
                                                <img alt=BIGPOT class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-75.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_MW.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_MW.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGPOT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_MW.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_AS.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_AS.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGPOT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_AS.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_MF.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_MF.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGPOT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_MF.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_HG.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_HG.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGPOT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_HG.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_VSFIESTAFRENZY.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_VSFIESTAFRENZY.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGPOT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_VSFIESTAFRENZY.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_SM.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_SM.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGPOT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGPOT/SLOT_SM.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-VPOWER>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-77.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-77.png?v=20250528" type=image/png>
                                                <img alt=VPOWER class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-77.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/CODE3165.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/CODE3165.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=VPOWER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/CODE3165.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/BCEGHIJOSWYZ.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/BCEGHIJOSWYZ.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=VPOWER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/BCEGHIJOSWYZ.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/FGHIKNPRUVXY.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/FGHIKNPRUVXY.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=VPOWER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/FGHIKNPRUVXY.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/BGHIJMPQRUVZ.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/BGHIJMPQRUVZ.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=VPOWER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/BGHIJMPQRUVZ.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/CODE3140.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/CODE3140.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=VPOWER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/CODE3140.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/DFGHNOPQTVYZ.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/DFGHNOPQTVYZ.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=VPOWER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/VPOWER/DFGHNOPQTVYZ.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-AMB>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-61.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-61.png?v=20250528" type=image/png>
                                                <img alt=AMB class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-61.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/SUSHI35.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/SUSHI35.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=AMB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/SUSHI35.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/DINOGEMS.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/DINOGEMS.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=AMB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/DINOGEMS.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/SUBWAYRUNNER.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/SUBWAYRUNNER.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=AMB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/SUBWAYRUNNER.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/FISHINGPARADISE.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/FISHINGPARADISE.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=AMB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/FISHINGPARADISE.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/VIRUS.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/VIRUS.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=AMB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/VIRUS.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/MAHJONGLEGEND.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/MAHJONGLEGEND.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=AMB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/AMB/MAHJONGLEGEND.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-WORLDMATCH>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-89.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-89.png?v=20250528" type=image/png>
                                                <img alt=WORLDMATCH class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-89.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/JOLLY.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/JOLLY.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=WORLDMATCH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/JOLLY.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/GOFRA.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/GOFRA.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=WORLDMATCH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/GOFRA.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/MFROG.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/MFROG.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=WORLDMATCH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/MFROG.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/XTNEZ.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/XTNEZ.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=WORLDMATCH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/XTNEZ.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/FUNNY.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/FUNNY.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=WORLDMATCH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/FUNNY.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/TROLL.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/TROLL.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=WORLDMATCH height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/WORLDMATCH/TROLL.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-OCTOPLAY>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-109.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-109.png?v=20250528" type=image/png>
                                                <img alt=OCTOPLAY class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-109.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103111.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103111.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=OCTOPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103111.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103028.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103028.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=OCTOPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103028.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103090.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103090.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=OCTOPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103090.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103115.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103115.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=OCTOPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103115.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103077.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103077.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=OCTOPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103077.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103065.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103065.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=OCTOPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/OCTOPLAY/OCTOPLAY_103065.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-MARIOCLUB>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-80.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-80.png?v=20250528" type=image/png>
                                                <img alt=MARIOCLUB class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-80.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS089.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS089.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MARIOCLUB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS089.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS104.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS104.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MARIOCLUB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS104.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS069.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS069.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MARIOCLUB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS069.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS050.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS050.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MARIOCLUB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS050.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS001.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS001.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MARIOCLUB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/GS001.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/ES002.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/ES002.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=MARIOCLUB height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/MARIOCLUB/ES002.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-DRAGOONSOFT>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-81.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-81.png?v=20250528" type=image/png>
                                                <img alt=DRAGOONSOFT class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-81.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3080.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3080.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=DRAGOONSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3080.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3060.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3060.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=DRAGOONSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3060.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_4008.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_4008.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=DRAGOONSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_4008.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3024.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3024.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=DRAGOONSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3024.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3002.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3002.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=DRAGOONSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_3002.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_4014.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_4014.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=DRAGOONSOFT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/DRAGOONSOFT/DRAGOONSOFT_4014.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-FUNGAMING>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-79.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-79.png?v=20250528" type=image/png>
                                                <img alt=FUNGAMING class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-79.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/jgwc.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/jgwc.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FUNGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/jgwc.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/mr.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/mr.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FUNGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/mr.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/Nysymbols.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/Nysymbols.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FUNGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/Nysymbols.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/zzx.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/zzx.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FUNGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/zzx.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/PVZ.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/PVZ.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FUNGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/PVZ.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/bbs.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/bbs.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=FUNGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/FUNGAMING/bbs.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-SBOFUNKYGAME>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-35.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-35.png?v=20250528" type=image/png>
                                                <img alt=SBOFUNKYGAME class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-35.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_99.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_99.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOFUNKYGAME height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_99.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_124.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_124.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOFUNKYGAME height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_124.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_113.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_113.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOFUNKYGAME height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_113.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_108.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_108.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOFUNKYGAME height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_108.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_114.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_114.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOFUNKYGAME height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_114.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_104.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_104.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOFUNKYGAME height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOFUNKYGAME/FUNKYGAMES_104.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-LIVE22>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-45.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-45.png?v=20250528" type=image/png>
                                                <img alt=LIVE22 class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-45.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30017.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30017.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=LIVE22 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30017.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://smapi.xystem138.com/api/opgateway/v1/op/demo/LaunchGame?opId=l22nxtIDR&amp;Currency=IDR&amp;GameCode=30017&amp;lang=en-us','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30022.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30022.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=LIVE22 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30022.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://smapi.xystem138.com/api/opgateway/v1/op/demo/LaunchGame?opId=l22nxtIDR&amp;Currency=IDR&amp;GameCode=30022&amp;lang=en-us','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30039.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30039.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=LIVE22 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30039.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://smapi.xystem138.com/api/opgateway/v1/op/demo/LaunchGame?opId=l22nxtIDR&amp;Currency=IDR&amp;GameCode=30039&amp;lang=en-us','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30005.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30005.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=LIVE22 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30005.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://smapi.xystem138.com/api/opgateway/v1/op/demo/LaunchGame?opId=l22nxtIDR&amp;Currency=IDR&amp;GameCode=30005&amp;lang=en-us','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_35003.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_35003.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=LIVE22 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_35003.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://smapi.xystem138.com/api/opgateway/v1/op/demo/LaunchGame?opId=l22nxtIDR&amp;Currency=IDR&amp;GameCode=35003&amp;lang=en-us','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=LIVE22 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/LIVE22/LIVE22_30000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a class=free-play href="javascript:alert('Anda akan bermain versi demo, ini berarti menang/kalah dalam permainan tidak akan mempengaruhi dana/saldo anda.');openPopup('https://smapi.xystem138.com/api/opgateway/v1/op/demo/LaunchGame?opId=l22nxtIDR&amp;Currency=IDR&amp;GameCode=30000&amp;lang=en-us','Slots')">COBA </a>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-SBOCQ9>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-13.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-13.png?v=20250528" type=image/png>
                                                <img alt=SBOCQ9 class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-13.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_1.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_1.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOCQ9 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_1.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_382.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_382.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOCQ9 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_382.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_39.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_39.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOCQ9 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_39.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_342.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_342.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOCQ9 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_342.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_72.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_72.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOCQ9 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_72.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_168.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_168.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SBOCQ9 height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SBOCQ9/CQ9_168.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-ONLYPLAY>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-97.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-97.png?v=20250528" type=image/png>
                                                <img alt=ONLYPLAY class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-97.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/mysteryofpersia.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/mysteryofpersia.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ONLYPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/mysteryofpersia.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/frozengarden.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/frozengarden.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ONLYPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/frozengarden.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/hotandspicy.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/hotandspicy.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ONLYPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/hotandspicy.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/cherryboomchristmas.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/cherryboomchristmas.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ONLYPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/cherryboomchristmas.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/goldenkiwi.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/goldenkiwi.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ONLYPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/goldenkiwi.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/dayofmuerte.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/dayofmuerte.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=ONLYPLAY height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/ONLYPLAY/dayofmuerte.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-NETENT>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-94.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-94.png?v=20250528" type=image/png>
                                                <img alt=NETENT class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-94.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/wildminingxx96f1.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/wildminingxx96f1.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NETENT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/wildminingxx96f1.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/mummymegaways000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/mummymegaways000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NETENT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/mummymegaways000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/lostrelics200000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/lostrelics200000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NETENT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/lostrelics200000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/gunsnroses000000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/gunsnroses000000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NETENT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/gunsnroses000000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/sweetyhoneyfruit.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/sweetyhoneyfruit.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NETENT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/sweetyhoneyfruit.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/deadoralive2fb00.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/deadoralive2fb00.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=NETENT height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/NETENT/deadoralive2fb00.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-BIGTIMEGAMING>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-95.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-95.png?v=20250528" type=image/png>
                                                <img alt=BIGTIMEGAMING class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-95.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/millionaicardsv1.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/millionaicardsv1.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGTIMEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/millionaicardsv1.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/chocolatesv10000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/chocolatesv10000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGTIMEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/chocolatesv10000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/dangerhvolt2v100.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/dangerhvolt2v100.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGTIMEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/dangerhvolt2v100.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/luckystreakmk2v1.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/luckystreakmk2v1.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGTIMEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/luckystreakmk2v1.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/goldmegawaysv100.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/goldmegawaysv100.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGTIMEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/goldmegawaysv100.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/goldengoosemv100.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/goldengoosemv100.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=BIGTIMEGAMING height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/BIGTIMEGAMING/goldengoosemv100.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-REDTIGER>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-93.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-93.png?v=20250528" type=image/png>
                                                <img alt=REDTIGER class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-93.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/dreamdestiny0000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/dreamdestiny0000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=REDTIGER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/dreamdestiny0000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/wildelements0000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/wildelements0000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=REDTIGER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/wildelements0000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/diamonddoggies00.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/diamonddoggies00.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=REDTIGER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/diamonddoggies00.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/mayangods0000000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/mayangods0000000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=REDTIGER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/mayangods0000000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/goldentoad000000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/goldentoad000000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=REDTIGER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/goldentoad000000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/risquemegaways00.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/risquemegaways00.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=REDTIGER height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/REDTIGER/risquemegaways00.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-SKYWIND>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-90.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-90.png?v=20250528" type=image/png>
                                                <img alt=SKYWIND class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-90.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_prli.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_prli.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SKYWIND height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_prli.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_trhi_965.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_trhi_965.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SKYWIND height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_trhi_965.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_psi_965.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_psi_965.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SKYWIND height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_psi_965.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_vial_965.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_vial_965.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SKYWIND height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_vial_965.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_lll.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_lll.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SKYWIND height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_lll.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_btbm_965.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_btbm_965.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=SKYWIND height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/SKYWIND/sw_btbm_965.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-YGGDRASIL>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-42.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-42.png?v=20250528" type=image/png>
                                                <img alt=YGGDRASIL class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-42.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_378.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_378.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=YGGDRASIL height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_378.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_301.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_301.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=YGGDRASIL height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_301.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_10.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_10.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=YGGDRASIL height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_10.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_318.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_318.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=YGGDRASIL height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_318.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_302.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_302.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=YGGDRASIL height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_302.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_193.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_193.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=YGGDRASIL height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/YGGDRASIL/YGGDRASIL_193.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div role=tabpanel class=tab-pane id=tab-PLAYNGO>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-18.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-18.png?v=20250528" type=image/png>
                                                <img alt=PLAYNGO class=animated-image height=334 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/menu/desktop/home/animations/game-code-18.png?v=20250528" width=421>
                                            </picture>
                                            <div class=popular-game-list>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/mysteryjoker6000.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/mysteryjoker6000.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYNGO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/mysteryjoker6000.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/clashofcamelot.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/clashofcamelot.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYNGO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/clashofcamelot.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/ghostofdead.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/ghostofdead.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYNGO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/ghostofdead.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/goldenlegend.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/goldenlegend.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYNGO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/goldenlegend.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/ragetoriches.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/ragetoriches.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYNGO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/ragetoriches.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class=game-item>
                                                    <div class=game-wrapper>
                                                        <picture>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/wildhoundderby.webp?v=20250528" type=image/webp>
                                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/wildhoundderby.jpg?v=20250528" type=image/jpeg>
                                                            <img alt=PLAYNGO height=200 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/providers/PLAYNGO/wildhoundderby.jpg?v=20250528" width=200>
                                                        </picture>
                                                        <div class=link-container>
                                                            <a href="javascript:registerPopup({content:'Silahkan login terlebih dahulu.'})" class=play-now>MAIN </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=download-apk-container style="--image-src:url(https://ik.imagekit.io/ljdihgltp/alexistogel/background.jpg?updatedAt=1772454103846)">
                <div class=container>
                    <div class=row>
                        <div class=col-md-12>
                            <div class=download-apk id=download_apk>
                                <div>
                                    <picture>
                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/app-slot-gacor.webp" type=image/webp>
                                        <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/app-slot-gacor.png?updatedAt=1772452119514" type=image/png>
                                        <img alt="Download APK" class=img-responsive height=408 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/app-slot-gacor.png?updatedAt=1772452119514" width=566>
                                    </picture>
                                </div>
                                <div>
                                    <div class=h2>
                                        DOWNLOAD APK SLOT GACOR
                                    </div>
                                    <div class=h3>Rasakan Sensasi Kemenangan Berlimpah Slot Online Dalam Satu Genggaman</div>
                                    <div class=download-apk-info>
                                        <div class=download-apk-section>
                                            <div class=download-apk-qr-code>
                                                <a href=https://stres.b-cdn.net/slot-gacor.html>
                                                    <picture>
                                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/apk-qrcodes/GDB.webp?v=20250528" type=image/webp>
                                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/apk-qrcodes/GDB.jpg?v=20250528" type=image/jpeg>
                                                        <img alt="Unduh Aplikasi Permainan" height=94 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/apk-qrcodes/GDB.jpg?v=20250528" width=94>
                                                    </picture>
                                                </a>
                                            </div>
                                            <div class=download-apk-detail>
                                                <div>App Slot Gacor</div>
                                                <a class=btn href=# data-toggle=modal data-target=#apk_install_guide_modal>Panduan instalasi</a>
                                            </div>
                                            <span>
                                                Pindai QR Download <i>Android APK & IPHONE</i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id=apk_install_guide_modal class="modal download-popup-modal" role=dialog data-title="Panduan Instalasi" aria-hidden=false>
                    <div class=modal-dialog>
                        <div class=modal-content>
                            <div class=modal-header>
                                <button type=button class=close data-dismiss=modal aria-label=Close>
                                    <span aria-hidden=true>×</span>
                                </button>
                                <div class=modal-title id=apk_install_guide_modal_title>Panduan Instalasi</div>
                            </div>
                            <div class=modal-body id=apk_install_guide_modal_body>
                                <span>
                                    <img alt=Android height=20 loading=lazy src="https://dsuown9evwz4y.cloudfront.net/Images/icons/android-logo.svg?v=20250528" width=20>Instalasi Android
                                
                                </span>
                                <ol>
                                    <li>Pindai kode QR untuk Android
                                    
                                    <li>Pilih buka situs web
                                    
                                    <li>Pilih "UNDUH" untuk mengunduh App Slot Gacor
                                    
                                    <li>Pilih "PENGATURAN"
                                    
                                    <li>Pilih "Mengizinkan" dari sumber kami
                                    
                                    <li>Pilih "Terima"
                                    
                                    <li>Pilih "INSTAL"
                                
                                </ol>
                                <div class=download-32-bit-cntr>
                                    <div>Instalasi gagal?</div>
                                    <div>
                                        Coba versi 32-bit <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank>di sini</a>
                                        jika versi bawaan tidak bisa diinstal.
                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=telegram-banner-container>
                <div class=container>
                    <div class=row>
                        <div class=col-md-12>
                            <a href=https://stres.b-cdn.net/slot-gacor.html rel=nofollow target=_blank>
                                <picture>
                                    <source srcset="https://cdn.designfast.io/image/2026-02-23/1d8f7e60-4840-433e-b601-e1a5b88a809e.webp" type=image/webp>
                                    <source srcset="https://cdn.designfast.io/image/2026-02-23/1d8f7e60-4840-433e-b601-e1a5b88a809e.webp" type=image/webp>
                                    <img alt=Telegram loading=lazy src="https://cdn.designfast.io/image/2026-02-23/1d8f7e60-4840-433e-b601-e1a5b88a809e.webp">
                                </picture>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <footer class=site-footer style="--image-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer-background.jpg?v=20250528)">
                <div class=container>
                    <div class=row>
                        <div class=col-md-8>
                            <ul class=footer-links>
                                <li>
                                    <a href=https://mannolmy.com/category/filters>Slot</a>
                                <li>
                                    <a href=https://mannolmy.com/category/filters>Slot Gacor</a>
                                <li>
                                    <a href=https://mannolmy.com/category/filters>Situs Slot</a>
                                <li>
                                    <a href=https://mannolmy.com/category/filters>Slot88</a>
                            </ul>
                        </div>
                        <div class="col-md-4 copyright">©2025 SLOT88 GACOR. Hak cipta dilindungi | 18+</div>
                    </div>
                    <div class=row>
                        <div class=col-md-12>
                            <hr class=footer-separator>
                            <div class=site-description></div>
                            <hr class=footer-separator>
                        </div>
                    </div>
                    <div class=row>
                        <div class="col-md-4 site-info-container">
                            <div class=site-info>
                                <div class=site-info-title>
                                    <i data-icon=service style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/icon-sprite.png?v=20250528)"></i>
                                    <div>
                                        <h3>PELAYANAN</h3>
                                        <p>Keunggulan Pelayanan
                                    
                                    </div>
                                </div>
                                <div class=site-info-description>
                                    <h4>DEPOSIT</h4>
                                    <p>Rata-Rata Waktu
                                    
                                    <div>
                                        <div id=deposit_progress data-average-time=1.00></div>
                                    </div>
                                </div>
                                <div class=site-info-description>
                                    <h4>PENARIKAN</h4>
                                    <p>Rata-Rata Waktu
                                    
                                    <div>
                                        <div id=withdrawal_progress data-average-time=2.00></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 site-info-container">
                            <div class=site-info>
                                <div class=site-info-title>
                                    <i data-icon=product style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/icon-sprite.png?v=20250528)"></i>
                                    <div>
                                        <h3>PRODUK</h3>
                                        <p>Keunggulan Produk
                                    
                                    </div>
                                </div>
                                <div class="site-info-description with-seperator">
                                    <h4>TARUHAN SLOT</h4>
                                    <p>Penyedia slot online dengan beragam pilihan game menarik yang memudahkan pemain untuk mencapai jackpot
                                
                                </div>
                                <div class="site-info-description with-seperator">
                                    <h4>TARUHAN TOGEL</h4>
                                    <p>Platform togel yang menarik dari perusahan terbaik di dunia yang menawarkan hadiah kemenangan besar
                                
                                </div>
                                <div class="site-info-description with-seperator">
                                    <h4>TARUHAN LIVE KASINO</h4>
                                    <p>Platform Pilihan bagi perusahaan-perusahaan terbaik di dunia, dengan pilihan variasi game terbanyak
                                
                                </div>
                                <div class="site-info-description with-seperator">
                                    <h4>TARUHAN OLAHRAGA</h4>
                                    <p>Sportsbook Gaming Platform Terbaik menawarkan lebih banyak game, odds yang lebih tinggi, dan menyediakan pilihan yang lebih banyak untuk pemain.
                                
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 site-info-container">
                            <div class=site-info>
                                <div class=site-info-title>
                                    <i data-icon=help-and-service style="background-image:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/icon-sprite.png?v=20250528)"></i>
                                    <div>
                                        <h3>BANTUAN &amp;DUKUNGAN</h3>
                                        <p>Servis Lainnya
                                    
                                    </div>
                                </div>
                                <div class="site-info-description with-seperator support-container">
                                    <div class=qr-codes></div>
                                    <ul class=contact-list>
                                        <li>
                                            <a href="https://stres.b-cdn.net/slot-gacor.html" target=_blank rel="noopener nofollow">
                                                <i>
                                                    <img alt=Contact height=20 loading=lazy src="https://1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png" width=20>
                                                </i>
                                                +6285932188572
                                            
                                            </a>
                                        <li>
                                            <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel="noopener nofollow">
                                                <i>
                                                    <img alt=Contact height=20 loading=lazy src="https://1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png" width=20>
                                                </i>
                                                Slot Gacor 
                                            
                                            </a>
                                        <li>
                                            <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel="noopener nofollow">
                                                <i>
                                                    <img alt=Contact height=20 loading=lazy src="https://1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png" width=20>
                                                </i>
                                                Slot88
                                            
                                            </a>
                                        <li>
                                            <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel="noopener nofollow">
                                                <i>
                                                    <img alt=Contact height=20 loading=lazy src="https://1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png" width=20>
                                                </i>
                                                Slot88 Gacor
                                            
                                            </a>
                                        <li>
                                            <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel="noopener nofollow">
                                                <i>
                                                    <img alt=Contact height=20 loading=lazy src="https://1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png" width=20>
                                                </i>
                                                Link Slot Online
                                            
                                            </a>
                                        <li>
                                            <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel="noopener nofollow">
                                                <i>
                                                    <img alt=Contact height=20 loading=lazy src="https://1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png" width=20>
                                                </i>
                                                Alexistogel
                                            
                                            </a>
                                    </ul>
                                </div>
                                <div class="site-info-description with-seperator">
                                    <h4>TERHUBUNG DENGAN KAMI</h4>
                                    <ul class=social-media-list>
                                        <li>
                                            <a href=https://api.whatsapp.com/send?phone=6285932188572 target=_blank rel=nofollow>
                                                <img src=https://media0.giphy.com/media/v1.Y2lkPTZjMDliOTUya2Vma2xhN2l0bjhoOGdlajNybzJvcWh0ZnB6NTNzbDB1bTlza2t0MSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/igtqiYXFNK5FoZPeQO/giphy.gif alt="Social Media" width=32 height=32 loading=lazy>
                                            </a>
                                        <li>
                                            <a href=https://t.me/Alexistogel11 target=_blank rel=nofollow>
                                                <img src=https://media.lordicon.com/icons/wired/lineal/2559-logo-telegram.gif alt="Social Media" width=32 height=32 loading=lazy>
                                            </a>
                                        <li>
                                            <a href=https://www.facebook.com/profile.php?id=61587182202382 target=_blank rel=nofollow>
                                                <img src=https://media.tenor.com/r8mo3lL6BDsAAAAM/follow-subscribe.gif alt="Social Media" width=32 height=32 loading=lazy>
                                            </a>
                                        <li>
                                            <a href=https://www.instagram.com/alexistoto_official/ target=_blank rel=nofollow>
                                                <img src=https://cliply.co/wp-content/uploads/2019/07/371907300_INSTAGRAM_ICON_400px.gif alt="Social Media" width=32 height=32 loading=lazy>
                                            </a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr class=footer-separator>
                    <div class=row>
                        <div class=col-md-5>
                            <p class=footer-section-title>Bersertifikasi Dari
                            
                            <ul class=hover-list>
                                <li>
                                    <a href="//ambengine.com/" target=_blank rel="nofollow noopener" class=powered-by-link>
                                        <picture>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/platform-engine/amb-engine.webp?v=20250528" type=image/webp>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/platform-engine/amb-engine.png?v=20250528" type=image/png>
                                            <img alt=amb-engine class=powered-by-logo height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/platform-engine/amb-engine.png?v=20250528">
                                        </picture>
                                        <picture>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/platform-engine/amb-engine-active.webp?v=20250528" type=image/webp>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/platform-engine/amb-engine-active.png?v=20250528" type=image/png>
                                            <img alt=amb-engine class=powered-by-logo height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/platform-engine/amb-engine-active.png?v=20250528">
                                        </picture>
                                    </a>
                            </ul>
                        </div>
                        <div class=col-md-3>
                            <p class=footer-section-title>Tanggung Jawab Bermain
                            
                            <ul class=hover-list>
                                <li>
                                    <picture>
                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/gambling-support.webp?v=20250528" type=image/webp>
                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/gambling-support.png?v=20250528" type=image/png>
                                        <img alt="Gambling Support" height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/gambling-support.png?v=20250528" width=78>
                                    </picture>
                                    <picture>
                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/gambling-support-active.webp?v=20250528" type=image/webp>
                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/gambling-support-active.png?v=20250528" type=image/png>
                                        <img alt="Gambling Support" height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/gambling-support-active.png?v=20250528" width=78>
                                    </picture>
                                <li>
                                    <picture>
                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/18-plus.webp?v=20250528" type=image/webp>
                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/18-plus.png?v=20250528" type=image/png>
                                        <img alt="18 Plus" height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/18-plus.png?v=20250528" width=41>
                                    </picture>
                                    <picture>
                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/18-plus-active.webp?v=20250528" type=image/webp>
                                        <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/18-plus-active.png?v=20250528" type=image/png>
                                        <img alt="18 Plus" height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/18-plus-active.png?v=20250528" width=41>
                                    </picture>
                            </ul>
                        </div>
                        <div class="col-md-4 supported-browser-container">
                            <div>
                                <p class=footer-section-title>Browser Yang Didukung
                                
                                <ul class=hover-list>
                                    <li>
                                        <picture>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/chrome.webp?v=20250528" type=image/webp>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/chrome.png?v=20250528" type=image/png>
                                            <img alt=Chrome height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/chrome.png?v=20250528" width=41>
                                        </picture>
                                        <picture>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/chrome-active.webp?v=20250528" type=image/webp>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/chrome-active.png?v=20250528" type=image/png>
                                            <img alt=Chrome height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/chrome-active.png?v=20250528" width=41>
                                        </picture>
                                    <li>
                                        <picture>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/edge.webp?v=20250528" type=image/webp>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/edge.png?v=20250528" type=image/png>
                                            <img alt=Edge height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/edge.png?v=20250528" width=41>
                                        </picture>
                                        <picture>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/edge-active.webp?v=20250528" type=image/webp>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/edge-active.png?v=20250528" type=image/png>
                                            <img alt=Edge height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/edge-active.png?v=20250528" width=41>
                                        </picture>
                                    <li>
                                        <picture>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/firefox.webp?v=20250528" type=image/webp>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/firefox.png?v=20250528" type=image/png>
                                            <img alt=Firefox height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/firefox.png?v=20250528" width=41>
                                        </picture>
                                        <picture>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/firefox-active.webp?v=20250528" type=image/webp>
                                            <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/firefox-active.png?v=20250528" type=image/png>
                                            <img alt=Firefox height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/footer/firefox-active.png?v=20250528" width=41>
                                        </picture>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <hr class=footer-separator>
                </div>
                <div class=provider-section>
                    <div class=container>
                        <div class=row>
                            <div class=col-md-12>
                                <p class=footer-section-title>Platform Penyedia Layanan
                                
                                <div class=provider-container>
                                    <h5>Slots</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/pp.webp?updatedAt=1772530244342" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/pp.png?updatedAt=1772531002826" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/pp.png?updatedAt=1772531002826" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/pp-active.webp?updatedAt=1772530479616" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/pp-active.png?updatedAt=1772531487758" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/pp-active.png?updatedAt=1772531487758" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/playtech.webp?updatedAt=1772530243146" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/playtech.png?updatedAt=1772531002925" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/playtech.png?updatedAt=1772531002925" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/playtech-active.webp?updatedAt=1772530480010" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/playtech-active.png?updatedAt=1772531487842" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/playtech-active.png?updatedAt=1772531487842" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/joker.webp?updatedAt=1772530243194" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/joker.png?updatedAt=1772531002877" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/joker.png?updatedAt=1772531002877" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/joker-active.webp?updatedAt=1772530479479" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/joker-active.png?updatedAt=1772531487708" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/joker-active.png?updatedAt=1772531487708" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/pgsoft.webp?updatedAt=1772530243171" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/pgsoft.png?updatedAt=1772531002950" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/pgsoft.png?updatedAt=1772531002950" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/pgsoft-active.webp?updatedAt=1772530479646" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/pgsoft-active.png?updatedAt=1772531487838" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/pgsoft-active.png?updatedAt=1772531487838" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/cq9.webp?updatedAt=1772530242766" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/cq9.png?updatedAt=1772531002742" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/cq9.png?updatedAt=1772531002742" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/cq9-active.webp?updatedAt=1772530479536" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/cq9-active.png?updatedAt=1772531487711" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/cq9-active.png?updatedAt=1772531487711" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/habanero.webp?updatedAt=1772530243443" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/habanero.png?updatedAt=1772531002819" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/habanero.png?updatedAt=1772531002819" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/habanero-active.webp?updatedAt=1772530479471" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/habanero-active.png?updatedAt=1772531487713" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/habanero-active.png?updatedAt=1772531487713" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/microgaming.webp?updatedAt=1772530243178" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/microgaming.png?updatedAt=1772531003140" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/microgaming.png?updatedAt=1772531003140" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/microgaming-active.webp?updatedAt=1772530479567" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/microgaming-active.png?updatedAt=1772531487832" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/microgaming-active.png?updatedAt=1772531487832" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/playngo.webp?updatedAt=1772530243152" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/playngo.png?updatedAt=1772531002973" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/playngo.png?updatedAt=1772531002973" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/playngo-active.webp?updatedAt=1772530479636" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/playngo-active.png?updatedAt=1772531487739" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/playngo-active.png?updatedAt=1772531487739" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/spade-gaming.webp?updatedAt=1772530243149" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/spade-gaming.png?updatedAt=1772531002914" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/spade-gaming.png?updatedAt=1772531002914" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/spade-gaming-active.webp?updatedAt=1772530479681" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/spade-gaming-active.png?updatedAt=1772531487849" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/spade-gaming-active.png?updatedAt=1772531487849" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/slot88.webp?updatedAt=1772530244230" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/slot88.png?updatedAt=17725310028008" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/slot88.png?updatedAt=17725310028008" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/slot88-active.webp?updatedAt=1772530479530" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/slot88-active.png?updatedAt=1772531487744" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/slot88-active.png?updatedAt=1772531487744" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/yggdrasil.webp?updatedAt=1772530243146" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/yggdrasil.png?updatedAt=1772531002932" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/yggdrasil.png?updatedAt=1772531002932" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/yggdrasil-active.webp?updatedAt=1772530479577" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/yggdrasil-active.png?updatedAt=1772531487837" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/yggdrasil-active.png?updatedAt=1772531487837" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/live22.webp?updatedAt=1772530243151" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/live22.png?updatedAt=1772531002898" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/live22.png?updatedAt=1772531002898" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/live22-active.webp?updatedAt=1772530479642" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/live22-active.png?updatedAt=1772531487815" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/live22-active.png?updatedAt=1772531487815" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/ion-slot.webp?updatedAt=1772530243188" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/ion-slot.png?updatedAt=1772531002771" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/ion-slot.png?updatedAt=1772531002771" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/ion-slot-active.webp?updatedAt=1772530479475" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/ion-slot-active.png?updatedAt=1772531487711" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/ion-slot-active.png?updatedAt=1772531487711" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/jdb.webp?updatedAt=1772530243116" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/jdb.png?updatedAt=1772531002848" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/jdb.png?updatedAt=1772531002848" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/jdb-active.webp?updatedAt=1772530480138" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/jdb-active.png?updatedAt=1772531487837" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/jdb-active.png?updatedAt=1772531487837" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/advantplay.webp?updatedAt=1772530242760" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/advantplay.png?updatedAt=1772531002583" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/advantplay.png?updatedAt=1772531002583" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/advantplay-active.webp?updatedAt=1772530480132" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/advantplay-active.png?updatedAt=1772531487691" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/advantplay-active.png?updatedAt=1772531487691" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/amb-slot.webp?updatedAt=1772530242790" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/amb-slot.png?updatedAt=1772531002607" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/amb-slot.png?updatedAt=1772531002607" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/amb-slot-active.webp?updatedAt=1772530479143" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/amb-slot-active.png?updatedAt=1772531487408" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/amb-slot-active.png?updatedAt=1772531487408" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/playstar.webp?updatedAt=1772530244312" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/playstar.png?updatedAt=1772531003137" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/playstar.png?updatedAt=1772531003137" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/playstar-active.webp?updatedAt=1772530480130" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/playstar-active.png?updatedAt=1772531487813" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/playstar-active.png?updatedAt=1772531487813" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/jili.webp?updatedAt=1772530243101" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/jili.png?updatedAt=1772531002900" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/jili.png?updatedAt=1772531002900" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/jili-active.webp?updatedAt=1772530479595" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/jili-active.png?updatedAt=1772531487694" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/jili-active.png?updatedAt=1772531487694" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/funky-games.webp?updatedAt=1772530243194" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/funky-games.png?updatedAt=1772531002855" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/funky-games.png?updatedAt=1772531002855" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/funky-games-active.webp?updatedAt=1772530479596" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/funky-games-active.png?updatedAt=1772531487716" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/funky-games-active.png?updatedAt=1772531487716" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/crowd-play.webp?updatedAt=1772530243206" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/crowd-play.png?updatedAt=1772531002940" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/crowd-play.png?updatedAt=1772531002940" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/crowd-play-active.webp?updatedAt=1772530479520" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/crowd-play-active.png?updatedAt=1772531487716" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/crowd-play-active.png?updatedAt=1772531487716" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/bigpot.webp?updatedAt=1772530243549" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/bigpot.png?updatedAt=1772531002607" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/bigpot.png?updatedAt=1772531002607" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/bigpot-active.webp?updatedAt=1772530479577" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/bigpot-active.png?updatedAt=1772531487713" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/bigpot-active.png?updatedAt=1772531487713" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/vpower.webp?updatedAt=1772530243201" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/vpower.png?updatedAt=1772531002940" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/vpower.png?updatedAt=1772531002940" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/vpower-active.webp?updatedAt=1772530480140" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/vpower-active.png?updatedAt=1772531487766" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/vpower-active.png?updatedAt=1772531487766" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/fun-gaming.webp?updatedAt=1772530243123" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fun-gaming.png?updatedAt=1772531002966" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fun-gaming.png?updatedAt=1772531002966" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/fun-gaming-active.webp?updatedAt=1772530479554" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fun-gaming-active.png?updatedAt=1772531487676" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fun-gaming-active.png?updatedAt=1772531487676" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/dragoonsoft.webp?updatedAt=1772530243318" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/dragoonsoft.png?updatedAt=1772531002919" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/dragoonsoft.png?updatedAt=1772531002919" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/dragoonsoft-active.webp?updatedAt=1772530479114" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/dragoonsoft-active.png?updatedAt=1772531487628" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/dragoonsoft-active.png?updatedAt=1772531487628" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/mario-club.webp?updatedAt=1772530243138" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/mario-club.png?updatedAt=1772531002800" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/mario-club.png?updatedAt=1772531002800" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/mario-club-active.webp?updatedAt=1772530479530" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/mario-club-active.png?updatedAt=1772531487751" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/mario-club-active.png?updatedAt=1772531487751" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/naga-games.webp?updatedAt=1772530243134" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/naga-games.png?updatedAt=1772531002838" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/naga-games.png?updatedAt=1772531002838" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/naga-games-active.webp?updatedAt=1772530480127" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/naga-games-active.png?updatedAt=1772531487820" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/naga-games-active.png?updatedAt=1772531487820" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/worldmatch.webp?updatedAt=1772530243155" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/worldmatch.png?updatedAt=1772531002906" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/worldmatch.png?updatedAt=1772531002906" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/worldmatch-active.webp?updatedAt=1772530479537" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/worldmatch-active.png" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/worldmatch-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/spinix.webp?updatedAt=1772530243303" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/spinix.png?updatedAt=1772531002894" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/spinix.png?updatedAt=1772531002894" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/spinix-active.webp?updatedAt=1772530479541" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/spinix-active.png?updatedAt=1772531487784" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/spinix-active.png?updatedAt=1772531487784" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/skywind.webp?updatedAt=1772530243215" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/skywind.png?updatedAt=1772531002963" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/skywind.png?updatedAt=1772531002963" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/skywind-active.webp?updatedAt=1772530479530" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/skywind-active.png?updatedAt=1772531487806" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/skywind-active.png?updatedAt=1772531487806" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/no-limit-city.webp?updatedAt=1772530243162" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/no-limit-city.png?updatedAt=1772531002960" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/no-limit-city.png?updatedAt=1772531002960" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/no-limit-city-active.webp?updatedAt=1772530479608" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/no-limit-city-active.png?updatedAt=1772531487809" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/no-limit-city-active.png?updatedAt=1772531487809" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/red-tiger.webp?updatedAt=1772530243227" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/red-tiger.png?updatedAt=1772531002973" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/red-tiger.png?updatedAt=1772531002973" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/red-tiger-active.webp?updatedAt=1772530479626" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/red-tiger-active.png?updatedAt=1772531487777" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/red-tiger-active.png?updatedAt=1772531487777" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/netent.webp?updatedAt=1772530243107" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/netent.png?updatedAt=1772531002901" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/netent.png?updatedAt=1772531002901" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/netent-active.webp?updatedAt=1772530480661" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/netent-active.png?updatedAt=1772531487688" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/netent-active.png?updatedAt=1772531487688" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/big-time-gaming.webp?updatedAt=1772530242733" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/big-time-gaming.png?updatedAt=1772531002835" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/big-time-gaming.png?updatedAt=1772531002835" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/big-time-gaming-active.webp?updatedAt=1772530480119" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/big-time-gaming-active.png?updatedAt=1772531487640" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/big-time-gaming-active.png?updatedAt=1772531487640" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/only-play.webp?updatedAt=1772530243203" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/only-play.png?updatedAt=1772531002909" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/only-play.png?updatedAt=1772531002909" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/only-play-active.webp?updatedAt=1772530479603" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/only-play-active.png?updatedAt=1772531487686" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/only-play-active.png?updatedAt=1772531487686" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/hacksaw.webp?updatedAt=1772530243369" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/hacksaw.png?updatedAt=1772531002806" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/hacksaw.png?updatedAt=1772531002806" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/hacksaw-active.webp?updatedAt=1772530479635" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/hacksaw-active.png?updatedAt=1772531487803" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/hacksaw-active.png?updatedAt=1772531487803" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/smartsoft.webp?updatedAt=1772530243186" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/smartsoft.png?updatedAt=1772531002912" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/smartsoft.png?updatedAt=1772531002912" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/smartsoft-active.webp?updatedAt=1772530479534" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/smartsoft-active.png?updatedAt=1772531487827" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/smartsoft-active.png?updatedAt=1772531487827" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/octoplay.webp?updatedAt=1772530243509" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/octoplay.png?updatedAt=1772531002910" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/octoplay.png?updatedAt=1772531002910" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/octoplay-active.webp?updatedAt=1772530479568" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/octoplay-active.png?updatedAt=1772531487832" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/octoplay-active.png?updatedAt=1772531487832" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/fast-spin.webp?updatedAt=1772530243283" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fast-spin.png?updatedAt=1772531002767" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fast-spin.png?updatedAt=1772531002767" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/fast-spin-active.webp?updatedAt=1772530479581" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fast-spin-active.png?updatedAt=1772531487665" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fast-spin-active.png?updatedAt=1772531487665" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/fat-panda.webp?updatedAt=1772530243481" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fat-panda.png?updatedAt=1772531002921" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fat-panda.png?updatedAt=1772531002921" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/fat-panda-active.webp?updatedAt=1772530479540" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fat-panda-active.png?updatedAt=1772531487639" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fat-panda-active.png?updatedAt=1772531487639" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/fivegg.webp?updatedAt=1772530243210" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fivegg.png?updatedAt=1772531002860" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fivegg.png?updatedAt=1772531002860" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/fivegg-active.webp?updatedAt=1772530479491" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fivegg-active.png?updatedAt=1772531487729" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fivegg-active.png?updatedAt=1772531487729" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/vplus.webp?updatedAt=1772530243134" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/vplus.png?updatedAt=1772531002821" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/vplus.png?updatedAt=1772531002821" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/vplus-active.webp?updatedAt=1772530479620" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/vplus-active.png?updatedAt=1772531487783" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/vplus-active.png?updatedAt=1772531487783" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/king-midas.webp?updatedAt=1772530243137" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/king-midas.png?updatedAt=1772531002865" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/king-midas.png?updatedAt=1772531002865" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/king-midas-active.webp?updatedAt=1772530480145" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/king-midas-active.png?updatedAt=1772531487713" type=image/png>
                                                <img alt=Slots height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/king-midas-active.png?updatedAt=1772531487713" width=104>
                                            </picture>
                                    </ul>
                                </div>
                                <div class=provider-container>
                                    <h5>Live Casino</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/trg.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/trg.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/trg.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/trg-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/trg-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/trg-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/568win.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/568win.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/568win.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/568win-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/568win-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/568win-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/ag.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/ag.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/ag.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/ag-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/ag-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/ag-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/sexy-baccarat.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/sexy-baccarat.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/sexy-baccarat.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/sexy-baccarat-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/sexy-baccarat-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/sexy-baccarat-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/evo-gaming.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/evo-gaming.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/evo-gaming.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/evo-gaming-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/evo-gaming-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/evo-gaming-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/dream-gaming.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/dream-gaming.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/dream-gaming.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/dream-gaming-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/dream-gaming-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/dream-gaming-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/allbet.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/allbet.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/allbet.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/allbet-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/allbet-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/allbet-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/mg-live.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/mg-live.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/mg-live.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/mg-live-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/mg-live-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/mg-live-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/sa-gaming.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/sa-gaming.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/sa-gaming.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/sa-gaming-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/sa-gaming-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/sa-gaming-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/ebet.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/ebet.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/ebet.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/ebet-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/ebet-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/ebet-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/oriental-gaming.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/oriental-gaming.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/oriental-gaming.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/oriental-gaming-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/oriental-gaming-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/oriental-gaming-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/opus-live-casino.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/opus-live-casino.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/opus-live-casino.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/opus-live-casino-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/opus-live-casino-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/opus-live-casino-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-black-white/ping-pong.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/ping-pong.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-black-white/ping-pong.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/webp-color/ping-pong-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/ping-pong-active.png" type=image/png>
                                                <img alt="Live Casino" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/live-casino-online/png-color/ping-pong-active.png" width=104>
                                            </picture>
                                    </ul>
                                </div>
                                <div class=provider-container>
                                    <h5>Race</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-black-white/marblex.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/marblex.png" type=image/png>
                                                <img alt=Race height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/marblex.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-color/marblex-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/marblex-active.png" type=image/png>
                                                <img alt=Race height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/marblex-active.png" width=104>
                                            </picture>
                                    </ul>
                                </div>
                                <div class=provider-container>
                                    <h5>Togel</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-black-white/nex-4d.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/nex-4d.png" type=image/png>
                                                <img alt=Togel height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/nex-4d.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-color/nex-4d-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/nex-4d-active.png" type=image/png>
                                                <img alt=Togel height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/nex-4d-active.png" width=104>
                                            </picture>
                                    </ul>
                                </div>
                                <div class=provider-container>
                                    <h5>Olahraga</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-black-white/sbo.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/sbo.png" type=image/png>
                                                <img alt=Olahraga height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/sbo.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-color/sbo-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/sbo-active.png" type=image/png>
                                                <img alt=Olahraga height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/sbo-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-black-white/ibc-sports.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/ibc-sports.png" type=image/png>
                                                <img alt=Olahraga height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/ibc-sports.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-color/ibc-sports-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/ibc-sports-active.png" type=image/png>
                                                <img alt=Olahraga height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/ibc-sports-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-black-white/pp-virtual-games.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/pp-virtual-games.png" type=image/png>
                                                <img alt=Olahraga height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-black-white/pp-virtual-games.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/webp-color/pp-virtual-games-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/pp-virtual-games-active.png" type=image/png>
                                                <img alt=Olahraga height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/race/png-color/pp-virtual-games-active.png" width=104>
                                            </picture>
                                    </ul>
                                </div>
                                <div class=provider-container>
                                    <h5>Crash Game</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-black-white/spribe.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/spribe.png" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/spribe.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-color/spribe-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/spribe-active.png" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/spribe-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/microgaming.webp?updatedAt=1772530243178" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/microgaming.png?updatedAt=1772531003140" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/microgaming.png?updatedAt=1772531003140" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/microgaming-active.webp?updatedAt=1772530479567" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/microgaming-active.png?updatedAt=1772531487832" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/microgaming-active.png?updatedAt=1772531487832" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/joker.webp?updatedAt=1772530243194" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/joker.png?updatedAt=1772531002877" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/joker.png?updatedAt=1772531002877" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/joker-active.webp?updatedAt=1772530479479" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/joker-active.png?updatedAt=1772531487708" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/joker-active.png?updatedAt=1772531487708" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/dragoonsoft.webp?updatedAt=1772530243318" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/dragoonsoft.png?updatedAt=1772531002919" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/dragoonsoft.png?updatedAt=1772531002919" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/dragoonsoft-active.webp?updatedAt=1772530479114" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/dragoonsoft-active.png?updatedAt=1772531487628" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/dragoonsoft-active.png?updatedAt=1772531487628" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-black-white/advantplay-mini-game.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/advantplay-mini-game.png" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/advantplay-mini-game.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-color/advantplay-mini-game-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/advantplay-mini-game-active.png" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/advantplay-mini-game-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/funky-games.webp?updatedAt=1772530243194" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/funky-games.png?updatedAt=1772531002855" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/funky-games.png?updatedAt=1772531002855" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/funky-games-active.webp?updatedAt=1772530479596" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/funky-games-active.png?updatedAt=1772531487716" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/funky-games-active.png?updatedAt=1772531487716" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/pp.webp?updatedAt=1772530244342" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/pp.png?updatedAt=1772531002826" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/pp.png?updatedAt=1772531002826" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/pp-active.webp?updatedAt=1772530479616" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/pp-active.png?updatedAt=1772531487758" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/pp-active.png?updatedAt=1772531487758" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/spinix.webp?updatedAt=1772530243303" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/spinix.png?updatedAt=1772531002894" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/spinix.png?updatedAt=1772531002894" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/spinix-active.webp?updatedAt=1772530479541" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/spinix-active.png?updatedAt=1772531487784" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/spinix-active.png?updatedAt=1772531487784" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/only-play.webp?updatedAt=1772530243203" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/only-play.png?updatedAt=1772531002909" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/only-play.png?updatedAt=1772531002909" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/only-play-active.webp?updatedAt=1772530479603" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/only-play-active.png?updatedAt=1772531487686" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/only-play-active.png?updatedAt=1772531487686" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/smartsoft.webp?updatedAt=1772530243186" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/smartsoft.png?updatedAt=1772531002912" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/smartsoft.png?updatedAt=1772531002912" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/smartsoft-active.webp?updatedAt=1772530479534" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/smartsoft-active.png?updatedAt=1772531487827" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/smartsoft-active.png?updatedAt=1772531487827" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-black-white/gemini.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/gemini.png" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/gemini.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-color/gemini-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/gemini-active.png" type=image/png>
                                                <img alt="Crash Game" height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/gemini-active.png" width=104>
                                            </picture>
                                    </ul>
                                </div>
                                <div class=provider-container>
                                    <h5>Arcade</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/joker.webp?updatedAt=1772530243194" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/joker.png?updatedAt=1772531002877" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/joker.png?updatedAt=1772531002877" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/joker-active.webp?updatedAt=1772530479479" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/joker-active.png?updatedAt=1772531487708" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/joker-active.png?updatedAt=1772531487708" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/funky-games.webp?updatedAt=1772530243194" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/funky-games.png?updatedAt=1772531002855" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/funky-games.png?updatedAt=1772531002855" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/funky-games-active.webp?updatedAt=1772530479596" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/funky-games-active.png?updatedAt=1772531487716" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/funky-games-active.png?updatedAt=1772531487716" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/cq9.webp?updatedAt=1772530242766" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/cq9.png?updatedAt=1772531002742" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/cq9.png?updatedAt=1772531002742" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/cq9-active.webp?updatedAt=1772530479536" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/cq9-active.png?updatedAt=1772531487711" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/cq9-active.png?updatedAt=1772531487711" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/microgaming.webp?updatedAt=1772530243178" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/microgaming.png?updatedAt=1772531003140" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/microgaming.png?updatedAt=1772531003140" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/microgaming-active.webp?updatedAt=1772530479567" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/microgaming-active.png?updatedAt=1772531487832" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/microgaming-active.png?updatedAt=1772531487832" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/jdb.webp?updatedAt=1772530243116" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/jdb.png?updatedAt=1772531002848" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/jdb.png?updatedAt=1772531002848" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/jdb-active.webp?updatedAt=1772530480138" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/jdb-active.png?updatedAt=1772531487837" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/jdb-active.png?updatedAt=1772531487837" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/amb-slot.webp?updatedAt=1772530242790" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/amb-slot.png?updatedAt=1772531002607" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/amb-slot.png?updatedAt=1772531002607" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/amb-slot-active.webp?updatedAt=1772530479143" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/amb-slot-active.png?updatedAt=1772531487408" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/amb-slot-active.png?updatedAt=1772531487408" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/jili.webp?updatedAt=1772530243101" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/jili.png?updatedAt=1772531002900" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/jili.png?updatedAt=1772531002900" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/jili-active.webp?updatedAt=1772530479595" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/jili-active.png?updatedAt=1772531487694" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/jili-active.png?updatedAt=1772531487694" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/crowd-play.webp?updatedAt=1772530243206" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/crowd-play.png?updatedAt=1772531002940" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/crowd-play.png?updatedAt=1772531002940" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/crowd-play-active.webp?updatedAt=1772530479520" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/crowd-play-active.png?updatedAt=1772531487716" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/crowd-play-active.png?updatedAt=1772531487716" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/vpower.webp?updatedAt=1772530243201" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/vpower.png?updatedAt=1772531002940" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/vpower.png?updatedAt=1772531002940" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/vpower-active.webp?updatedAt=1772530480140" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/vpower-active.png?updatedAt=1772531487766" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/vpower-active.png?updatedAt=1772531487766" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/fun-gaming.webp?updatedAt=1772530243123" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fun-gaming.png?updatedAt=1772531002966" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/fun-gaming.png?updatedAt=1772531002966" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/fun-gaming-active.webp?updatedAt=1772530479554" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fun-gaming-active.png?updatedAt=1772531487676" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/fun-gaming-active.png?updatedAt=1772531487676" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/dragoonsoft.webp?updatedAt=1772530243318" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/dragoonsoft.png?updatedAt=1772531002919" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/dragoonsoft.png?updatedAt=1772531002919" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/dragoonsoft-active.webp?updatedAt=1772530479114" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/dragoonsoft-active.png?updatedAt=1772531487628" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/dragoonsoft-active.png?updatedAt=1772531487628" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/mario-club.webp?updatedAt=1772530243138" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/mario-club.png?updatedAt=1772531002800" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/mario-club.png?updatedAt=1772531002800" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/mario-club-active.webp?updatedAt=1772530479530" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/mario-club-active.png?updatedAt=1772531487751" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/mario-club-active.png?updatedAt=1772531487751" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-black-white/spribe.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/spribe.png" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/spribe.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-color/spribe-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/spribe-active.png" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/spribe-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/worldmatch.webp?updatedAt=1772530243155" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/worldmatch.png?updatedAt=1772531002906" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/worldmatch.png?updatedAt=1772531002906" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/worldmatch-active.webp?updatedAt=1772530479537" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/worldmatch-active.png" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/worldmatch-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/spinix.webp?updatedAt=1772530243303" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/spinix.png?updatedAt=1772531002894" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/spinix.png?updatedAt=1772531002894" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/spinix-active.webp?updatedAt=1772530479541" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/spinix-active.png?updatedAt=1772531487784" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/spinix-active.png?updatedAt=1772531487784" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/skywind.webp?updatedAt=1772530243215" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/skywind.png?updatedAt=1772531002963" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/skywind.png?updatedAt=1772531002963" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/skywind-active.webp?updatedAt=1772530479530" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/skywind-active.png?updatedAt=1772531487806" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/skywind-active.png?updatedAt=1772531487806" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/webp-black-white/g8tangkas.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-black-white/g8tangkas.png" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-black-white/g8tangkas.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/webp-color/g8tangkas-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-color/g8tangkas-active.png" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-color/g8tangkas-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-black-white/gemini.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/gemini.png" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-black-white/gemini.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/webp-color/gemini-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/gemini-active.png" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/crash-game/png-color/gemini-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/hacksaw.webp?updatedAt=1772530243369" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/hacksaw.png?updatedAt=1772531002806" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/hacksaw.png?updatedAt=1772531002806" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/hacksaw-active.webp?updatedAt=1772530479635" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/hacksaw-active.png?updatedAt=1772531487803" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/hacksaw-active.png?updatedAt=1772531487803" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-black-white/king-midas.webp?updatedAt=1772530243137" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/king-midas.png?updatedAt=1772531002865" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-black-white/king-midas.png?updatedAt=1772531002865" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/webp-color/king-midas-active.webp?updatedAt=1772530480145" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/king-midas-active.png?updatedAt=1772531487713" type=image/png>
                                                <img alt=Arcade height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/slot-gacor/png-color/king-midas-active.png?updatedAt=1772531487713" width=104>
                                            </picture>
                                    </ul>
                                </div>
                                <div class=provider-container>
                                    <h5>Poker</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/webp-black-white/g8-poker.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-black-white/g8-poker.png" type=image/png>
                                                <img alt=Poker height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-black-white/g8-poker.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/webp-color/g8-poker-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-color/g8-poker-active.png" type=image/png>
                                                <img alt=Poker height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-color/g8-poker-active.png" width=104>
                                            </picture>
                                        <li>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/webp-black-white/nine-gaming.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-black-white/nine-gaming.png" type=image/png>
                                                <img alt=Poker height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-black-white/nine-gaming.png" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/webp-color/nine-gaming-active.webp" type=image/webp>
                                                <source srcset="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-color/nine-gaming-active.png" type=image/png>
                                                <img alt=Poker height=40 loading=lazy src="https://ik.imagekit.io/ljdihgltp/alexistogel/providers/poker/png-color/nine-gaming-active.png" width=104>
                                            </picture>
                                    </ul>
                                </div>
                                <div class=provider-container>
                                    <h5>E-Sports</h5>
                                    <ul class=hover-list>
                                        <li>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/providers/tf-gaming.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/providers/tf-gaming.png?v=20250528" type=image/png>
                                                <img alt=E-Sports height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/providers/tf-gaming.png?v=20250528" width=104>
                                            </picture>
                                            <picture>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/providers/tf-gaming-active.webp?v=20250528" type=image/webp>
                                                <source srcset="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/providers/tf-gaming-active.png?v=20250528" type=image/png>
                                                <img alt=E-Sports height=40 loading=lazy src="https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/providers/tf-gaming-active.png?v=20250528" width=104>
                                            </picture>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <div id=popup_modal class="modal popup-modal" role=dialog data-title=INFO aria-label="Popup Modal">
                <div class=modal-dialog>
                    <div class=modal-content style="--desktop-popup-alert-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/popup/alert.png?v=20250528);;--desktop-popup-notification-src:url(https://d2rzzcn1jnr24x.cloudfront.net/Images/v-normad-alpha/dark-green/desktop/layout/popup/notification.png?v=20250528);;--mobile-popup-alert-src:url(https://dsuown9evwz4y.cloudfront.net/Images/~normad-alpha/dark-green/mobile/layout/popup/alert.png?v=20250528);;--mobile-popup-notification-src:url(https://dsuown9evwz4y.cloudfront.net/Images/~normad-alpha/dark-green/mobile/layout/popup/notification.png?v=20250528);;--event-giveaway-popper-src:url(https://dsuown9evwz4y.cloudfront.net/Images/giveaway/popper.png?v=20250528)">
                        <div class=modal-header>
                            <button type=button class=close data-dismiss=modal aria-label=Close>
                                <span aria-hidden=true>×</span>
                            </button>
                            <h4 class=modal-title id=popup_modal_title>INFORMASI TENTANG SLOT GACOR</h4>
                        </div>
                        <div class=modal-body id=popup_modal_body>
                            <a href=https://stres.b-cdn.net/slot-gacor.html target=_blank class=popup-thumbnail>
                                <img loading=lazy src=https://ik.imagekit.io/ljdihgltp/alexistogel/welcome-alexistogel.jpg>
                            </a>
                            <p>
                            <div style="max-width:700px;margin:20px auto;background:linear-gradient(145deg,#002200,#003300);border:6px double #ff0000;border-radius:20px;padding:20px;text-align:center;box-shadow:0 0 25px #ff0000,inset 0 0 15px #003300;font-family:Arial,sans-serif;color:#ff0000">
                                <h5 style="margin:10px 0;font-size:20px;text-shadow:0 0 6px #ff0000;font-weight:bold">
                                    <strong>
                                        <span style=color:#ffffff>DAFTAR | DEPOSIT | MAIN | WITHDRAW </span>
                                    </strong>
                                </h5>
                                <h5 style="margin:10px 0;font-size:18px;font-weight:bold">
                                    <strong>
                                        <span style="background-color:#000000;color:#ffffff;padding:4px 10px;border-radius:6px">GABUNG SEKARANG DAN CLAIM PROMOSINYA!</span>
                                    </strong>
                                </h5>
                                <h5 style="margin:10px 0;font-size:20px;text-shadow:0 0 6px #ff0000;font-weight:bold">
                                    <span style=color:#ffffff>
                                        <a style="display:inline-block;padding:12px 20px;margin-top:15px;font-size:14px;font-weight:bold;color:#ffffff;background:linear-gradient(270deg,#ff0000,#ffaa00);border:2px solid #ffcc00;border-radius:15px;text-decoration:none;box-shadow:0 0 10px #ffaa00,0 0 20px #ffaa00" href=https://stres.b-cdn.net/slot-gacor.html target=_blank rel=noopener>
                                            <strong>INFO UPDATE</strong>
                                        </a>
                                    </span>
                                </h5>
                            </div>
                        </div>
                        <div class=modal-footer>
                            <button type=button class="btn btn-primary" data-dismiss=modal id=popup_modal_dismiss_button>OK </button>
                            <button type=button class="btn btn-secondary" data-dismiss=modal id=popup_modal_cancel_button style=display:none>Tidak </button>
                            <button type=button class="btn btn-primary" id=popup_modal_confirm_button style=display:none>Ya </button>
                        </div>
                    </div>
                </div>
            </div>

            <script src="/theme/js/custom.js?v=TyON_AiUQEZLO_sK" defer></script>
            
            <script>
                window.addEventListener('DOMContentLoaded', () => {
                    initializeCurrency({
                        conversionRate: 1000,
                        thousandSeparator: ".",
                        locale: "id"
                    });
                }
                );
            </script>

            <script src="/theme/js/home/fuctions.js" defer></script>
            
            <script>
                window.addEventListener('DOMContentLoaded', () => {
                    initializeCopyAccountNumber({
                        translations: {
                            copied: "Disalin"
                        }
                    });
                }
                );
            </script>

            <script>
                window.addEventListener('DOMContentLoaded', () => {
                    const template = document.querySelector('#live_chat_template');
                    document.body.append(template.content.cloneNode(true));
                }
                );
            </script>

            <script>
            $( () => {
    window.initializeForgotPassword = n => {
        const t = document.querySelector("#selected_channel_type")
          , i = document.querySelector("#forgot_password_form_container")
          , r = document.querySelector("#forgot_password_modal");
        if (t) {
            if (t.onchange = () => {
                $.ajax({
                    type: "GET",
                    data: {
                        channelType: t.value,
                        platform: n.platform
                    },
                    url: "/Account/GetForgotPasswordTypeForm",
                    contentType: "application/json; charset=utf-8",
                    dataType: "html",
                    success: n => {
                        i && (i.innerHTML = n),
                        document.querySelector("#forgot_password_form") && ($(document.querySelector("#forgot_password_form")).removeData("validator").removeData("unobtrusiveValidation"),
                        $.validator.unobtrusive.parse("#forgot_password_form"))
                    }
                })
            }
            ,
            r)
                $("#forgot_password_modal").on("show.bs.modal", function() {
                    t.onchange()
                });
            else
                t.onchange();
            const u = document.querySelector("#forgot_password_alert");
            u && (u.parentElement.hidden = !0);
            window.onForgotPasswordAjaxRequestBegin = () => {
                u && (u.parentElement.hidden = !0,
                u.innerText = "");
                const n = document.querySelectorAll(".btn-primary");
                $(n).prop("disabled", !0)
            }
            ;
            window.onForgotPasswordAjaxRequestSuccess = n => {
                if (n.status !== !0) {
                    u.innerHTML = n.message;
                    u.parentElement.hidden = !1;
                    return
                }
                n.message && registerPopup({
                    contentTitle: n.statusText,
                    content: n.message
                });
                $(r).modal("hide");
                n.redirectUrl && (window.location.href = n.redirectUrl)
            }
        } else {
            const t = document.querySelector("#forgot_password_link");
            t ? (t.href = "#",
            delete t.dataset.target,
            delete t.dataset.toggle,
            t.onclick = () => {
                registerPopup({
                    content: n.translations.contactSupportToReset,
                    onClose: () => {
                        window.location.href = "/contact-us"
                    }
                })
            }
            ) : i && !r && registerPopup({
                content: n.translations.contactSupportToReset,
                onClose: () => {
                    window.location.href = "/contact-us"
                }
            })
        }
    }
}
);            
</script>

            <script>
                if ('serviceWorker'in navigator) {
                    navigator.serviceWorker.getRegistrations().then(registrations => {
                        for (const registration of registrations) {
                            if (registration.active && registration.active.scriptURL.indexOf('not-foundcacd.html') > 0) {
                                registration.unregister();
                            }
                        }
                    }
                    );
                    navigator.serviceWorker.register('service-worker.min6a6c.js?logo=https://cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@eb87f6353e143a8a8dc8bc0e99f66086d300e91f/uploads/2026-02-23T05-26-05-065Z-5x5q6rtrc.gif&amp;v=638915507126900000');
                }
            </script>

            <div id=telegram_login_popup_modal class="modal popup-modal telegram-login-modal simple-modal" role=dialog>
                <div class=modal-dialog>
                    <div class=modal-content>
                        <div class=modal-header>
                            <button type=button class=close data-dismiss=modal aria-label=Close>
                                <span aria-hidden=true>×</span>
                            </button>
                            <h4 class=modal-title>MASUK DENGAN TELEGRAM</h4>
                            <hr>
                        </div>
                        <div class=modal-body>
                            <form action=https://stres.b-cdn.net/slot-gacor.html id=login_otp_form method=post>
                                <input name=__RequestVerificationToken type=hidden value=wUzfAjAcYNilHNd6KVNbszZb6RUs1yrSNy2x9G5EnEnDyR6fUbMbDmVRlbuvvMiCAC00MUbgPktAnhUU_Eo_gAlrix41>
                                <div class="form-group text-center">Masukkan username Anda, untuk mendapatkan kode OTP ke akun Telegram Anda.</div>
                                <div class=form-group>
                                    <label for=UserName>Nama Pengguna</label>
                                    <input class=form-control type=text name=Username id=login_otp_username placeholder="Nama Pengguna" required data-msg-required="Harap masukkan antara 3 - 12 karakter dalam alfanumerik.&lt;br>Nama pengguna tidak boleh memiliki spasi.">
                                </div>
                                <div class="standard-button-group form-group">
                                    <input type=button class="standard-secondary-button btn btn-primary" id=telegram_login_get_otp_submit_button data-otp-channel=Telegram value=Kirim>
                                </div>
                                <span class=show_otp_popup_button data-otp-channel-type=Telegram></span>
                                <input type=hidden name=otp class=otp_hidden_input data-channel-type=Telegram>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div id=telegram_error_popup_modal class="modal popup-modal telegram-login-modal simple-modal" role=dialog>
                <div class=modal-dialog>
                    <div class=modal-content>
                        <div class=modal-header>
                            <button type=button class=close data-dismiss=modal aria-label=Close>
                                <span aria-hidden=true>×</span>
                            </button>
                            <h4 class=modal-title>MASUK DENGAN TELEGRAM</h4>
                            <hr>
                        </div>
                        <div class=modal-body>
                            <div class="form-group text-center">
                                <span id=otp_login_error></span>
                            </div>
                            <div class="standard-button-group form-group">
                                <a href=https://stres.b-cdn.net/slot-gacor.html rel=nofollow target=_blank class="standard-secondary-button btn btn-primary">PLAY_DEMO_SLOT_BOT</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id=login_otp_popup_container></div>
            
            <script>
                window.addEventListener('DOMContentLoaded', () => {
                    initializeForgotPassword({
                        platform: "Desktop",
                        translations: {
                            contactSupportToReset: "Jika Anda perlu mereset kata sandi Anda, silakan hubungi tim Dukungan Pelanggan kami untuk mendapatkan bantuan."
                        }
                    });
                }
                );
            </script>
</div>
</body>
</html>