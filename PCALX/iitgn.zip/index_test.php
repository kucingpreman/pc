<?php
$msg="";
// first if
if(isset($_POST['btn-save'])){
	session_start();
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	
	// start try
	try {
		$mysqli = new mysqli("localhost", "hostixah_acdadm", "V3N?PHaMugV@", "hostixah_academic_result");
		//$mysqli = new mysqli("localhost", "root", "", "academic_result");
		$mysqli->set_charset("utf8mb4");
	} catch(Exception $e) {
		error_log($e->getMessage());
		exit('There is an issue to connect the server. Please try again or send an email to admission@iitgn.ac.in for further query.'); //Should be a message a typical user could understand
	}
	//end of try
	$stmt = $mysqli->prepare("SELECT ap_number,name,discipline,programme,email,date,status,result,zoom FROM result WHERE ap_number = ? AND dob = ?");
	$stmt->bind_param("ss", $_POST['ap_number'], $_POST['dob']);
	$stmt->execute();
	$stmt->store_result();
	$stmt->num_rows;
	// secod if
	if($stmt->num_rows === 0) {
		$msg="Either you have entered incorrect application number/ date of birth or you are not shortlited.!";
	}
	else{
		$stmt->bind_result($ap_number, $name, $discipline,$programme,$email,$date,$status,$result,$zoom);
		$stmt->fetch();
		
		$stmt->close();
	//	echo $ap_number. $name. $email.$phone;
						
		//$rndno=rand(100000, 999999);//OTP generate
		//$message = urlencode("otp number.".$rndno);
		
		// These are our "usual" mail parameters
//$to = $email;
//$subject = "OTP for admission at IITGN";
	//	$txt = "Dear $name,<br><br>
		//Your OTP number is ".$rndno."<br><br>
		//Best Regards,<br>
		//Academic Office,<br>
		//Indian Institute of Technology Gandhinagar<br>
		//Palaj, Gandhinagar-382355<br>
		//Gujarat
		
		//";
// Custom headers
//$headers = [
 // 'MIME-Version: 1.0',
 // 'Content-type: text/html; charset=ISO-8859-1',
 // 'From: IITGN Admission <noreply1@iitgn.ac.in>',
//  'Bcc: tejg@iitgn.ac.in',
//  'Bcc: noreply1@iitgn.ac.in'
//];
//$headers = implode("\r\n", $headers);

// Send the email
//$sent = mail($to, $subject, $txt, $headers);
//echo $sent ? "Mail send OK" : "Mail send ERROR" ;

	// Always set content-type when sending HTML email
//$headers = "MIME-Version: 1.0" . "\r\n";
//$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
//$headers .= 'From: IITGN Admission <noreply1@iitgn.ac.in>' . "\r\n";
//$headers .= 'Bcc: tejg@iitgn.ac.in' . "\r\n";
//$headers .= 'Bcc: noreply1@iitgn.ac.in' . "\r\n";

	//$sent=mail($to,$subject,$txt,$headers);
		
		$mail="success";
		//if(isset($_POST['btn-save']))
		//{
		$_SESSION['name']=$name;
		$_SESSION['ap_number']=$ap_number;
		$_SESSION['discipline']=$discipline;
		$_SESSION['programme']=$programme;
		$_SESSION['email']=$email;
		$_SESSION['date']=$date;
		$_SESSION['otp']=$rndno;
		$_SESSION['status']=$status;
		$_SESSION['result']=$result;
		$_SESSION['zoom']=$zoom;
		
		
		header( "Location: otp-test.php" );
	}// end  second if 
}// end first if
?>

<!DOCTYPE html>
<html>
<header>
<title>Admission | IIT Gandhinagar</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-158026806-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-158026806-1');
</script>

<header>
<body>
<br><br>
<div align="center">
<div class="w3-half w3-card-2 w3-round">
<div class="w3-container w3-center w3-blue" align="center">
<img src="iitgn.png" style="width:130px;"><h2>IIT Gandhinagar</h2>
</div>
<!--marquee width="90%" direction="left" height="40px" style="color:#990000">
<span style="color:#FF0000">All provisionally selected candidates in the special round of PhD admission 2021-22, SEM-I have been informed.</span>
</marquee==-->
<!--p></p>
<p><font style="color:#0066FF; font-size:14px;">"The candidates who applied for Theoretical and Applied Mechanics in the discipline of Mechanical Engineering may enter <font color='red'> '00000' (five times zero) </font> in the field of Application Number."</font></p>-->


<p>
    <font style="color:#006600;"><sup><img src="new1.gif"></sup> Shortlisted candidates for Interview 
    <br> <b>MSc in Cognitive Sciences Programme</b> 
    <br>
    <!--b>M.A. in Society and Culture Programme<br-->
    AY: 2022-23 (Semester I)</b></font><br>
   
                               
    <!--font>List of Candidates Provisionally Shortlisted for Online written test/ interview of <b>Start Early Ph.D, Early Admit M.Tech</b> and <b>Early Admit M.Sc Programme AY: 2022-23 (Semester I)</b></font><br>
    <!--font>List of Candidates Provisionally Shortlisted for online written test and/or online interview of M.Tech/WS M.Tech/PGDIIT Programmes for Semester-I of AY 2021-22</font><br>
<!--font style="color:#FF0000;">
M.A. Society and Culture programme (Admission)<br>
 Early Admit MSc Programme  (Admission)<br>
 Start Early Ph.D. Programme (Admission)<br>
 M.Sc Cognitive Sciences (Admission)<br>
 Early Admit M.Tech Programme (Admission)
<br>
</font>
<font>
AY: 2021-22 (Semester-I)</font--></p>
<div id="content" style="float:right">
<div class="help-tip">
	<p>If you have any query/issue related to admission please email to <a href="mailto:academics@iitgn.ac.in">academics@iitgn.ac.in</a>.</p>
</div>
</div>
<br>
<p style=" color:#FF0000"><?php echo $msg;?></p>
<form class="w3-container" method="post" action="">
<label class="w3-label w3-text-black"><b>Application Number</b></label>
<p><input class="w3-input w3-border w3-round" type="text" placeholder="" name="ap_number" required></p>
<label class="w3-label w3-text-black"><b>Date of Birth (dd/mm/yyyy)</b></label>
<p><input class="w3-input w3-border w3-round" type="text" placeholder="ex: 02/09/1995" name="dob" required></p>
<p class="w3-center"><button class="w3-btn w3-blue w3-round" style="width:100%;height:40px" name="btn-save">Submit</button></p>
</form>
<br><br>
<div class="w3-container w3-center w3-light-grey">
<h4>&copy;Copyright <?php echo date("Y"); ?>. IIT Gandhinagar</h4>
</div>
</div>
<div class="w3-half">
</div>
</div>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
</body>

</html>