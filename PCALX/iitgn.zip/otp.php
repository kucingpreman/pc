<?php
session_start();
if(isset($_SESSION['email'])){
$sessionemail=$_SESSION['email'];
}else{
header( "Location: index.php" );
}
//$message="Dear" .$_SESSION['name']. "<br><br>An OTP has been sent in your registered email id [".$_SESSION['email']."]. Please check your span/junk box if you do not receive any email in your inbox.";
/*if(isset($_POST['save']))
{
$rno=$_SESSION['otp'];
$urno=$_POST['otpvalue'];
if(!strcmp($rno,$urno))
{*/
	$name=$_SESSION['name'];
	$email=$_SESSION['email'];
    $status=$_SESSION['status'];
	$discipline=$_SESSION['discipline'];
	$programme=$_SESSION['programme'];
	$ap_number= $_SESSION['ap_number'];
    $result= $_SESSION['result'];
    
$servername = "localhost";
$username = "apply4ttgd_academicresult";
$password = "lH0A981b}%DT";
$dbname = "apply4ttgd_academic_result";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM result WHERE ap_number='$ap_number'";
$result = $conn->query($sql);
//echo "result number -->".$result->num_rows;

//$conn->close();

?>

<!DOCTYPE html>
<html>
<header>
<title>Admission | IIT Gandhinagar </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<style>
a{
text-decoration:none;
}
</style>
<style>
        /* Basic table styling */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }

        /* Responsive design: Stack rows on smaller screens */
        @media screen and (max-width: 600px) {
            table {
                width: 100%;
                border: none;
            }
            thead {
                display: none; /* Hide table headers on small screens */
            }
            tr {
                display: block; /* Make each row a block element */
                margin-bottom: 10px; /* Add space between rows */
            }
            td {
                display: block; /* Make each cell a block element */
                text-align: right; /* Align text to the right */
                padding-left: 50%; /* Add space for labels */
                position: relative;
            }
            td::before {
                /* Add labels to each cell */
                content: attr(data-label);
                position: absolute;
                left: 10px;
                top: 10px;
                font-weight: bold;
            }
        }
    </style>
<header>
<body>
<?php 
//if(isset($status)){
?>
<div align="center">
<div class="w3-half w3-card-2 w3-round">
<div class="w3-container w3-center w3-blue" align="center"><br>
<img src="iitgn_logo_white.png" style="width:80px;"><h2><a href="logout.php"><img src="home.png" style="width:40px;" title="Search you result"></a> | IIT Gandhinagar</h2>
</div>
<div id="content" style="float:right">
	
	<div class="help-tip">
				<p>If you have any query/issue related to your admission please email to <a href="mailto:admission@iitgn.ac.in"><strong><u>admission@iitgn.ac.in</u></strong></a>.</p>
			</div>
</div>
<br><br>
<div  style="text-align:center">
  <?php   
 // echo $result->num_rows;
    if ($result->num_rows > 0) {?>
	<table >
    	<thead>
    		<tr>
    	<th scope='col'>Name </th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Department</th>
    	<th scope='col'>Status</th>
    	
    	</tr>
    	</thead>
	<?php 
    // output data of each row
    while($row = $result->fetch_assoc()) { ?>
        
        <tr>
    	<td  data-label='Name'> <?php echo $row["name"]; ?></td>
    	<td data-label='Application Number'><?php echo $row["ap_number"]; ?></td>
    	<td data-label='Programme'><?php echo $row["programme"]; ?></td>
    	<td data-label='Discipline'><?php echo $row["discipline"]; ?></td>
    	<td data-label='Status'><?php echo $row["status"]; ?></td>
		
	
		<?php 
		echo "	</tr>";
    }
     echo "</table>";
} else {
    echo "0 results";
}

?>

    
</div>

<p><br><br><br></p>
<div class="w3-container w3-center w3-light-grey">
<h4>&copy;Copyright <?php echo date("Y"); ?>. IIT Gandhinagar</h4>
</div>
</div>
<div class="w3-half">
</div>
</div>

<?php //} else{?>

<?php /*?><div align="center">
<div class="w3-half w3-card-2 w3-round" align="center">
<div class="w3-container w3-center w3-blue" align="center">
<img src="iitgn.png" style="width:150px;"><h2><a href="logout.php"><img src="home.png" style="width:40px;" title="Search you result"></a> | IIT Gandhinagar</h2>
<hr>
<h3>Submit your OTP</h3>
</div>
<div id="content" style="float:right">
	<div class="help-tip">
				<p>If you have any query/issue related to your admission please email to <a href="mailto:admission@iitgn.ac.in"><strong><u>admission@iitgn.ac.in</u></strong></a>.</p>
			</div>
</div>

<br>
<form class="w3-container" method="post" action="">
<br>
<div  style="text-align:center; float:left"><?php if(isset($message1)) { echo $message1; } ?>
</div>

<p> <?php if(isset($_GET["mail"]) && ($_GET["mail"]== "send")){echo "Dear " .$_SESSION['name'].",<br><br>An OTP has been sent in your registered email  [".$_SESSION['email']."]. Please wait for some time and <font color='red'><u>check your spam/junk box</u></font> if you do not receive any email in your inbox.";}
if(isset($_GET["otp"]) && ($_GET["otp"]== "invalid")){echo "<font color=red>Invalid OTP. Please try again!</font>";}

if(isset($_GET["otp"]) && ($_GET["otp"]== "resend")){echo "<font color=green>Sucessfully resend OTP to your email [".$_SESSION['email']."]. Please wait for some time and check your spam/junk box if you do not receive any email in your inbox.</font>";}

?></p>
<p><input class="w3-input w3-border w3-round" type="password" placeholder="OTP" name="otpvalue"></p>
<p class="w3-center"><button class="w3-btn w3-blue w3-round" style="width:100%;height:40px" name="save">Submit</button></p>
<p class="w3-center"><button class="w3-btn w3-blue w3-round" style="width:100%;height:40px" name="resend">Resend</button></p>
</form>
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<br>
<div class="w3-container w3-center w3-light-grey">
<h4>&copy;Copyright 2020. IIT Gandhinagar</h4>
</div>
</div>
<div class="w3-half">
</div>
</div><?php */?>
<?php// }?>
</body>
<style>
table {
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 100%;
  table-layout: fixed;
}

table caption {
  font-size: 1.5em;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
}

table th,
table td {
  padding: .625em;
  text-align: center;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  table td::before {
    /*
    * aria-label has no advantage, it won't be read inside a table
    content: attr(aria-label);
    */
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}
</style>
</html>