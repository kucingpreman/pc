<?php
$msg="";
// first if
if(isset($_POST['btn-save'])){
	session_start();
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	
	// start try
	try {
		$mysqli = new mysqli("localhost", "hostixah_acdadm", "V3N?PHaMugV@", "hostixah_academic_result");
		$mysqli->set_charset("utf8mb4");
	} catch(Exception $e) {
		error_log($e->getMessage());
		exit('There is an issue to connect the server. Please try again or send an email to admission@iitgn.ac.in for further query.'); //Should be a message a typical user could understand
	}
	//end of try
	$stmt = $mysqli->prepare("SELECT ap_number,name,discipline,programme,email,status FROM result WHERE ap_number = ? AND dob = ?");
	$stmt->bind_param("ss", $_POST['ap_number'], $_POST['dob']);
	$stmt->execute();
	$stmt->store_result();
	
	// secod if
	if($stmt->num_rows === 0) {
		$msg="You have entered incorrect application number or date of birth!";
	}
	else{
		$stmt->bind_result($ap_number, $name, $discipline,$programme,$email, $status);
		$stmt->fetch();
		
		$stmt->close();
	//	echo $ap_number. $name. $email.$phone;
						
		$rndno=rand(100000, 999999);//OTP generate
		$message = urlencode("otp number.".$rndno);
		
		// These are our "usual" mail parameters
$to = $email;
$subject = "OTP for admission at IITGN";
		$txt = "Dear $name,<br><br>
		Your OTP number is ".$rndno."<br><br>
		Best Regards,<br>
		Academic Office,<br>
		Indian Institute of Technology Gandhinagar<br>
		Palaj, Gandhinagar-382355<br>
		Gujarat
		
		";
// Custom headers
$headers = [
  'MIME-Version: 1.0',
  'Content-type: text/html; charset=ISO-8859-1',
  'From: IITGN Admission <admission@iitgn.ac.in>',
  'Reply-To: IITGN Admission <admission@iitgn.ac.in>',
  'Bcc: tejg@iitgn.ac.in'
];
$headers = implode("\r\n", $headers);

// Send the email
$sent = mail($to, $subject, $txt, $headers);
//echo $sent ? "Mail send OK" : "Mail send ERROR" ;

		
		//
//		$headers = "From: IITGN Admission <admission@iitgn.ac.in>" . "\r\n" .
//		$headers .= "Bcc: tejg@iitgn.ac.in"."\r\n";
//		$headers .= "MIME-Version: 1.0\r\n";
//		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
//		
//		mail($to,$subject,$txt,$headers);
		
		$mail="success";
		//if(isset($_POST['btn-save']))
		//{
		$_SESSION['name']=$name;
		$_SESSION['ap_number']=$ap_number;
		$_SESSION['discipline']=$discipline;
		$_SESSION['programme']=$programme;
		$_SESSION['email']=$email;
		$_SESSION['otp']=$rndno;
		$_SESSION['status']=$status;
		
		header( "Location: otp.php?mail=send" );
	}// end  second if 
}// end first if
?>

<!DOCTYPE html>
<html>
<header>
<title>Admission | IIT Gandhinagar</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<header>
<body>

<br><br>
<div align="center">
<div class="w3-half w3-card-2 w3-round">
<div class="w3-container w3-center w3-blue" align="center">
<img src="iitgn.png" style="width:130px;"><h2>IIT Gandhinagar</h2>
</div>
<p  style="color:#CC0000;"><b>Site is under maintenance. Please come back after some time!</b></p>


<div class="w3-container w3-center w3-light-grey">
<h4>&copy;Copyright 2019. IIT Gandhinagar</h4>
</div>
</div>
<div class="w3-half">
</div>
</div>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
</body>

</html>