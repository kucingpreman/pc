<?php
$msg="";
// first if
if(isset($_POST['btn-save'])){
	session_start();
	mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	
	// start try
	try {
		$mysqli = new mysqli("localhost", "apply4ttgd_academicresult", "lH0A981b}%DT", "apply4ttgd_academic_result");
		$mysqli->set_charset("utf8mb4");
	} catch(Exception $e) {
		error_log($e->getMessage());
		exit('There is an issue to connect the server. Please try again or send an email to admission@iitgn.ac.in for further query.'); //Should be a message a typical user could understand
	}
	//end of try
	$stmt = $mysqli->prepare("SELECT ap_number,name,discipline,programme,email,status FROM emaster WHERE ap_number = ? AND dob = ?");
	$stmt->bind_param("ss", $_POST['ap_number'], $_POST['dob']);
	$stmt->execute();
	$stmt->store_result();
	$stmt->num_rows;
	// secod if
	if($stmt->num_rows === 0) {
		$msg="Either you have entered incorrect application number/ date of birth or your record is not found!";
	}
	else{
		$stmt->bind_result($ap_number, $name, $discipline,$programme,$email,$status);
		$stmt->fetch();
		
		$stmt->close();
		$mail="success";
		//if(isset($_POST['btn-save']))
		//{
		$_SESSION['name']=$name;
		$_SESSION['ap_number']=$ap_number;
		$_SESSION['discipline']=$discipline;
		$_SESSION['programme']=$programme;
		$_SESSION['email']=$email;
		$_SESSION['status']=$status;
		
		header( "Location: emaster-otp.php" );
	}// end  second if 
}// end first if
?>

<!DOCTYPE html>
<html>
<header>
<title>Admission | IIT Gandhinagar</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-158026806-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-158026806-1');
</script>

<header>
<body>
<div align="center">
<div class="w3-half w3-card-2 w3-round">
<div class="w3-container w3-center w3-blue" align="center"><br>
<img src="iitgn_logo_white.png" style="width:80px;"><h4>Executive Masters Result Announcement</h4>
</div>
<br>
 <hr>
<p style="font-size:14px;"><font style="color:blue"><sup><img src="new1.gif"></sup>List of candidates provisionally selected for Energy Policy and Regulation- Batch 2  - Round 7
 </font>
 </p>
<p style="font-size:14px;"><font style="color:blue"> List of candidates provisionally selected for Energy Policy and Regulation- Batch 2  - Round 6
 </font>
 </p>
 <hr>
<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for Energy Policy and Regulation- Batch 2  - Round 5
 </font>
 </p>
 <hr>
<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for Data Science for Decision Making - Batch 2- Round 4
 </font>
 </p>

 <!--<hr>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for Data Science for Decision Making - Batch 2- Round 3-->
<!-- </font>-->
<!-- </p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for   Energy Policy and Regulation- Batch 2  - Round 3-->
<!-- </font></p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for  Application of Machine Learning in Engineering - Round 4-->
<!-- </font></p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for  Application of Machine Learning in Engineering - Round 3-->
<!-- </font></p>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for Energy Policy and Regulation- Batch 2- Round 2-->
<!-- </font></p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue"> List of candidates provisionally selected for Data Science for Decision Making- Batch 2- Round 2-->
<!-- </font></p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue"> List of candidates provisionally selected for Composites-->
<!-- </font></p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue"> List of candidates provisionally selected for Energy Policy and Regulation- Batch 2- Round 1-->
<!-- </font></p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for e-Masters Applications of Machine Learning in Engineering (AMLE) - Round 2-->
<!-- </font></p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for e-Masters in Data Science for Decision Making (DSDM)- Round 1-->
<!-- </font></p>-->
 <!--<hr>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of candidates provisionally selected for e-Masters in Applications of Machine Learning in Engineering (AMLE)- Round 1-->
<!-- </font></p>-->
<!-- <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue">List of Candidates Provisionally Selected for Admission to Early Admit MTech Programme (Phase II)<br>-->
<!--(Semester I, AY 2025-26)<br>-->
<!--Mechanical Engineering<br>-->
<!--Earth System Science<br>-->
<!--Materials Engineering<br>-->
<!--Electrical Engineering<br> -->
<!--Biological Engineering<br>-->
<!--Integrated Circuit Design and Technology<br>-->
<!--Chemical Engineering<br>-->
<!--Artificial Intelligence<br>-->
<!--Computer Science and Engineering<br>-->
<!--Civil Engineering -->
 </font></p>
<!--<p style="padding:0px 0px 0px 0px"><b>Humanities and Social Sciences</b><br> -->
<!--   </p> -->
<!--    <hr>-->
<!--<p style="font-size:14px;"><font style="color:blue"><sup><img src="new1.gif"></sup> List of Candidates Provisionally Shortlisted for written test and/or Interview of M.Sc.-Regular Programme for 2025-2026 & Semester-1-->
<!-- </font></p>-->
<!--<p style="padding:0px 0px 0px 0px"><b>Cognitive and Brain Sciences</b><br> -->
<!--   </p> -->
    <!--<hr>-->

<!--<p style="font-size:14px;"><font style="color:blue"><sup><img src="new1.gif"></sup> List of Candidates Provisionally Selected for Admission to PhD Regular Programme (Semester-II, AY 2024-25) </font></p>-->
<!--<p style="padding:0px 0px 0px 0px"><b>Humanities and Social Sciences-->
<!-- | Computer Science and Engineering | Cognitive Sciences | Earth Science | Physics | Chemistry | Biological Sciences and Engineering | Mechanical Engineering | Civil Engineering | Electrical Engineering | Mathematics | Chemical Engineering | Materials Engineering</b><br> -->
<!--   </p> -->
<!--    <hr>-->
<!--    <p style="font-size:14px;"><font style="color:blue"><sup><img src="new1.gif"></sup> List of Candidates Provisionally Selected for PhD CDP Programme (Semester-II, AY 2024-25)</font></p>-->
<!--<p style="padding:0px 0px 0px 0px"><b>Computer Science and Engineering | Physics | Mechanical Engineering | Civil Engineering | Cognitive and Brain Sciences | Chemistry | Electrical Engineering-->
<!-- | Biological Sciences and Engineering | Chemical Engineering</b><br> -->
<!--   </p> -->
<!--    <hr>-->
<!--     <p style="font-size:14px;"><font style="color:blue"><sup><img src="new1.gif"></sup> List of Candidates Provisionally Selected for Admission to Start Early PhD Programme (Semester I, AY 2025-26)</font></p>-->
<!--<p style="padding:0px 0px 0px 0px"><b>Computer Science and Engineering | Biological Sciences and Engineering | Chemistry | Civil Engineering | Mechanical Engineering | Electrical Engineering | Earth Science | Physics | Chemical Engineering | Materials Engineering</b><br> -->
<!--   </p> -->
    <hr>
<div id="content" style="float:right">
<div class="help-tip">
	<p>If you have any query/issue related to admission please email to <a href="mailto:admission@iitgn.ac.in">admission@iitgn.ac.in</a>.</p>
</div>
</div>
<br>
<p style=" color:#FF0000"><?php echo $msg;?></p>
<form class="w3-container" method="post" action="">
<label class="w3-label w3-text-black"><b>Application Number</b></label>
<p><input class="w3-input w3-border w3-round" type="text" placeholder="" name="ap_number" required></p>
<label class="w3-label w3-text-black"><b>Date of Birth (dd/mm/yyyy)</b></label>
<p><input class="w3-input w3-border w3-round" type="text" placeholder="ex: 02/09/1995" name="dob" required></p>
<p class="w3-center"><button class="w3-btn w3-blue w3-round" style="width:100%;height:40px" name="btn-save">Submit</button></p>
</form>
<br><br>
<!--<div class="w3-container w3-center w3-light-grey">-->
<!--<h4>&copy;Copyright <?php //echo date("Y"); ?>. IIT Gandhinagar</h4>-->
<!--</div>-->
</div>
<div class="w3-half">
</div>
</div>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
</body>

</html>