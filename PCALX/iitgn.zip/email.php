<?php
$to = "tejg@iitgn.ac.in";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: webmaster@iitgn.ac.in" . "\r\n" .
"CC: tejdgurung20@gmail.com";

mail($to,$subject,$txt,$headers);
if(mail){
    echo "send";
    
}
else{
    
    echo "not send";
}
?>