<style>
table {
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 100%;
  table-layout: fixed;
}

table caption {
  font-size: 1.5em;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
}

table th,
table td {
  padding: .625em;
  text-align: center;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  table td::before {
    /*
    * aria-label has no advantage, it won't be read inside a table
    content: attr(aria-label);
    */
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}
</style>

<?php
session_start();
if(isset($_SESSION['email'])){
echo $sessionemail=$_SESSION['email'];
}else{
echo $sessionemail="not found";
}
<!DOCTYPE html>
<html>
<header>
<title>Admissions | IIT Gandhinagar</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<style>
a{
text-decoration:none;
}
</style>
<header>
<body>
<br>
<?php 
if(isset($status)){
?>
<div align="center">
<div class="w3-half w3-card-2 w3-round">
<div class="w3-container w3-center w3-blue" align="center">
<img src="iitgn.png" style="width:150px;"><h2><a href="index.php"><img src="home.png" style="width:40px;" title="Search you result"></a> | IIT Gandhinagar</h2>
</div>
<br>
<div  style="text-align:center"><?php echo "test"; if(isset($message1)) { echo "mesage : ".$message1; } ?>
</div>
<br>
<div class="w3-container w3-center w3-light-grey">
<h4>Copyright&copy; IIT Gandhinagar</h4>
</div>
</div>
<div class="w3-half">
</div>
</div>

<?php } else{?>

<div align="center">
<div class="w3-half w3-card-2 w3-round" align="center">
<div class="w3-container w3-center w3-blue" align="center">
<img src="iitgn.png" style="width:150px;"><h2><a href="index.php"><img src="home.png" style="width:40px;" title="Search you result"></a> | IIT Gandhinagar</h2>

<hr>
<h3>Submit your OTP</h3>
</div>

<br>
<form class="w3-container" method="post" action="">
<br>
<div  style="text-align:center"><?php if(isset($message1)) { echo $message1; } ?>
</div>

<p> <?php if(isset($_GET["mail"]) && ($_GET["mail"]== "send")){echo "Dear " .$_SESSION['name'].",<br><br>An OTP has been sent in your registered email  [".preg_replace('/(?:^|@).\K|\.[^@]*$(*SKIP)(*F)|.(?=.*?\.)/', '*', $_SESSION['email'])."]. Please check your spam/junk box if you do not receive any email in your inbox.";}
if(isset($_GET["otp"]) && ($_GET["otp"]== "invalid")){echo "<font color=red>Invalid OTP. Please try again!</font>";}

if(isset($_GET["otp"]) && ($_GET["otp"]== "resend")){echo "<font color=green>Sucessfully resend OTP to your email [".preg_replace('/(?:^|@).\K|\.[^@]*$(*SKIP)(*F)|.(?=.*?\.)/', '*', $_SESSION['email'])."].</font>";}

?></p>
<p><input class="w3-input w3-border w3-round" type="password" placeholder="OTP" name="otpvalue"></p>
<p class="w3-center"><button class="w3-btn w3-blue w3-round" style="width:100%;height:40px" name="save">Submit</button></p>
<p class="w3-center"><button class="w3-btn w3-blue w3-round" style="width:100%;height:40px" name="resend">Resend</button></p>
</form>
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<br>
<div class="w3-container w3-center w3-light-grey">
<h4>Copyright&copy; IIT Gandhinagar</h4>
</div>
</div>
<div class="w3-half">
</div>
</div>
<?php }?>
</body>
</html>