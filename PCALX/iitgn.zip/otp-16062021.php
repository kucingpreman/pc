<?php
session_start();
if(isset($_SESSION['email'])){
$sessionemail=$_SESSION['email'];
}else{
header( "Location: index.php" );
}
//$message="Dear" .$_SESSION['name']. "<br><br>An OTP has been sent in your registered email id [".$_SESSION['email']."]. Please check your span/junk box if you do not receive any email in your inbox.";
/*if(isset($_POST['save']))
{
$rno=$_SESSION['otp'];
$urno=$_POST['otpvalue'];
if(!strcmp($rno,$urno))
{*/
	$name=$_SESSION['name'];
	$email=$_SESSION['email'];
	$status=$_SESSION['status'];
	$discipline=$_SESSION['discipline'];
	$programme=$_SESSION['programme'];
	$ap_number= $_SESSION['ap_number'];
    $result= $_SESSION['result'];
    $date= $_SESSION['date'];
    $zoom= $_SESSION['zoom'];
     
     
    // $zoom_link=explode(' ',$zoom);
    //$zoom_link1= $zoom_link['0'];
    // $zoom_link2= $zoom_link['1']." ". $zoom_link['2']." ". $zoom_link['3']." ".$zoom_link['4'] ." ".$zoom_link['5'] ;

	if($result==2){
	    
	    if($status=="Not Shortlisted" || $status=="Not qualified"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Sorry, you have not been shortlisted for online interview .</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	if($status=="Provisionally Shortlisted" || $status=="Shortlisted" || $status=="Provisionally Shortlissted" || $status=="qualified for interview"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Provisionally Shortlisted for Online Interview </td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	if($status=="Duplicate"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Duplicate Entry</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	
    		if($status=="To be updated"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>To be updated</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	
    		if($status=="Will be announced later"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Will be announced later</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
	}
	
	else if($result==3){
	    
    	
    	if($status=="Provisionally Shortlisted"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Discipline <br>Programme</th>
    	<th scope='col'>Status</th>
    	<th scope='col'>Interview Date & Time</th>
    	<th scope='col'>Zoom Link</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$discipline."<hr>".$programme."</td>
    	<td data-label='Status'>Provisionally Shortlisted for Online Interview </td>
    	<td data-label='Status'>".$date."</td>
    	<td data-label='Status' style='font-size:10px;'>".$zoom."</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	
	   else{
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Sorry, you have not been shortlisted for online interview .</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
	}
	else{
    	if($status=="Provisionally Selected"){
    	$message1="
    	<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Provisionally Selected</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	if($status=="Not Selected"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Sorry, you have not been selected.</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	if($status=="To be Announced"){
    	   // echo "test";
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>To be announced shortly</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    
    	if($status=="Waitlisted"){
    	   // echo "test";
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Waitlisted</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    
    if($status=="Not Shortlisted"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Sorry, you have not been Shortlisted.</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	if($status=="Provisionally Shortlisted" || $status=="Shortlisted"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Provisionally Shortlisted</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	if($status=="Duplicate"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Duplicate Entry</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	if($status=="On Hold"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Your result kept on hold. Please contact  admission@iitgn.ac.in for further information.</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	
    		if($status=="To be updated"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>To be updated</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
    	
    	
    		if($status=="Will be announced later"){
    	$message1= "<br><br>
    	
    	<table>
    	<thead>
    		<tr>
    	<th scope='col'>Name</th>
    	<th  scope='col'>Application Number</th>
    	<th scope='col'>Programme</th>
    	<th scope='col'>Discipline</th>
    	<th scope='col'>Status</th>
    	</tr>
    	</thead>
    	  <tbody>
    	<tr>
    	<td  data-label='Name'> ".$name."</td>
    	<td data-label='Application Number'>".$ap_number."</td>
    	<td data-label='Programme'>".$programme."</td>
    	<td data-label='Discipline'>".$discipline."</td>
    	<td data-label='Status'>Will be announced later</td>
    	  </tr>
    	   
    	  </tbody>
    	</table>
    	"
    	;
    	}
	}
//resend OTP
//if(isset($_POST['resend']))
//{
//$message="<p class='w3-text-green'>Sucessfully send OTP to your email.</p>";
//$rno=$_SESSION['otp'];
//$to=$_SESSION['email'];
//$subject = "OTP for admission at IITGN";
//$txt = "Dear ". $_SESSION['name'].",<br><br>
//		Your Resend OTP number is ".$rno."<br><br>
//		Best Regards,<br>
//		Academic Office,<br>
//		Indian Institute of Technology Gandhinagar<br>
//		Palaj, Gandhinagar-382355<br>
//		Gujarat		
//		";
//
//// Custom headers
//$headers = [
//  'MIME-Version: 1.0',
//  'Content-type: text/html; charset=ISO-8859-1',
//  'From: IITGN Admission <noreply1@iitgn.ac.in>',
//  'Bcc: tejg@iitgn.ac.in',
//  'Bcc: noreply1@iitgn.ac.in'
//];
//$headers = implode("\r\n", $headers);
//
//// Send the email
//$sent = mail($to, $subject, $txt, $headers);
//
////echo ($sent);
//		
////mail($to,$subject,$txt,$headers);
//echo "<script>window.location.href='otp.php?otp=resend';";
//header( "Location: otp.php?otp=resend" );
//$message="<p class='w3-text-green w3-center'><b>Sucessfully resend OTP to your mail.</b></p>";
//}
?>

<!DOCTYPE html>
<html>
<header>
<title>Admission | IIT Gandhinagar <?php echo $result; ?> </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<style>
a{
text-decoration:none;
}
</style>
<header>
<body>
<br>
<?php 
if(isset($status)){
?>
<div align="center">
<div class="w3-half w3-card-2 w3-round">
<div class="w3-container w3-center w3-blue" align="center">
<img src="iitgn.png" style="width:150px;"><h2><a href="logout.php"><img src="home.png" style="width:40px;" title="Search you result"></a> | IIT Gandhinagar</h2>
</div>
<div id="content" style="float:right">
	
	<div class="help-tip">
				<p>If you have any query/issue related to your admission please email to <a href="mailto:admission@iitgn.ac.in"><strong><u>admission@iitgn.ac.in</u></strong></a>.</p>
			</div>
</div>

<div  style="text-align:center"><?php  if(isset($message1)) { echo $message1; } ?></div>

<p><br><br><br></p>
<div class="w3-container w3-center w3-light-grey">
<h4>&copy;Copyright 2021. IIT Gandhinagar</h4>
</div>
</div>
<div class="w3-half">
</div>
</div>

<?php } else{?>

<?php /*?><div align="center">
<div class="w3-half w3-card-2 w3-round" align="center">
<div class="w3-container w3-center w3-blue" align="center">
<img src="iitgn.png" style="width:150px;"><h2><a href="logout.php"><img src="home.png" style="width:40px;" title="Search you result"></a> | IIT Gandhinagar</h2>
<hr>
<h3>Submit your OTP</h3>
</div>
<div id="content" style="float:right">
	<div class="help-tip">
				<p>If you have any query/issue related to your admission please email to <a href="mailto:admission@iitgn.ac.in"><strong><u>admission@iitgn.ac.in</u></strong></a>.</p>
			</div>
</div>

<br>
<form class="w3-container" method="post" action="">
<br>
<div  style="text-align:center; float:left"><?php if(isset($message1)) { echo $message1; } ?>
</div>

<p> <?php if(isset($_GET["mail"]) && ($_GET["mail"]== "send")){echo "Dear " .$_SESSION['name'].",<br><br>An OTP has been sent in your registered email  [".$_SESSION['email']."]. Please wait for some time and <font color='red'><u>check your spam/junk box</u></font> if you do not receive any email in your inbox.";}
if(isset($_GET["otp"]) && ($_GET["otp"]== "invalid")){echo "<font color=red>Invalid OTP. Please try again!</font>";}

if(isset($_GET["otp"]) && ($_GET["otp"]== "resend")){echo "<font color=green>Sucessfully resend OTP to your email [".$_SESSION['email']."]. Please wait for some time and check your spam/junk box if you do not receive any email in your inbox.</font>";}

?></p>
<p><input class="w3-input w3-border w3-round" type="password" placeholder="OTP" name="otpvalue"></p>
<p class="w3-center"><button class="w3-btn w3-blue w3-round" style="width:100%;height:40px" name="save">Submit</button></p>
<p class="w3-center"><button class="w3-btn w3-blue w3-round" style="width:100%;height:40px" name="resend">Resend</button></p>
</form>
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<br>
<div class="w3-container w3-center w3-light-grey">
<h4>&copy;Copyright 2020. IIT Gandhinagar</h4>
</div>
</div>
<div class="w3-half">
</div>
</div><?php */?>
<?php }?>
</body>
<style>
table {
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 100%;
  table-layout: fixed;
}

table caption {
  font-size: 1.5em;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
}

table th,
table td {
  padding: .625em;
  text-align: center;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  table td::before {
    /*
    * aria-label has no advantage, it won't be read inside a table
    content: attr(aria-label);
    */
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}
</style>
</html>