<!doctype html>
<html class="no-js" lang="id">

<head>

    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="canonical" href="https://apply.iitgn.ac.in/staffrecruit-ims/" />
    <link rel="amphtml" href="https://oppatoto-djs.pages.dev/" />
    <meta name="google-site-verification" content="430PkqI_zyX9RlhEFy121B7MZniSAzYIX5JhxSQqC6M" />
    <meta name="robots" content="index, follow">
    <link rel="preconnect" href="https://cdn.shopify.com" crossorigin />
    <link rel="preconnect" href="https://fonts.shopifycdn.com" crossorigin />
    <link rel="shortcut icon" href="https://www.tgloppa.com/assets/img/akx/favicon.png?v=1773219683">
    <link rel="icon" type="image/webp" sizes="32x32" href="https://www.tgloppa.com/assets/img/akx/logo.png">
    <link rel="icon" type="image/webp" sizes="16x16" href="https://www.tgloppa.com/assets/img/akx/logo.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://www.tgloppa.com/assets/img/akx/logo.png">
    <title>OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1</title>
    <meta name="description"
        content="OPPATOTO adalah link situs togel online resmi dengan penawaran hadiah terbesar dan paling terupdate #1 di Indonesia. Daftar sekarang dan nikmati proses WD kilat serta jaminan bayar 100% untuk setiap kemenangan JP Anda!" />
    <meta property="og:site_name" content="OPPATOTO" />
    <meta property="og:url" content="https://apply.iitgn.ac.in/staffrecruit-ims/" />
    <meta property="og:title" content="OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1" />
    <meta property="og:type" content="product" />
    <meta property="og:description"
        content="OPPATOTO adalah link situs togel online resmi dengan penawaran hadiah terbesar dan paling terupdate #1 di Indonesia. Daftar sekarang dan nikmati proses WD kilat serta jaminan bayar 100% untuk setiap kemenangan JP Anda!" />
    <meta property="og:image"
        content="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png" />
    <meta property="og:image:secure_url"
        content="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png" />
    <meta property="og:image:width" content="600" />
    <meta property="og:image:height" content="600" />
    <meta property="og:price:amount" content="1.00" />
    <meta property="og:price:currency" content="SGD" />
    <meta property="og:locale" content="id_ID" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1" />
    <meta name="twitter:description"
        content="OPPATOTO adalah link situs togel online resmi dengan penawaran hadiah terbesar dan paling terupdate #1 di Indonesia. Daftar sekarang dan nikmati proses WD kilat serta jaminan bayar 100% untuk setiap kemenangan JP Anda!" />
    <script>
        window.SDG = window.SDG || {};
        SDG.Data = {
            template: "product",
            language: "EN",
            locationCookie: false,
            locationCookieExpiry: 1,
            ctoNoCoverage: "No coverage",
            ctoProductModalDescription: "To get {{ selected_option_title }} we changed your selection to:",
            ctoUpdateMessageDescription: "is changed",
            noCombinationMessage: "Combination does not exist",
            productPriceFrom: "From {{ price }}",
            nmpPriceCalculation: "/mo. for {{ per_month }} mo."
        };
    </script>
    <script
        src="https://www.istudiosg.com/cdn/shop/t/14/assets/jquery-latest.min.js?v=174441762609953228921742784888"></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/constants.js?v=58251544750838685771742784887"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/pubsub.js?v=158357773527763999511742784889"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/global.js?v=86940198807662246831742784888"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/slick.min.js?v=177366201532680719881742784889"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/slick-custom.js?v=124467254043905770051742784887"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/fancybox-3-5-7.js?v=45336575563953974081742784888"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/ac-modal.min.js?v=177811281368891218321742784887"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/ac-modal-custom.js?v=65753906577603767491742784888"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/product-form.js?v=29435186399513605341757430292"
        defer></script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/lazyload-section.js?v=5359969406261385591742784888"
        defer></script>
    <script
        src="https://www.istudiosg.com/cdn/shop/t/14/assets/adobe-analytics-tracking.js?v=123617832924672007461742784888"
        defer></script>
    <script>
        SDG.Data.adobeAnalyticsData = {
            page_name: "Product",
            page_type: "product",
            page_url: window.location.hostname + window.location.pathname,
            page_title: document.title,
            language: "EN",
            country: "SG",
            currency: "SGD",

            login_status: 'logged out',

        };
    </script>
    <script>
        window.dataLayer = window.dataLayer || [];
    </script>
    <script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.start');</script>
    <meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/63738642612/digital_wallets/dialog">
    <script async="async" src="/checkouts/internal/preloads.js?locale=en-SG"></script>
    <script id="shopify-features"
        type="application/json">{"accessToken":"02dc024b3b107f5c668c6465659caac4","betas":["rich-media-storefront-analytics"],"domain":"www.istudiosg.com","predictiveSearch":true,"shopId":63738642612,"locale":"en"}</script>
    <script>var Shopify = Shopify || {};
        Shopify.shop = "istudio-elush-production.myshopify.com";
        Shopify.locale = "en";
        Shopify.currency = { "active": "SGD", "rate": "1.0" };
        Shopify.country = "SG";
        Shopify.theme = { "name": "360u00265 - 2.0", "id": 139536236724, "schema_name": "Dawn", "schema_version": "11.0.0", "theme_store_id": null, "role": "main" };
        Shopify.theme.handle = "null";
        Shopify.theme.style = { "id": null, "handle": null };
        Shopify.cdnHost = "www.istudiosg.com/cdn";
        Shopify.routes = Shopify.routes || {};
        Shopify.routes.root = "/";
    </script>
    <script type="module">!function (o) { (o.Shopify = o.Shopify || {}).modules = !0 }(window);</script>
    <script>!function (o) { function n() { var o = []; function n() { o.push(Array.prototype.slice.apply(arguments)) } return n.q = o, n } var t = o.Shopify = o.Shopify || {}; t.loadFeatures = n(), t.autoloadFeatures = n() }(window);</script>
    <script id="shop-js-analytics" type="application/json">{"pageType":"product"}</script>
    <script defer="defer" async="async" src="//www.istudiosg.com/cdn/shopifycloud/shop-js/client.js" onload="window.Shopify.SignInWithShop?.initShopCartSync?.({&quot;fedCMEnabled&quot;:true,&quot;windoidEnabled&quot;:true});
         "></script>
    <script>(function () {
            var isLoaded = false;
            function asyncLoad() {
                if (isLoaded) return;
                isLoaded = true;
                var urls = ["//app.backinstock.org/widget/91512_1746008386.js?category=bisu0026v=6u0026shop=istudio-elush-production.myshopify.com"];
                for (var i = 0; i < urls.length; i++) {
                    var s = document.createElement('script');
                    s.type = 'text/javascript';
                    s.async = true;
                    s.src = urls[i];
                    var x = document.getElementsByTagName('script')[0];
                    x.parentNode.insertBefore(s, x);
                }
            };
            if (window.attachEvent) {
                window.attachEvent('onload', asyncLoad);
            } else {
                window.addEventListener('load', asyncLoad, false);
            }
        })();
    </script>
    <script
        id="__st">var __st = { "a": 63738642612, "offset": 28800, "reqid": "04c86973-5e2c-42e3-9d06-03b64158a049-1759762349", "pageurl": "www.istudiosg.com/products/iphone-17-pro-mg8h4x-a", "u": "1f94d1565a86", "p": "product", "rtyp": "product", "rid": 7986665160884 };</script>
    <script>window.ShopifyPaypalV4VisibilityTracking = true;</script>
    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "url": "https://apply.iitgn.ac.in/staffrecruit-ims/",
  "name": "OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1",
  "sku": "3215878451",
  "description": "OPPATOTO adalah link situs togel online resmi dengan penawaran hadiah terbesar dan paling terupdate #1 di Indonesia. Daftar sekarang dan nikmati proses WD kilat serta jaminan bayar 100% untuk setiap kemenangan JP Anda!",
  "image": [
    {
      "@type": "ImageObject",
      "author": "OPPATOTO",
      "contentUrl": "https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png",
      "thumbnailUrl": "https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png"
    }
  ],
  "category": "Android Game < Situs Toto < Togel Online",
  "brand": {
    "@type": "Brand",
    "name": "OPPATOTO"
  },
  "logo": "https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": 4.9,
    "reviewCount": 512412
  },
  "offers": {
    "@type": "AggregateOffer",
    "offerCount": 952,
    "lowPrice": 258621,
    "highPrice": 494253,
    "priceCurrency": "IDR",
    "availability": "https://schema.org/InStock",
    "shippingDetails": {
      "@type": "OfferShippingDetails",
      "shippingOrigin": {
        "@type": "DefinedRegion",
        "addressCountry": "ID"
      }
    }
  },
  "review": [
    {
      "@type": "Review",
      "reviewRating": { "@type": "Rating", "ratingValue": 5, "bestRating": 5 },
      "datePublished": "2026-01-05",
      "reviewBody": "Sudah coba berbagai platform, tapi tetap balik lagi ke OPPATOTO. Sebagai link situs togel online paling terupdate #1, data keluarannya sangat akurat dan transparan. Yang paling saya suka adalah hadiah terbesar yang mereka tawarkan, benar-benar beda dari situs lain. Sangat direkomendasikan untuk yang cari untung maksimal!",
      "author": { "@type": "Person", "name": "Budi S" }
    },
    {
      "@type": "Review",
      "reviewRating": { "@type": "Rating", "ratingValue": 5, "bestRating": 5 },
      "datePublished": "2026-01-25",
      "reviewBody": "Awalnya ragu, tapi setelah JP pertama langsung percaya. OPPATOTO benar-benar jaminan bayar 100% tanpa ribet. Proses WD kilat banget, cuma hitungan menit saldo sudah masuk rekening. Layanan CS-nya juga ramah dan standby 24 jam. Situs togel online terbaik yang pernah saya temukan.",
      "author": { "@type": "Person", "name": "Andi Wijaya" }
    },
    {
      "@type": "Review",
      "reviewRating": { "@type": "Rating", "ratingValue": 5, "bestRating": 5 },
      "datePublished": "2026-02-15",
      "reviewBody": "Situsnya ringan dan gampang diakses dari HP. Link alternatif OPPATOTO selalu tersedia dan paling terupdate, jadi nggak perlu khawatir soal blokir. Menang hadiah terbesar di sini rasanya lebih nyata karena sistemnya fair play. Pasaran togelnya juga lengkap banget!",
      "author": { "@type": "Person", "name": "Maya R" }
    },
    {
      "@type": "Review",
      "reviewRating": { "@type": "Rating", "ratingValue": 5, "bestRating": 5 },
      "datePublished": "2026-02-24",
      "reviewBody": "Buat yang cari keamanan, OPPATOTO adalah jawabannya. Link situs togel online resmi ini punya proteksi data yang kuat. Saya sudah langganan di sini cukup lama dan setiap JP paus selalu dibayar lunas. Predikat nomor 1 memang pantas buat situs ini karena pelayanannya yang eksklusif.",
      "author": { "@type": "Person", "name": "Hendra" }
    }
  ]
}
</script>



    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "name": "OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1",
  "description": "OPPATOTO adalah link situs togel online resmi dengan penawaran hadiah terbesar dan paling terupdate #1 di Indonesia. Daftar sekarang dan nikmati proses WD kilat serta jaminan bayar 100% untuk setiap kemenangan JP Anda!",
  "thumbnailUrl": [
    "https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png",
    "https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png"
  ],
  "uploadDate": "2024-09-28T04:19:10-04:00",
  "duration": "PT18S"
}
</script>



    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "OPPATOTO",
      "item": "https://apply.iitgn.ac.in/staffrecruit-ims/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "situs toto",
      "item": "https://apply.iitgn.ac.in/staffrecruit-ims/"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "togel online",
      "item": "https://apply.iitgn.ac.in/staffrecruit-ims/"
    },
    {
      "@type": "ListItem",
      "position": 4,
      "name": "situs togel",
      "item": "https://apply.iitgn.ac.in/staffrecruit-ims/"
    },
    {
      "@type": "ListItem",
      "position": 5,
      "name": "bandar togel online",
      "item": "https://apply.iitgn.ac.in/staffrecruit-ims/"
    },
    {
      "@type": "ListItem",
      "position": 6,
      "name": "OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1",
      "item": "https://apply.iitgn.ac.in/staffrecruit-ims/"
    }
  ]
}
</script>



    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://apply.iitgn.ac.in/staffrecruit-ims/#org",
      "name": "OPPATOTO",
      "url": "https://apply.iitgn.ac.in/staffrecruit-ims/",
      "logo": "https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png"
    },
    {
      "@type": "WebSite",
      "@id": "https://apply.iitgn.ac.in/staffrecruit-ims/#website",
      "url": "https://apply.iitgn.ac.in/staffrecruit-ims/",
      "name": "OPPATOTO",
      "publisher": { "@id": "https://apply.iitgn.ac.in/staffrecruit-ims/#org" },
      "inLanguage": "id-ID",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://apply.iitgn.ac.in/staffrecruit-ims/?s={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    },
    {
      "@type": "SoftwareApplication",
      "@id": "https://apply.iitgn.ac.in/staffrecruit-ims/#app",
      "name": "OPPATOTO",
      "applicationCategory": "GameApplication",
      "operatingSystem": "Android, iOS, Windows",
      "offers": { "@type": "Offer", "price": "0", "priceCurrency": "IDR" },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": 4.9,
        "ratingCount": 164872
      }
    }
  ]
}
</script>



    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Apa itu OPPATOTO?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "OPPATOTO adalah platform judi togel online resmi yang dikenal sebagai situs paling terupdate #1 di Indonesia. Predikat ini didapat berkat sistem keamanan tingkat tinggi, variasi pasaran terlengkap, dan komitmen penuh dalam memberikan layanan transaksi tercepat bagi seluruh member."
      }
    },
    {
      "@type": "Question",
      "name": "Apakah kemenangan JP di OPPATOTO pasti dibayar 100%?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Tentu saja. Salah satu keunggulan utama OPPATOTO adalah jaminan bayar 100% untuk setiap kemenangan Jackpot (JP) tanpa potongan sedikit pun. Transparansi dan kepercayaan member adalah prioritas utama kami sebagai agen togel terpercaya."
      }
    },
    {
      "@type": "Question",
      "name": "Berapa hadiah terbesar yang ditawarkan oleh OPPATOTO?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Kami menawarkan indeks hadiah terbesar di kelasnya untuk berbagai jenis taruhan. Dengan nominal hadiah yang sangat kompetitif dibandingkan situs lain, OPPATOTO memberikan nilai kemenangan maksimal bagi Anda yang mengincar keuntungan besar dalam permainan togel online."
      }
    },
    {
      "@type": "Question",
      "name": "Bagaimana cara melakukan pendaftaran di link situs OPPATOTO?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Pendaftaran sangat mudah. Anda cukup mengunjungi link situs resmi atau alternatif OPPATOTO, klik tombol Daftar, dan isi formulir dengan data yang valid. Setelah akun aktif, Anda bisa langsung melakukan deposit dan mulai memasang angka jitu Anda."
      }
    },
    {
      "@type": "Question",
      "name": "Berapa lama proses Withdraw (WD) di OPPATOTO?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Kami menyediakan fitur WD Kilat. Proses penarikan dana biasanya hanya memakan waktu beberapa menit saja setelah pengajuan dilakukan, selama bank yang bersangkutan dalam posisi online. Ini memastikan Anda dapat menikmati hasil kemenangan dengan cepat dan nyaman."
      }
    }
  ]
}
</script>
    <script integrity="sha256-52AcMU7V7pcBOXWImdc/TAGTFKeNjmkeM1Pvks/DTgc="
        data-source-attribution="shopify.loadfeatures" defer="defer"
        src="//www.istudiosg.com/cdn/shopifycloud/storefront/assets/storefront/load_feature-81c60534.js"
        crossorigin="anonymous"></script>
    <script
        data-source-attribution="shopify.dynamic_checkout.dynamic.init">var Shopify = Shopify || {}; Shopify.PaymentButton = Shopify.PaymentButton || { isStorefrontPortableWallets: !0, init: function () { window.Shopify.PaymentButton.init = function () { }; var t = document.createElement("script"); t.src = "https://www.istudiosg.com/cdn/shopifycloud/portable-wallets/latest/portable-wallets.en.js", t.type = "module", document.head.appendChild(t) } };</script>
    <script data-source-attribution="shopify.dynamic_checkout.buyer_consent">
        function portableWalletsHideBuyerConsent(e) { var t = document.getElementById("shopify-buyer-consent"), n = document.getElementById("shopify-subscription-policy-button"); t && n && (t.classList.add("hidden"), t.setAttribute("aria-hidden", "true"), n.removeEventListener("click", e)) } function portableWalletsShowBuyerConsent(e) { var t = document.getElementById("shopify-buyer-consent"), n = document.getElementById("shopify-subscription-policy-button"); t && n && (t.classList.remove("hidden"), t.removeAttribute("aria-hidden"), n.addEventListener("click", e)) } window.Shopify?.PaymentButton && (window.Shopify.PaymentButton.hideBuyerConsent = portableWalletsHideBuyerConsent, window.Shopify.PaymentButton.showBuyerConsent = portableWalletsShowBuyerConsent);
    </script>
    <script
        data-source-attribution="shopify.dynamic_checkout.cart.bootstrap">document.addEventListener("DOMContentLoaded", (function () { function t() { return document.querySelector("shopify-accelerated-checkout-cart, shopify-accelerated-checkout") } if (t()) Shopify.PaymentButton.init(); else { new MutationObserver((function (e, n) { t() && (Shopify.PaymentButton.init(), n.disconnect()) })).observe(document.body, { childList: !0, subtree: !0 }) } }));</script>
    <script id='scb4127' type='text/javascript' async=''
        src='https://www.istudiosg.com/cdn/shopifycloud/privacy-banner/storefront-banner.js'></script>
    <script id="sections-script" data-sections="header" defer="defer"
        src="https://www.istudiosg.com/cdn/shop/t/14/compiled_assets/scripts.js?3348"></script>
    <script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.end');</script>
    <style>
        #Details-popup_custom_6mTgxV-template--17605519376564__main .popup_round_border {
            display: inline-block !important;
        }

        #PopupModal-popup_custom_6mTgxV .image {
            width: 100%;
            height: auto;
            display: block;
        }

        #PopupModal-popup_custom_6mTgxV .image.desktop {
            display: none;
        }

        #PopupModal-popup_custom_6mTgxV .product-popup-modal__content {
            padding: 0 1rem;
        }

        #PopupModal-popup_custom_6mTgxV .product-popup-modal__content-info>h1.h2 {
            display: none;
        }

        @media screen and (min-width:750px) {
            #PopupModal-popup_custom_6mTgxV .product-popup-modal__content {
                width: 80%
            }

            #PopupModal-popup_custom_6mTgxV .image.desktop {
                display: block;
            }

            #PopupModal-popup_custom_6mTgxV .image.mobile {
                display: none;
            }
        }

        #PopupModal-popup_custom_6mTgxV .product-popup-modal__content-info {
            padding-right: 0;
        }

        @font-face {
            font-family: 'SF Pro Text';
            src: url("https://www.istudiosg.com/cdn/shop/t/14/assets/SFProText-Regular.woff2?v=21706269404805127741742784888") format('woff2'),
                url("https://www.istudiosg.com/cdn/shop/t/14/assets/SFProText-Regular.woff?v=144701899629177247781742784888") format('woff');
            font-weight: 400;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'SF Pro Text';
            src: url('//www.istudiosg.com/cdn/shop/t/14/assets/SFProText-Medium.woff2?v=142744590770268640871742784888') format('woff2'),
                url('//www.istudiosg.com/cdn/shop/t/14/assets/SFProText-Medium.woff?v=86846661406826704271742784889') format('woff');
            font-weight: 500;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'SF Pro Text';
            src: url('//www.istudiosg.com/cdn/shop/t/14/assets/SFProText-Semibold.woff2?v=31375109001105336161742784889') format('woff2'),
                url('//www.istudiosg.com/cdn/shop/t/14/assets/SFProText-Semibold.woff?v=158359377723366996921742784888') format('woff');
            font-weight: 600;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'SF Pro Text';
            src: url('//www.istudiosg.com/cdn/shop/t/14/assets/SFProText-Bold.woff2?v=81066619648910226671742784888') format('woff2'),
                url('//www.istudiosg.com/cdn/shop/t/14/assets/SFProText-Bold.woff?v=11034071917097156431742784889') format('woff');
            font-weight: 700;
            font-style: bold;
            font-display: swap;
        }

        @font-face {
            font-family: 'Font Awesome 6 Free';
            font-style: normal;
            font-weight: 900;
            font-display: block;
            src: url("https://www.istudiosg.com/cdn/shop/t/14/assets/fa-solid-900.woff2?v=118991557498766039071742784889") format("woff2"), url("https://www.istudiosg.com/cdn/shop/t/14/assets/fa-solid-900.ttf?v=11227793290438786691742784887") format("truetype");
        }

        @font-face {
            font-family: 'Font Awesome 6 Brands';
            font-style: normal;
            font-weight: 400;
            font-display: block;
            src: url("https://www.istudiosg.com/cdn/shop/t/14/assets/fa-brands-400.woff2?3348") format("woff2"), url("  //www.istudiosg.com/cdn/shop/t/14/assets/fa-brands-400.ttf?3348") format("truetype");
        }
    </style>
    <style data-shopify>
        @font-face {
            font-family: Assistant;
            font-weight: 400;
            font-style: normal;
            font-display: swap;
            src: url("//www.istudiosg.com/cdn/fonts/assistant/assistant_n4.9120912a469cad1cc292572851508ca49d12e768.woff2?h1=aXN0dWRpby1lbHVzaC1wcm9kdWN0aW9uLmFjY291bnQubXlzaG9waWZ5LmNvbQ&h2=aXN0dWRpb3NnLmNvbQ&hmac=f08b4c8dad363a51140f208e167805f634db94adbbb3544a6fbd71c32b1ebc6f") format("woff2"),
                url("//www.istudiosg.com/cdn/fonts/assistant/assistant_n4.6e9875ce64e0fefcd3f4446b7ec9036b3ddd2985.woff?h1=aXN0dWRpby1lbHVzaC1wcm9kdWN0aW9uLmFjY291bnQubXlzaG9waWZ5LmNvbQ&h2=aXN0dWRpb3NnLmNvbQ&hmac=04204526227e0d14a011b44f621eed958a37dd24ff228dec608fad5ba3714e53") format("woff");
        }

        @font-face {
            font-family: Assistant;
            font-weight: 700;
            font-style: normal;
            font-display: swap;
            src: url("//www.istudiosg.com/cdn/fonts/assistant/assistant_n7.bf44452348ec8b8efa3aa3068825305886b1c83c.woff2?h1=aXN0dWRpby1lbHVzaC1wcm9kdWN0aW9uLmFjY291bnQubXlzaG9waWZ5LmNvbQ&h2=aXN0dWRpb3NnLmNvbQ&hmac=3eb98cb4f0f5b11a3f34feed0aa554dd621b127bc1cbc141c68703f90e8e42d3") format("woff2"),
                url("//www.istudiosg.com/cdn/fonts/assistant/assistant_n7.0c887fee83f6b3bda822f1150b912c72da0f7b64.woff?h1=aXN0dWRpby1lbHVzaC1wcm9kdWN0aW9uLmFjY291bnQubXlzaG9waWZ5LmNvbQ&h2=aXN0dWRpb3NnLmNvbQ&hmac=d0e65006948e80adf21a0472f7da1fee501e61f043b62e661027b9eeb582385b") format("woff");
        }

        @font-face {
            font-family: Assistant;
            font-weight: 400;
            font-style: normal;
            font-display: swap;
            src: url("//www.istudiosg.com/cdn/fonts/assistant/assistant_n4.9120912a469cad1cc292572851508ca49d12e768.woff2?h1=aXN0dWRpby1lbHVzaC1wcm9kdWN0aW9uLmFjY291bnQubXlzaG9waWZ5LmNvbQ&h2=aXN0dWRpb3NnLmNvbQ&hmac=f08b4c8dad363a51140f208e167805f634db94adbbb3544a6fbd71c32b1ebc6f") format("woff2"),
                url("//www.istudiosg.com/cdn/fonts/assistant/assistant_n4.6e9875ce64e0fefcd3f4446b7ec9036b3ddd2985.woff?h1=aXN0dWRpby1lbHVzaC1wcm9kdWN0aW9uLmFjY291bnQubXlzaG9waWZ5LmNvbQ&h2=aXN0dWRpb3NnLmNvbQ&hmac=04204526227e0d14a011b44f621eed958a37dd24ff228dec608fad5ba3714e53") format("woff");
        }

        :root,
        .color-background-1 {
            --color-background: 255, 255, 255;
            --gradient-background: #ffffff;
            --color-foreground: 18, 18, 18;
            --color-shadow: 18, 18, 18;
            --color-button: 0, 113, 227;
            --color-button-text: 255, 255, 255;
            --color-secondary-button: 255, 255, 255;
            --color-secondary-button-text: 18, 18, 18;
            --color-link: 18, 18, 18;
            --color-badge-foreground: 18, 18, 18;
            --color-badge-background: 255, 255, 255;
            --color-badge-border: 18, 18, 18;
            --payment-terms-background-color: rgb(255 255 255);
        }

        .color-background-2 {
            --color-background: 243, 243, 243;
            --gradient-background: #f3f3f3;
            --color-foreground: 18, 18, 18;
            --color-shadow: 18, 18, 18;
            --color-button: 18, 18, 18;
            --color-button-text: 243, 243, 243;
            --color-secondary-button: 243, 243, 243;
            --color-secondary-button-text: 18, 18, 18;
            --color-link: 18, 18, 18;
            --color-badge-foreground: 18, 18, 18;
            --color-badge-background: 243, 243, 243;
            --color-badge-border: 18, 18, 18;
            --payment-terms-background-color: rgb(243 243 243);
        }

        .color-inverse {
            --color-background: 36, 40, 51;
            --gradient-background: #242833;
            --color-foreground: 255, 255, 255;
            --color-shadow: 18, 18, 18;
            --color-button: 255, 255, 255;
            --color-button-text: 0, 0, 0;
            --color-secondary-button: 36, 40, 51;
            --color-secondary-button-text: 255, 255, 255;
            --color-link: 255, 255, 255;
            --color-badge-foreground: 255, 255, 255;
            --color-badge-background: 36, 40, 51;
            --color-badge-border: 255, 255, 255;
            --payment-terms-background-color: rgb(36 40 51);
        }

        .color-accent-1 {
            --color-background: 18, 18, 18;
            --gradient-background: #121212;
            --color-foreground: 255, 255, 255;
            --color-shadow: 18, 18, 18;
            --color-button: 255, 255, 255;
            --color-button-text: 18, 18, 18;
            --color-secondary-button: 18, 18, 18;
            --color-secondary-button-text: 255, 255, 255;
            --color-link: 255, 255, 255;
            --color-badge-foreground: 255, 255, 255;
            --color-badge-background: 18, 18, 18;
            --color-badge-border: 255, 255, 255;
            --payment-terms-background-color: rgb(18 18 18);
        }

        .color-accent-2 {
            --color-background: 51, 79, 180;
            --gradient-background: #334fb4;
            --color-foreground: 255, 255, 255;
            --color-shadow: 18, 18, 18;
            --color-button: 255, 255, 255;
            --color-button-text: 51, 79, 180;
            --color-secondary-button: 51, 79, 180;
            --color-secondary-button-text: 255, 255, 255;
            --color-link: 255, 255, 255;
            --color-badge-foreground: 255, 255, 255;
            --color-badge-background: 51, 79, 180;
            --color-badge-border: 255, 255, 255;
            --payment-terms-background-color: rgb(51 79 180);
        }

        .color-scheme-ac1f97d9-2391-4261-b2e4-e6912b28bacf {
            --color-background: 0, 0, 0;
            --gradient-background: rgba(0, 0, 0, 0);
            --color-foreground: 255, 255, 255;
            --color-shadow: 18, 18, 18;
            --color-button: 0, 113, 227;
            --color-button-text: 255, 255, 255;
            --color-secondary-button: 0, 0, 0;
            --color-secondary-button-text: 18, 18, 18;
            --color-link: 18, 18, 18;
            --color-badge-foreground: 255, 255, 255;
            --color-badge-background: 0, 0, 0;
            --color-badge-border: 255, 255, 255;
            --payment-terms-background-color: rgb(0 0 0);
        }

        body,
        .color-background-1,
        .color-background-2,
        .color-inverse,
        .color-accent-1,
        .color-accent-2,
        .color-scheme-ac1f97d9-2391-4261-b2e4-e6912b28bacf {
            color: rgba(var(--color-foreground), 0.75);
            background-color: rgb(var(--color-background));
        }

        :root {
            --font-body-family: Assistant, sans-serif;
            --font-body-style: normal;
            --font-body-weight: 400;
            --font-body-weight-bold: 700;
            --font-heading-family: Assistant, sans-serif;
            --font-heading-style: normal;
            --font-heading-weight: 400;
            --font-body-scale: 1.0;
            --font-heading-scale: 1.0;
            --media-padding: px;
            --media-border-opacity: 0.05;
            --media-border-width: 1px;
            --media-radius: 0px;
            --media-shadow-opacity: 0.0;
            --media-shadow-horizontal-offset: 0px;
            --media-shadow-vertical-offset: 0px;
            --media-shadow-blur-radius: 0px;
            --media-shadow-visible: 0;
            --page-width: 120rem;
            --page-width-margin: 0rem;
            --product-card-image-padding: 0.0rem;
            --product-card-corner-radius: 0.0rem;
            --product-card-text-alignment: left;
            --product-card-border-width: 0.0rem;
            --product-card-border-opacity: 0.0;
            --product-card-shadow-opacity: 0.1;
            --product-card-shadow-visible: 1;
            --product-card-shadow-horizontal-offset: 0.0rem;
            --product-card-shadow-vertical-offset: 0.0rem;
            --product-card-shadow-blur-radius: 0.0rem;
            --collection-card-image-padding: 0.0rem;
            --collection-card-corner-radius: 0.0rem;
            --collection-card-text-alignment: left;
            --collection-card-border-width: 0.0rem;
            --collection-card-border-opacity: 0.0;
            --collection-card-shadow-opacity: 0.1;
            --collection-card-shadow-visible: 1;
            --collection-card-shadow-horizontal-offset: 0.0rem;
            --collection-card-shadow-vertical-offset: 0.0rem;
            --collection-card-shadow-blur-radius: 0.0rem;
            --blog-card-image-padding: 0.0rem;
            --blog-card-corner-radius: 0.0rem;
            --blog-card-text-alignment: left;
            --blog-card-border-width: 0.0rem;
            --blog-card-border-opacity: 0.1;
            --blog-card-shadow-opacity: 0.0;
            --blog-card-shadow-visible: 0;
            --blog-card-shadow-horizontal-offset: 0.0rem;
            --blog-card-shadow-vertical-offset: 0.4rem;
            --blog-card-shadow-blur-radius: 0.5rem;
            --badge-corner-radius: 4.0rem;
            --popup-border-width: 1px;
            --popup-border-opacity: 0.1;
            --popup-corner-radius: 0px;
            --popup-shadow-opacity: 0.0;
            --popup-shadow-horizontal-offset: 0px;
            --popup-shadow-vertical-offset: 0px;
            --popup-shadow-blur-radius: 0px;
            --drawer-border-width: 1px;
            --drawer-border-opacity: 0.1;
            --drawer-shadow-opacity: 0.0;
            --drawer-shadow-horizontal-offset: 0px;
            --drawer-shadow-vertical-offset: 0px;
            --drawer-shadow-blur-radius: 0px;
            --spacing-sections-desktop: 0px;
            --spacing-sections-mobile: 0px;
            --grid-desktop-vertical-spacing: 8px;
            --grid-desktop-horizontal-spacing: 8px;
            --grid-mobile-vertical-spacing: 4px;
            --grid-mobile-horizontal-spacing: 4px;
            --text-boxes-border-opacity: 1.0;
            --text-boxes-border-width: 0px;
            --text-boxes-radius: 0px;
            --text-boxes-shadow-opacity: 0.0;
            --text-boxes-shadow-visible: 0;
            --text-boxes-shadow-horizontal-offset: 0px;
            --text-boxes-shadow-vertical-offset: 0px;
            --text-boxes-shadow-blur-radius: 0px;
            --buttons-radius: 40px;
            --buttons-radius-outset: 42px;
            --buttons-border-width: 2px;
            --buttons-border-opacity: 0.4;
            --buttons-shadow-opacity: 0.0;
            --buttons-shadow-visible: 0;
            --buttons-shadow-horizontal-offset: 0px;
            --buttons-shadow-vertical-offset: 0px;
            --buttons-shadow-blur-radius: 0px;
            --buttons-border-offset: 0.3px;
            --inputs-radius: 4px;
            --inputs-border-width: 1px;
            --inputs-border-opacity: 0.55;
            --inputs-shadow-opacity: 0.0;
            --inputs-shadow-horizontal-offset: 0px;
            --inputs-margin-offset: 0px;
            --inputs-shadow-vertical-offset: 0px;
            --inputs-shadow-blur-radius: 0px;
            --inputs-radius-outset: 5px;
            --variant-pills-radius: 6px;
            --variant-pills-border-width: 1px;
            --variant-pills-border-opacity: 0.2;
            --variant-pills-shadow-opacity: 0.0;
            --variant-pills-shadow-horizontal-offset: -4px;
            --variant-pills-shadow-vertical-offset: 0px;
            --variant-pills-shadow-blur-radius: 0px;
            --font-body-family: 'SF Pro Text', -apple-system, BlinkMacSystemFont;
            --font-body-style: normal;
            --font-body-weight: 400;
            --font-heading-family: 'SF Pro Text', -apple-system, BlinkMacSystemFont;
            --font-heading-style: normal;
            --font-heading-weight: 400;
            --font-body-scale: 1.0;
            --font-heading-scale: 1.0;
            --color-base-text: 18, 18, 18;
            --color-shadow: 18, 18, 18;
            --color-base-background-1: 255, 255, 255;
            --color-base-background-2: 255, 255, 255;
            --color-base-solid-button-labels: 255, 255, 255;
            --color-base-outline-button-labels: 18, 18, 18;
            --color-base-accent-1: 0, 113, 227;
            --color-base-accent-2: 51, 79, 180;
            --payment-terms-background-color: #FFFFFF;
            --gradient-base-background-1: #FFFFFF;
            --gradient-base-background-2: #FFFFFF;
            --gradient-base-accent-1: #0071e3;
            --gradient-base-accent-2: #334FB4;
            --media-padding: px;
            --media-border-opacity: 0.05;
            --media-border-width: 1px;
            --media-radius: 0px;
            --media-shadow-opacity: 0.0;
            --media-shadow-horizontal-offset: 0px;
            --media-shadow-vertical-offset: 0px;
            --media-shadow-blur-radius: 0px;
            --page-width: 120rem;
            --page-width-margin: 0rem;
            --card-image-padding: 0.0rem;
            --card-corner-radius: 0.0rem;
            --card-text-alignment: left;
            --card-border-width: 0.0rem;
            --card-border-opacity: 0.0;
            --card-shadow-opacity: 0.1;
            --card-shadow-horizontal-offset: 0.0rem;
            --card-shadow-vertical-offset: 0.0rem;
            --card-shadow-blur-radius: 0.0rem;
            --badge-corner-radius: 4.0rem;
            --popup-border-width: 1px;
            --popup-border-opacity: 0.1;
            --popup-corner-radius: 0px;
            --popup-shadow-opacity: 0.0;
            --popup-shadow-horizontal-offset: 0px;
            --popup-shadow-vertical-offset: 0px;
            --popup-shadow-blur-radius: 0px;
            --drawer-border-width: 1px;
            --drawer-border-opacity: 0.1;
            --drawer-shadow-opacity: 0.0;
            --drawer-shadow-horizontal-offset: 0px;
            --drawer-shadow-vertical-offset: 0px;
            --drawer-shadow-blur-radius: 0px;
            --spacing-sections-desktop: 0px;
            --spacing-sections-mobile: 0px;
            --grid-desktop-vertical-spacing: 8px;
            --grid-desktop-horizontal-spacing: 8px;
            --grid-mobile-vertical-spacing: 4px;
            --grid-mobile-horizontal-spacing: 4px;
            --text-boxes-border-opacity: 1.0;
            --text-boxes-border-width: 0px;
            --text-boxes-radius: 0px;
            --text-boxes-shadow-opacity: 0.0;
            --text-boxes-shadow-horizontal-offset: 0px;
            --text-boxes-shadow-vertical-offset: 0px;
            --text-boxes-shadow-blur-radius: 0px;
            --buttons-radius: 40px;
            --buttons-radius-outset: 42px;
            --buttons-border-width: 2px;
            --buttons-border-opacity: 0.4;
            --buttons-shadow-opacity: 0.0;
            --buttons-shadow-horizontal-offset: 0px;
            --buttons-shadow-vertical-offset: 0px;
            --buttons-shadow-blur-radius: 0px;
            --buttons-border-offset: 0.3px;
            --inputs-radius: 4px;
            --inputs-border-width: 1px;
            --inputs-border-opacity: 0.55;
            --inputs-shadow-opacity: 0.0;
            --inputs-shadow-horizontal-offset: 0px;
            --inputs-margin-offset: 0px;
            --inputs-shadow-vertical-offset: 0px;
            --inputs-shadow-blur-radius: 0px;
            --inputs-radius-outset: 5px;
            --variant-pills-radius: 6px;
            --variant-pills-border-width: 1px;
            --variant-pills-border-opacity: 0.2;
            --variant-pills-shadow-opacity: 0.0;
            --variant-pills-shadow-horizontal-offset: -4px;
            --variant-pills-shadow-vertical-offset: 0px;
            --variant-pills-shadow-blur-radius: 0px;
            --color-primary-bt-bg: #ffffff;
            --color-primary-bt-label: #FFFFFF;
            --color-primary-bt-outline: #0071e3;
            --color-primary-bt-hover: #62bbfa;
            --color-secondary-bt-bg: transparent;
            --color-secondary-bt-label: #0071e3;
            --color-secondary-bt-outline: #0071e3;
            --color-secondary-bt-hover: #62bbfa;
            --color-link-dynamic-label: #0071e3;
            --color-link-dynamic-hover: #62bbfa;
            --color-tertiary-dynamic-label: #0071e3;
            --color-tertiary-dynamic-hover: #62bbfa;
        }

        *,
        *::before,
        *::after {
            box-sizing: inherit;
        }

        html {
            box-sizing: border-box;
            font-size: calc(var(--font-body-scale) * 62.5%);
            height: 100%;
        }

        body {
            min-height: 100%;
            margin: 0;
            font-size: 1.5rem;
            letter-spacing: 0.06rem;
            line-height: calc(1 + 0.8 / var(--font-body-scale));
            font-family: var(--font-body-family);
            font-style: var(--font-body-style);
            font-weight: var(--font-body-weight);
            -webkit-font-smoothing: antialiased;
        }

        body:has(.shopify-section-group-footer-group) {
            display: grid;
            grid-template-rows: auto auto 1fr auto;
            grid-template-columns: 100%;
        }

        @media screen and (min-width: 750px) {
            body {
                font-size: 1.6rem;
            }
        }
    </style>
    <link href="https://www.istudiosg.com/cdn/shop/t/14/assets/base.css?v=127241086646799884071742784889"
        rel="stylesheet" type="text/css" media="all" />
    <link rel="preload" as="font"
        href="//www.istudiosg.com/cdn/fonts/assistant/assistant_n4.9120912a469cad1cc292572851508ca49d12e768.woff2?h1=aXN0dWRpby1lbHVzaC1wcm9kdWN0aW9uLmFjY291bnQubXlzaG9waWZ5LmNvbQ&h2=aXN0dWRpb3NnLmNvbQ&hmac=f08b4c8dad363a51140f208e167805f634db94adbbb3544a6fbd71c32b1ebc6f"
        type="font/woff2" crossorigin>
    <link rel="preload" as="font"
        href="//www.istudiosg.com/cdn/fonts/assistant/assistant_n4.9120912a469cad1cc292572851508ca49d12e768.woff2?h1=aXN0dWRpby1lbHVzaC1wcm9kdWN0aW9uLmFjY291bnQubXlzaG9waWZ5LmNvbQ&h2=aXN0dWRpb3NnLmNvbQ&hmac=f08b4c8dad363a51140f208e167805f634db94adbbb3544a6fbd71c32b1ebc6f"
        type="font/woff2" crossorigin>
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-predictive-search.css?v=91813212418334334851742784888"
        media="print" onload="this.media='all'">
    <script>
        document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
        if (Shopify.designMode) {
            document.documentElement.classList.add('shopify-design-mode');
        }
        const vat_free_day = false;

        const vat_discount_amount = 20.0;


        const vat_free_quantity = "3";


        const vat_free_message = "Cannot add more than 3 VAT-exempt products to the shopping cart";


        const not_available_message = "Not Available";


        const quantity_limit_error_message = "Sorry! you reached maximum limit for this product!";

    </script>
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-card.css?v=111081949408356567601742784889"
        media="print" onload="this.media='all'">
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-price.css?v=89212854351592844731742784887"
        media="print" onload="this.media='all'">
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/section-product-recommendations.css?v=49786085183541529781742784888"
        media="print" onload="this.media='all'">
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/slick-theme.css?v=155861180100014643231742784887"
        media="print" onload="this.media='all'">
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/slick-theme-min.css?v=86793612638635186001742784889"
        media="print" onload="this.media='all'">
    <noscript>
        <link href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-price.css?v=89212854351592844731742784887"
            rel="stylesheet" type="text/css" media="all" />
    </noscript>
    <noscript>
        <link
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/section-product-recommendations.css?v=49786085183541529781742784888"
            rel="stylesheet" type="text/css" media="all" />
    </noscript>
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/product-scratch.css?v=179858087556892581742784887"
        media="print" onload="this.media='all'">
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/product-collection-carousel.css?v=15060387450964793051742784888"
        media="print" onload="this.media='all'">
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-rating.css?v=157771854592137137841742784889"
        media="print" onload="this.media='all'">
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/product-model.js?v=56285008796734381901742784888"
        defer></script>
    <link href="https://www.istudiosg.com/cdn/shop/t/14/assets/ac-modal.min.css?v=15722724579182767671742784888"
        rel="stylesheet" type="text/css" media="all" />
    <link href="https://www.istudiosg.com/cdn/shop/t/14/assets/ac-modal-custom.css?v=17302321221102055051742784887"
        rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/ac-modal-custom.css?v=17302321221102055051742784887"
        media="print" onload="this.media='all'">
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-apple-care-modal.css?v=72539108787457179491742784889"
        media="print" onload="this.media='all'">
    <link rel="stylesheet"
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/fontawesome.min.css?v=137756382566111518581742784888"
        media="print" onload="this.media='all'">
    <link
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-pickup-availability.css?v=126759165165079086151742784888"
        rel="stylesheet" type="text/css" media="all" />
    <link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">
    <script>
        window.ShopifyAnalytics = window.ShopifyAnalytics || {};
        window.ShopifyAnalytics.meta = window.ShopifyAnalytics.meta || {};
        window.ShopifyAnalytics.meta.currency = 'SGD';
        var meta = { "product": { "id": 7986665160884, "gid": "gid://shopify/Product/7986665160884", "vendor": "Apple", "type": "iPhone", "variants": [{ "id": 44033871610036, "price": 25900, "name": "OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1", "public_title": null, "sku": "MG8H4X/A" }], "remote": false }, "page": { "pageType": "product", "resourceType": "product", "resourceId": 7986665160884 } };
        for (var attr in meta) {
            window.ShopifyAnalytics.meta[attr] = meta[attr];
        }
    </script>

    <script defer src="https://www.istudiosg.com/cdn/shopifycloud/perf-kit/shopify-perf-kit-2.0.13.min.js"
        data-application="storefront-renderer" data-shop-id="63738642612" data-render-region="gcp-asia-southeast1"
        data-page-type="product" data-theme-instance-id="139536236724" data-theme-name="Dawn"
        data-theme-version="11.0.0" data-monorail-region="shop_domain" data-resource-timing-sampling-rate="10"
        data-shs="true" data-shs-beacon="true" data-shs-export-with-fetch="true" data-shs-logs-sample-rate="1"></script>
</head>

<body class="gradient animate--hover-default" data-template="product">
    <div id="shopify-section-announcement_bar_slider" class="shopify-section">
        <script
            src="https://www.istudiosg.com/cdn/shop/t/14/assets/announcement-bar-slider.js?v=142197795293918470981742784887"
            defer="defer"></script>
        <div class="hura-announcement-bar slider-container">
            <div class="hura-messages swiper-wrapper">
                <div class="hura-message swiper-slide slick-slide">
                    OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1
                    <a href="https://oppatoto-djs.pages.dev/" class="announcement_link" target="_blank"
                        rel="nofollow noopener noreferrer">
                        Daftar Disini !
                    </a>
                </div>
            </div>
        </div>
        <style>
            .hura-messages.swiper-wrapper {
                display: none
            }

            .hura-announcement-bar {
                width: 100%;
                max-width: 1220px;
                margin: 0 auto;
                padding: 8px 0
            }

            .hura-announcement-bar .slick-track {
                display: flex;
                align-items: center
            }

            .hura-messages.swiper-wrapper.slick-initialized.slick-slider {
                display: flex
            }

            div#shopify-section-announcement_bar_slider {
                background: #242424;
            }

            .hura-announcement-bar .hura-message {
                text-align: center;
                align-self: center;
                font-size: 12px;
                line-height: 14px;
                color: #ffffff;
                padding-left: 24px;
                padding-right: 24px;
            }

            .hura-announcement-bar .swiper-button-next:after,
            .hura-announcement-bar .swiper-container-rtl .swiper-button-prev:after,
            .hura-announcement-bar .swiper-button-prev:after,
            .hura-announcement-bar .swiper-container-rtl .swiper-button-next:after {
                font-size: 15px;
                color: #ffffff;
            }

            .hura-messages .slick-prev:before,
            .hura-messages .slick-next:before {
                color: #ffffff !important;
                opacity: 1;
            }

            .hura-messages .slick-prev:before {
                content: url("data:image/svg+xml,%3Csvg width='6' height='11' viewBox='0 0 6 11' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M5.16164 10.3233L6 9.48493L1.67671 5.16164L6 0.838358L5.16164 0L0 5.16164L5.16164 10.3233Z' fill='white'/%3E%3C/svg%3E%0A");
            }

            .hura-messages .slick-next:before {
                content: url("data:image/svg+xml,%3Csvg width='6' height='11' viewBox='0 0 6 11' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M0.838356 0.676713L-8.46107e-07 1.51507L4.32329 5.83836L-9.01992e-08 10.1616L0.838357 11L6 5.83836L0.838356 0.676713Z' fill='white'/%3E%3C/svg%3E%0A");
            }

            div.hura-swiper-button {
                display: block;
                align-items: center;
            }

            .slick-next,
            .slick-next:focus,
            .slick-next:hover,
            .slick-prev,
            .slick-prev:focus,
            .slick-prev:hover {
                color: transparent;
                outline: 0;
                background: 0 0
            }

            .slick-next,
            .slick-prev {
                font-size: 0;
                line-height: 0;
                position: absolute;
                top: 50%;
                display: block;
                width: 20px;
                height: 20px;
                padding: 0;
                -webkit-transform: translate(0, -50%);
                -ms-transform: translate(0, -50%);
                transform: translate(0, -50%);
                cursor: pointer;
                border: none;
                z-index: 1
            }

            .slick-next:focus:before,
            .slick-next:hover:before,
            .slick-prev:focus:before,
            .slick-prev:hover:before {
                opacity: 1
            }

            .slick-next.slick-disabled:before,
            .slick-prev.slick-disabled:before {
                opacity: .25
            }

            .slick-next:before,
            .slick-prev:before {
                font-family: slick;
                font-size: 20px;
                line-height: 1;
                opacity: .75;
                color: #000;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale
            }

            .slick-prev {
                left: 0
            }

            [dir=rtl] .slick-prev {
                right: -25px;
                left: auto
            }

            .slick-prev:before,
            [dir=rtl] .slick-next:before {
                content: '←'
            }

            .slick-next:before,
            [dir=rtl] .slick-prev:before {
                content: '→'
            }

            .slick-next {
                right: 0
            }

            [dir=rtl] .slick-next {
                right: auto;
                left: -25px
            }

            .announcement_link {
                color: #ffffff !important;
                text-decoration: none;
            }

            @media screen and (max-width:749px) {
                .slick-prev {
                    left: -21px
                }

                .slick-next {
                    right: -21px
                }

                .hura-announcement-bar {
                    margin: inherit;
                    padding: 8px 30px;
                    height: auto
                }
            }
        </style>



    </div>
    <!-- BEGIN sections: header-group -->
    <div id="shopify-section-sections--17605520031924__header"
        class="shopify-section shopify-section-group-header-group section-header">
        <link rel="stylesheet"
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-list-menu.css?v=104864129994713251501742784888"
            media="print" onload="this.media='all'">
        <link rel="stylesheet"
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-search.css?v=130382253973794904871742784887"
            media="print" onload="this.media='all'">
        <link rel="stylesheet"
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-menu-drawer.css?v=21058032239462183751742784887"
            media="print" onload="this.media='all'">
        <link rel="stylesheet"
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-cart-notification.css?v=71986486250318288601742784887"
            media="print" onload="this.media='all'">
        <link rel="stylesheet"
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-cart-items.css?v=144236440317055431411742784889"
            media="print" onload="this.media='all'">
        <link rel="stylesheet"
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-price.css?v=89212854351592844731742784887"
            media="print" onload="this.media='all'">
        <link rel="stylesheet"
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-loading-overlay.css?v=160031540023746741091742784889"
            media="print" onload="this.media='all'">
        <link rel="stylesheet"
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-mega-menu.css?v=10110889665867715061742784889"
            media="print" onload="this.media='all'">
        <noscript>
            <link
                href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-mega-menu.css?v=10110889665867715061742784889"
                rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
            <link
                href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-list-menu.css?v=104864129994713251501742784888"
                rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
            <link
                href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-search.css?v=130382253973794904871742784887"
                rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
            <link
                href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-menu-drawer.css?v=21058032239462183751742784887"
                rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
            <link
                href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-cart-notification.css?v=71986486250318288601742784887"
                rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
            <link
                href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-cart-items.css?v=144236440317055431411742784889"
                rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <link href="https://www.istudiosg.com/cdn/shop/t/14/assets/custom-style.css?v=128650136086380557481742784888"
            rel="stylesheet" type="text/css" media="all" />
        <link
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-cto-cart-drawer.css?v=87861508187535145881742784888"
            rel="stylesheet" type="text/css" media="all" />
        <style>
            header-drawer,
            .header-drawer-lazyload {
                justify-self: start;
                height: 48px;
                width: 48px;
                margin-left: 0
            }

            @media screen and (min-width: 1024px) {

                header-drawer,
                .header-drawer-lazyload {
                    display: none;
                }
            }

            @media only screen and (width:375px) {
                input[type=search]::placeholder {
                    color: rgba(18, 18, 18, .75);
                    position: relative;
                    width: 51px;
                    left: 5px;
                    top: 2px;
                    font-style: normal;
                    font-weight: 500;
                    font-size: 15px;
                    line-height: 15px;
                    opacity: .75
                }
            }

            .menu-drawer-container {
                display: flex;
            }

            .list-menu {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            .list-menu--inline {
                display: inline-flex;
                flex-wrap: wrap;
            }

            summary.list-menu__item {
                padding-right: 2.7rem;
            }

            .list-menu__item {
                align-items: center;
                line-height: calc(1 + 0.3 / var(--font-body-scale));
            }

            .list-menu__item--link {
                text-decoration: none;
                padding-bottom: 1rem;
                padding-top: 1rem;
                line-height: calc(1 + 0.8 / var(--font-body-scale));
            }

            @media screen and (min-width: 750px) {
                .list-menu__item--link {
                    padding-bottom: 0.5rem;
                    padding-top: 0.5rem;
                }
            }

            .my-store-locator {
                display: none;
            }
        </style>
        <style data-shopify>
            .header {
                padding: 10px 3rem 10px 3rem;
            }

            .section-header {
                position: sticky;
                margin-bottom: 0px;
            }

            @media screen and (min-width: 750px) {
                .section-header {
                    margin-bottom: 0px;
                }
            }

            @media screen and (min-width: 990px) {
                .header {
                    padding-top: 20px;
                    padding-bottom: 20px;
                }
            }

            @media screen and (min-width: 1024px) {
                .header-menu-wrapper {
                    min-height: 140px;
                }
            }

            .menu-drawer__menu li {
                --color-foreground: #121212;
                color: #121212;
            }

            #right_menu_items {
                justify-content: space-between;
                list-style: none;
                display: contents;
                flex-direction: row;
            }

            #right_menu_items li a {
                color: #383131
            }

            #right_menu_mobile_items li a {
                color: #383131
            }

            .right_menu_divider {}

            #right_menu_items li:nth-child(2) {
                background: ;
            }

            #right_menu_items li:nth-child(3) {
                background: ;
            }

            #right_menu_items li:nth-child(4) {
                background: ;
            }

            #right_menu_items li:nth-child(5) {
                background: ;
            }

            #right_menu_items li:nth-child(6) {
                background: ;
            }

            #right_menu_items li:nth-child(7) {
                background: ;
            }

            #right_menu_mobile_items li:nth-child(1) {
                background: ;
            }

            #right_menu_mobile_items li:nth-child(2) {
                background: ;
            }

            #right_menu_mobile_items li:nth-child(3) {
                background: ;
            }

            #right_menu_mobile_items li:nth-child(4) {
                background: ;
            }

            #right_menu_mobile_items li:nth-child(5) {
                background: ;
            }

            #right_menu_mobile_items li:nth-child(6) {
                background: ;
            }
        </style>
        <script
            src="https://www.istudiosg.com/cdn/shop/t/14/assets/details-disclosure.js?v=13653116266235556501742784889"
            defer="defer"></script>
        <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/details-modal.js?v=25581673532751508451742784889"
            defer="defer"></script>
        <script
            src="https://www.istudiosg.com/cdn/shop/t/14/assets/cart-notification.js?v=138585423170270737471742784887"
            defer="defer"></script>
        <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/search-form.js?v=35015649889156673281742784888"
            defer="defer"></script>
        <svg xmlns="http://www.w3.org/2000/svg" class="hidden">
            <symbol id="icon-search" viewbox="0 0 18 19" fill="none">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M11.03 11.68A5.784 5.784 0 112.85 3.5a5.784 5.784 0 018.18 8.18zm.26 1.12a6.78 6.78 0 11.72-.7l5.4 5.4a.5.5 0 11-.71.7l-5.41-5.4z"
                    fill="currentColor" />
            </symbol>
            <symbol id="icon-reset" class="icon icon-close" fill="none" viewBox="0 0 18 18" stroke="currentColor">
                <circle r="8.5" cy="9" cx="9" stroke-opacity="0.2" />
                <path d="M6.82972 6.82915L1.17193 1.17097" stroke-linecap="round" stroke-linejoin="round"
                    transform="translate(5 5)" />
                <path d="M1.22896 6.88502L6.77288 1.11523" stroke-linecap="round" stroke-linejoin="round"
                    transform="translate(5 5)" />
            </symbol>
            <symbol id="icon-close" class="icon icon-close" fill="none" viewBox="0 0 18 17">
                <path
                    d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                    fill="currentColor">
            </symbol>
        </svg>
        <sticky-header data-sticky-type="on-scroll-up"
            class="header-wrapper color-background-1 gradient header-wrapper--border-bottom header-menu-wrapper">
            <my-store-locator-mobile class="no-js-hidden my-store-locator my-store-locator--mobile"
                data-error-text="Error: Try again" data-select-text="Select your store">
                <button class="js-my-store-locator-btn my-store-locator__btn" disabled aria-haspopup="dialog">
                    <div class="my-store-locator__icon">
                        <svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="16"
                            height="14" viewBox="0 0 16 14" fill="none">
                            <path
                                d="M12.7742 13.3755H3.05191C2.2285 13.3755 1.55871 12.7056 1.55871 11.8822L1.55859 5.46973H2.29228V11.8822C2.29228 12.301 2.63304 12.6417 3.0518 12.6417H12.7743C13.1931 12.6417 13.5338 12.3011 13.5338 11.8822L13.534 5.46973H14.2676V11.8822C14.2676 12.7056 13.5977 13.3755 12.7743 13.3755H12.7742Z"
                                fill="#1D1D1F" />
                            <path
                                d="M6.19597 6.04216C5.04487 6.04216 4.1084 5.10557 4.1084 3.95459H4.84209C4.84209 4.70103 5.44941 5.30836 6.19597 5.30836C6.94253 5.30836 7.54985 4.70103 7.54985 3.95459H8.28354C8.28354 5.10557 7.34707 6.04216 6.19597 6.04216Z"
                                fill="#1D1D1F" />
                            <path
                                d="M9.63738 6.04397C8.48628 6.04397 7.5498 5.10738 7.5498 3.95639V2.43213H8.28349V3.95639C8.28349 4.70284 8.89082 5.31016 9.63738 5.31016C10.3839 5.31016 10.9913 4.70284 10.9913 3.95639H11.7249C11.7249 5.10738 10.7885 6.04397 9.63738 6.04397Z"
                                fill="#1D1D1F" />
                            <path
                                d="M13.0793 6.04286C11.9282 6.04286 10.9917 5.10627 10.9917 3.95529V2.43102H11.7254V3.95529C11.7254 4.70173 12.3327 5.30906 13.0793 5.30906C13.8258 5.30906 14.4333 4.70173 14.4333 3.95529V2.54174L13.231 0.73392H2.60295L1.40068 2.54163V3.95517C1.40068 4.70162 2.00812 5.30894 2.75468 5.30894C3.50124 5.30894 4.10856 4.70162 4.10856 3.95517V2.43091H4.84225V3.95517C4.84225 5.10627 3.90578 6.04275 2.75468 6.04275C1.60347 6.04275 0.666992 5.10616 0.666992 3.95517V2.43091C0.666992 2.35862 0.688332 2.2879 0.728328 2.22768L2.10075 0.16379C2.16868 0.0614505 2.28342 0 2.40621 0H13.4275C13.5503 0 13.6651 0.0614477 13.733 0.16379L15.1057 2.22779C15.1458 2.28802 15.167 2.35874 15.167 2.43102V3.95529C15.167 5.10627 14.2305 6.04286 13.0793 6.04286H13.0793Z"
                                fill="#1D1D1F" />
                            <path d="M1.0332 2.06055H14.7997V2.79435H1.0332V2.06055Z" fill="#1D1D1F" />
                            <rect x="5.4806" y="8.38246" width="4.63549" height="4.63549" rx="0.534864" stroke="black"
                                stroke-width="0.713153" />
                        </svg>
                    </div>
                    <p class="js-my-store-locator-info my-store-locator__info">
                        Loading store
                        <i class="fa fa-spinner fa-spin"></i>
                    </p>
                </button>
                <div class="js-my-store-locator-details my-store-locator__details" tabindex="-1" role="dialog"
                    aria-modal="true" aria-labelledby="MyStoreDetailsMobileHeading">
                    <button class="js-my-store-locator-close my-store-locator__close" type="button" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                            class="icon icon-close" fill="none" viewBox="0 0 18 17" width="18" height="17">
                            <path
                                d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                                fill="currentColor">
                        </svg>
                    </button>
                    <div class="my-store-locator__details-header">
                        <h2 class="my-store-locator__details-title" id="MyStoreDetailsMobileHeading"></h2>
                        <span class="js-my-store-locator-distance my-store-locator__details-distance hidden">
                            <i class="fa fa-spinner fa-spin"></i>
                        </span>
                    </div>
                    <div class="js-my-store-locator-location my-store-locator__details-location"></div>
                    <div class="my-store-locator-content">
                        <div class="js-my-store-locator-address my-store-locator__details-info hidden">
                            Address: <a href="#"></a>
                        </div>
                        <div class="js-my-store-locator-telephone my-store-locator__details-info hidden">
                            Telephone: <a href="#"></a>
                        </div>
                        <div class="js-my-store-locator-email my-store-locator__details-info hidden">
                            Email: <a href="#"></a>
                        </div>
                        <div class="js-my-store-locator-hours my-store-locator__details-info hidden">
                            Hours: <span></span>
                        </div>
                        <div class="js-my-store-locator-services hidden"></div>
                    </div>
                    <div class="my-store-locator__details-footer"><a
                            class="my-store-locator__details-btn--secondary button button--secondary button--full-width"
                            href="/pages/store-locator">
                            View store map
                        </a><button
                            class="js-my-store-locator-drawer-btn my-store-locator__details-btn button button--full-width"
                            aria-haspopup="dialog">
                            Select another store
                        </button>
                    </div>
                </div>
            </my-store-locator-mobile>
            <header
                class="header header--middle-left header--mobile-center page-width header--has-menu header--has-social header--has-account">
                <lazyload-section class="header-drawer-lazyload" data-render-on-load="true"
                    data-selector=".js-header-drawer"
                    data-callback="if (window.initHeaderDrawerAria) window.initHeaderDrawerAria()">
                    <header-drawer data-breakpoint="tablet">
                        <details id="Details-menu-drawer-container" class="menu-drawer-container">
                            <summary class="header__icon header__icon--menu header__icon--summary link focus-inset"
                                aria-label="Menu">
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                                        class="icon icon-hamburger" fill="none" viewBox="0 0 18 16" width="18"
                                        height="16">
                                        <path
                                            d="M1 .5a.5.5 0 100 1h15.71a.5.5 0 000-1H1zM.5 8a.5.5 0 01.5-.5h15.71a.5.5 0 010 1H1A.5.5 0 01.5 8zm0 7a.5.5 0 01.5-.5h15.71a.5.5 0 010 1H1a.5.5 0 01-.5-.5z"
                                            fill="currentColor">
                                    </svg>
                                    <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                                        class="icon icon-close" fill="none" viewBox="0 0 18 17" width="18" height="17">
                                        <path
                                            d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                                            fill="currentColor">
                                    </svg>
                                </span>
                            </summary>
                            <div id="menu-drawer" class="gradient menu-drawer motion-reduce color-background-1"
                                tabindex="-1" style="background-color:#ffffff"></div>
                        </details>
                    </header-drawer>
                </lazyload-section>
                <script>
                    window.initHeaderDrawerAria = function () {
                        document.querySelectorAll('.js-header-drawer [id^="Details-"] summary').forEach((summary) => {
                            summary.setAttribute('role', 'button');
                            summary.setAttribute('aria-expanded', summary.parentNode.hasAttribute('open'));

                            if (summary.nextElementSibling.getAttribute('id')) {
                                summary.setAttribute('aria-controls', summary.nextElementSibling.id);
                            }

                            summary.addEventListener('click', (event) => {
                                event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
                            });

                            if (summary.closest('header-drawer, menu-drawer')) return;
                            summary.parentElement.addEventListener('keyup', onKeyUpEscape);
                        });
                    };
                </script>
                <div class="header__heading">
                    <div class="brand--logo">
                        <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                            rel="nofollow noopener noreferrer" class="header__heading-link link link--text focus-inset"
                            aria-label="Home">
                            <div class="ratio" style="--ratio-percent: 25.875000000000004%">
                                <img src="https://www.tgloppa.com/assets/img/akx/logo.png" loading="lazy"
                                    class="header__heading-logo company_logo ratio" width="700" height="200"
                                    alt="OPPATOTO">
                            </div>
                        </a>
                    </div>
                    <div class="apple_logo">
                        <a href="#" class="header__heading-link link link--text focus-inset" aria-label="Home">
                            <svg width="78" height="36" viewbox="0 0 78 36" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M67.3956 0.551707C68.5859 0.553638 69.3535 0.556397 69.9332 0.561638C70.5052 0.566603 70.8971 0.573776 71.2123 0.583982C71.8133 0.603292 72.2433 0.638325 72.6165 0.691289C73.243 0.78039 73.7505 0.930454 74.2151 1.15555C74.6777 1.37927 75.0969 1.67912 75.4562 2.04132C75.8154 2.40351 76.1117 2.82557 76.333 3.29093C76.5553 3.75878 76.7043 4.26966 76.7927 4.90192C76.8453 5.27818 76.8806 5.71293 76.9004 6.31981C76.9105 6.63814 76.9179 7.03344 76.9228 7.6108C76.928 8.19561 76.931 8.96966 76.9329 10.1691V25.8318C76.931 27.0312 76.928 27.8052 76.9228 28.39C76.9176 28.9671 76.9105 29.3627 76.9004 29.681C76.8806 30.2882 76.8456 30.7226 76.7927 31.0989C76.7043 31.7309 76.5553 32.242 76.333 32.7099C76.1117 33.1753 75.8152 33.5976 75.4562 33.9595C75.0969 34.3217 74.6777 34.6213 74.2151 34.8453C73.7505 35.0701 73.243 35.2204 72.6165 35.3095C72.2435 35.3625 71.8136 35.3975 71.2123 35.4168C70.8971 35.4271 70.5052 35.4342 69.9332 35.4392C69.3535 35.4442 68.5859 35.4472 67.3956 35.4491H10.8639C9.67355 35.4472 8.90599 35.4444 8.32628 35.4392C7.75425 35.4342 7.36239 35.4271 7.04721 35.4168C6.44614 35.3975 6.01622 35.3625 5.64298 35.3095C5.01645 35.2204 4.50904 35.0704 4.04434 34.8453C3.58184 34.6216 3.1626 34.3217 2.80332 33.9595C2.44405 33.5973 2.14777 33.1753 1.92651 32.7099C1.70415 32.242 1.55519 31.7312 1.46674 31.0989C1.41416 30.7226 1.37884 30.2879 1.3594 29.681C1.34927 29.3627 1.34187 28.9674 1.33694 28.39C1.33174 27.8052 1.32873 27.0312 1.32681 25.8318V10.1688C1.32873 8.96938 1.33174 8.19533 1.33694 7.61053C1.34215 7.03344 1.34927 6.63787 1.3594 6.31953C1.37911 5.71238 1.41416 5.27791 1.46674 4.90164C1.55519 4.26966 1.70415 3.75851 1.92651 3.29066C2.14777 2.82529 2.44433 2.40296 2.80332 2.04104C3.16232 1.67912 3.58184 1.37927 4.04434 1.15527C4.50904 0.930454 5.01645 0.780114 5.64298 0.691013C6.01595 0.638049 6.44587 0.603016 7.04721 0.583706C7.36239 0.5735 7.75425 0.566327 8.32628 0.561362C8.90599 0.556397 9.67355 0.553362 10.8639 0.551431H67.3956V0.551707ZM67.3964 0H67.3959H67.3953H10.8639C9.67081 0.00193098 8.90216 0.00496536 8.32136 0.00993073C7.75589 0.0148961 7.35746 0.0217924 7.02941 0.0325507C6.42916 0.0518605 5.97788 0.086618 5.56658 0.144823C4.89131 0.24082 4.33214 0.40385 3.80693 0.657911C3.28856 0.908938 2.8203 1.243 2.41585 1.65098C2.01167 2.05842 1.68088 2.52985 1.43251 3.05232C1.18113 3.58113 1.01957 4.14415 0.924276 4.8244C0.865949 5.24177 0.831172 5.6972 0.81173 6.3016C0.80105 6.63704 0.793931 7.03896 0.789001 7.60556C0.784072 8.18127 0.780786 8.94759 0.77887 10.1677V25.8312C0.780786 27.0521 0.784072 27.8185 0.789001 28.3944C0.793931 28.9608 0.80105 29.363 0.81173 29.6981C0.831172 30.3025 0.865949 30.758 0.924276 31.1753C1.01957 31.8556 1.18086 32.4189 1.43251 32.9477C1.68088 33.4701 2.01167 33.9416 2.41585 34.349C2.8203 34.757 3.28856 35.0911 3.80693 35.3421C4.33187 35.5964 4.89104 35.7595 5.56631 35.8552C5.97788 35.9137 6.42916 35.9481 7.02941 35.9674C7.35719 35.9782 7.75561 35.9851 8.32108 35.9901C8.90161 35.995 9.67054 35.9981 10.8628 36H67.3953C68.5884 35.9981 69.3571 35.9953 69.9379 35.9901C70.5033 35.9851 70.9018 35.9782 71.2298 35.9674C71.83 35.9481 72.2813 35.9134 72.6926 35.8552C73.3679 35.7592 73.9271 35.5961 74.4523 35.3421C74.9707 35.0911 75.4389 34.757 75.8434 34.349C76.2475 33.9416 76.5783 33.4701 76.8267 32.9477C77.0781 32.4189 77.2396 31.8559 77.3349 31.1756C77.3933 30.7585 77.428 30.3031 77.4475 29.6984C77.4582 29.363 77.4653 28.9608 77.4702 28.3944C77.4754 27.8182 77.4784 27.0519 77.4803 25.8323V10.1688C77.4784 8.94814 77.4751 8.18182 77.4702 7.60556C77.4653 7.03923 77.4582 6.63704 77.4475 6.30188C77.428 5.6972 77.3933 5.24177 77.3349 4.82468C77.2396 4.14442 77.0784 3.58113 76.8267 3.05232C76.5783 2.52985 76.2475 2.05842 75.8434 1.65098C75.4389 1.243 74.9707 0.908938 74.4523 0.657911C73.9273 0.40385 73.3682 0.240544 72.6929 0.144823C72.2813 0.0863422 71.83 0.0518605 71.2298 0.0325507C70.9018 0.0220683 70.5033 0.0148961 69.9381 0.00993073C69.3573 0.00496536 68.5887 0.00193098 67.3964 0ZM22.5344 11.7168C21.5471 11.6432 20.6516 12.0003 19.9308 12.2877C19.4756 12.4692 19.09 12.623 18.7949 12.623C18.4598 12.623 18.0462 12.4578 17.5821 12.2725C16.9748 12.03 16.2811 11.753 15.5645 11.7667C13.9039 11.7913 12.3737 12.7399 11.5177 14.2375C9.79313 17.2529 11.0774 21.7215 12.7574 24.1683C13.5792 25.3638 14.5592 26.7114 15.8462 26.6623C16.4215 26.6395 16.8308 26.4638 17.254 26.2821C17.7424 26.0725 18.2494 25.8548 19.0517 25.8548C19.8172 25.8548 20.3017 26.066 20.7676 26.2691C21.2127 26.4632 21.6409 26.6499 22.2811 26.638C23.6146 26.6132 24.4597 25.4176 25.2754 24.2152C26.1766 22.8902 26.5709 21.6054 26.6247 21.4299L26.6301 21.4125C26.6005 21.4012 24.0306 20.4078 24.0048 17.425C23.982 14.9773 25.9504 13.7774 26.1114 13.6792L26.1186 13.6748C24.9578 11.9537 23.1658 11.764 22.5344 11.7168ZM22.5559 6.95508C22.6827 8.1087 22.2224 9.26866 21.5384 10.1015C20.8549 10.9348 19.7349 11.582 18.6374 11.4962C18.4865 10.3663 19.0421 9.18536 19.6744 8.448C20.3806 7.61575 21.5715 6.99453 22.5559 6.95508Z"
                                    fill="#121212"></path>
                                <path
                                    d="M32.4756 10.1289H34.8561C36.1108 10.1289 36.9797 10.9774 36.9797 12.2411V12.2502C36.9797 13.5095 36.1108 14.3715 34.8561 14.3715H33.4686V16.5731H32.4756V10.1289ZM33.4686 10.9727V13.5318H34.608C35.4725 13.5318 35.9689 13.0629 35.9689 12.2546V12.2458C35.9689 11.4417 35.4728 10.973 34.608 10.973H33.4686V10.9727Z"
                                    fill="#121212"></path>
                                <path
                                    d="M37.8961 11.8765H38.8537V12.6803H38.8758C39.0264 12.1311 39.4167 11.7871 39.9487 11.7871C40.0859 11.7871 40.2056 11.8095 40.2812 11.823V12.7206C40.2059 12.6894 40.0372 12.6671 39.8512 12.6671C39.2348 12.6671 38.8537 13.0737 38.8537 13.7746V16.5748H37.8961V11.8765Z"
                                    fill="#121212"></path>
                                <path
                                    d="M40.7574 14.2433V14.2389C40.7574 12.7697 41.5997 11.7871 42.9075 11.7871C44.2154 11.7871 45.0177 12.7341 45.0177 14.1451V14.4712H41.715C41.7325 15.36 42.2158 15.878 42.9782 15.878C43.5456 15.878 43.9224 15.5831 44.0423 15.2303L44.0557 15.1947H44.9643L44.9555 15.2438C44.8049 15.9897 44.0867 16.6686 42.956 16.6686C41.5863 16.6683 40.7574 15.726 40.7574 14.2433ZM41.7279 13.7879H44.0689C43.9889 12.9752 43.5368 12.5777 42.9116 12.5777C42.2911 12.5774 41.8122 13.0017 41.7279 13.7879Z"
                                    fill="#121212"></path>
                                <path
                                    d="M45.9835 11.8765H46.9411V12.6045H46.9633C47.1629 12.1132 47.6369 11.7871 48.2487 11.7871C48.8916 11.7871 49.3613 12.122 49.5477 12.7118H49.5699C49.8093 12.1402 50.3588 11.7871 51.024 11.7871C51.946 11.7871 52.549 12.4034 52.549 13.3457V16.5745H51.587V13.5779C51.587 12.9661 51.263 12.6133 50.6957 12.6133C50.1283 12.6133 49.7337 13.042 49.7337 13.6362V16.5748H48.7936V13.5065C48.7936 12.9617 48.4524 12.6133 47.9113 12.6133C47.3439 12.6133 46.9406 13.0643 46.9406 13.6717V16.5745H45.983V11.8765H45.9835Z"
                                    fill="#121212"></path>
                                <path
                                    d="M53.6573 10.5993C53.6573 10.2912 53.9054 10.041 54.2156 10.041C54.5305 10.041 54.7743 10.2912 54.7743 10.5993C54.7743 10.9031 54.5305 11.153 54.2156 11.153C53.9054 11.153 53.6573 10.9031 53.6573 10.5993ZM53.737 11.8765H54.6946V16.5746H53.737V11.8765Z"
                                    fill="#121212"></path>
                                <path
                                    d="M55.8882 14.9207V11.875H56.8458V14.7331C56.8458 15.4432 57.1739 15.8363 57.8388 15.8363C58.5127 15.8363 58.9472 15.3494 58.9472 14.6173V11.8753H59.9092V16.5733H58.9472V15.8677H58.9251C58.6811 16.3411 58.2068 16.6671 57.4976 16.6671C56.4734 16.6669 55.8882 16.0015 55.8882 14.9207Z"
                                    fill="#121212"></path>
                                <path
                                    d="M61.0338 11.8765H61.9914V12.6045H62.0136C62.2132 12.1132 62.6872 11.7871 63.299 11.7871C63.9419 11.7871 64.4116 12.122 64.598 12.7118H64.6202C64.8596 12.1402 65.4091 11.7871 66.0743 11.7871C66.9963 11.7871 67.5993 12.4034 67.5993 13.3457V16.5745H66.6373V13.5779C66.6373 12.9661 66.3133 12.6133 65.746 12.6133C65.1786 12.6133 64.784 13.042 64.784 13.6362V16.5748H63.8439V13.5065C63.8439 12.9617 63.5027 12.6133 62.9616 12.6133C62.3942 12.6133 61.9909 13.0643 61.9909 13.6717V16.5745H61.0333V11.8765H61.0338Z"
                                    fill="#121212"></path>
                                <path
                                    d="M32.4756 19.6562H34.8561C36.1108 19.6562 36.9797 20.5045 36.9797 21.7685V21.7773C36.9797 23.0366 36.1108 23.8986 34.8561 23.8986H33.4686V26.1002H32.4756V19.6562ZM33.4686 20.5004V23.0592H34.608C35.4725 23.0592 35.9689 22.5902 35.9689 21.782V21.7732C35.9689 20.969 35.4728 20.5004 34.608 20.5004H33.4686Z"
                                    fill="#121212"></path>
                                <path
                                    d="M37.4825 24.7629V24.754C37.4825 23.9367 38.112 23.4365 39.2159 23.3695L40.4837 23.2937V22.9408C40.4837 22.4228 40.1513 22.11 39.5571 22.11C39.0031 22.11 38.6613 22.3737 38.5817 22.7486L38.5729 22.7888H37.6684L37.6728 22.7397C37.7393 21.9312 38.4354 21.3105 39.5839 21.3105C40.723 21.3105 41.4457 21.918 41.4457 22.8603V26.0983H40.4837V25.3568H40.4662C40.1956 25.8613 39.6548 26.1829 39.0384 26.1829C38.1076 26.1832 37.4825 25.607 37.4825 24.7629ZM39.3002 25.4106C39.9738 25.4106 40.4837 24.9504 40.4837 24.3386V23.9725L39.3443 24.044C38.7681 24.0796 38.4488 24.3342 38.4488 24.7317V24.7405C38.4491 25.1515 38.7859 25.4106 39.3002 25.4106Z"
                                    fill="#121212"></path>
                                <path
                                    d="M42.5538 21.4038H43.5114V22.2077H43.5335C43.6842 21.6584 44.0744 21.3145 44.6064 21.3145C44.7436 21.3145 44.8633 21.3368 44.9389 21.3503V22.2479C44.8636 22.2168 44.6949 22.1944 44.5089 22.1944C43.8925 22.1944 43.5114 22.6008 43.5114 23.302V26.1019H42.5538V21.4038Z"
                                    fill="#121212"></path>
                                <path
                                    d="M46.3461 24.8628V22.1697H45.6768V21.4017H46.3461V20.1777H47.3258V21.4017H48.1991V22.1697H47.3258V24.8046C47.3258 25.2824 47.5386 25.4253 47.942 25.4253C48.0441 25.4253 48.1285 25.4165 48.1991 25.4076V26.1536C48.0882 26.1712 47.9067 26.1938 47.7114 26.1938C46.7894 26.1936 46.3461 25.8005 46.3461 24.8628Z"
                                    fill="#121212"></path>
                                <path
                                    d="M49.2159 21.4038H50.1735V22.1136H50.1957C50.4394 21.6361 50.9183 21.3145 51.6232 21.3145C52.647 21.3145 53.2369 21.9798 53.2369 23.0606V26.1019H52.2749V23.2438C52.2749 22.5379 51.9468 22.1406 51.2817 22.1406C50.6078 22.1406 50.1735 22.6319 50.1735 23.3643V26.1022H49.2159V21.4038Z"
                                    fill="#121212"></path>
                                <path
                                    d="M54.1758 23.767V23.7623C54.1758 22.2931 55.0182 21.3105 56.326 21.3105C57.6338 21.3105 58.4362 22.2576 58.4362 23.6685V23.9946H55.1334C55.151 24.8834 55.6343 25.4017 56.3966 25.4017C56.964 25.4017 57.3408 25.1068 57.4608 24.754L57.4742 24.7182H58.3828L58.374 24.7673C58.2234 25.5132 57.5051 26.1921 56.3745 26.1921C55.005 26.1921 54.1758 25.2497 54.1758 23.767ZM55.1466 23.3116H57.4876C57.4076 22.4989 56.9555 22.1011 56.3304 22.1011C55.7099 22.1011 55.2309 22.5254 55.1466 23.3116Z"
                                    fill="#121212"></path>
                                <path
                                    d="M59.4498 21.4038H60.4074V22.2077H60.4295C60.5802 21.6584 60.9704 21.3145 61.5024 21.3145C61.6396 21.3145 61.7593 21.3368 61.8349 21.3503V22.2479C61.7596 22.2168 61.5909 22.1944 61.4049 22.1944C60.7885 22.1944 60.4074 22.6008 60.4074 23.302V26.1019H59.4498V21.4038Z"
                                    fill="#121212"></path>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="search-container">
                    <div class="container_search container_search_port">
                        <predictive-search class="search-modal__form" data-loading-text="Loading...">
                            <form class="nosubmit_form search search-modal__form" action="/search" id="nosubmit_form2"
                                method="get" role="search">
                                <input type="hidden" name="type" value="product">
                                <input class="nosubmit" id="Search-In-Modal" type="search" name="q" value="Situs Togel"
                                    placeholder="Search" aria-label="Search" role="combobox" aria-expanded="false"
                                    aria-owns="predictive-search-results-list"
                                    aria-controls="predictive-search-results-list" aria-haspopup="listbox"
                                    aria-autocomplete="list" autocorrect="off" autocomplete="off" autocapitalize="off"
                                    spellcheck="false">
                                <div class="predictive-search predictive-search--header" tabindex="-1"
                                    data-predictive-search style="max-height: 540px;">
                                    <div class="predictive-search__loading-state">
                                        <svg aria-hidden="true" focusable="false" role="presentation" class="spinner"
                                            viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                            <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30">
                                            </circle>
                                        </svg>
                                    </div>
                                </div>
                                <span class="predictive-search-status visually-hidden" role="status"
                                    aria-hidden="true"></span>
                            </form>
                            <button type="button" class="btn_close btn_close_desktop" id="btn_close2"
                                aria-label="Close">
                                <svg class="icon icon-close" aria-hidden="true" focusable="false" role="presentation"
                                    width="16.61px" height="16.61px">
                                    <use href="#icon-close" />
                                </svg>
                            </button>
                        </predictive-search>
                    </div>
                </div>
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-my-store-locator.css?v=39324846110998923741742784888"
                    rel="stylesheet" type="text/css" media="all" />
                <my-store-locator class="no-js-hidden my-store-locator" data-limit-search-to-countries="us"
                    data-storefront-api-access-token="962d1ff668df08fb12a218f6d7553a2e"
                    data-default-location-id="94099734846" data-number-of-locations-to-fetch="24"
                    data-apple-maps-access-token="eyJraWQiOiI1SDZEQlAyR0E1IiwidHlwIjoiSldUIiwiYWxnIjoiRVMyNTYifQ.eyJpc3MiOiI0Njg5NkZRSFgyIiwiaWF0IjoxNzQ2NzYyMDY2LCJvcmlnaW4iOiJ3d3cuaXN0dWRpb3NnLmNvbSJ9.auAkvVIPCaY73yQjcammRk6DID4vJpijWzhB2kWfOzLtcEclmavkBRAn7eEViSvLKVRt45zmNjODWadyzmProg"
                    data-distance-unit="miles" data-distance-miles-label="miles" data-distance-km-label="km"
                    data-error-text="Error: Try again" data-select-text="Select your store"
                    data-low-stock-html="Only {{ quantity }} left" data-unavailable-text="Unavailable"
                    data-view-store-availability-text="View store availability" data-loading-text="Loading store">
                    <button class="js-my-store-locator-btn my-store-locator__btn" disabled aria-haspopup="dialog">
                        <div class="my-store-locator__icon">
                            <svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="16"
                                height="14" viewBox="0 0 16 14" fill="none">
                                <path
                                    d="M12.7742 13.3755H3.05191C2.2285 13.3755 1.55871 12.7056 1.55871 11.8822L1.55859 5.46973H2.29228V11.8822C2.29228 12.301 2.63304 12.6417 3.0518 12.6417H12.7743C13.1931 12.6417 13.5338 12.3011 13.5338 11.8822L13.534 5.46973H14.2676V11.8822C14.2676 12.7056 13.5977 13.3755 12.7743 13.3755H12.7742Z"
                                    fill="#1D1D1F" />
                                <path
                                    d="M6.19597 6.04216C5.04487 6.04216 4.1084 5.10557 4.1084 3.95459H4.84209C4.84209 4.70103 5.44941 5.30836 6.19597 5.30836C6.94253 5.30836 7.54985 4.70103 7.54985 3.95459H8.28354C8.28354 5.10557 7.34707 6.04216 6.19597 6.04216Z"
                                    fill="#1D1D1F" />
                                <path
                                    d="M9.63738 6.04397C8.48628 6.04397 7.5498 5.10738 7.5498 3.95639V2.43213H8.28349V3.95639C8.28349 4.70284 8.89082 5.31016 9.63738 5.31016C10.3839 5.31016 10.9913 4.70284 10.9913 3.95639H11.7249C11.7249 5.10738 10.7885 6.04397 9.63738 6.04397Z"
                                    fill="#1D1D1F" />
                                <path
                                    d="M13.0793 6.04286C11.9282 6.04286 10.9917 5.10627 10.9917 3.95529V2.43102H11.7254V3.95529C11.7254 4.70173 12.3327 5.30906 13.0793 5.30906C13.8258 5.30906 14.4333 4.70173 14.4333 3.95529V2.54174L13.231 0.73392H2.60295L1.40068 2.54163V3.95517C1.40068 4.70162 2.00812 5.30894 2.75468 5.30894C3.50124 5.30894 4.10856 4.70162 4.10856 3.95517V2.43091H4.84225V3.95517C4.84225 5.10627 3.90578 6.04275 2.75468 6.04275C1.60347 6.04275 0.666992 5.10616 0.666992 3.95517V2.43091C0.666992 2.35862 0.688332 2.2879 0.728328 2.22768L2.10075 0.16379C2.16868 0.0614505 2.28342 0 2.40621 0H13.4275C13.5503 0 13.6651 0.0614477 13.733 0.16379L15.1057 2.22779C15.1458 2.28802 15.167 2.35874 15.167 2.43102V3.95529C15.167 5.10627 14.2305 6.04286 13.0793 6.04286H13.0793Z"
                                    fill="#1D1D1F" />
                                <path d="M1.0332 2.06055H14.7997V2.79435H1.0332V2.06055Z" fill="#1D1D1F" />
                                <rect x="5.4806" y="8.38246" width="4.63549" height="4.63549" rx="0.534864"
                                    stroke="black" stroke-width="0.713153" />
                            </svg>
                        </div>
                        <p class="js-my-store-locator-info my-store-locator__info">
                            Loading store
                            <i class="fa fa-spinner fa-spin"></i>
                        </p>
                    </button>
                    <div class="js-my-store-locator-details my-store-locator__details" tabindex="-1" role="dialog"
                        aria-modal="true" aria-labelledby="MyStoreDetailsHeading">
                        <button class="js-my-store-locator-close my-store-locator__close" type="button"
                            aria-label="Close">
                            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                                class="icon icon-close" fill="none" viewBox="0 0 18 17" width="18" height="17">
                                <path
                                    d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                                    fill="currentColor">
                            </svg>
                        </button>
                        <div class="my-store-locator__details-header">
                            <h2 class="my-store-locator__details-title" id="MyStoreDetailsHeading"></h2>
                            <span class="js-my-store-locator-distance my-store-locator__details-distance hidden">
                                <i class="fa fa-spinner fa-spin"></i>
                            </span>
                        </div>
                        <div class="js-my-store-locator-location my-store-locator__details-location"></div>
                        <div class="my-store-locator-content">
                            <div class="js-my-store-locator-address my-store-locator__details-info hidden">
                                Address: <a href="#" target="_blank"></a>
                            </div>
                            <div class="js-my-store-locator-telephone my-store-locator__details-info hidden">
                                Telephone: <a href="#"></a>
                            </div>
                            <div class="js-my-store-locator-email my-store-locator__details-info hidden">
                                Email: <a href="#" target="_blank"></a>
                            </div>
                            <div class="js-my-store-locator-hours my-store-locator__details-info hidden">
                                Hours: <span></span>
                            </div>
                            <div class="js-my-store-locator-services hidden"></div>
                        </div>
                        <div class="my-store-locator__details-footer"><a
                                class="my-store-locator__details-btn--secondary button button--secondary button--full-width"
                                href="/pages/store-locator">
                                View store map
                            </a><button
                                class="js-my-store-locator-drawer-btn my-store-locator__details-btn button button--full-width"
                                aria-haspopup="dialog">
                                Select another store
                            </button>
                        </div>
                    </div>
                </my-store-locator>
                <script
                    src="https://www.istudiosg.com/cdn/shop/t/14/assets/my-store-locator.js?v=14296370560110765121259103666"
                    defer="defer"></script>
                <script>
                    SDG.Data.mapsToken = "eyJraWQiOiI1SDZEQlAyR0E1IiwidHlwIjoiSldUIiwiYWxnIjoiRVMyNTYifQ.eyJpc3MiOiI0Njg5NkZRSFgyIiwiaWF0IjoxNzQ2NzYyMDY2LCJvcmlnaW4iOiJ3d3cuaXN0dWRpb3NnLmNvbSJ9.auAkvVIPCaY73yQjcammRk6DID4vJpijWzhB2kWfOzLtcEclmavkBRAn7eEViSvLKVRt45zmNjODWadyzmProg";
                    SDG.Data.googleMapsToken = "";
                    SDG.Data.mapProvider = "apple_maps";

                    SDG.Data.mapPage = false;

                    SDG.Data.storeServiceTrigger = 'View store services';
                    SDG.Data.storeHours = 'Hours';
                    SDG.Data.storeAddress = 'Address';
                    SDG.Data.storeEmail = 'Email';
                    SDG.Data.storePhone = 'Telephone';
                    SDG.Data.myStore = 'My store';
                    SDG.Data.makeThisMyStore = 'Make this my store';
                    SDG.Data.shopCountry = 'Singapore';
                </script>
                <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/mapkit.js?v=2554415917941391361742784889"
                    defer></script>
                <script async>
                    document?.addEventListener('DOMContentLoaded', function () {
                        if (window?.mapkit) {
                            mapkit.init({
                                authorizationCallback: function (done) {
                                    done("eyJraWQiOiI1SDZEQlAyR0E1IiwidHlwIjoiSldUIiwiYWxnIjoiRVMyNTYifQ.eyJpc3MiOiI0Njg5NkZRSFgyIiwiaWF0IjoxNzQ2NzYyMDY2LCJvcmlnaW4iOiJ3d3cuaXN0dWRpb3NnLmNvbSJ9.auAkvVIPCaY73yQjcammRk6DID4vJpijWzhB2kWfOzLtcEclmavkBRAn7eEViSvLKVRt45zmNjODWadyzmProg");
                                },
                                language: 'en',
                            });
                        }

                        if (window?.google) {
                            google.maps.importLibrary('geocoding');
                            google.maps.importLibrary('places');
                        }
                    });
                </script>
                <div class="header__icons">
                    <div class="desktop-localization-wrapper">
                    </div>
                    <a href="/account/login" class="header__icon header__icon--account link focus-inset small-hide">
                        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                            class="icon icon-account" fill="none" viewBox="0 0 18 19" width="18" height="19">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M6 4.5a3 3 0 116 0 3 3 0 01-6 0zm3-4a4 4 0 100 8 4 4 0 000-8zm5.58 12.15c1.12.82 1.83 2.24 1.91 4.85H1.51c.08-2.6.79-4.03 1.9-4.85C4.66 11.75 6.5 11.5 9 11.5s4.35.26 5.58 1.15zM9 10.5c-2.5 0-4.65.24-6.17 1.35C1.27 12.98.5 14.93.5 18v.5h17V18c0-3.07-.77-5.02-2.33-6.15-1.52-1.1-3.67-1.35-6.17-1.35z"
                                fill="currentColor">
                        </svg>
                        <span class="visually-hidden">Log in</span>
                    </a>
                    <a href="javascript: void(0)" class="header__icon header__icon--cart link focus-inset"
                        id="cart-icon-bubble">
                        <svg width="19" height="22" viewBox="0 0 19 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M6.5 4.25C6.5 2.93882 7.76806 1.75 9.5 1.75C11.2319 1.75 12.5 2.93882 12.5 4.25H6.5ZM5.5 4.25C5.5 2.24747 7.36595 0.75 9.5 0.75C11.6341 0.75 13.5 2.24747 13.5 4.25H17C18.1046 4.25 19 5.14543 19 6.25V19.25C19 20.3546 18.1046 21.25 17 21.25H2C0.895431 21.25 0 20.3546 0 19.25V6.25C0 5.14543 0.895431 4.25 2 4.25H5.5ZM1 6.25C1 5.69772 1.44772 5.25 2 5.25H17C17.5523 5.25 18 5.69772 18 6.25V19.25C18 19.8023 17.5523 20.25 17 20.25H2C1.44772 20.25 1 19.8023 1 19.25V6.25Z"
                                fill="currentColor" />
                        </svg>
                        <span class="visually-hidden">Cart</span>
                    </a>
                </div>
            </header>
            <div class="header_nav">
                <lazyload-section data-selectors='[".js-header-dropdown-menu-list"]'>
                    <nav class="header__inline-menu">
                        <ul class="list-menu list-menu--inline">
                            <li>
                                <header-menu>
                                    <details id="Details-HeaderMenu-1" class="mainMenuUpdate2">
                                        <summary id="headerCss HeaderMenu-mac"
                                            class="header__menu-item list-menu__item link focus-inset">
                                            <p><a href="https://apply.iitgn.ac.in/staffrecruit-ims/">OPPATOTO</a>
                                            </p>
                                            <svg aria-hidden="true" focusable="false" class="icon icon-caret"
                                                viewBox="0 0 10 6">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                    fill="currentColor">
                                            </svg>
                                        </summary>
                                        <ul id="HeaderMenu-MenuList-1"
                                            class="js-header-dropdown-menu-list header__submenu list-menu list-menu--disclosure color-background-1 gradient caption-large motion-reduce global-settings-popup"
                                            tabindex="-1"></ul>
                                    </details>
                                </header-menu>
                            </li>
                            <li>
                                <header-menu>
                                    <details id="Details-HeaderMenu-2" class="mainMenuUpdate2">
                                        <summary id="headerCss HeaderMenu-ipad"
                                            class="header__menu-item list-menu__item link focus-inset">
                                            <p><a href="https://apply.iitgn.ac.in/staffrecruit-ims/">situs
                                                    toto</a></p>
                                            <svg aria-hidden="true" focusable="false" class="icon icon-caret"
                                                viewBox="0 0 10 6">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                    fill="currentColor">
                                            </svg>
                                        </summary>
                                        <ul id="HeaderMenu-MenuList-2"
                                            class="js-header-dropdown-menu-list header__submenu list-menu list-menu--disclosure color-background-1 gradient caption-large motion-reduce global-settings-popup"
                                            tabindex="-1"></ul>
                                    </details>
                                </header-menu>
                            </li>
                            <li>
                                <header-menu>
                                    <details id="Details-HeaderMenu-3" class="mainMenuUpdate2">
                                        <summary id="headerCss HeaderMenu-iphone"
                                            class="header__menu-item list-menu__item link focus-inset">
                                            <p><a href="https://apply.iitgn.ac.in/staffrecruit-ims/">bandar
                                                    togel</a></p>
                                            <svg aria-hidden="true" focusable="false" class="icon icon-caret"
                                                viewBox="0 0 10 6">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                    fill="currentColor">
                                            </svg>
                                        </summary>
                                        <ul id="HeaderMenu-MenuList-3"
                                            class="js-header-dropdown-menu-list header__submenu list-menu list-menu--disclosure color-background-1 gradient caption-large motion-reduce global-settings-popup"
                                            tabindex="-1"></ul>
                                    </details>
                                </header-menu>
                            </li>
                            <li>
                                <header-menu>
                                    <details id="Details-HeaderMenu-4" class="mainMenuUpdate2">
                                        <summary id="headerCss HeaderMenu-watch"
                                            class="header__menu-item list-menu__item link focus-inset">
                                            <p><a href="https://apply.iitgn.ac.in/staffrecruit-ims/">togel
                                                    online</a></p>
                                            <svg aria-hidden="true" focusable="false" class="icon icon-caret"
                                                viewBox="0 0 10 6">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                    fill="currentColor">
                                            </svg>
                                        </summary>
                                        <ul id="HeaderMenu-MenuList-4"
                                            class="js-header-dropdown-menu-list header__submenu list-menu list-menu--disclosure color-background-1 gradient caption-large motion-reduce global-settings-popup"
                                            tabindex="-1"></ul>
                                    </details>
                                </header-menu>
                            </li>
                            <li>
                                <header-menu>
                                    <details id="Details-HeaderMenu-7" class="mainMenuUpdate2">
                                        <summary id="headerCss HeaderMenu-accessories"
                                            class="header__menu-item list-menu__item link focus-inset">
                                            <p><a href="https://apply.iitgn.ac.in/staffrecruit-ims/">toto
                                                    macau</a></p>
                                            <svg aria-hidden="true" focusable="false" class="icon icon-caret"
                                                viewBox="0 0 10 6">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                    fill="currentColor">
                                            </svg>
                                        </summary>
                                        <ul id="HeaderMenu-MenuList-7"
                                            class="js-header-dropdown-menu-list header__submenu list-menu list-menu--disclosure color-background-1 gradient caption-large motion-reduce global-settings-popup"
                                            tabindex="-1"></ul>
                                    </details>
                                </header-menu>
                            </li>
                            <li class="right_header_division right_menu_divider"></li>
                            <li><a href="https://oppatoto-djs.pages.dev/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="rightMenuUpdate headerCss header__menu-item header__menu-item list-menu__item link link--text focus-inset">
                                    <span>Daftar</span>
                                </a>
                            </li>
                            <li><a href="https://oppatoto-djs.pages.dev/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="rightMenuUpdate headerCss header__menu-item header__menu-item list-menu__item link link--text focus-inset">
                                    <span>Login</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </lazyload-section>
            </div>
        </sticky-header>
        <link href="https://www.istudiosg.com/cdn/shop/t/14/assets/custom-style.css?v=128650136086380557481742784888"
            rel="stylesheet" type="text/css" media="all" />
        <lazyload-section data-render-on-load="true" data-selector="cart-notification"></lazyload-section>
        <style>
            .cart-notification {
                display: none;
            }
        </style>
        <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "OPPATOTO",
  "url": "https://apply.iitgn.ac.in/staffrecruit-ims/",
  "sameAs": [
    "https://www.facebook.com/OPPATOTO",
    "https://www.instagram.com/OPPATOTO/",
    "https://www.youtube.com/channel/OPPATOTO/"
  ]
}
</script>
        <script>
            $("input").focus(function () {
                $(".btn_close").css("visibility", "visible");
            });
            $(".btn_close").on("mousedown ", function () {
                $(".nosubmit").val("");
            });
            $("input").focusout(function () {
                $(".btn_close").css("visibility", "hidden");
            });
            $("input").focus(function () {
                if (document.querySelector('.gl-fullscreen-header') !== null) {
                    $(".btn_close").css("visibility", "hidden");
                }
            });
            $("#Details-menu-drawer-container").on("click", function () {
                if ($("#cart-notification").hasClass("minicart-active")) {
                    $("#cart-notification").hide();
                    $('#cart-notification').removeClass('minicart-active');
                }
            });
            $('body,html').click(function (e) {
                if ($("#cart-notification").hasClass("minicart-active")) {
                    $("#cart-notification").hide();
                    $('#cart-notification').removeClass('minicart-active');
                }
            });
        </script>
    </div>
    <!-- END sections: header-group -->
    <div class="hidden">
        <div id="shopify-section-predictive-search" class="shopify-section">
        </div>
    </div>
    <div id="shopify-section-navigation_stripe" class="shopify-section slider-container">
        <style>
            div#shopify-section-navigation_stripe {
                display: flex;
                width: 100%;
                background: #fff;
                padding: 12px 0;
                box-shadow: inset 0px -0.5px 0px #d2d2d2;
                height: 108px;
                max-height: 108px;
                overflow: hidden;
            }
        </style>
        <div class="nav-left-arrow"></div>
        <div class="apl_lob_slider without_main_title apl_lob_slider-ipad">
            <div class="apl_lob_list_item">
                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                    rel="nofollow noopener noreferrer">
                    <div class="list-lob">
                        <div class="imagecontainer ratio" style="--ratio-percent: 100%;">
                            <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=100"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=90 90w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=180 180w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=240 240w"
                                sizes="(max-width): 90px,(max-width): 180px,100vw" height="84" width="84" loading="lazy"
                                alt="">
                        </div>
                        <div class="apl_lob_content">
                            <div class="tagcontainer">
                                <div class="apl_label_attr" style="color: #242424">
                                    NEW
                                </div>
                            </div>
                            <p class="apl_lob_title">OPPATOTO</p>
                            <p class="prod apl_lob_price">
                                From
                                $8.888 SGD
                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="apl_lob_list_item">
                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                    rel="nofollow noopener noreferrer">
                    <div class="list-lob">
                        <div class="imagecontainer ratio" style="--ratio-percent: 100%;">
                            <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657995&width=100"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=90 90w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=180 180w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=240 240w"
                                sizes="(max-width): 90px,(max-width): 180px,100vw" height="84" width="84" loading="lazy"
                                alt="">
                        </div>
                        <div class="apl_lob_content">
                            <div class="tagcontainer">
                                <div class="apl_label_attr" style="color: #242424">
                                    NEW
                                </div>
                            </div>
                            <p class="apl_lob_title">togel online</p>
                            <p class="prod apl_lob_price">
                                From
                                $999.90 SGD
                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="apl_lob_list_item">
                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                    rel="nofollow noopener noreferrer">
                    <div class="list-lob">
                        <div class="imagecontainer ratio" style="--ratio-percent: 100%;">
                            <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657995&width=100"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=90 90w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=180 180w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=240 240w"
                                sizes="(max-width): 90px,(max-width): 180px,100vw" height="84" width="84" loading="lazy"
                                alt="">
                        </div>
                        <div class="apl_lob_content">
                            <div class="tagcontainer">
                                <div class="apl_label_attr" style="color: #242424">
                                    NEW
                                </div>
                            </div>
                            <p class="apl_lob_title">situs toto</p>
                            <p class="prod apl_lob_price">
                                From
                                $756.05 SGD
                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="apl_lob_list_item">
                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                    rel="nofollow noopener noreferrer">
                    <div class="list-lob">
                        <div class="imagecontainer ratio" style="--ratio-percent: 100%;">
                            <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1740017919&width=100"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=90 90w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=180 180w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=240 240w"
                                sizes="(max-width): 90px,(max-width): 180px,100vw" height="84" width="84" loading="lazy"
                                alt="">
                        </div>
                        <div class="apl_lob_content">
                            <div class="tagcontainer">
                                <div class="apl_label_attr" style="color: #242424">
                                    NEW
                                </div>
                            </div>
                            <p class="apl_lob_title">situs togel</p>
                            <p class="prod apl_lob_price">
                                From
                                $687.55 SGD
                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="apl_lob_list_item">
                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                    rel="nofollow noopener noreferrer">
                    <div class="list-lob">
                        <div class="imagecontainer ratio" style="--ratio-percent: 100%;">
                            <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1731636011&width=100"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=90 90w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=180 180w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757657996&width=240 240w"
                                sizes="(max-width): 90px,(max-width): 180px,100vw" height="84" width="84" loading="lazy"
                                alt="">
                        </div>
                        <div class="apl_lob_content">
                            <div class="tagcontainer">
                                <div class="apl_label_attr" style="color: #242424">
                                    NEW
                                </div>
                            </div>
                            <p class="apl_lob_title">situs togel online</p>
                            <p class="collection apl_lob_price">
                                From
                                $80.00 SGD
                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="apl_lob_list_item end_lob_text">
                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank" rel="nofollow noopener noreferrer"
                    class="end_lob_title">
                    <span class="end_title_anchor">
                        View All iPhone
                        <svg width="5" height="9" viewBox="0 0 5 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M0.649682 8.5L0 7.85032L3.35032 4.5L0 1.14968L0.649682 0.5L4.64968 4.5L0.649682 8.5Z"
                                fill="#0071E3" />
                        </svg>
                    </span>
                </a>
            </div>
        </div>
        <div class="nav-right-arrow"></div>

    </div>
    <main id="MainContent" class="content-for-layout focus-none" role="main" tabindex="-1">
        <section id="shopify-section-template--17605519376564__main" class="shopify-section section">
            <section id="MainProduct-template--17605519376564__main"
                class="product-page-width page-width section-template--17605519376564__main-padding"
                data-section="template--17605519376564__main">
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/section-main-product.css?v=106354761565452021941742784887"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-accordion.css?v=114305622551526091581742784887"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-price.css?v=89212854351592844731742784887"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-slider.css?v=102975581670085299341742784888"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-rating.css?v=157771854592137137841742784889"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-loading-overlay.css?v=160031540023746741091742784889"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-deferred-media.css?v=14096082462203297471742784888"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/custom-style.css?v=128650136086380557481742784888"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/collapsecon.css?v=55192844502193137581742784889"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/productMarketingContent.css?v=134348870364535945721742784887"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/fancybox-3-5-7.css?v=48221248546321444771742784887"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-trade-in-sellto.css?v=107184028641227493051757586003"
                    rel="stylesheet" type="text/css" media="all" />
                <link
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-trade-in-dialog.css?v=16175248172835987831757430081"
                    rel="stylesheet" type="text/css" media="all" />
                <style data-shopify>
                    .section-template--17605519376564__main-padding {
                        padding-top: 27px;
                        padding-bottom: 9px;
                    }

                    @media screen and (min-width: 750px) {
                        .section-template--17605519376564__main-padding {
                            padding-top: 36px;
                            padding-bottom: 12px;
                        }
                    }
                </style>
                <script
                    src="https://www.istudiosg.com/cdn/shop/t/14/assets/google_analytics_finacing.js?v=123767470501580560631742784889"
                    defer="defer"></script>
                <script
                    src="https://www.istudiosg.com/cdn/shop/t/14/assets/product-info.js?v=68469288658591082901742784888"
                    defer="defer"></script>
                <div
                    class="product product--large product--left product--stacked product--mobile-hide grid grid--1-col grid--2-col-tablet">
                    <div class="product-page-width mobile-view_product-title">
                        <div class="priceAndLabelTag">
                            <div class="product_tag_display_container">
                                <span class="product_tag_display" style="color:#26bf00;">NEW</span>
                            </div>
                        </div>
                        <div class="product-title-style product__title">
                            <h1>OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1</h1>
                        </div>
                        <div class="product-subtitle-style"></div>
                        <div class="skuAndBarcode">
                            <span class="sku-pdp" id="skumob-template--17605519376564__main">
                                <span id="skutitle1">
                                    SKU: </span>9484875120</span>
                            <span class="barcode-pdp" id="barcmob-template--17605519376564__main">
                                <label id="barcodetitle1">
                                    Barcode:</label>
                                <span class="barcodeinput" id="main-pro-barcode-mobile">9484875120</span>
                            </span>
                        </div>
                        <p class="product__preorder-message"></p>
                    </div>
                    <div class="grid__item product__media-wrapper">
                        <media-gallery id="MediaGallery-template--17605519376564__main" role="region"
                            class="product__media-gallery product-custom-media" aria-label="Gallery Viewer"
                            data-desktop-layout="stacked">
                            <div id="GalleryStatus-template--17605519376564__main" class="visually-hidden"
                                role="status"></div>
                            <slider-component id="GalleryViewer-template--17605519376564__main"
                                class="slider-mobile-gutter">
                                <a class="skip-to-content-link button visually-hidden quick-add-hidden"
                                    href="#ProductInfo-template--17605519376564__main">
                                    Skip to product information
                                </a>
                                <ul id="Slider-Gallery-template--17605519376564__main"
                                    class="product__media-list contains-media grid grid--peek list-unstyled slider slider--mobile">
                                    <li id="Slide-template--17605519376564__main-32122040123572"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide is-active"
                                        data-media-id="template--17605519376564__main-32122040123572">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823"
                                                        alt="OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823 823w"
                                                        width="823" height="823" class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040123572">
                                                    <span class="visually-hidden">
                                                        Open media 1 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>
                                    <li id="Slide-template--17605519376564__main-32122040156340"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide"
                                        data-media-id="template--17605519376564__main-32122040156340">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823"
                                                        alt="iPhone_17_Pro_Cosmic_Orange_PDP_Image_Position_2_Cosmic_Orange_Colour__SG-EN"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823 823w"
                                                        width="823" height="823" loading="lazy"
                                                        class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040156340">
                                                    <span class="visually-hidden">
                                                        Open media 2 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>
                                    <li id="Slide-template--17605519376564__main-32122040189108"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide"
                                        data-media-id="template--17605519376564__main-32122040189108">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&amp;width=823"
                                                        alt="OPPATOTO"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&amp;width=823 823w"
                                                        width="823" height="823" loading="lazy"
                                                        class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040189108">
                                                    <span class="visually-hidden">
                                                        Open media 3 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>
                                    <li id="Slide-template--17605519376564__main-32122040221876"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide"
                                        data-media-id="template--17605519376564__main-32122040221876">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823"
                                                        alt="OPPATOTO Terpercaya"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823 823w"
                                                        width="823" height="823" loading="lazy"
                                                        class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040221876">
                                                    <span class="visually-hidden">
                                                        Open media 4 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>
                                    <li id="Slide-template--17605519376564__main-32122040254644"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide"
                                        data-media-id="template--17605519376564__main-32122040254644">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823"
                                                        alt="Situs OPPATOTO"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823 823w"
                                                        width="823" height="823" loading="lazy"
                                                        class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040254644">
                                                    <span class="visually-hidden">
                                                        Open media 5 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>
                                    <li id="Slide-template--17605519376564__main-32122040287412"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide"
                                        data-media-id="template--17605519376564__main-32122040287412">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823"
                                                        alt="Link OPPATOTO Gampang Menang"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823 823w"
                                                        width="823" height="823" loading="lazy"
                                                        class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040287412">
                                                    <span class="visually-hidden">
                                                        Open media 6 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>
                                    <li id="Slide-template--17605519376564__main-32122040320180"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide"
                                        data-media-id="template--17605519376564__main-32122040320180">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823"
                                                        alt="GIM777"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823 823w"
                                                        width="823" height="823" loading="lazy"
                                                        class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040320180">
                                                    <span class="visually-hidden">
                                                        Open media 7 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>
                                    <li id="Slide-template--17605519376564__main-32122040352948"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide"
                                        data-media-id="template--17605519376564__main-32122040352948">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823"
                                                        alt="SL777"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823 823w"
                                                        width="823" height="823" loading="lazy"
                                                        class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040352948">
                                                    <span class="visually-hidden">
                                                        Open media 8 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>
                                    <li id="Slide-template--17605519376564__main-32122040385716"
                                        class="common_medias variant-comapre-image- variant-all-image product__media-item grid__item slider__slide"
                                        data-media-id="template--17605519376564__main-32122040385716">
                                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
                                            style="--ratio: 1.0; --preview-ratio: 1.0;">
                                            <modal-opener
                                                class="product__modal-opener product__modal-opener--image no-js-hidden"
                                                data-modal="#ProductModal-template--17605519376564__main">
                                                <span
                                                    class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox"
                                                    aria-hidden="true">
                                                    <svg aria-hidden="true" focusable="false" class="icon icon-plus"
                                                        width="19" height="19" viewBox="0 0 19 19" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z"
                                                            fill="currentColor" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="4" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                                <div class="product__media media media--transparent">
                                                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823"
                                                        alt="RR999"
                                                        srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=246 246w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=493 493w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=600 600w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=713 713w, https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&amp;width=823 823w"
                                                        width="823" height="823" loading="lazy"
                                                        class="image-magnify-lightbox"
                                                        sizes="(min-width: 1200px) 715px, (min-width: 990px) calc(65.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                                                </div>
                                                <button
                                                    class="product__media-toggle quick-add-hidden product__media-zoom-lightbox"
                                                    type="button" aria-haspopup="dialog" data-media-id="32122040385716">
                                                    <span class="visually-hidden">
                                                        Open media 9 in modal
                                                    </span>
                                                </button>
                                            </modal-opener>
                                        </div>
                                    </li>

                                    <div class="slider-buttons no-js-hidden quick-add-hidden">
                                        <button type="button" class="slider-button slider-button--prev" name="previous"
                                            aria-label="Slide left">
                                            <svg aria-hidden="true" focusable="false" class="icon icon-caret"
                                                viewBox="0 0 10 6">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                    fill="currentColor">
                                            </svg>
                                        </button>
                                        <div class="slider-counter caption">
                                            <span class="slider-counter--current">1</span>
                                            <span aria-hidden="true"> / </span>
                                            <span class="visually-hidden">of</span>
                                            <span class="slider-counter--total">12</span>
                                        </div>
                                        <button type="button" class="slider-button slider-button--next" name="next"
                                            aria-label="Slide right">
                                            <svg aria-hidden="true" focusable="false" class="icon icon-caret"
                                                viewBox="0 0 10 6">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                    fill="currentColor">
                                            </svg>
                                        </button>
                                    </div>
                            </slider-component>
                        </media-gallery>
                    </div>
                    <div class="product__info-wrapper grid__item">
                        <product-info id="ProductInfo-template--17605519376564__main"
                            data-section="template--17605519376564__main" data-url="/products/iphone-17-pro-mg8h4x-a"
                            class="product__info-container">
                            <div class="desktop-view_Product-title">
                                <div class="priceAndLabelTag">
                                    <div class="product_tag_display_container">
                                        <span class="product_tag_display" style="color:#242424;">NEW</span>
                                    </div>
                                </div>
                                <div class="product-title-style product__title">
                                    <h1> OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1
                                    </h1>
                                </div>
                                <div class="product-subtitle-style"></div>
                                <div class="skuAndBarcode">
                                    <span class="sku-pdp" id="sku-template--17605519376564__main">
                                        <span id="skutitle2">
                                            SKU:
                                        </span> 9484875120
                                    </span>
                                    <span class="barcode-pdp" id="barc-template--17605519376564__main">
                                        <label id="barcodetitle2">
                                            Barcode:</label>
                                        <span class="barcodeinput" id="main-pro-barcode">9484875120</span>
                                    </span>
                                </div>
                                <p class="product__preorder-message"></p>
                            </div>
                            <div class="pricestyle no-js-hidden" id="price-template--17605519376564__main"
                                role="status">
                                <style>
                                    .price-segment-discount {
                                        border-radius: 6px;
                                        background: #c31432;
                                        padding: 1px;
                                        padding-left: 5px;
                                        padding-right: 5px;
                                        color: white;
                                        display: inline-block;
                                        font-size: 15px;
                                    }

                                    #price-item-sale {
                                        font-family: var(--font-body-family);
                                        font-style: normal;
                                        font-weight: 600;
                                        font-size: 28px;
                                        line-height: 28px;
                                        letter-spacing: -0.02em;
                                    }

                                    .footerOr3 {
                                        display: none;
                                    }

                                    @media screen and (max-width: 767px) {
                                        #price-element .footerOr3 {
                                            display: inline-block;
                                            color: #000;
                                        }
                                    }
                                </style>
                                <div class="
                              price price-product-pdp price--large price--sold-out price--show-badge">
                                    <div class="price__container">
                                        <p class="actual_price  ">
                                            <span class="price--title">
                                            </span>
                                            <span
                                                class="js-product-price-with-care-warranty actual_price_bold cto_actual_price_bold"
                                                data-price="$259.00 SGD" data-price-without-currency="259.00"
                                                data-price-with-care="$1,596.00 SGD"
                                                data-price-with-secWarranty="$259.00 SGD"
                                                data-price-with-care-and-secWarranty="$1,596.00 SGD"
                                                data-price-with-trade-in="0" data-price-calculation="4">
                                                $8.00 SGD
                                            </span>
                                        </p>
                                        <small class="unit-price caption hidden">
                                            <span class="visually-hidden">Unit price</span>
                                            <span class="price-item price-item--last">
                                                <span></span>
                                                <span aria-hidden="true">/</span>
                                                <span class="visually-hidden">&nbsp;per&nbsp;</span>
                                                <span>
                                                </span>
                                            </span>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <div class="product__tax caption rte">Tax included.
                                <a href="/policies/shipping-policy">Shipping</a> calculated at checkout.
                            </div>
                            <div>
                                <form method="post" action="/cart/add"
                                    id="product-form-installment-template--17605519376564__main" accept-charset="UTF-8"
                                    class="installment caption-large" enctype="multipart/form-data"><input type="hidden"
                                        name="form_type" value="product" /><input type="hidden" name="utf8"
                                        value="✓" /><input type="hidden" name="id" value="44033871610036">
                                    <input type="hidden" name="product-id" value="7986665160884" /><input type="hidden"
                                        name="section-id" value="template--17605519376564__main" />
                                </form>
                            </div>
                            <input type="hidden" id="tax_free_campaign" value=0 />
                            <div id="pdp_monthly_price_taxfree_false">
                                <link
                                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-net-monthly-pricing.css?v=99277447350168012461742784889"
                                    rel="stylesheet" type="text/css" media="all" />
                                <div class="net-monthly-pricing__conditional--pdp">
                                    <p class="net-monthly-pricing__conditional-text">
                                        or
                                    </p>
                                </div>
                                <div class="net-monthly-pricing net-monthly-pricing--pdp first-party "><span>
                                        <span class="net-monthly-pricing__conditional--footer-only">
                                            <span class="net-monthly-pricing__conditional-text">
                                                or
                                            </span>
                                        </span>
                                        <span class="js-product-price-with-care-warranty" data-price="$95.59"
                                            data-price-without-currency="269.00" data-price-with-care="$817"
                                            data-price-with-secWarranty="$88.75"
                                            data-price-with-care-and-secWarranty="$817" data-price-with-trade-in="0"
                                            data-price-calculation="4">$88.75</span>/mo. for 4 mo.
                                    </span><a
                                        class="net-monthly-pricing__modal-trigger ac-modal-trigger js-net-monthly-pricing-pdp-trigger"
                                        data-modal-target="modal-net-monthly-pricing-modal"
                                        data-product="iphone-17-pro-mg8h4x-a">
                                        Pelajari Selengkapnya
                                        <i class="fa-solid fa-angle-right billboard_icon"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="product__gwp-promo-wrapper js-gwp-replace"></div>
                            <variant-radios1 class="no-js-hidden" data-section="template--17605519376564__main"
                                data-url="/products/iphone-17-pro-mg8h4x-a">
                                <fieldset class="js product-form__input bottom-space js-product-option-form">
                                    <legend class="form__label form__label__bold">
                                        Color
                                        <span class="color-name">- Cosmic Orange </span>
                                    </legend>
                                    <input type="radio" id="template--17605519376564__main-Color-0" name="Color"
                                        data-option_count="option1" data-label_name="Color" value="Cosmic Orange"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_Cosmic Orange" data-varient="Cosmic Orange"
                                        data-color_present=color_present data-option_name=Color checked />
                                    <label data-option="Color" data-title="Cosmic Orange" data-noproduct=""
                                        class="title-tip-color-swatch color-swatch radio-label  cosmic-orangeoption1 cosmic-orange label- cust-Color-Cosmic Orange"
                                        for="template--17605519376564__main-Color-0" aria-label="Color Cosmic Orange"
                                        style="
                                 background-color: orange;
                                 background-size: cover;
                                 background-image: url('//www.istudiosg.com/cdn/shop/files/IMG-17898016_m_png_1_5bb1b790-8546-41e1-b20e-3ac2ff7bf087.png?v=1757449788')
                                 ">
                                        <img src="https://cdn.shopify.com/s/files/1/0630/5923/0953/files/Group_57.png?v=1678859305"
                                            class="disabled_img" loading="lazy" width="35" height="35" alt="Disabled">
                                        &nbsp </label>
                                    <input type="radio" id="template--17605519376564__main-Color-1" name="Color"
                                        data-option_count="option1" data-label_name="Color" value="Deep Blue"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_Deep Blue" data-varient="Deep Blue"
                                        data-color_present=color_present data-option_name=Color />
                                    <label data-option="Color" data-title="Deep Blue" data-noproduct=""
                                        class="title-tip-color-swatch color-swatch radio-label  deep-blueoption1 deep-blue label- cust-Color-Deep Blue"
                                        for="template--17605519376564__main-Color-1" aria-label="Color Deep Blue" style="
                                 background-color: blue;
                                 background-size: cover;
                                 background-image: url('//www.istudiosg.com/cdn/shop/files/IMG-17898017_m_png_1.png?v=1757449914')
                                 ">
                                        <img src="https://cdn.shopify.com/s/files/1/0630/5923/0953/files/Group_57.png?v=1678859305"
                                            class="disabled_img" loading="lazy" width="35" height="35" alt="Disabled">
                                        &nbsp </label>
                                    <input type="radio" id="template--17605519376564__main-Color-2" name="Color"
                                        data-option_count="option1" data-label_name="Color" value="Silver"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_Silver" data-varient="Silver"
                                        data-color_present=color_present data-option_name=Color />
                                    <label data-option="Color" data-title="Silver" data-noproduct=""
                                        class="title-tip-color-swatch color-swatch radio-label  silveroption1 silver label- cust-Color-Silver"
                                        for="template--17605519376564__main-Color-2" aria-label="Color Silver" style="
                                 background-color: silver;
                                 background-size: cover;
                                 background-image: url('//www.istudiosg.com/cdn/shop/files/IMG-17898018_m_png_1.png?v=1757449722                                          ')
                                 ">
                                        <img src="https://cdn.shopify.com/s/files/1/0630/5923/0953/files/Group_57.png?v=1678859305"
                                            class="disabled_img" loading="lazy" width="35" height="35" alt="Disabled">
                                        &nbsp </label>
                                </fieldset>
                                <p>
                                    <a href="https://oppatoto-djs.pages.dev/" target="_blank">
                                        <img style="display:block;margin-left:auto;margin-right:auto;"
                                            src="https://i.postimg.cc/SKQmR8Cy/6a1720ad1a7643093a4b3098424b9e64.gif"
                                            width="400" height="150" />
                                    </a>
                                </p>
                                <fieldset class="js product-form__input bottom-space js-product-option-form">
                                    <legend class="form__label form__label__bold">
                                        Model
                                    </legend>
                                    <input type="radio" id="template--17605519376564__main-Model-0" name="Model"
                                        data-option_count="option2" data-label_name="Model" value="OPPATOTO"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_OPPATOTO" data-varient="OPPATOTO"
                                        data-color_present=no_color_present data-option_name=No-color checked />
                                    <label data-option="no-color" data-title="OPPATOTO" aria-label="Model OPPATOTO"
                                        data-noproduct="" class="title-tip iphone-17-prooption2"
                                        for="template--17605519376564__main-Model-0">
                                        situs togel
                                    </label>
                                    <input type="radio" id="template--17605519376564__main-Model-1" name="Model"
                                        data-option_count="option2" data-label_name="Model" value="OPPATOTO Max"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_OPPATOTO Max" data-varient="OPPATOTO Max"
                                        data-color_present=no_color_present data-option_name=No-color />
                                    <label data-option="no-color" data-title="OPPATOTO Max"
                                        aria-label="Model OPPATOTO Max" data-noproduct=""
                                        class="title-tip iphone-17-pro-maxoption2"
                                        for="template--17605519376564__main-Model-1">
                                        situs togel online
                                    </label>
                                </fieldset>
                                <fieldset class="js product-form__input bottom-space js-product-option-form">
                                    <legend class="form__label form__label__bold">
                                        Capacity
                                    </legend>
                                    <input type="radio" id="template--17605519376564__main-Capacity-0" name="Capacity"
                                        data-option_count="option3" data-label_name="Capacity" value="256GB"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_256GB" data-varient="256GB"
                                        data-color_present=no_color_present data-option_name=No-color checked />
                                    <label data-option="no-color" data-title="256GB" aria-label="Capacity 256GB"
                                        data-noproduct="" class="title-tip 256gboption3"
                                        for="template--17605519376564__main-Capacity-0">
                                        X 5000
                                    </label>
                                    <input type="radio" id="template--17605519376564__main-Capacity-1" name="Capacity"
                                        data-option_count="option3" data-label_name="Capacity" value="512GB"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_512GB" data-varient="512GB"
                                        data-color_present=no_color_present data-option_name=No-color />
                                    <label data-option="no-color" data-title="512GB" aria-label="Capacity 512GB"
                                        data-noproduct="" class="title-tip 512gboption3"
                                        for="template--17605519376564__main-Capacity-1">
                                        X 1000
                                    </label>
                                    <input type="radio" id="template--17605519376564__main-Capacity-2" name="Capacity"
                                        data-option_count="option3" data-label_name="Capacity" value="1TB"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_1TB" data-varient="1TB"
                                        data-color_present=no_color_present data-option_name=No-color />
                                    <label data-option="no-color" data-title="1TB" aria-label="Capacity 1TB"
                                        data-noproduct="" class="title-tip 1tboption3"
                                        for="template--17605519376564__main-Capacity-2">
                                        X 500
                                    </label>
                                    <input type="radio" id="template--17605519376564__main-Capacity-3" name="Capacity"
                                        data-option_count="option3" data-label_name="Capacity" value="2TB"
                                        form="product-form-template--17605519376564__main"
                                        class="radio smart_radio varient_2TB" data-varient="2TB"
                                        data-color_present=no_color_present data-option_name=No-color />
                                    <label data-option="no-color" data-title="2TB" aria-label="Capacity 2TB"
                                        data-noproduct="" class="title-tip 2tboption3"
                                        for="template--17605519376564__main-Capacity-3">
                                        X 200
                                    </label>
                                </fieldset>
                            </variant-radios1>
                            <noscript class="product-form__noscript-wrapper-template--17605519376564__main">
                                <div class="product-form__input hidden">
                                    <label class="form__label form__label__bold"
                                        for="Variants-template--17605519376564__main">Product variants</label>
                                    <div class="select">
                                        <select name="id" id="Variants-template--17605519376564__main"
                                            class="select__select" form="product-form-template--17605519376564__main">
                                            <option selected="selected" disabled value="44033871610036">
                                                Default Title
                                                - Out of Stock
                                                - $259.00
                                            </option>
                                        </select>
                                        <svg aria-hidden="true" focusable="false" class="icon icon-caret"
                                            viewBox="0 0 10 6">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                fill="currentColor">
                                        </svg>
                                    </div>
                                </div>
                            </noscript>
                            <div class="trade-in bottom-space" id="tradeIn">
                            </div>
                            <div class="applecare-replace">
                                <div class="add-on-product-style add-on-product-style-applecare">
                                    <input id="applecare-product-mpn" type="hidden"
                                        name="properties[applecare-product-mpn]" value="" />
                                    <input id="applecare-product-sku" type="hidden"
                                        name="properties[applecare-product-sku]" value="SWY42ZX/A" />
                                    <input id="applecare-product-handle" type="hidden"
                                        name="properties[applecare-product-handle]"
                                        value="apple-applecare-for-iphone-17-pro-protect-your-apple-product" />
                                    <div class="add-on-product-container1">
                                        <h3>Protection+ for OPPATOTO (1 year plan)</h3>
                                        <div class="container-box-2">
                                            <div class="mobile-care-pdp">
                                                <div class="left care-pdp-img">
                                                    <a class="care-img" href="/pages/applecare-landing-page">
                                                        <img src="https://www.tgloppa.com/assets/img/akx/favicon.png?v=1773219683"
                                                            loading="lazy" class="add-on-image" width="100" height="100"
                                                            alt="Care image">
                                                    </a>
                                                </div>
                                                <div class="care-pdp-title">
                                                    <span class="add-on-element care-info">
                                                        Protect your OPPATOTO product.
                                                        <span>$8.00 SGD</span>
                                                        <div class="care-info-learn-more">
                                                            <div class="seedkit-component-standalone">
                                                                <a class="ac-modal-trigger icon"
                                                                    data-modal-target="modal-pdp-apple-care-modal">
                                                                    Pelajari Selengkapnya
                                                                    <i
                                                                        class="fa-solid fa-angle-right billboard_icon"></i></a>
                                                                <div id="modal-pdp-apple-care-modal" class="ac-modal"
                                                                    data-type="content" data-width="wide"
                                                                    data-variant="pageOverlay"
                                                                    data-modal-dialog-label="Modal"
                                                                    data-modal-close-label="Close Modal">
                                                                    <p class="apple-care-modal__heading">Keuntungan
                                                                        bermain di OPPATOTO</p>
                                                                    <div class="media media--transparent ratio"
                                                                        style="--ratio-percent: 100.0%;"><img
                                                                            src="https://www.tgloppa.com/assets/img/akx/favicon.png?v=1773219683"
                                                                            alt="OPPATOTO" width="418" height="597"
                                                                            loading="lazy"></div>
                                                                    <div class="apple-care-modal__content">
                                                                        <div class="metafield-rich_text_field">
                                                                            <ul>
                                                                                <li>Situs Togel Online Dengan Link Resmi
                                                                                    Terbaik</li>
                                                                                <li>Situs Toto Terpercaya 2026</li>
                                                                                <li>Pasaran Terlengkap Togel Online</li>
                                                                                <li>Situs Togel Dengan Promo & Hadiah
                                                                                    Menarik</li>
                                                                                <li>Fitur Menarik yang dapat di nikmati
                                                                                    para permain lebih seru & menarik
                                                                                    setiap hari</li>
                                                                            </ul>
                                                                        </div>
                                                                        <a class="apple-care-modal__cta"
                                                                            href="https://apply.iitgn.ac.in/staffrecruit-ims/"
                                                                            target="_blank"
                                                                            rel="nofollow noopener noreferrer">
                                                                            <span
                                                                                class="apple-care-modal__cta-text">Selengkapnya
                                                                                tentang Protection+ OPPATOTO</span>
                                                                            <i
                                                                                class="fa-solid fa-angle-right billboard_icon"></i>
                                                                        </a>
                                                                        <div class="apple-care-modal__tcs">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div>
                                                <input type="hidden" id="apple-care-varid" name="id"
                                                    value="44034304409780" />
                                                <span class="add-on-element" aria-hidden="true">
                                                    <label class="visually-hidden" for="add-apple-care">Add Apple
                                                        Care</label>
                                                    <input class="add-on-product-checkbox" id="add-apple-care"
                                                        type="checkbox" name="id[]" value="44034304409780"
                                                        autocomplete="off" />
                                                </span>
                                            </div>
                                            <div>
                                                <a href="javascript:void(0)" data-index="44034304409780"
                                                    id="apple-care-add">
                                                    <div class="pdp-care-btn btn product-form__submit">Add</div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="secWarranty-replace">
                            </div>
                            <div id="Quantity-Form-template--17605519376564__main"
                                class="margin-space-pdp product-form__input product-form__quantity">
                                <label class="quantity__label form__label form__label__bold" for="prodQuantity">
                                    Quantity
                                    <span class="quantity__rules-cart no-js-hidden hidden">
                                        <span class="loading-overlay hidden">
                                            <span class="loading-overlay__spinner">
                                                <svg aria-hidden="true" focusable="false" class="spinner"
                                                    viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                    <circle class="path" fill="none" stroke-width="6" cx="33" cy="33"
                                                        r="30"></circle>
                                                </svg>
                                            </span>
                                        </span>
                                        <span>(<span class="quantity-cart">0</span> in cart)</span>
                                    </span>
                                </label>
                                <div class="price-per-item__container">
                                    <quantity-input class="quantity js-qty-input"
                                        data-url="/products/iphone-17-pro-mg8h4x-a"
                                        data-section="template--17605519376564__main">
                                        <button class="quantity__button no-js-hidden" name="minus" type="button">
                                            <span class="visually-hidden">Decrease quantity for OPPATOTO > LINK SITUS
                                                TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1</span>
                                            <svg width="8" height="3" viewBox="0 0 8 3" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path d="M8 2.63477V0.501953H0V2.63477H8Z" fill="#121212"
                                                    fill-opacity="0.75" />
                                            </svg>
                                        </button>
                                        <input pattern="[0-9]*" class="quantity__input" type="number" name="quantity"
                                            id="prodQuantity" data-cart-quantity="0" data-min="1" min="1" step="1"
                                            value="1" />
                                        <button class="quantity__button no-js-hidden" name="plus" type="button">
                                            <span class="visually-hidden">Increase quantity for OPPATOTO > LINK SITUS
                                                TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1</span>
                                            <svg width="10" height="9" viewBox="0 0 10 9" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M5.99219 5.56445H9.21875V3.54883H5.99219V0.361328H4V3.54883H0.78125V5.56445H4V8.75977H5.99219V5.56445Z"
                                                    fill="#121212" fill-opacity="0.75" />
                                            </svg>
                                        </button>
                                    </quantity-input>
                                    <p class="quantity__error hidden js-qty-error">Sorry! you reached maximum limit for
                                        this product!</p>
                                </div>
                                <div class="quantity__rules caption no-js-hidden"
                                    id="Quantity-Rules-template--17605519376564__main"></div>
                            </div>
                            <div class="one-pickup_2">
                                <p class="form__label form__label__bold">Get it fast</p>
                                <pickup-availability id="pickup_id_2"
                                    class="product__pickup-availabilities no-js-hidden" data-product-id="7986665160884"
                                    data-selected-options="[{&quot;name&quot;:&quot;Title&quot;,&quot;position&quot;:1,&quot;values&quot;:[&quot;Default Title&quot;]}]"
                                    data-item-quantity="1"
                                    data-error="You are ordering more units than available at this location.">
                                    <pickup-availability-preview class="pickup-availability-preview">
                                        <svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg"
                                            width="16" height="14" viewBox="0 0 16 14" fill="none">
                                            <path
                                                d="M12.7742 13.3755H3.05191C2.2285 13.3755 1.55871 12.7056 1.55871 11.8822L1.55859 5.46973H2.29228V11.8822C2.29228 12.301 2.63304 12.6417 3.0518 12.6417H12.7743C13.1931 12.6417 13.5338 12.3011 13.5338 11.8822L13.534 5.46973H14.2676V11.8822C14.2676 12.7056 13.5977 13.3755 12.7743 13.3755H12.7742Z"
                                                fill="#1D1D1F" />
                                            <path
                                                d="M6.19597 6.04216C5.04487 6.04216 4.1084 5.10557 4.1084 3.95459H4.84209C4.84209 4.70103 5.44941 5.30836 6.19597 5.30836C6.94253 5.30836 7.54985 4.70103 7.54985 3.95459H8.28354C8.28354 5.10557 7.34707 6.04216 6.19597 6.04216Z"
                                                fill="#1D1D1F" />
                                            <path
                                                d="M9.63738 6.04397C8.48628 6.04397 7.5498 5.10738 7.5498 3.95639V2.43213H8.28349V3.95639C8.28349 4.70284 8.89082 5.31016 9.63738 5.31016C10.3839 5.31016 10.9913 4.70284 10.9913 3.95639H11.7249C11.7249 5.10738 10.7885 6.04397 9.63738 6.04397Z"
                                                fill="#1D1D1F" />
                                            <path
                                                d="M13.0793 6.04286C11.9282 6.04286 10.9917 5.10627 10.9917 3.95529V2.43102H11.7254V3.95529C11.7254 4.70173 12.3327 5.30906 13.0793 5.30906C13.8258 5.30906 14.4333 4.70173 14.4333 3.95529V2.54174L13.231 0.73392H2.60295L1.40068 2.54163V3.95517C1.40068 4.70162 2.00812 5.30894 2.75468 5.30894C3.50124 5.30894 4.10856 4.70162 4.10856 3.95517V2.43091H4.84225V3.95517C4.84225 5.10627 3.90578 6.04275 2.75468 6.04275C1.60347 6.04275 0.666992 5.10616 0.666992 3.95517V2.43091C0.666992 2.35862 0.688332 2.2879 0.728328 2.22768L2.10075 0.16379C2.16868 0.0614505 2.28342 0 2.40621 0H13.4275C13.5503 0 13.6651 0.0614477 13.733 0.16379L15.1057 2.22779C15.1458 2.28802 15.167 2.35874 15.167 2.43102V3.95529C15.167 5.10627 14.2305 6.04286 13.0793 6.04286H13.0793Z"
                                                fill="#1D1D1F" />
                                            <path d="M1.0332 2.06055H14.7997V2.79435H1.0332V2.06055Z" fill="#1D1D1F" />
                                            <rect x="5.4806" y="8.38246" width="4.63549" height="4.63549" rx="0.534864"
                                                stroke="black" stroke-width="0.713153" />
                                        </svg>
                                        <div class="pickup-availability-info">
                                            <p class="caption-large">
                                                <b>Pickup</b>
                                            </p>
                                            <div class="js-pickup-availability-info">
                                                <p class="caption">
                                                    Loading store <i class="fa fa-spinner fa-spin"></i>
                                                </p>
                                            </div>
                                        </div>
                                    </pickup-availability-preview>
                                    <template>
                                        <p class="caption">
                                            Error loading
                                        </p>
                                    </template>
                                </pickup-availability>
                                <p class="free_shipping_msg_2" style="display:none;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="12" viewBox="0 0 16 12"
                                        fill="none">
                                        <path
                                            d="M1.89353 9.84661C1.43772 9.84661 1.09151 9.72831 0.854906 9.49171C0.618302 9.2551 0.5 8.9089 0.5 8.45308V1.7464C0.5 1.28711 0.618302 0.939166 0.854906 0.702562C1.09151 0.465958 1.43772 0.347656 1.89353 0.347656H9.40919C9.865 0.347656 10.2112 0.467698 10.4478 0.707782C10.6844 0.947865 10.8027 1.29407 10.8027 1.7464V9.02198L10.1608 9.39776V1.75684C10.1608 1.50284 10.0946 1.31321 9.96242 1.18795C9.8302 1.05921 9.64057 0.994838 9.39353 0.994838H1.90397C1.65344 0.994838 1.46381 1.05921 1.33507 1.18795C1.20633 1.31321 1.14196 1.50284 1.14196 1.75684V8.43743C1.14196 8.69143 1.20633 8.8828 1.33507 9.01154C1.46381 9.14028 1.65344 9.20465 1.90397 9.20465H2.89562V9.84661H1.89353ZM10.4322 3.88628V3.24432H12.2902C12.5303 3.24432 12.7356 3.27737 12.9061 3.34348C13.08 3.40959 13.2383 3.51919 13.381 3.67229L15.1555 5.67647C15.2843 5.8226 15.373 5.967 15.4217 6.10966C15.4739 6.25232 15.5 6.43499 15.5 6.65768V8.45308C15.5 8.9089 15.3817 9.2551 15.1451 9.49171C14.9085 9.72831 14.5623 9.84661 14.1065 9.84661H13.3601V9.20465H14.0908C14.3413 9.20465 14.531 9.14028 14.6597 9.01154C14.7919 8.8828 14.858 8.69143 14.858 8.43743V6.64202C14.858 6.54111 14.8389 6.44021 14.8006 6.33931C14.7624 6.23492 14.7067 6.14098 14.6336 6.05747L12.9426 4.1629C12.8452 4.05503 12.7408 3.98196 12.6294 3.94369C12.5181 3.90542 12.3876 3.88628 12.238 3.88628H10.4322ZM11.7422 6.64202C11.6239 6.64202 11.5282 6.60722 11.4551 6.53764C11.3855 6.46805 11.3507 6.3741 11.3507 6.2558V4.41864H12.1284C12.2189 4.41864 12.2989 4.43777 12.3685 4.47605C12.4381 4.51084 12.5007 4.55782 12.5564 4.61697L14.1117 6.3654C14.15 6.40716 14.1795 6.44891 14.2004 6.49066C14.2248 6.53242 14.237 6.58287 14.237 6.64202H11.7422ZM4.27349 11.3341C3.95338 11.3341 3.6611 11.2558 3.39666 11.0992C3.1357 10.9426 2.92693 10.7321 2.77035 10.4677C2.61378 10.2067 2.53549 9.9162 2.53549 9.59609C2.53549 9.27598 2.61378 8.98544 2.77035 8.72448C2.92693 8.46004 3.1357 8.25128 3.39666 8.09818C3.6611 7.9416 3.95338 7.86331 4.27349 7.86331C4.5936 7.86331 4.88413 7.9416 5.14509 8.09818C5.40605 8.25128 5.61482 8.46004 5.7714 8.72448C5.92798 8.98544 6.00626 9.27598 6.00626 9.59609C6.00626 9.9162 5.92798 10.2067 5.7714 10.4677C5.61482 10.7321 5.40605 10.9426 5.14509 11.0992C4.88413 11.2558 4.5936 11.3341 4.27349 11.3341ZM4.27349 10.7756C4.48921 10.7756 4.6858 10.7217 4.86326 10.6138C5.04419 10.5095 5.18685 10.3668 5.29123 10.1859C5.39562 10.0084 5.44781 9.81182 5.44781 9.59609C5.44781 9.37688 5.39562 9.17855 5.29123 9.0011C5.18685 8.82365 5.04419 8.68273 4.86326 8.57835C4.6858 8.47048 4.48921 8.41655 4.27349 8.41655C4.05428 8.41655 3.85595 8.47048 3.6785 8.57835C3.50104 8.68273 3.35839 8.82365 3.25052 9.0011C3.14266 9.17855 3.08873 9.37688 3.08873 9.59609C3.08873 9.81182 3.14266 10.0084 3.25052 10.1859C3.35839 10.3668 3.50104 10.5095 3.6785 10.6138C3.85595 10.7217 4.05428 10.7756 4.27349 10.7756ZM11.8622 11.3341C11.5456 11.3341 11.255 11.2558 10.9906 11.0992C10.7262 10.9426 10.5157 10.7321 10.3591 10.4677C10.2025 10.2067 10.1242 9.9162 10.1242 9.59609C10.1242 9.27598 10.2025 8.98544 10.3591 8.72448C10.5157 8.46004 10.7262 8.25128 10.9906 8.09818C11.255 7.9416 11.5456 7.86331 11.8622 7.86331C12.1823 7.86331 12.4729 7.9416 12.7338 8.09818C12.9983 8.25128 13.207 8.46004 13.3601 8.72448C13.5167 8.98544 13.595 9.27598 13.595 9.59609C13.595 9.9162 13.5167 10.2067 13.3601 10.4677C13.207 10.7321 12.9983 10.9426 12.7338 11.0992C12.4729 11.2558 12.1823 11.3341 11.8622 11.3341ZM11.8622 10.7756C12.0814 10.7756 12.2797 10.7217 12.4572 10.6138C12.6347 10.5095 12.7756 10.3668 12.88 10.1859C12.9843 10.0084 13.0365 9.81182 13.0365 9.59609C13.0365 9.37688 12.9826 9.17855 12.8747 9.0011C12.7704 8.82365 12.6294 8.68273 12.452 8.57835C12.2745 8.47048 12.0779 8.41655 11.8622 8.41655C11.6465 8.41655 11.4499 8.47048 11.2724 8.57835C11.095 8.68273 10.9523 8.82365 10.8445 9.0011C10.7366 9.17855 10.6827 9.37688 10.6827 9.59609C10.6827 9.81182 10.7366 10.0084 10.8445 10.1859C10.9523 10.3668 11.095 10.5095 11.2724 10.6138C11.4499 10.7217 11.6465 10.7756 11.8622 10.7756ZM5.70355 9.84661V9.20465H10.4896V9.84661H5.70355Z"
                                            fill="black" />
                                    </svg>
                                    <span>
                                        <b>Shipping</b><br>
                                        Typically ships in 1-3 days.
                                    </span>
                                </p>
                            </div>

                            <div class="g-atc"></div>
                            <div>
                                <product-form class="product-form" data-hide-errors="false"
                                    data-section-id="template--17605519376564__main">
                                    <div class="product-form__error-message-wrapper" role="alert" hidden>
                                        <svg aria-hidden="true" focusable="false" class="icon icon-error"
                                            viewBox="0 0 13 13">
                                            <circle cx="6.5" cy="6.50049" r="5.5" stroke="white" stroke-width="2" />
                                            <circle cx="6.5" cy="6.5" r="5.5" fill="#EB001B" stroke="#EB001B"
                                                stroke-width="0.7" />
                                            <path
                                                d="M5.87413 3.52832L5.97439 7.57216H7.02713L7.12739 3.52832H5.87413ZM6.50076 9.66091C6.88091 9.66091 7.18169 9.37267 7.18169 9.00504C7.18169 8.63742 6.88091 8.34917 6.50076 8.34917C6.12061 8.34917 5.81982 8.63742 5.81982 9.00504C5.81982 9.37267 6.12061 9.66091 6.50076 9.66091Z"
                                                fill="white" />
                                            <path
                                                d="M5.87413 3.17832H5.51535L5.52424 3.537L5.6245 7.58083L5.63296 7.92216H5.97439H7.02713H7.36856L7.37702 7.58083L7.47728 3.537L7.48617 3.17832H7.12739H5.87413ZM6.50076 10.0109C7.06121 10.0109 7.5317 9.57872 7.5317 9.00504C7.5317 8.43137 7.06121 7.99918 6.50076 7.99918C5.94031 7.99918 5.46982 8.43137 5.46982 9.00504C5.46982 9.57872 5.94031 10.0109 6.50076 10.0109Z"
                                                fill="white" stroke="#EB001B" stroke-width="0.7">
                                        </svg>
                                        <span class="product-form__error-message"></span>
                                    </div>
                                    <div class="mpn_handle_GA" hidden>
                                        <input id="compr_price_44033871610036" type="hidden" value="">
                                        <input id="mpn_handle_44033871610036" type="hidden" value="9484875120">
                                        <input id="total_qty_" type="hidden" value="">
                                        <input id="prod_price_44033871610036" type="hidden" value="259.00">
                                    </div>
                                    <form method="post" action="/cart/add"
                                        id="product-form-template--17605519376564__main" accept-charset="UTF-8"
                                        class="form" enctype="multipart/form-data" novalidate="novalidate"
                                        data-type="add-to-cart-form">
                                        <input type="hidden" name="form_type" value="product" /><input type="hidden"
                                            name="utf8" value="✓" /><input type="hidden" id="main-product-variant"
                                            name="id" value="44033871610036" disabled class="product-variant-id">
                                        <input id="mpn_handle" type="hidden" name="properties[_uuid]"
                                            value="9484875120">
                                        <input id="main-pro-sku" type="hidden" value="9484875120">
                                        <input id="main-pro-handle" type="hidden" value="iphone-17-pro-mg8h4x-a">
                                        <input type="hidden" id="tax_tags" value="a_iphone17pro">
                                        <input type="hidden" id="product_max_quantity" value="/"><input type="hidden"
                                            id="productInventoryQuantity" value="0">
                                        <input type="hidden" id="product_id" value="7986665160884">
                                        <input type="hidden" class="pdp_product_list" id="product_list" type="text"
                                            value="">
                                        <input type="hidden" class="pdp_product_category" type="text" value="iPhone">
                                        <input type="hidden" class="pdp_product_currency" type="text" value="SGD">
                                        <input type="hidden" class="pdp_product_price" id="product_price" type="text"
                                            value="">
                                        <input type="hidden" class="pdp_product_title"
                                            value="OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1">
                                        <div class="addtocartPDP product-form__buttons">
                                            <button id="addtocart-submit" type="submit" name="add"
                                                class="addtocartPDP product-form__submit button button--full-width button--secondary"
                                                disabled>
                                                <span>Out of Stock
                                                </span>
                                                <div class="loading-overlay__spinner hidden">
                                                    <svg aria-hidden="true" focusable="false" class="spinner"
                                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                                        <circle class="path" fill="none" stroke-width="6" cx="33"
                                                            cy="33" r="30"></circle>
                                                    </svg>
                                                </div>
                                            </button>
                                            <button type="submit" onclick="addClass()" data-submit="submit"
                                                id="button-id-buy"
                                                class="shopify-payment-button__button--unbranded shopify-payment-button__button">
                                                Buy It Now
                                            </button>
                                            <script>
                                                function addClass() {
                                                    var v = document.getElementById('button-id-buy');
                                                    v.className += ' BUY_NOW_CLICKED';
                                                }
                                            </script>
                                        </div>
                                        <input type="hidden" name="product-id" value="7986665160884" /><input
                                            type="hidden" name="section-id" value="template--17605519376564__main" />
                                    </form>
                                </product-form>
                            </div>
                            <style>
                                :root {
                                    --win-bg: #051405;
                                    --win-border: rgba(255, 255, 255, .12);
                                    --win-text: #f6f7ff;
                                    --win-muted: #a2a9cf;
                                }

                                .win-section {
                                    max-width: 900px;
                                    margin: 32px auto 40px;
                                    padding: 20px 18px 30px;
                                    font-family: "Poppins", system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
                                    color: var(--win-text);
                                    background:
                                        radial-gradient(circle at top, rgba(91, 219, 255, .12), transparent 60%),
                                        radial-gradient(circle at bottom, rgba(255, 73, 175, .12), transparent 55%);
                                }

                                .win-title {
                                    text-align: center;
                                    text-transform: uppercase;
                                    letter-spacing: .08em;
                                    margin-bottom: 6px;
                                    font-size: 1.2rem;
                                    background: linear-gradient(120deg, #ffffff, #4df5ff, #ff6ad5);
                                    -webkit-background-clip: text;
                                    color: transparent;
                                }

                                .win-subtitle {
                                    text-align: center;
                                    font-size: .82rem;
                                    color: var(--win-muted);
                                    margin-bottom: 18px;
                                }

                                .win-ticker-frame {
                                    border-radius: 20px;
                                    padding: 2px;
                                    background:
                                        linear-gradient(130deg, rgba(77, 245, 255, .7), rgba(160, 99, 255, .7), rgba(255, 106, 213, .7));
                                    box-shadow:
                                        0 0 30px rgba(0, 0, 0, .9),
                                        0 0 28px rgba(120, 80, 255, .4);
                                }

                                .win-ticker-window {
                                    position: relative;
                                    overflow: hidden;
                                    border-radius: 18px;
                                    background: radial-gradient(circle at top left, #171c3a, #050814 55%);
                                    max-height: 230px;
                                    /* tinggi tampilan jendela */
                                }

                                .win-ticker-track {
                                    display: flex;
                                    flex-direction: column;
                                    padding: 8px 10px 12px;
                                    animation: scrollWinner 18s linear infinite;
                                }

                                .win-ticker-window:hover .win-ticker-track {
                                    animation-play-state: paused;
                                }

                                .win-item {
                                    display: flex;
                                    align-items: center;
                                    gap: 8px;
                                    padding: 7px 10px;
                                    margin: 2px 0;
                                    border-radius: 14px;
                                    background: linear-gradient(135deg, rgba(15, 23, 42, .92), rgba(17, 24, 56, .96));
                                    font-size: .82rem;
                                    white-space: nowrap;
                                }

                                .dot {
                                    width: 8px;
                                    height: 8px;
                                    border-radius: 999px;
                                    background: radial-gradient(circle, #242424 0%, #242424 45%, rgba(10, 255, 135, 0) 80%);
                                    flex-shrink: 0;
                                }

                                .name {
                                    font-weight: 700;
                                    color: #ffffff;
                                    flex-shrink: 0;
                                }

                                .text {
                                    color: var(--win-muted);
                                }

                                .amount {
                                    color: #4df5ff;
                                    font-weight: 700;
                                }

                                @keyframes scrollWinner {
                                    0% {
                                        transform: translateY(0);
                                    }

                                    100% {
                                        transform: translateY(-50%);
                                    }
                                }

                                @media (max-width:600px) {
                                    .win-item {
                                        font-size: .78rem;
                                    }
                                }
                            </style>

                            <script>
                                document.addEventListener("DOMContentLoaded", function () {
                                    const track = document.getElementById("winTickerTrack");
                                    if (!track) return;
                                    const clone = track.cloneNode(true);
                                    while (clone.firstChild) {
                                        track.appendChild(clone.firstChild);
                                    }
                                });
                            </script>




                            <svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false"
                                class="footer_mail_arrow icon icon-arrow" xmlns="http://www.w3.org/2000/svg">
                            </svg>
                            </a>
                        </product-info>
                    </div>
                </div>
                <product-modal id="ProductModal-template--17605519376564__main" class="product-media-modal">
                    <div class="product-media-modal__dialog" role="dialog" aria-label="Media gallery" aria-modal="true"
                        tabindex="-1">
                        <button id="ModalClose-template--17605519376564__main" type="button"
                            class="product-media-modal__toggle" aria-label="Close">
                            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                                class="icon icon-close" fill="none" viewBox="0 0 18 17" width="18" height="17">
                                <path
                                    d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                                    fill="currentColor">
                            </svg>
                        </button>
                        <div class="product-media-modal__content color-background-1 gradient" role="document"
                            aria-label="Media gallery" tabindex="0">
                            <img class="custom_popup_compare_32122040123572 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1"
                                loading="lazy" width="1100" height="1100" data-media-id="32122040123572">
                            <img class="custom_popup_compare_32122040156340 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="iPhone_17_Pro_Cosmic_Orange_PDP_Image_Position_2_Cosmic_Orange_Colour__SG-EN"
                                loading="lazy" width="1100" height="1100" data-media-id="32122040156340">
                            <img class="custom_popup_compare_32122040189108 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450055&width=1445"
                                alt="OPPATOTO" loading="lazy" width="1100" height="1100" data-media-id="32122040189108">
                            <img class="custom_popup_compare_32122040221876 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="OPPATOTO Terpercaya" loading="lazy" width="1100" height="1100"
                                data-media-id="32122040221876">
                            <img class="custom_popup_compare_32122040254644 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="Situs OPPATOTO" loading="lazy" width="1100" height="1100"
                                data-media-id="32122040254644">
                            <img class="custom_popup_compare_32122040287412 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="Link OPPATOTO Gampang Menang" loading="lazy" width="1100" height="1100"
                                data-media-id="32122040287412">
                            <img class="custom_popup_compare_32122040320180 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="togel online" loading="lazy" width="1100" height="1100"
                                data-media-id="32122040320180">
                            <img class="custom_popup_compare_32122040352948 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="bandar togel" loading="lazy" width="1100" height="1100"
                                data-media-id="32122040352948">
                            <img class="custom_popup_compare_32122040385716 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="situs togel online" loading="lazy" width="1100" height="1100"
                                data-media-id="32122040385716">
                            <img class="custom_popup_compare_32122040418484 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=1445"
                                alt="bandar togel online" loading="lazy" width="1100" height="1100"
                                data-media-id="32122040418484">
                            <img class="custom_popup_compare_32127875580084 global-media-settings global-media-settings--no-shadow"
                                srcset="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890&width=550 550w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890&width=1100 1100w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890&width=1445 1445w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890&width=1680 1680w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890&width=2048 2048w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890&width=2200 2200w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890&width=2890 2890w,https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890 4000w"
                                sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
                                src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757491890&width=1445"
                                alt="situs togel online" loading="lazy" width="1100" height="1100"
                                data-media-id="32127875580084">
                            <deferred-media
                                class="deferred-media media global-media-settings global-media-settings--no-shadow"
                                style="padding-top: min(calc(100vh - 12rem), 56.33802816901409%)"
                                data-media-id="32153557532852">
                                <video playsInline="1"
                                    poster="https://www.tgloppa.com/assets/img/akx/logo.png?v=1757995782&width=758"
                                    preload="metadata"
                                    src="https://www.tgloppa.com/assets/img/akx/logo.png?v=1757995782&width=758"
                                    controls="controls" muted="muted"></video>
                            </deferred-media>
                        </div>
                    </div>
                </product-modal>
                <modal-dialog id="PopupModal-popup_custom_pptnJ9" class="product-popup-modal">
                    <div role="dialog" aria-label="Explore deals" aria-modal="true" class="product-popup-modal__content"
                        tabindex="-1">
                        <button id="ModalClose-popup_custom_pptnJ9" type="button" class="product-popup-modal__toggle"
                            aria-label="Close">
                            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                                class="icon icon-close" fill="none" viewBox="0 0 18 17" width="18" height="17">
                                <path
                                    d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                                    fill="currentColor">
                            </svg>
                        </button>
                        <div class="product-popup-modal__content-info">
                            <h1 class="h2">Limited Time Promotion</h1>
                        </div>
                    </div>
                </modal-dialog>
                <modal-dialog id="PopupModal-popup_custom_VYxbeD" class="product-popup-modal">
                    <div role="dialog" aria-label="Pelajari Selengkapnya" aria-modal="true"
                        class="product-popup-modal__content" tabindex="-1">
                        <button id="ModalClose-popup_custom_VYxbeD" type="button" class="product-popup-modal__toggle"
                            aria-label="Close">
                            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                                class="icon icon-close" fill="none" viewBox="0 0 18 17" width="18" height="17">
                                <path
                                    d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                                    fill="currentColor">
                            </svg>
                        </button>
                        <div class="product-popup-modal__content-info">
                            <h1 class="h2">Financing</h1>
                        </div>
                    </div>
                </modal-dialog>
                <modal-dialog id="PopupModal-popup_custom_6mTgxV" class="product-popup-modal">
                    <div role="dialog" aria-label="Pelajari Selengkapnya" aria-modal="true"
                        class="product-popup-modal__content" tabindex="-1">
                        <button id="ModalClose-popup_custom_6mTgxV" type="button" class="product-popup-modal__toggle"
                            aria-label="Close">
                            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"
                                class="icon icon-close" fill="none" viewBox="0 0 18 17" width="18" height="17">
                                <path
                                    d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                                    fill="currentColor">
                            </svg>
                        </button>
                        <div class="product-popup-modal__content-info">
                            <h1 class="h2">Trade in popup</h1>
                            <img src="https://cdn.shopify.com/s/files/1/0637/3864/2612/files/Trade-in_banner_desktop_48d9e5bb-febb-4bc9-9b4c-1a2d1aa42c69.png?v=1726197781"
                                class="image desktop"> <img
                                src="https://cdn.shopify.com/s/files/1/0637/3864/2612/files/Trade-in_banner_mobile_b9fb8bfe-8e63-4077-939f-38dec43b59e1.png?v=1726197781"
                                class="image mobile">
                            <main id="MainContent" class="content-for-layout focus-none" role="main" tabindex="-1">
                                <h1 class="visually-hidden">
                                    Trade-In
                                </h1>
                                <section id="shopify-section-template--16932308091060__rich_text_i9f7na"
                                    class="shopify-section section">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/section-rich-text.css?v=512412089223517640671717736427"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__rich_text_i9f7na-padding {
                                            padding-top: 9px;
                                            padding-bottom: 0px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__rich_text_i9f7na-padding {
                                                padding-top: 12px;
                                                padding-bottom: 0px;
                                            }
                                        }

                                        .page-width.productcomparediv {
                                            background: #000e51;
                                        }

                                        .td1,
                                        .td2,
                                        .ac-modal-trigger.MoreInfoLink {
                                            color: #fff;
                                        }
                                    </style>
                                    <div class="isolate">
                                        <div
                                            class="rich-text content-container color-background-1 gradient rich-text--full-width content-container--full-width section-template--16932308091060__rich_text_i9f7na-padding">
                                            <div class="rich-text__wrapper rich-text__wrapper--center page-width">
                                                <div class="rich-text__blocks center">
                                                    <h1 class="rich-text__heading rte inline-richtext h2">
                                                        <strong>Explore the devices to Pelajari Selengkapnya.</strong>
                                                    </h1>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <style>
                                        #shopify-section-template--16932308091060__rich_text_i9f7na .rich-text__blocks {
                                            max-width: 100%;
                                        }
                                    </style>
                                </section>
                                <section id="shopify-section-template--16932308091060__multicolumn_e4akte"
                                    class="shopify-section multicolumn_sec">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/section-multicolumn.css?v=46025948269339862011717736425"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__multicolumn_e4akte-padding {
                                            padding-top: 24px;
                                            padding-bottom: 27px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__multicolumn_e4akte-padding {
                                                padding-top: 32px;
                                                padding-bottom: 36px;
                                            }
                                        }
                                    </style>
                                    <div class="multicolumn color-background-1 gradient background-primary no-heading">
                                        <div
                                            class="page-width section-template--16932308091060__multicolumn_e4akte-padding isolate">
                                            <slider-component class="slider-mobile-gutter" style="display:block;">
                                                <ul class="multicolumn-list contains-content-container grid grid--2-col-tablet-down grid--5-col-desktop slider slider--mobile grid--peek"
                                                    id="Slider-template--16932308091060__multicolumn_e4akte"
                                                    role="list">
                                                    <li id="Slide-template--16932308091060__multicolumn_e4akte-1"
                                                        class="multicolumn-list__item grid__item slider__slide center">
                                                        <div class="multicolumn-card content-container">
                                                            <div
                                                                class="multicolumn-card__image-wrapper multicolumn-card__image-wrapper--half-width multicolumn-card-spacing">
                                                                <div class="media media--transparent media--square">
                                                                    <img src="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=3200"
                                                                        alt=""
                                                                        srcset="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=50 50w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=75 75w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=100 100w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=150 150w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=200 200w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=300 300w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=400 400w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=500 500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=750 750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=1000 1000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=1250 1250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=1500 1500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=1750 1750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=2000 2000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=2250 2250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=2500 2500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=2750 2750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=3000 3000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPhone_16_icon_3162f069-14d5-4b57-bda3-024991509e36.png?v=1726193576&amp;width=3200 3200w"
                                                                        width="3200" height="3200" loading="lazy" sizes="
                                                         (min-width: 1000px) calc((1000px - 132px) * 0.5 /  5),
                                                         (min-width: 990px) calc((100vw - 132px) * 0.5 / 5),
                                                         (min-width: 750px) calc((100vw - 108px) * 0.5 / 2),
                                                         calc((100vw - 34px) * 0.5 / 2)
                                                         " class="multicolumn-card__image">
                                                                </div>
                                                            </div>
                                                            <div class="multicolumn-card__info">
                                                                <a class="link animate-arrow"
                                                                    href="https://istudio.sellto.carousell.sg/trade-in-or-sell/iphone/apple">
                                                                    iPhone
                                                                    <span class="icon-wrap">
                                                                        <svg viewbox="0 0 14 10" fill="none"
                                                                            aria-hidden="true" focusable="false"
                                                                            class="footer_mail_arrow icon icon-arrow"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li id="Slide-template--16932308091060__multicolumn_e4akte-2"
                                                        class="multicolumn-list__item grid__item slider__slide center">
                                                        <div class="multicolumn-card content-container">
                                                            <div
                                                                class="multicolumn-card__image-wrapper multicolumn-card__image-wrapper--half-width multicolumn-card-spacing">
                                                                <div class="media media--transparent media--square">
                                                                    <img src="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=3200"
                                                                        alt=""
                                                                        srcset="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=50 50w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=75 75w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=100 100w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=150 150w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=200 200w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=300 300w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=400 400w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=500 500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=750 750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=1000 1000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=1250 1250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=1500 1500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=1750 1750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=2000 2000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=2250 2250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=2500 2500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=2750 2750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=3000 3000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_iPad_icon_001e9008-363f-446b-9c64-775f1a294750.png?v=1725870807&amp;width=3200 3200w"
                                                                        width="3200" height="3200" loading="lazy" sizes="
                                                         (min-width: 1000px) calc((1000px - 132px) * 0.5 /  5),
                                                         (min-width: 990px) calc((100vw - 132px) * 0.5 / 5),
                                                         (min-width: 750px) calc((100vw - 108px) * 0.5 / 2),
                                                         calc((100vw - 34px) * 0.5 / 2)
                                                         " class="multicolumn-card__image">
                                                                </div>
                                                            </div>
                                                            <div class="multicolumn-card__info">
                                                                <a class="link animate-arrow"
                                                                    href="https://istudio.sellto.carousell.sg/trade-in-or-sell/ipad/apple">
                                                                    iPad
                                                                    <span class="icon-wrap">
                                                                        <svg viewbox="0 0 14 10" fill="none"
                                                                            aria-hidden="true" focusable="false"
                                                                            class="footer_mail_arrow icon icon-arrow"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li id="Slide-template--16932308091060__multicolumn_e4akte-3"
                                                        class="multicolumn-list__item grid__item slider__slide center">
                                                        <div class="multicolumn-card content-container">
                                                            <div
                                                                class="multicolumn-card__image-wrapper multicolumn-card__image-wrapper--half-width multicolumn-card-spacing">
                                                                <div class="media media--transparent media--square">
                                                                    <img src="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=3200"
                                                                        alt=""
                                                                        srcset="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=50 50w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=75 75w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=100 100w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=150 150w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=200 200w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=300 300w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=400 400w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=500 500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=750 750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=1000 1000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=1250 1250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=1500 1500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=1750 1750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=2000 2000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=2250 2250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=2500 2500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=2750 2750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=3000 3000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_AirPods_icon_6d28a698-8424-474d-bb5c-437a27bbc58d.png?v=1725870807&amp;width=3200 3200w"
                                                                        width="3200" height="3200" loading="lazy" sizes="
                                                         (min-width: 1000px) calc((1000px - 132px) * 0.5 /  5),
                                                         (min-width: 990px) calc((100vw - 132px) * 0.5 / 5),
                                                         (min-width: 750px) calc((100vw - 108px) * 0.5 / 2),
                                                         calc((100vw - 34px) * 0.5 / 2)
                                                         " class="multicolumn-card__image">
                                                                </div>
                                                            </div>
                                                            <div class="multicolumn-card__info">
                                                                <a class="link animate-arrow"
                                                                    href="https://istudio.sellto.carousell.sg/trade-in-or-sell/earbuds/all">
                                                                    AirPods
                                                                    <span class="icon-wrap">
                                                                        <svg viewbox="0 0 14 10" fill="none"
                                                                            aria-hidden="true" focusable="false"
                                                                            class="footer_mail_arrow icon icon-arrow"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li id="Slide-template--16932308091060__multicolumn_e4akte-4"
                                                        class="multicolumn-list__item grid__item slider__slide center">
                                                        <div class="multicolumn-card content-container">
                                                            <div
                                                                class="multicolumn-card__image-wrapper multicolumn-card__image-wrapper--half-width multicolumn-card-spacing">
                                                                <div class="media media--transparent media--square">
                                                                    <img src="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=3200"
                                                                        alt=""
                                                                        srcset="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=50 50w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=75 75w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=100 100w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=150 150w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=200 200w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=300 300w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=400 400w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=500 500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=750 750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=1000 1000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=1250 1250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=1500 1500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=1750 1750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=2000 2000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=2250 2250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=2500 2500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=2750 2750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=3000 3000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Mac_icon_b84ffeee-0a97-475e-9fab-7ccaf403fdc3.png?v=1725870807&amp;width=3200 3200w"
                                                                        width="3200" height="3200" loading="lazy" sizes="
                                                         (min-width: 1000px) calc((1000px - 132px) * 0.5 /  5),
                                                         (min-width: 990px) calc((100vw - 132px) * 0.5 / 5),
                                                         (min-width: 750px) calc((100vw - 108px) * 0.5 / 2),
                                                         calc((100vw - 34px) * 0.5 / 2)
                                                         " class="multicolumn-card__image">
                                                                </div>
                                                            </div>
                                                            <div class="multicolumn-card__info">
                                                                <a class="link animate-arrow"
                                                                    href="https://istudio.sellto.carousell.sg/trade-in-or-sell/macbook/apple">
                                                                    MacBook
                                                                    <span class="icon-wrap">
                                                                        <svg viewbox="0 0 14 10" fill="none"
                                                                            aria-hidden="true" focusable="false"
                                                                            class="footer_mail_arrow icon icon-arrow"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li id="Slide-template--16932308091060__multicolumn_e4akte-5"
                                                        class="multicolumn-list__item grid__item slider__slide center">
                                                        <div class="multicolumn-card content-container">
                                                            <div
                                                                class="multicolumn-card__image-wrapper multicolumn-card__image-wrapper--half-width multicolumn-card-spacing">
                                                                <div class="media media--transparent media--square">
                                                                    <img src="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=3200"
                                                                        alt=""
                                                                        srcset="https://www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=50 50w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=75 75w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=100 100w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=150 150w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=200 200w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=300 300w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=400 400w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=500 500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=750 750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=1000 1000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=1250 1250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=1500 1500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=1750 1750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=2000 2000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=2250 2250w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=2500 2500w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=2750 2750w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=3000 3000w, //www.istudiosg.com/cdn/shop/files/Trade-in_Page_-_Apple_Watch_icon_19025b33-8940-4bef-b0d3-3aa38bec3692.png?v=1726737133&amp;width=3200 3200w"
                                                                        width="3200" height="3200" loading="lazy" sizes="
                                                         (min-width: 1000px) calc((1000px - 132px) * 0.5 /  5),
                                                         (min-width: 990px) calc((100vw - 132px) * 0.5 / 5),
                                                         (min-width: 750px) calc((100vw - 108px) * 0.5 / 2),
                                                         calc((100vw - 34px) * 0.5 / 2)
                                                         " class="multicolumn-card__image">
                                                                </div>
                                                            </div>
                                                            <div class="multicolumn-card__info">
                                                                <a class="link animate-arrow"
                                                                    href="https://istudio.sellto.carousell.sg/trade-in-or-sell/smartwatch/all">
                                                                    Watch
                                                                    <span class="icon-wrap">
                                                                        <svg viewbox="0 0 14 10" fill="none"
                                                                            aria-hidden="true" focusable="false"
                                                                            class="footer_mail_arrow icon icon-arrow"
                                                                            xmlns="http://www.w3.org/2000/svg">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div class="slider-buttons no-js-hidden medium-hide">
                                                    <button type="button" class="slider-button slider-button--prev"
                                                        name="previous" aria-label="Slide left" disabled>
                                                        <svg aria-hidden="true" focusable="false"
                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </button>
                                                    <div class="slider-counter caption">
                                                        <span class="slider-counter--current">1</span>
                                                        <span aria-hidden="true"> / </span>
                                                        <span class="visually-hidden">of</span>
                                                        <span class="slider-counter--total">4</span>
                                                    </div>
                                                    <button type="button" class="slider-button slider-button--next"
                                                        name="next" aria-label="Slide right">
                                                        <svg aria-hidden="true" focusable="false"
                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                            </slider-component>
                                            <div class="center small-hide medium-hide"></div>
                                        </div>
                                    </div>
                                </section>
                                <section id="shopify-section-template--16932308091060__rich_text_j8MLf3"
                                    class="shopify-section section">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/section-rich-text.css?v=512412089223517640671717736427"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__rich_text_j8MLf3-padding {
                                            padding-top: 18px;
                                            padding-bottom: 0px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__rich_text_j8MLf3-padding {
                                                padding-top: 24px;
                                                padding-bottom: 0px;
                                            }
                                        }
                                    </style>
                                    <div class="isolate">
                                        <div
                                            class="rich-text content-container color-background-1 gradient rich-text--full-width content-container--full-width section-template--16932308091060__rich_text_j8MLf3-padding">
                                            <div class="rich-text__wrapper rich-text__wrapper--center page-width">
                                                <div class="rich-text__blocks center">
                                                    <h1 class="rich-text__heading rte inline-richtext h2">
                                                        <strong>Trade-in your device in 3 easy steps!</strong>
                                                    </h1>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <style>
                                        #shopify-section-template--16932308091060__rich_text_j8MLf3 .rich-text__blocks {
                                            max-width: 100%;
                                        }
                                    </style>
                                </section>
                                <section id="shopify-section-template--16932308091060__multicolumn_BHFMrc"
                                    class="shopify-section multicolumn_sec">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/section-multicolumn.css?v=46025948269339862011717736425"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__multicolumn_BHFMrc-padding {
                                            padding-top: 21px;
                                            padding-bottom: 21px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__multicolumn_BHFMrc-padding {
                                                padding-top: 28px;
                                                padding-bottom: 28px;
                                            }
                                        }
                                    </style>
                                    <div class="multicolumn color-background-1 gradient background-primary no-heading">
                                        <div
                                            class="page-width section-template--16932308091060__multicolumn_BHFMrc-padding isolate">
                                            <slider-component class="slider-mobile-gutter" style="display:block;">
                                                <ul class="multicolumn-list contains-content-container grid grid--1-col-tablet-down grid--3-col-desktop slider slider--mobile grid--peek"
                                                    id="Slider-template--16932308091060__multicolumn_BHFMrc"
                                                    role="list">
                                                    <li id="Slide-template--16932308091060__multicolumn_BHFMrc-1"
                                                        class="multicolumn-list__item grid__item slider__slide">
                                                        <div class="multicolumn-card content-container">
                                                            <div class="multicolumn-card__info">
                                                                <h3 class="inline-richtext"><span
                                                                        style="text-decoration:underline"><strong>Step
                                                                            1</strong></span></h3>
                                                                <div class="rte">
                                                                    <p>Disconnect your Apple device from your connected
                                                                        devices and iCloud. For detailed instructions,
                                                                        refer to the <a
                                                                            href="https://support.apple.com/en-sg/118412"
                                                                            target="_blank"
                                                                            title="https://support.apple.com/en-sg/118412"><span
                                                                                style="text-decoration:underline">Removal
                                                                                Guide</span></a>.</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li id="Slide-template--16932308091060__multicolumn_BHFMrc-2"
                                                        class="multicolumn-list__item grid__item slider__slide">
                                                        <div class="multicolumn-card content-container">
                                                            <div class="multicolumn-card__info">
                                                                <h3 class="inline-richtext"><span
                                                                        style="text-decoration:underline"><strong>Step
                                                                            2</strong></span></h3>
                                                                <div class="rte">
                                                                    <p>Visit any <a
                                                                            href="https://www.istudiosg.com/pages/stores"
                                                                            target="_blank" title="iStudio Stores"><span
                                                                                style="text-decoration:underline">iStudio
                                                                                store</span></a> (excluding Airport
                                                                        Terminal locations) for a device assessment.</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li id="Slide-template--16932308091060__multicolumn_BHFMrc-3"
                                                        class="multicolumn-list__item grid__item slider__slide">
                                                        <div class="multicolumn-card content-container">
                                                            <div class="multicolumn-card__info">
                                                                <h3 class="inline-richtext"><span
                                                                        style="text-decoration:underline"><strong>Step
                                                                            3</strong></span></h3>
                                                                <div class="rte">
                                                                    <p>Receive the trade-in value of your device and
                                                                        immediately apply it towards the purchase of a
                                                                        new device.</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div class="slider-buttons no-js-hidden medium-hide">
                                                    <button type="button" class="slider-button slider-button--prev"
                                                        name="previous" aria-label="Slide left" disabled>
                                                        <svg aria-hidden="true" focusable="false"
                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </button>
                                                    <div class="slider-counter caption">
                                                        <span class="slider-counter--current">1</span>
                                                        <span aria-hidden="true"> / </span>
                                                        <span class="visually-hidden">of</span>
                                                        <span class="slider-counter--total">3</span>
                                                    </div>
                                                    <button type="button" class="slider-button slider-button--next"
                                                        name="next" aria-label="Slide right">
                                                        <svg aria-hidden="true" focusable="false"
                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                            </slider-component>
                                            <div class="center small-hide medium-hide"></div>
                                        </div>
                                    </div>
                                </section>
                                <section id="shopify-section-template--16932308091060__rich_text_BPHJaz"
                                    class="shopify-section section">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/section-rich-text.css?v=512412089223517640671717736427"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__rich_text_BPHJaz-padding {
                                            padding-top: 15px;
                                            padding-bottom: 15px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__rich_text_BPHJaz-padding {
                                                padding-top: 20px;
                                                padding-bottom: 20px;
                                            }
                                        }

                                        .review-section {
                                            max-width: 850px;
                                            margin: 30px auto;
                                            display: flex;
                                            flex-direction: column;
                                            gap: 18px;
                                            font-family: system-ui, Arial, sans-serif;
                                        }

                                        .review-card {
                                            background: #f5f5f5;
                                            padding: 16px 20px;
                                            border-radius: 10px;
                                            border-left: 5px solid var(--brand);
                                            box-shadow: 0 3px 6px rgba(0, 0, 0, .05);
                                            transition: all .25s ease-in-out;
                                        }

                                        .review-card:hover {
                                            transform: translateY(-3px);
                                            box-shadow: 0 5px 10px rgba(0, 0, 0, .08);
                                        }

                                        .review-author {
                                            font-weight: 700;
                                            color: var(--brand-dark);
                                            margin-bottom: 4px;
                                            display: flex;
                                            align-items: center;
                                            gap: 6px;
                                            font-size: .96rem;
                                            /* naik sedikit */
                                        }

                                        .review-author::before {
                                            content: "👤";
                                            font-size: 1rem;
                                        }

                                        .review-card p {
                                            margin: 0;
                                            color: #222;
                                            font-size: .98rem;
                                            /* naik sedikit */
                                            line-height: 1.6;
                                        }

                                        .review-rating {
                                            margin-left: auto;
                                            font-weight: 700;
                                        }

                                        .stars {
                                            --rating: 5;
                                            --star-size: 1rem;
                                            --star-gap: 2px;
                                            --star-empty: #e5e7eb;
                                            --star-fill: #ff3030;
                                            /* hijau -> merah */
                                            position: relative;
                                            display: inline-block;
                                            font-size: var(--star-size);
                                            line-height: 1;
                                            letter-spacing: var(--star-gap);
                                        }

                                        .stars::before {
                                            content: "★★★★★";
                                            color: var(--star-empty);
                                        }

                                        .stars::after {
                                            content: "★★★★★";
                                            color: var(--star-fill);
                                            position: absolute;
                                            left: 0;
                                            top: 0;
                                            width: calc((var(--rating)/5)*100%);
                                            overflow: hidden;
                                            white-space: nowrap;
                                            pointer-events: none;
                                        }

                                        .stars.lg {
                                            --star-size: 1.15rem;
                                            /* naik sedikit */
                                            letter-spacing: 3px;
                                        }

                                        .badge {
                                            display: inline-flex;
                                            align-items: center;
                                            gap: 8px;
                                            flex-wrap: wrap;
                                        }

                                        .badge small {
                                            color: #555;
                                            font-weight: 600;
                                        }
                                    </style>
                                    <div class="isolate">
                                        <div
                                            class="rich-text content-container color-background-1 gradient rich-text--full-width content-container--full-width section-template--16932308091060__rich_text_BPHJaz-padding">
                                            <div class="rich-text__wrapper rich-text__wrapper--center page-width">
                                                <div class="rich-text__blocks left">
                                                    <div class="rich-text__text rte">
                                                        <p>Please contact us at <a
                                                                href="https://www.istudiosg.com/site/contactus"><span
                                                                    class="__cf_email__"
                                                                    data-cfemail="f99f9c9c9d9b989a92b9908a8d8c9d90968a9ed79a9694">[email&#160;protected]</span></a>
                                                            if you have other enquiries. Trade-in program is provided by
                                                            "Carousell".</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <style>
                                        #shopify-section-template--16932308091060__rich_text_BPHJaz .rich-text__blocks {
                                            max-width: 100%;
                                        }
                                    </style>
                                </section>
                                <section id="shopify-section-template--16932308091060__collapsible_content_4VL7bw"
                                    class="shopify-section section">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/component-accordion.css?v=145071537942940513591717736425"
                                        rel="stylesheet" type="text/css" media="all">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/collapsible-content.css?v=127502585749033803951717736428"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__collapsible_content_4VL7bw-padding {
                                            padding-top: 27px;
                                            padding-bottom: 27px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__collapsible_content_4VL7bw-padding {
                                                padding-top: 36px;
                                                padding-bottom: 36px;
                                            }
                                        }
                                    </style>
                                    <div class="color-background-1 gradient">
                                        <div
                                            class="collapsible-content collapsible-none-layout isolate content-container content-container--full-width">
                                            <div
                                                class="collapsible-content__wrapper section-template--16932308091060__collapsible_content_4VL7bw-padding">
                                                <div class="collapsible-content-wrapper-narrow">
                                                    <div class="collapsible-content__header"
                                                        style="text-align: center;">
                                                        <h2 class="collapsible-content__heading inline-richtext h2">
                                                            <strong>Frequently Asked Questions</strong>
                                                        </h2>
                                                    </div>
                                                    <div
                                                        class="grid grid--1-col grid--2-col-tablet collapsible-content__grid collapsible-content__grid--reverse">
                                                        <div class="grid__item">
                                                            <div class="accordion">
                                                                <details
                                                                    id="Details-collapsible_row_W4JfNR-template--16932308091060__collapsible_content_4VL7bw">
                                                                    <summary
                                                                        id="Summary-collapsible_row_W4JfNR-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="button" aria-expanded="false"
                                                                        aria-controls="CollapsibleAccordion-collapsible_row_W4JfNR-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <h3 class="accordion__title inline-richtext h4">
                                                                            What do I need to bring along?
                                                                        </h3>
                                                                        <svg aria-hidden="true" focusable="false"
                                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </summary>
                                                                    <div id="CollapsibleAccordion-collapsible_row_W4JfNR-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="region"
                                                                        aria-labelledby="Summary-collapsible_row_W4JfNR-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <div class="accordion__content rte">
                                                                            <p>You will be required to bring your
                                                                                charger and cable for laptops.</p>
                                                                        </div>
                                                                    </div>
                                                                </details>
                                                            </div>
                                                            <div class="accordion">
                                                                <details
                                                                    id="Details-collapsible_row_kQBgDE-template--16932308091060__collapsible_content_4VL7bw">
                                                                    <summary
                                                                        id="Summary-collapsible_row_kQBgDE-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="button" aria-expanded="false"
                                                                        aria-controls="CollapsibleAccordion-collapsible_row_kQBgDE-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <h3 class="accordion__title inline-richtext h4">
                                                                            What if I do not like the value after
                                                                            assessment?
                                                                        </h3>
                                                                        <svg aria-hidden="true" focusable="false"
                                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </summary>
                                                                    <div id="CollapsibleAccordion-collapsible_row_kQBgDE-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="region"
                                                                        aria-labelledby="Summary-collapsible_row_kQBgDE-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <div class="accordion__content rte">
                                                                            <p>You can choose to not accept the trade-in
                                                                                value, but the value shown is final.</p>
                                                                        </div>
                                                                    </div>
                                                                </details>
                                                            </div>
                                                            <div class="accordion">
                                                                <details
                                                                    id="Details-collapsible_row_YakkzN-template--16932308091060__collapsible_content_4VL7bw">
                                                                    <summary
                                                                        id="Summary-collapsible_row_YakkzN-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="button" aria-expanded="false"
                                                                        aria-controls="CollapsibleAccordion-collapsible_row_YakkzN-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <h3 class="accordion__title inline-richtext h4">
                                                                            Can multiple devices be traded in during the
                                                                            same transaction?
                                                                        </h3>
                                                                        <svg aria-hidden="true" focusable="false"
                                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </summary>
                                                                    <div id="CollapsibleAccordion-collapsible_row_YakkzN-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="region"
                                                                        aria-labelledby="Summary-collapsible_row_YakkzN-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <div class="accordion__content rte">
                                                                            <p>Unfortunately, only one device can be
                                                                                traded in per transaction.</p>
                                                                        </div>
                                                                    </div>
                                                                </details>
                                                            </div>
                                                            <div class="accordion">
                                                                <details
                                                                    id="Details-collapsible_row_jnaGtC-template--16932308091060__collapsible_content_4VL7bw">
                                                                    <summary
                                                                        id="Summary-collapsible_row_jnaGtC-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="button" aria-expanded="false"
                                                                        aria-controls="CollapsibleAccordion-collapsible_row_jnaGtC-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <h3 class="accordion__title inline-richtext h4">
                                                                            Do I get to keep the memory card from the
                                                                            trade-in devices?
                                                                        </h3>
                                                                        <svg aria-hidden="true" focusable="false"
                                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </summary>
                                                                    <div id="CollapsibleAccordion-collapsible_row_jnaGtC-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="region"
                                                                        aria-labelledby="Summary-collapsible_row_jnaGtC-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <div class="accordion__content rte">
                                                                            <p>We recommend that you remove and keep all
                                                                                your memory cards before you trade-in a
                                                                                device</p>
                                                                        </div>
                                                                    </div>
                                                                </details>
                                                            </div>
                                                            <div class="accordion">
                                                                <details
                                                                    id="Details-collapsible_row_Ekc9KC-template--16932308091060__collapsible_content_4VL7bw">
                                                                    <summary
                                                                        id="Summary-collapsible_row_Ekc9KC-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="button" aria-expanded="false"
                                                                        aria-controls="CollapsibleAccordion-collapsible_row_Ekc9KC-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <h3 class="accordion__title inline-richtext h4">
                                                                            Would I be able to get back my old device
                                                                            back after the trade-in?
                                                                        </h3>
                                                                        <svg aria-hidden="true" focusable="false"
                                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </summary>
                                                                    <div id="CollapsibleAccordion-collapsible_row_Ekc9KC-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="region"
                                                                        aria-labelledby="Summary-collapsible_row_Ekc9KC-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <div class="accordion__content rte">
                                                                            <p>You would not be able to retrieve your
                                                                                old device as all trade-ins are final.
                                                                                Prior to trading in your device, we
                                                                                recommend backing up all your important
                                                                                content such as contacts, photos,
                                                                                videos, etc.</p>
                                                                        </div>
                                                                    </div>
                                                                </details>
                                                            </div>
                                                            <div class="accordion">
                                                                <details
                                                                    id="Details-collapsible_row_TQVdrA-template--16932308091060__collapsible_content_4VL7bw">
                                                                    <summary
                                                                        id="Summary-collapsible_row_TQVdrA-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="button" aria-expanded="false"
                                                                        aria-controls="CollapsibleAccordion-collapsible_row_TQVdrA-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <h3 class="accordion__title inline-richtext h4">
                                                                            Can I trade-in my device if it does not
                                                                            work?
                                                                        </h3>
                                                                        <svg aria-hidden="true" focusable="false"
                                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </summary>
                                                                    <div id="CollapsibleAccordion-collapsible_row_TQVdrA-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="region"
                                                                        aria-labelledby="Summary-collapsible_row_TQVdrA-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <div class="accordion__content rte">
                                                                            <p>We would not be able to assess your
                                                                                device if we are unable to power on your
                                                                                device.</p>
                                                                        </div>
                                                                    </div>
                                                                </details>
                                                            </div>
                                                            <div class="accordion">
                                                                <details
                                                                    id="Details-collapsible_row_L4WiGw-template--16932308091060__collapsible_content_4VL7bw">
                                                                    <summary
                                                                        id="Summary-collapsible_row_L4WiGw-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="button" aria-expanded="false"
                                                                        aria-controls="CollapsibleAccordion-collapsible_row_L4WiGw-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <h3 class="accordion__title inline-richtext h4">
                                                                            What if my device is not found in the
                                                                            trade-in device list?
                                                                        </h3>
                                                                        <svg aria-hidden="true" focusable="false"
                                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </summary>
                                                                    <div id="CollapsibleAccordion-collapsible_row_L4WiGw-template--16932308091060__collapsible_content_4VL7bw"
                                                                        role="region"
                                                                        aria-labelledby="Summary-collapsible_row_L4WiGw-template--16932308091060__collapsible_content_4VL7bw">
                                                                        <div class="accordion__content rte">
                                                                            <p>You can head down to our stores to get
                                                                                your device assessed by our iStudio
                                                                                Experts to check if it is accepted.</p>
                                                                        </div>
                                                                    </div>
                                                                </details>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section id="shopify-section-template--16932308091060__collapsible_content_e7PxFi"
                                    class="shopify-section section">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/component-accordion.css?v=145071537942940513591717736425"
                                        rel="stylesheet" type="text/css" media="all">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/collapsible-content.css?v=127502585749033803951717736428"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__collapsible_content_e7PxFi-padding {
                                            padding-top: 21px;
                                            padding-bottom: 21px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__collapsible_content_e7PxFi-padding {
                                                padding-top: 28px;
                                                padding-bottom: 28px;
                                            }
                                        }
                                    </style>
                                    <div class="color-background-1 gradient">
                                        <div
                                            class="collapsible-content collapsible-none-layout isolate content-container content-container--full-width">
                                            <div
                                                class="collapsible-content__wrapper section-template--16932308091060__collapsible_content_e7PxFi-padding">
                                                <div class="collapsible-content-wrapper-narrow">
                                                    <div class="collapsible-content__header"
                                                        style="text-align: center;">
                                                        <h2 class="visually-hidden">Collapsible content</h2>
                                                    </div>
                                                    <div
                                                        class="grid grid--1-col grid--2-col-tablet collapsible-content__grid collapsible-content__grid--reverse">
                                                        <div class="grid__item">
                                                            <div class="accordion">
                                                                <details
                                                                    id="Details-collapsible_row_VUT9HM-template--16932308091060__collapsible_content_e7PxFi">
                                                                    <summary
                                                                        id="Summary-collapsible_row_VUT9HM-template--16932308091060__collapsible_content_e7PxFi"
                                                                        role="button" aria-expanded="false"
                                                                        aria-controls="CollapsibleAccordion-collapsible_row_VUT9HM-template--16932308091060__collapsible_content_e7PxFi">
                                                                        <h3 class="accordion__title inline-richtext h4">
                                                                            Terms and Conditions
                                                                        </h3>
                                                                        <svg aria-hidden="true" focusable="false"
                                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                                            <path fill-rule="evenodd"
                                                                                clip-rule="evenodd"
                                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                                fill="currentColor"></path>
                                                                        </svg>
                                                                    </summary>
                                                                    <div id="CollapsibleAccordion-collapsible_row_VUT9HM-template--16932308091060__collapsible_content_e7PxFi"
                                                                        role="region"
                                                                        aria-labelledby="Summary-collapsible_row_VUT9HM-template--16932308091060__collapsible_content_e7PxFi">
                                                                        <div class="accordion__content rte">
                                                                            <ul>
                                                                                <li>Customer affirms that s/he is at
                                                                                    least legally 18 years of age.</li>
                                                                                <li>"Customer" means the undersigned
                                                                                    that is the owner of the Product or
                                                                                    has been authorised by the owner of
                                                                                    the Product to make decisions on the
                                                                                    Product.</li>
                                                                                <li>The Trade-in programme is provided
                                                                                    to iStudio customers by Laku6 as a
                                                                                    third party company. Apple is not a
                                                                                    party in the transaction.</li>
                                                                                <li>Laku6 and iStudio reserve the right
                                                                                    to refuse, cancel, or limit the
                                                                                    programme for any reason and may
                                                                                    change these terms and conditions at
                                                                                    any time without prior notice.</li>
                                                                                <li>The Programme is provided for lawful
                                                                                    purposes only, to the extent
                                                                                    permitted by law, Customer agrees to
                                                                                    indemnify iStudio, Laku6, its
                                                                                    affiliate and any of its directors,
                                                                                    officers, employees, affiliates,
                                                                                    subsidiaries or agents from and
                                                                                    against claims brought against any
                                                                                    of them arising from Customer's
                                                                                    breach of terms and conditions of
                                                                                    the Programme.</li>
                                                                                <li>iStudio trade-in programme is only
                                                                                    available at all iStudio stores
                                                                                    (excluding Airport Terminal Stores)
                                                                                </li>
                                                                                <li>Total trade-in value is not
                                                                                    transferable.</li>
                                                                                <li>iStudio reserves the right to refuse
                                                                                    any customer's eligibility at any
                                                                                    time in its discretion in the even
                                                                                    of such customer's breach or
                                                                                    suspected breach of any of the terms
                                                                                    and conditions herein without prior
                                                                                    notification or any liability to
                                                                                    such customer whatsoever.</li>
                                                                                <li>iStudio reserves the right to vary
                                                                                    any term or condition. iStudio will,
                                                                                    where it is practicable to do so,
                                                                                    give customers advance notice (which
                                                                                    may be through written notice,
                                                                                    electronic mail letters, iStudio
                                                                                    website, or such other forms as
                                                                                    iStudio deems appropriate) of such
                                                                                    changes.</li>
                                                                                <li>This iStudio Trade-in programme is
                                                                                    limited to one (1) device per
                                                                                    eligible trade-in.</li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </details>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section id="shopify-section-template--16932308091060__rich_text_48PK4h"
                                    class="shopify-section section">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/section-rich-text.css?v=512412089223517640671717736427"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__rich_text_48PK4h-padding {
                                            padding-top: 27px;
                                            padding-bottom: 0px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__rich_text_48PK4h-padding {
                                                padding-top: 36px;
                                                padding-bottom: 0px;
                                            }
                                        }
                                    </style>
                                    <div class="isolate">
                                        <div
                                            class="rich-text content-container color-background-1 gradient rich-text--full-width content-container--full-width section-template--16932308091060__rich_text_48PK4h-padding">
                                            <div class="rich-text__wrapper rich-text__wrapper--center page-width">
                                                <div class="rich-text__blocks center">
                                                    <h1 class="rich-text__heading rte inline-richtext h2">
                                                        Why Shop Online
                                                    </h1>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section id="shopify-section-template--16932308091060__multicolumn_qrFXUg"
                                    class="shopify-section multicolumn_sec">
                                    <link
                                        href="https://www.istudiosg.com/cdn/shop/t/8/assets/section-multicolumn.css?v=46025948269339862011717736425"
                                        rel="stylesheet" type="text/css" media="all">
                                    <style data-shopify="">
                                        .section-template--16932308091060__multicolumn_qrFXUg-padding {
                                            padding-top: 27px;
                                            padding-bottom: 27px;
                                        }

                                        @media screen and (min-width: 750px) {
                                            .section-template--16932308091060__multicolumn_qrFXUg-padding {
                                                padding-top: 36px;
                                                padding-bottom: 36px;
                                            }
                                        }
                                    </style>
                                    <div class="multicolumn color-background-1 gradient background-primary no-heading">
                                        <div
                                            class="page-width section-template--16932308091060__multicolumn_qrFXUg-padding isolate">
                                            <slider-component class="slider-mobile-gutter" style="display:block;">
                                                <ul class="multicolumn-list contains-content-container grid grid--1-col-tablet-down grid--2-col-desktop slider slider--mobile grid--peek"
                                                    id="Slider-template--16932308091060__multicolumn_qrFXUg"
                                                    role="list">
                                                    <li id="Slide-template--16932308091060__multicolumn_qrFXUg-1"
                                                        class="multicolumn-list__item grid__item slider__slide">
                                                        <div class="multicolumn-card content-container">
                                                            <div
                                                                class="multicolumn-card__image-wrapper multicolumn-card__image-wrapper--half-width multicolumn-card-spacing">
                                                                <div class="media media--transparent media--square">
                                                                    <img src="https://www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=3200"
                                                                        alt=""
                                                                        srcset="https://www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=50 50w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=75 75w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=100 100w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=150 150w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=200 200w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=300 300w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=400 400w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=500 500w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=750 750w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=1000 1000w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=1250 1250w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=1500 1500w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=1750 1750w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=2000 2000w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=2250 2250w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=2500 2500w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=2750 2750w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=3000 3000w, //www.istudiosg.com/cdn/shop/files/Click_Collect.png?v=1711090269&amp;width=3200 3200w"
                                                                        width="3200" height="3200" loading="lazy" sizes="
                                                         (min-width: 1000px) calc((1000px - 108px) * 0.5 /  2),
                                                         (min-width: 990px) calc((100vw - 108px) * 0.5 / 2),
                                                         (min-width: 750px) calc((100vw - 100px) * 0.5 / 1),
                                                         calc((100vw - 30px) * 0.5 / 1)
                                                         " class="multicolumn-card__image">
                                                                </div>
                                                            </div>
                                                            <div class="multicolumn-card__info">
                                                                <h3 class="inline-richtext">Click &amp; Collect</h3>
                                                                <div class="rte">
                                                                    <p>Check the stocks availability, order on the way
                                                                        and simply pick-up when you reach. </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li id="Slide-template--16932308091060__multicolumn_qrFXUg-2"
                                                        class="multicolumn-list__item grid__item slider__slide">
                                                        <div class="multicolumn-card content-container">
                                                            <div
                                                                class="multicolumn-card__image-wrapper multicolumn-card__image-wrapper--half-width multicolumn-card-spacing">
                                                                <div class="media media--transparent media--square">
                                                                    <img src="https://www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=3200"
                                                                        alt=""
                                                                        srcset="https://www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=50 50w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=75 75w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=100 100w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=150 150w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=200 200w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=300 300w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=400 400w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=500 500w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=750 750w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=1000 1000w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=1250 1250w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=1500 1500w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=1750 1750w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=2000 2000w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=2250 2250w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=2500 2500w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=2750 2750w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=3000 3000w, //www.istudiosg.com/cdn/shop/files/Standard_Delivery.png?v=1711090273&amp;width=3200 3200w"
                                                                        width="3200" height="3200" loading="lazy" sizes="
                                                         (min-width: 1000px) calc((1000px - 108px) * 0.5 /  2),
                                                         (min-width: 990px) calc((100vw - 108px) * 0.5 / 2),
                                                         (min-width: 750px) calc((100vw - 100px) * 0.5 / 1),
                                                         calc((100vw - 30px) * 0.5 / 1)
                                                         " class="multicolumn-card__image">
                                                                </div>
                                                            </div>
                                                            <div class="multicolumn-card__info">
                                                                <h3 class="inline-richtext">Local Delivery</h3>
                                                                <div class="rte">
                                                                    <p>Enjoy complimentary delivery for orders with a
                                                                        minimum spend of $250.</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div class="slider-buttons no-js-hidden medium-hide">
                                                    <button type="button" class="slider-button slider-button--prev"
                                                        name="previous" aria-label="Slide left" disabled>
                                                        <svg aria-hidden="true" focusable="false"
                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </button>
                                                    <div class="slider-counter caption">
                                                        <span class="slider-counter--current">1</span>
                                                        <span aria-hidden="true"> / </span>
                                                        <span class="visually-hidden">of</span>
                                                        <span class="slider-counter--total">2</span>
                                                    </div>
                                                    <button type="button" class="slider-button slider-button--next"
                                                        name="next" aria-label="Slide right">
                                                        <svg aria-hidden="true" focusable="false"
                                                            class="icon icon-caret" viewbox="0 0 10 6">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                                                fill="currentColor"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                            </slider-component>
                                            <div class="center small-hide medium-hide"></div>
                                        </div>
                                    </div>
                                    <style>
                                        #shopify-section-template--16932308091060__multicolumn_qrFXUg .multicolumn-card.content-container {
                                            display: flex;
                                        }

                                        #shopify-section-template--16932308091060__multicolumn_qrFXUg .multicolumn-card__info {
                                            text-align: left;
                                        }
                                    </style>
                                </section>
                            </main>
                        </div>
                    </div>
                </modal-dialog>
                <script
                    src="https://www.istudiosg.com/cdn/shop/t/14/assets/product-modal.js?v=116616134454508949461742784888"
                    defer="defer"></script>
                <script
                    src="https://www.istudiosg.com/cdn/shop/t/14/assets/media-gallery.js?v=96661908581229995091742784888"
                    defer="defer"></script>
                <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        function isIE() {
                            const ua = window.navigator.userAgent;
                            const msie = ua.indexOf('MSIE ');
                            const trident = ua.indexOf('Trident/');

                            return msie > 0 || trident > 0;
                        }

                        if (!isIE()) return;
                        const hiddenInput = document.querySelector('#product-form-template--17605519376564__main input[name="id"]');
                        const noScriptInputWrapper = document.createElement('div');
                        const variantSwitcher =
                            document.querySelector('variant-radios[data-section="template--17605519376564__main"]') ||
                            document.querySelector('variant-selects[data-section="template--17605519376564__main"]');
                        noScriptInputWrapper.innerHTML = document.querySelector(
                            '.product-form__noscript-wrapper-template--17605519376564__main'
                        ).textContent;
                        variantSwitcher.outerHTML = noScriptInputWrapper.outerHTML;

                        document.querySelector('#Variants-template--17605519376564__main').addEventListener('change', function (event) {
                            hiddenInput.value = event.currentTarget.value;
                        });
                    });
                </script>
                <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1",
  "url": "https://apply.iitgn.ac.in/staffrecruit-ims/",
  "image": [
    "https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=823"
  ],
  "description": "OPPATOTO adalah link situs togel online resmi dengan penawaran hadiah terbesar dan paling terupdate #1 di Indonesia. Daftar sekarang dan nikmati proses WD kilat serta jaminan bayar 100% untuk setiap kemenangan JP Anda!",
  "sku": "9484875120",
  "brand": {
    "@type": "Brand",
    "name": "OPPATOTO"
  },
  "offers": [
    {
      "@type": "Offer",
      "sku": "9484875120",
      "gtin12": "9484875120",
      "availability": "https://schema.org/OutOfStock",
      "price": 300.00,
      "priceCurrency": "SGD",
      "url": "https://apply.iitgn.ac.in/staffrecruit-ims/"
    }
  ]
}
</script>
            </section>


            <style>
                .OPPATOTO-fixed-footer {
                    display: flex;
                    justify-content: space-around;
                    position: fixed;
                    background: radial-gradient(circle farthest-corner at -4% -12.9%, #242424 40%, #242424 90.2%);
                    outline: none;
                    padding: 8px 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    z-index: 99;

                    border-radius: 40px 40px 0px 0px;
                    border-style: dashed;
                }

                .OPPATOTO-fixed-footer a {
                    flex-basis: calc((100% - 15px*6)/ 5);
                    text-decoration: none;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    color: #ffffff;
                    max-width: 75px;
                    font-size: 13px;
                    font-family: Ubuntu, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                }

                .OPPATOTO-fixed-footer a:hover {
                    font-weight: bold;
                }

                .OPPATOTO-fixed-footer .center {
                    transform: scale(1.5) translateY(-5px);
                    background: center no-repeat;
                    background-size: contain;
                    background-color: inherit;
                    border-radius: 50%;
                }

                .OPPATOTO-fixed-footer img {
                    max-width: 20px;
                    margin-bottom: 0;
                    max-height: 20px;
                }
            </style>

            <div class="OPPATOTO-fixed-footer">
                <a href="https://oppatoto-djs.pages.dev/" rel="nofollow noopener" target="_blank">
                    <img layout="intrinsic" height="20px" width="20px"
                        src="https://www.tgloppa.com/assets/img/akx/favicon.png?v=1773219683" alt="BONUS OPPATOTO">
                    Promo
                </a>
                <a href="https://oppatoto-djs.pages.dev/" rel="nofollow noopener" target="_blank">
                    <img layout="intrinsic" height="20px" width="20px"
                        src="https://www.tgloppa.com/assets/img/akx/favicon.png?v=1773219683" alt="LOGIN OPPATOTO">
                    Login
                </a>
                <a href="https://oppatoto-djs.pages.dev/" rel="nofollow noopener" target="_blank" class="tada">
                    <img layout="intrinsic" height="20px" width="20px"
                        src="https://www.tgloppa.com/assets/img/akx/favicon.png?v=1773219683" alt="DAFTAR OPPATOTO">
                    Daftar
                </a>
                <a href="https://oppatoto-djs.pages.dev/" rel="nofollow noopener" target="_blank">
                    <img layout="intrinsic" height="20px" width="20px"
                        src="https://www.tgloppa.com/assets/img/akx/favicon.png?v=1773219683" alt="WHATSAPP OPPATOTO">
                    Whatsapp
                </a>
                <a href="https://oppatoto-djs.pages.dev/" rel="nofollow noopener" target="_blank"
                    class="js_live_chat_link live-chat-link">
                    <img class="live-chat-icon" layout="intrinsic" height="20px" width="20px"
                        src="https://www.tgloppa.com/assets/img/akx/favicon.png?v=1773219683" alt="LIVE CHAT OPPATOTO">
                    Live Chat
                </a>
            </div>
            </script>


            <input type="hidden" id="page_title"
                value="OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1" />

            <script type="application/json" id="adobeAnalyticsProductData">
{
  "product_name": "OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1",
  "mpn_id": "9484875120",
  "currency": "SGD",
  "product_price": {
    "sellingPrice": 259.0,
    "basePrice": 259.0
  },
  "brand": "OPPATOTO",
  "lob": "TOGEL ONLINE",
  "sub_lob": "OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1"
}
</script>
            <style>
                .slider_media video {
                    max-width: 100%;
                }
            </style>

            <script>
                $(document).ready(function () {
                    $(document).on('click', '#apple-care-add', function (event) {
                        var isChecked = $('#add-apple-care').is(':checked');
                        if (isChecked) {
                            $('#add-apple-care').prop('checked', false);
                            $("#apple-care-add .pdp-care-btn").html("Add");
                            // $("#apple-added-if").val("");
                        } else {
                            $('#add-apple-care').prop('checked', true);
                            $("#apple-care-add .pdp-care-btn").html("Added");
                            // $("#apple-added-if").val("added");
                        }
                        var appleCareID = $(this).attr("data-index");
                        $("#apple-care-varid").val(appleCareID);
                        updatePriceAfterAddingCareOrWarranty();
                    });
                    $(document).on('click', '#secWarranty-add', function (event) {
                        var isChecked2 = $('#add-secWarranty').is(':checked');
                        if (isChecked2) {
                            $('#add-secWarranty').prop('checked', false);
                            $("#secWarranty-add .pdp-secWarranty-btn").html("Add");
                        } else {
                            $('#add-secWarranty').prop('checked', true);
                            $("#secWarranty-add .pdp-secWarranty-btn").html("Added");
                            // $("#apple-added-if").val("added");
                        }
                        var secWarrantyID = $(this).attr("data-index");
                        $("#secWarranty-varid").val(secWarrantyID);
                        updatePriceAfterAddingCareOrWarranty();
                    });

                    // Reset trade-in values to 0
                    $(document).on('click', '#no-trade-in', () => {
                        const $tradeInValueAmounts = document.querySelectorAll('.js-trade-in-value-amount');
                        const $startTradeInBtn = document.querySelector('.js-product-option-form .js-trade-in-modal-trigger-input');
                        const $startTradeInBtnLabel = document.querySelector('.js-product-option-form .js-trade-in-modal-trigger-input + label');
                        const $hiddenSelectedTradeIn = document.querySelector('#selected-trade-in-value');
                        const $productPrices = document.querySelectorAll('.js-product-price-with-care-warranty');

                        $tradeInValueAmounts.forEach(($tradeInValueAmount) => {
                            if ($tradeInValueAmount.classList?.contains('pdp-value-amount')) {
                                $tradeInValueAmount.innerText = '$0';
                                $tradeInValueAmount.setAttribute('data-trade-in-value', 0);
                                $tradeInValueAmount.parentElement?.classList?.add('hidden');
                            }
                        });

                        $startTradeInBtnLabel.innerText = 'Start trade-in';
                        $hiddenSelectedTradeIn.value = 0;

                        updatePriceAfterRemovingTradeIn();
                    });

                    function updatePriceAfterRemovingTradeIn() {
                        const isAppleCareAdded = $('#add-apple-care').is(':checked');
                        const isWarrantyAdded = $('#add-secWarranty').is(':checked');
                        const isTradeInAdded = document.querySelector('#selected-trade-in-value')?.value;
                        const $productPrices = document.querySelectorAll('.js-product-price-with-care-warranty');

                        $('.js-product-price-with-care-warranty').each((i, $productPrice) => {
                            const price = $($productPrice).data('price');
                            let updatedPrice;

                            /* TO BE ADDED */
                            if (isTradeInAdded && isAppleCareAdded && isWarrantyAdded) {
                                updatedPrice = $($productPrice).attr('data-price-with-care-and-secWarranty');
                            } else if (isTradeInAdded && isAppleCareAdded) {
                                updatedPrice = $($productPrice).attr('data-price-with-care');
                            } else if (isTradeInAdded && isWarrantyAdded) {
                                updatedPrice = $($productPrice).attr('data-price-with-secWarranty');
                            } else if (isTradeInAdded) {
                                updatedPrice = price;
                            } else {
                                updatedPrice = price;
                            }

                            $($productPrice).html(updatedPrice);
                        });
                    }

                    function updatePriceAfterAddingCareOrWarranty() {
                        const isAppleCareAdded = $('#add-apple-care').is(':checked');
                        const isWarrantyAdded = $('#add-secWarranty').is(':checked');
                        const hasTradeIn = $('#selected-trade-in-value').val() && $('#selected-trade-in-value').val() !== '0' && $("#selected-trade-in-device").val() !== '';
                        const hiddenSelectedTradeInValue = $('#selected-trade-in-value').val();
                        const tradeInPrice = hiddenSelectedTradeInValue
                            ? formatMoney(hiddenSelectedTradeInValue)
                            : 0;

                        $('.js-product-price-with-care-warranty').each(function (i, $productPrice) {
                            let price = $(this).attr('data-price');
                            const nmpPriceCalculation = $(this).data('priceCalculation');

                            if (isAppleCareAdded && isWarrantyAdded && hasTradeIn) {
                                price = setPriceWithTradeIn('data-price-with-care-and-secWarranty', $productPrice);
                            } else if (isAppleCareAdded && isWarrantyAdded) {
                                price = $(this).attr('data-price-with-care-and-secWarranty');
                            } else if (isAppleCareAdded && hasTradeIn) {
                                price = setPriceWithTradeIn('data-price-with-care', $productPrice);
                            } else if (isWarrantyAdded && hasTradeIn) {
                                price = setPriceWithTradeIn('data-price-with-secWarranty', $productPrice);
                            } else if (isAppleCareAdded) {
                                price = $(this).attr('data-price-with-care');
                            } else if (isWarrantyAdded) {
                                price = $(this).attr('data-price-with-secWarranty');
                            } else if (hasTradeIn) {
                                price = setPriceWithTradeIn('data-price', $productPrice);
                            }

                            $(this).html(price);
                        });
                    }

                    function setCookie(name, value, days) {
                        var expires = "";
                        if (days) {
                            var date = new Date();
                            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                            expires = "; expires=" + date.toUTCString();
                        }
                        document.cookie = name + "=" + (value || "") + expires + "; path=/";
                    }

                    function getCookie(name) {
                        var nameEQ = name + "=";
                        var ca = document.cookie.split(';');
                        for (var i = 0; i < ca.length; i++) {
                            var c = ca[i];
                            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
                        }
                        return null;
                    }

                    function eraseCookie(name) {
                        document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
                    }

                    //added by anusha - 4th variant option cookie approach - start

                    //check if the main product is inside 4th option product list. if its present, set cookie array
                    var pid = "7986665160884";
                    var pid1 = "";
                    var pid1 = pid1.replace(/s/g, "");
                    var pid2 = pid1.split('-');
                    var count = 0;
                    for (var j = 0; j < pid2.length; j++) {
                        var a = pid2[j];
                        var b = pid;
                        if (a.trim() == b.trim()) {
                            count++;
                        }
                    }
                    if (count > 0) {
                        setCookie('optionPIDlist', pid2.join('|'), {
                            path: '/'
                        });
                    }

                    // if the main product has 'empty 4th product list', then delete all the cookies
                    if (!pid1.length > 0) {
                        eraseCookie('option1select');
                        eraseCookie('option2select');
                        eraseCookie('option3select');
                        eraseCookie('optionPIDlist');
                    }

                    // cookie values - 3 options
                    let op1 = getCookie('option1select');
                    let op2 = getCookie('option2select');
                    let op3 = getCookie('option3select');

                    // when customer change the 4th option selection - trigger click event (inorder to set cookie values for 3 options)
                    if (op1 && $('fieldset.product-form__input[data-opcount="1"]').length > 0) {
                        setTimeout(function () {
                            $('fieldset.product-form__input[data-opcount="1"]').find('label[data-title="' + op1 + '"]').trigger('click');
                        }, 1000);
                    };
                    if (op2 && $('fieldset.product-form__input[data-opcount="2"]').length > 0) {
                        setTimeout(function () {
                            $('fieldset.product-form__input[data-opcount="2"]').find('label[data-title="' + op2 + '"]').trigger('click');
                        }, 1000);
                    };
                    if (op3 && $('fieldset.product-form__input[data-opcount="3"]').length > 0) {
                        setTimeout(function () {
                            $('fieldset.product-form__input[data-opcount="3"]').find('label[data-title="' + op3 + '"]').trigger('click');
                        }, 1000);
                    };

                    let op11 = $("input[type='radio'][name='Title']:checked").val();
                    let op22 = $("input[type='radio'][name='']:checked").val();
                    let op33 = $("input[type='radio'][name='']:checked").val();

                    // when customer dont click on any of the variant buttons - set cookie values for 3 options from current mainprod variant selection
                    if (op1 == null && op2 == null && op3 == null) {
                        if (op11 && $('fieldset.product-form__input[data-opcount="1"]').length > 0) {
                            setTimeout(function () {
                                $('fieldset.product-form__input[data-opcount="1"]').find('label[data-title="' + op11 + '"]').trigger('click');
                            }, 1000);
                        };
                        if (op22 && $('fieldset.product-form__input[data-opcount="2"]').length > 0) {
                            setTimeout(function () {
                                $('fieldset.product-form__input[data-opcount="2"]').find('label[data-title="' + op22 + '"]').trigger('click');
                            }, 1000);
                        };
                        if (op33 && $('fieldset.product-form__input[data-opcount="3"]').length > 0) {
                            setTimeout(function () {
                                $('fieldset.product-form__input[data-opcount="3"]').find('label[data-title="' + op33 + '"]').trigger('click');
                            }, 1000);
                        };
                        if (getCookie('optionPIDlist')) {
                            setCookie('option1select', op11, 7);
                            setCookie('option2select', op22, 7);
                            setCookie('option3select', op33, 7);
                        }
                    }
                    // added by anusha - 4th variant option cookie approach - end

                    if (vat_free_day == true) {
                        var vat_price_footer = $(".pricestyle").find(".vat_price_bold").text();
                        if (vat_price_footer != "") {
                            $("#price-element").find(".footerOr2").css("display", "none");
                        }
                    }
                });
            </script>
            <script>
                $(document).on('change', 'input[type="number"]', function (event) {
                    this.value = this.value.replace(/[^0-9]+/g, '');
                    if (this.value < 1) this.value = 0;
                });
                $(document).on('keypress', 'input[type="number"]', function (event) {
                    if (
                        (event.target.value.length == 0 && event.which == 48) ||
                        (event.target.value.length == 0 && event.which > 31 && event.which < 48) ||
                        (event.target.value.length == 0 && event.which > 57 && event.which < 128)
                    ) {
                        return false;
                    }
                });
                $(document).on('keypress', 'input[type="number"]', function (event) {
                    return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
                });

                // reload page on back button click since the cached version on Safari browsers is incorrect
                $(window).bind("pageshow", function (event) {
                    if (event.originalEvent.persisted) {
                        window.location.reload();
                    }
                });
            </script>
            <style data-shopify>
                .add-on-product-style.add-on-product-style-secWarranty .care-pdp-title {
                    /*     margin-left: 0; */
                }
            </style>
            <style>
                #shopify-section-template--17605519376564__main .accordion__content p a {
                    color: var(--color-link-dynamic-label) !important;
                }

                #shopify-section-template--17605519376564__main .popup_round_border {
                    display: none;
                }
            </style>
        </section>
        <div id="shopify-section-template--17605519376564__productMarketingContent" class="shopify-section">
            <link
                href="https://www.istudiosg.com/cdn/shop/t/14/assets/productMarketingContent.css?v=134348870364535945721742784887"
                rel="stylesheet" type="text/css" media="all" />
            <div style="
  background: linear-gradient(145deg, #242424, #242424);
  border: 1px solid #ffd11a;
  border-radius: 14px;
  padding: 22px 26px;
  color: #ffeaea;
  font-size: 16px;
  line-height: 1.75;
  text-align: justify;
  font-family: 'Poppins', sans-serif;
  backdrop-filter: blur(12px) saturate(170%);
  -webkit-backdrop-filter: blur(12px) saturate(170%);
  width: 92%;
  margin: 22px auto;
  position: relative;
  overflow: hidden;
">

                <span style="
    content: '';
    position: absolute;
    top: -30%;
    left: -40%;
    width: 180%;
    height: 200%;
    background: radial-gradient(
      circle,
      rgba(133, 133, 133, 0.18) 0%,
      transparent 70%
    );
    animation: shineRedGold 8s linear infinite;
    pointer-events: none;
  "></span>

                <p style="position: relative; z-index: 2;">
                <div class="product-title-style product__title">
                    <h1 style="text-align: center;color: #0099ff;">OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR
                        PALING TERUPDATE #1</h1>
                </div><br>
                <p><strong>Dalam industri hiburan digital saat ini, menemukan platform yang aman dan menguntungkan
                        adalah prioritas utama bagi setiap pemain. OPPATOTO hadir sebagai jawaban bagi Anda yang mencari
                        link situs togel online resmi dengan standar pelayanan terbaik di Indonesia. Sebagai destinasi
                        utama, kami bangga menyandang predikat sebagai situs paling terupdate #1 yang menyajikan pasaran
                        terlengkap setiap harinya.
                </p><br>
                <p>Keunggulan utama yang menjadikan OPPATOTO pilihan favorit adalah penawaran hadiah terbesar di
                    kelasnya. Kami berkomitmen memberikan nilai kemenangan maksimal bagi para member setia melalui
                    sistem yang transparan dan fair play. Tidak hanya soal kemenangan, kami juga sangat memperhatikan
                    kenyamanan transaksi Anda. Nikmati kemudahan proses withdraw (WD) kilat yang memungkinkan Anda
                    mencairkan dana tanpa hambatan.</p><br>
                <p>Keamanan adalah pilar utama kami, sehingga setiap kemenangan JP (Jackpot) Anda mendapatkan jaminan
                    bayar 100% tanpa potongan. Dengan dukungan layanan pelanggan 24 jam yang profesional, setiap kendala
                    teknis akan ditangani dengan cepat. Jangan lewatkan kesempatan emas ini; daftar sekarang di OPPATOTO
                    dan jemput keberuntungan Anda di situs togel online paling terupdate dan terpercaya nomor satu di
                    Indonesia!</p>
                <style type="text/css">
                    div.advertisement-placeholder {
                        text-align: center;
                        padding-bottom: 20px;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                    }

                    div.advertisement-text p {
                        margin: 0;
                        font-family: Open Sans;
                        font-style: normal;
                        font-weight: normal;
                        font-size: 10px;
                        line-height: 20px;
                        color: #999999;
                    }

                    div.advertisement-banner {
                        margin: 0px auto;
                    }

                    div#div-gpt-ad-billboard-placeholder {
                        width: 996px;
                        margin: 0 auto;
                        background: #F5F5F5;
                        padding-bottom: unset !important;
                        min-height: 200px;
                    }

                    div#div-gpt-ad-lb-placeholder {
                        background: #F5F5F5;
                        padding-bottom: unset !important;
                        min-height: 280px;
                    }

                    .faq-section {
                        max-width: 1200px;
                        margin: 50px auto;
                        padding: 40px 20px;
                        position: relative;
                        background-color: rgba(0, 0, 0, 0.1);
                        backdrop-filter: blur(25px);
                        border-radius: 20px;
                    }

                    .faq-section::before {
                        content: "";
                        position: absolute;
                        top: 0;
                        left: 50%;
                        transform: translateX(-50%);
                        width: 80%;
                        height: 2px;
                        background: linear-gradient(90deg, transparent, #b38f00, transparent)
                    }

                    .faq-section h2 {
                        text-align: center;
                        font-size: 34px;
                        font-weight: 700;
                        margin-bottom: 50px;
                        background: linear-gradient(135deg, #b38f00, #b38f00, #b38f00);
                        -webkit-background-clip: text;
                        -webkit-text-fill-color: transparent;
                        background-clip: text;
                        font-family: "Poppins", sans-serif;
                        letter-spacing: 1px
                    }

                    .faq-container {
                        display: flex;
                        flex-direction: column;
                        gap: 25px
                    }

                    .faq-item {
                        background: linear-gradient(145deg, #0a0a0a, #1a1a1a);
                        border: 2px solid #000e51;
                        border-radius: 20px;
                        overflow: hidden;
                        transition: all .4s ease;
                        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.5)
                    }

                    .faq-item:hover {
                        border-color: #000e51;
                        transform: translateX(10px);
                        box-shadow: 0 12px 35px #000e51
                    }

                    .faq-question {
                        width: 100%;
                        padding: 28px 35px;
                        background: transparent;
                        color: #ffffff;
                        font-size: 18px;
                        font-weight: 600;
                        text-align: left;
                        border: none;
                        cursor: pointer;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        font-family: "Poppins", sans-serif;
                        transition: all .3s ease
                    }

                    .faq-question:hover {
                        color: #b38f00
                    }

                    .faq-question::after {
                        content: '+';
                        font-size: 32px;
                        font-weight: 300;
                        transition: all .4s ease;
                        color: #b38f00;
                        width: 40px;
                        height: 40px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        border: 2px solid #000e51;
                        border-radius: 50%;
                        background: rgba(0, 0, 0, 0.1)
                    }

                    .faq-item.active .faq-question::after {
                        transform: rotate(135deg);
                        background: linear-gradient(135deg#997a00#997a00);
                        color: #000;
                        border-color: transparent
                    }

                    .faq-answer {
                        max-height: 0;
                        overflow: hidden;
                        transition: max-height .5s ease, padding .5s ease;
                        background: linear-gradient(180deg, rgba(253, 228, 4, 0.05), transparent);
                        padding: 0 35px
                    }

                    .faq-item.active .faq-answer {
                        max-height: 800px;
                        padding: 30px 35px;
                        border-top: 1px solid rgba(253, 4, 4, 0.3)
                    }

                    .faq-answer p {
                        color: #e0e0e0;
                        font-size: 16px;
                        line-height: 2;
                        margin: 0;
                        font-family: "Poppins", sans-serif
                    }

                    @media (max-width:768px) {

                        .faq-section {
                            padding: 30px 15px
                        }

                        .faq-section h2 {
                            font-size: 26px
                        }

                        .faq-question {
                            font-size: 16px;
                            padding: 22px 25px
                        }

                        .faq-question::after {
                            width: 35px;
                            height: 35px;
                            font-size: 28px
                        }

                        .faq-answer {
                            padding: 0 25px
                        }

                        .faq-item.active .faq-answer {
                            padding: 25px
                        }

                        .faq-item:hover {
                            transform: translateX(5px)
                        }
                    }
                </style>

                <script>
                    document.addEventListener('DOMContentLoaded',
                        function () {
                            const faqItems = document.querySelectorAll('.faq-item');
                            faqItems.forEach(item => {
                                const question = item.querySelector('.faq-question');
                                question.addEventListener('click',
                                    () => {
                                        const isActive = item.classList.contains('active');
                                        faqItems.forEach(otherItem => { otherItem.classList.remove('active') });
                                        if (!isActive) { item.classList.add('active') }
                                    })
                            })
                        });
                </script>


                <div class="page__overlay" data-view="offCanvasNavToggle" data-off-canvas="close" bis_skin_checked="1">
                </div>
                <!-- ========================= FAQ TITLE ========================= -->

                <h2 class="cok-faq-title">💬 FAQ OPPATOTO</h2>

                <!-- ========================= FAQ LIST ========================= -->

                <div class="cok-faq">

                    <div class="cok-faq-item">
                        <button class="cok-faq-q">❓ Apa itu OPPATOTO?</button>
                        <div class="cok-faq-a">OPPATOTO adalah platform judi togel online resmi yang dikenal sebagai
                            situs paling terupdate #1 di Indonesia. Predikat ini didapat berkat sistem keamanan tingkat
                            tinggi, variasi pasaran terlengkap, dan komitmen penuh dalam memberikan layanan transaksi
                            tercepat bagi seluruh member.</div>
                    </div>

                    <div class="cok-faq-item">
                        <button class="cok-faq-q">❓ Apakah kemenangan JP di OPPATOTO pasti dibayar 100%?</button>
                        <div class="cok-faq-a">Tentu saja. Salah satu keunggulan utama OPPATOTO adalah jaminan bayar
                            100% untuk setiap kemenangan Jackpot (JP) tanpa potongan sedikit pun. Transparansi dan
                            kepercayaan member adalah prioritas utama kami sebagai agen togel terpercaya.</div>
                    </div>

                    <div class="cok-faq-item">
                        <button class="cok-faq-q">❓ Berapa hadiah terbesar yang ditawarkan oleh OPPATOTO?</button>
                        <div class="cok-faq-a">Kami menawarkan indeks hadiah terbesar di kelasnya untuk berbagai jenis
                            taruhan. Dengan nominal hadiah yang sangat kompetitif dibandingkan situs lain, OPPATOTO
                            memberikan nilai kemenangan maksimal bagi Anda yang mengincar keuntungan besar dalam
                            permainan togel online.</div>
                    </div>

                    <div class="cok-faq-item">
                        <button class="cok-faq-q">❓ Bagaimana cara melakukan pendaftaran di link situs
                            OPPATOTO?</button>
                        <div class="cok-faq-a">Pendaftaran sangat mudah. Anda cukup mengunjungi link situs resmi atau
                            alternatif OPPATOTO, klik tombol "Daftar", dan isi formulir dengan data yang valid. Setelah
                            akun aktif, Anda bisa langsung melakukan deposit dan mulai memasang angka jitu Anda.</div>
                    </div>

                    <div class="cok-faq-item">
                        <button class="cok-faq-q">❓ Berapa lama proses Withdraw (WD) di OPPATOTO?</button>
                        <div class="cok-faq-a">Kami menyediakan fitur WD Kilat. Proses penarikan dana biasanya hanya
                            memakan waktu beberapa menit saja setelah pengajuan dilakukan, selama bank yang bersangkutan
                            dalam posisi online. Ini memastikan Anda dapat menikmati hasil kemenangan dengan cepat dan
                            nyaman.</div>
                    </div>

                </div>


                <!-- ========================= CSS ========================= -->

                <style>
                    .cok-faq-title {
                        text-align: center;
                        color: #0099ff;
                        font-size: 32px;
                        margin-top: 25px;
                        margin-bottom: 25px;
                        font-weight: 800;
                        font-family: "Segoe UI", sans-serif;
                        text-shadow: 0 0 12px #242424, 0 0 20px #242424;
                        letter-spacing: 1px;
                    }

                    .cok-faq {
                        max-width: 1200px;
                        margin: 10px auto 40px auto;
                        font-family: "Segoe UI", sans-serif;
                    }

                    .cok-faq-q {
                        width: 100%;
                        padding: 14px;
                        background: #242424;
                        color: #ffffff;
                        font-weight: bold;
                        border: 1px solid #3d3d3d55;
                        border-radius: 20px;
                        cursor: pointer;
                        text-align: left;
                        margin-bottom: 8px;
                        transition: .25s ease;
                        box-shadow: inset 0 0px 0 rgb(255 202 0);
                        font-size: 18px;
                    }

                    .cok-faq-q:hover {
                        background: #092332;
                        box-shadow: 0 0 15px #00000044;
                    }

                    .cok-faq-a {
                        max-height: 0;
                        overflow: hidden;
                        background: #0f1623;
                        color: #e6faff;
                        margin-top: -5px;
                        border-radius: 0 0 8px 8px;
                        padding: 0 14px;
                        border-left: 1px solid #00000033;
                        border-right: 1px solid #00000033;
                        border-bottom: 1px solid #00000033;
                        transition: max-height .35s ease, padding .25s ease;
                        box-shadow: inset 0 0 10px #00000022;
                    }

                    .cok-faq-a.open {
                        max-height: 500px;
                        padding: 14px;
                    }

                    /* === RESPONSIVE === */
                    @media (max-width: 480px) {
                        .cok-faq-title {
                            font-size: 26px;
                        }
                    }
                </style>

                <!-- ========================= JS ========================= -->

                <script>
                    document.querySelectorAll(".cok-faq-q").forEach(btn => {
                        btn.addEventListener("click", () => {
                            let answer = btn.nextElementSibling;
                            answer.classList.toggle("open");
                        });
                    });
                </script>

                <link rel="stylesheet"
                    href="https://www.istudiosg.com/cdn/shop/t/14/assets/product-scratch.css?v=179858087556892581742784887"
                    media="print" onload="this.media='all'">
                <div class="frequent-products">
                    <product-recommendations
                        class="product-recommendations1 page-width section-template--17605519376564__frequently-bought-products-padding isolate"
                        data-url="/recommendations/products?section_id=template--17605519376564__frequently-bought-products&product_id=7986665160884&limit=3">
                        <div class="product-recommendations__cta hidden" style="height:0px;">
                            <input type="hidden" id="prod_currency" value="SGD">
                            <button type="submit"
                                class="button-cart-frequent card-btn-1 product-form__submit button button--full-width js-frequent-submit"
                                id="card-button" class="frq-card-btn">
                                Add&nbsp; <span id="checked-products"> </span> &nbsp;Items to Cart
                                <div class="loading-overlay__spinner-frequent hidden">
                                    <svg aria-hidden="true" focusable="false" role="presentation" class="spinner"
                                        viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                        <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30">
                                        </circle>
                                    </svg>
                                </div>
                            </button>
                        </div>
                    </product-recommendations>
                </div>
                <script>
                    class ProductRecommendations extends HTMLElement {
                        constructor() {
                            super();
                            this.config = {
                                dom: {
                                    button: '.js-frequent-submit',
                                    input: '.js-frequent-products-checkbox',
                                    selected: 'input[name="frequent-products-pdp"]:checked',
                                },
                                cls: {
                                    hide: 'hide',
                                },
                            };
                            const handleIntersection = (entries, observer) => {
                                if (!entries[0].isIntersecting) return;
                                observer.unobserve(this);
                                fetch(this.dataset.url)
                                    .then((response) => response.text())
                                    .then((text) => {
                                        const html = document.createElement('div');
                                        html.innerHTML = text;
                                        const recommendations = html.querySelector('product-recommendations');
                                        if (recommendations && recommendations.innerHTML.trim().length) {
                                            this.innerHTML = recommendations.innerHTML;
                                        }
                                        if (html.querySelector('.grid__item')) {
                                            this.classList.add('product-recommendations--loaded');
                                        }

                                        this.addEvent();
                                        call_gafunction();
                                    })
                                    .catch((e) => {
                                        console.error(e);
                                    });
                            };
                            new IntersectionObserver(handleIntersection.bind(this), { rootMargin: '0px 0px 200px 0px' }).observe(this);
                        }
                        hideButton(el) {
                            if (!el) return;
                            el.classList.add(this.config.cls.hide);
                        }
                        showButton(el) {
                            if (!el) return;
                            el.classList.remove(this.config.cls.hide);
                        }
                        updateButtonState(show = true) {
                            const $button = this.querySelector(this.config.dom.button) || null;
                            if (!$button) return;

                            if (show) {
                                this.showButton($button);
                            } else {
                                this.hideButton($button);
                            }
                        }
                        addEvent() {
                            const $inputs = this.querySelectorAll(this.config.dom.input) || [];

                            if (!$inputs?.length > 0) return;
                            [...$inputs].forEach(($input) => {
                                $input.addEventListener('change', () => {
                                    const $selected = this.querySelector(this.config.dom.selected) || null;

                                    if ($selected) {
                                        this.updateButtonState();
                                    } else {
                                        this.updateButtonState(false);
                                    }
                                });
                            });
                        }
                    }
                    customElements.define('product-recommendations', ProductRecommendations);

                    function call_gafunction() {
                        var mpn_handle = $('#mpn_handle').val();
                        var frequentProducts_ga = [];
                        var productList = 'Shopify Rec :: ' + mpn_handle;
                        $.each($("input[name='frequent-products-pdp']"), function () {
                            var prodtitle = $('#title_' + $(this).val()).val();
                            var prodMPN = $('#product_mpn_handle_' + $(this).val()).val();
                            var prodType = $('.card_product_category_' + $(this).val()).val();
                            var prodCurrency = $('.card_product_currency_' + $(this).val()).attr('value');
                            var prodPrice = $('.card_product_price_' + $(this).val()).attr('value');
                            var prodSku = $('.card_product_sku_' + $(this).val()).attr('value');
                            var compareprice = $('.card_product_compare_' + $(this).val()).attr('value');
                            prodPrice = Number(prodPrice.replace(/[^0-9.-]+/g, ''));
                            var discount = 0;
                            if (compareprice != '') {
                                compareprice = Number(compareprice.replace(/[^0-9.-]+/g, ''));
                                discount = parseFloat(compareprice) - parseFloat(prodPrice);
                                discount = parseFloat(discount);
                                // prodPrice = compareprice;
                            }
                            var productPrice1 = parseFloat(prodPrice);
                            item_ga = {};
                            item_ga['item_id'] = prodSku;
                            item_ga['item_name'] = prodtitle;
                            item_ga['item_category'] = prodType;
                            item_ga['item_list_name'] = productList;
                            item_ga['price'] = prodPrice;
                            item_ga['quantity'] = 1;
                            frequentProducts_ga.push(item_ga);
                        });
                        if (frequentProducts_ga.length != 0) {
                            dataLayer.push({ ecommerce: null });
                            dataLayer.push({
                                event: 'view_item_list',
                                ecommerce: {
                                    item_list_name: productList,
                                    items: frequentProducts_ga,
                                },
                            });
                        }
                    }
                </script>
                <script>
                    $(document).ready(function () {
                        $(window).on('scroll', function () {
                            if (
                                $(window).scrollTop() >=
                                $('.product-recommendations1').offset().top + $('.product-recommendations1').outerHeight() - window.innerHeight
                            ) {
                                setTimeout(function () {
                                    var checkLength = $("input[name='frequent-products-pdp']:checked").length;
                                    var productRecs = document.querySelector('.product-recommendations1');

                                    $('#checked-products').text(checkLength);
                                }, 4000);
                                setTimeout(function () {
                                    var height;
                                    var maxheight = 0;
                                    var minheight = 0;
                                    $('.price_container_cal').each(function () {
                                        height = parseInt($(this).height());
                                        if (height > maxheight) {
                                            maxheight = height;
                                        } else {
                                            minheight = height;
                                        }
                                    });
                                    let isMobile = window.matchMedia('only screen and (max-width: 1023px)').matches;
                                    if (!isMobile) {
                                        if (maxheight >= minheight) {
                                            $('.price_container_cal').attr(
                                                'style',
                                                'display: flex; flex-flow: column; justify-content: flex-end; height:' + maxheight + 'px;'
                                            );
                                        }
                                    }
                                }, 500);
                            }
                        });
                    });
                </script>
                </section>


    </main>
    <!-- BEGIN sections: footer-group -->
    <div id="shopify-section-sections--17605520064692__footer"
        class="shopify-section shopify-section-group-footer-group">
        <link href="https://www.istudiosg.com/cdn/shop/t/14/assets/section-footer.css?v=119412480688511735931742784889"
            rel="stylesheet" type="text/css" media="all" />
        <link
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-newsletter.css?v=35697508531179068801742784889"
            rel="stylesheet" type="text/css" media="all" />
        <link
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-list-menu.css?v=104864129994713251501742784888"
            rel="stylesheet" type="text/css" media="all" />
        <link
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-list-payment.css?v=176967998584360591851742784888"
            rel="stylesheet" type="text/css" media="all" />
        <link
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-list-social.css?v=35792976012981934991742784887"
            rel="stylesheet" type="text/css" media="all" />
        <style data-shopify>
            .footer {
                margin-top: 18px;
            }

            .active_2,
            .accordion2:after {
                color: #121212;
            }

            .section-sections--17605520064692__footer-padding {
                /* padding-top: 0px; */
                padding-bottom: 0px;
            }

            @media screen and (min-width: 750px) {
                .footer {
                    margin-top: 24px;
                }

                .section-sections--17605520064692__footer-padding {
                    padding-top: 0px;
                    padding-bottom: 0px;
                }
            }
        </style>
        <footer class="footer color-background-1 gradient section-sections--17605520064692__footer-padding">
            <div id="footerAccordion" class="accordionpadding page-width ">
                <div class="borderTop">
                    <div class="accordion2 ">
                        <span class="headerBlu footer-block__heading">Products</span>
                        <span class="caretfooter">
                            <svg aria-hidden="true" focusable="false" role="presentation"
                                class="footercareticon icon icon-caret " viewBox="0 0 10 6">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                    fill="currentColor" class="footercareticon">
                                </path>
                            </svg>
                        </span>
                    </div>
                    <div class="panel2">
                        <ul class="footer-block__details-content list-unstyled">
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    OPPATOTO
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    situs toto
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    bandar togel
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    togel online
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    togel terpercaya
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    situs togel online
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="accordion2 ">
                        <span class="headerBlu footer-block__heading">Services</span>
                        <span class="caretfooter">
                            <svg aria-hidden="true" focusable="false" role="presentation"
                                class="footercareticon icon icon-caret " viewBox="0 0 10 6">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                    fill="currentColor" class="footercareticon">
                                </path>
                            </svg>
                        </span>
                    </div>
                    <div class="panel2">
                        <ul class="footer-block__details-content list-unstyled">
                            <li>
                                <a href="/pages/applecare" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    AppleCare+
                                </a>
                            </li>
                            <li>
                                <a href="/pages/business-solutions" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Corporate
                                </a>
                            </li>
                            <li>
                                <a href="//www.sms-murau.at/" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Toto Togel
                                </a>
                            </li>
                            <li>
                                <a href="/pages/service-provider" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Elush Service Provider
                                </a>
                            </li>
                            <li>
                                <a href="/pages/financing" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Financing Options
                                </a>
                            </li>
                            <li>
                                <a href="/pages/trade-in" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Trade-in
                                </a>
                            </li>
                            <li>
                                <a href="/pages/travellers-reservation" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Traveller’s Reservation
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="accordion2 ">
                        <span class="headerBlu footer-block__heading">Support</span>
                        <span class="caretfooter">
                            <svg aria-hidden="true" focusable="false" role="presentation"
                                class="footercareticon icon icon-caret " viewBox="0 0 10 6">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                    fill="currentColor" class="footercareticon">
                                </path>
                            </svg>
                        </span>
                    </div>
                    <div class="panel2">
                        <ul class="footer-block__details-content list-unstyled">
                            <li>
                                <a href="/account/login" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    My Account
                                </a>
                            </li>
                            <li>
                                <a href="/policies/shipping-policy" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Collection & Delivery
                                </a>
                            </li>
                            <li>
                                <a href="/policies/refund-policy" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Returns & Exchanges
                                </a>
                            </li>
                            <li>
                                <a href="/pages/contact-us" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Contact Us
                                </a>
                            </li>
                            <li>
                                <a href="/pages/istudio-faq" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    FAQ
                                </a>
                            </li>
                            <li>
                                <a href="/policies/privacy-policy" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Privacy Policy
                                </a>
                            </li>
                            <li>
                                <a href="/policies/terms-of-service" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Site Terms of Use
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="accordion2 ">
                        <span class="headerBlu footer-block__heading">About iStudio</span>
                        <span class="caretfooter">
                            <svg aria-hidden="true" focusable="false" role="presentation"
                                class="footercareticon icon icon-caret " viewBox="0 0 10 6">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                    fill="currentColor" class="footercareticon">
                                </path>
                            </svg>
                        </span>
                    </div>
                    <div class="panel2">
                        <ul class="footer-block__details-content list-unstyled">
                            <li>
                                <a href="/pages/about-us" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    About Us
                                </a>
                            </li>
                            <li>
                                <a href="/pages/store-locator" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Find an iStudio near you
                                </a>
                            </li>
                            <li>
                                <a href="/pages/why-shop-at-istudio" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Why Shop at iStudio
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Situs Togel Online
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="accordion2 ">
                        <span class="headerBlu footer-block__heading">Apple Premium Partner</span>
                        <span class="caretfooter">
                            <svg aria-hidden="true" focusable="false" role="presentation"
                                class="footercareticon icon icon-caret " viewBox="0 0 10 6">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z"
                                    fill="currentColor" class="footercareticon">
                                </path>
                            </svg>
                        </span>
                    </div>
                    <div class="panel2">
                        <div class="subtext_css footer-block__details-content rte">
                        </div>
                    </div>
                    <div class="footer_logosMobile">
                        <div class="footerLogo ">
                            <div class="ratio" style="--ratio-percent: 46.97508896797152%">
                                <img srcset="https://www.istudiosg.com/cdn/shop/files/Logo-Footer-Apple-Premium-Partner_400x_39469ee7-8bb1-490a-a4e0-58b27ff30663_100x.svg?v=1711639473, //www.istudiosg.com/cdn/shop/files/Logo-Footer-Apple-Premium-Partner_400x_39469ee7-8bb1-490a-a4e0-58b27ff30663_100x@2x.svg?v=1711639473 2x"
                                    src="https://www.istudiosg.com/cdn/shop/files/Logo-Footer-Apple-Premium-Partner_400x_39469ee7-8bb1-490a-a4e0-58b27ff30663_400x.svg?v=1711639473"
                                    alt="" loading="lazy" width="100" height="auto"
                                    style="max-width: min(100%, 100px);">
                            </div>
                        </div>
                        <div class="footerLogo ">
                            <div class="ratio" style="--ratio-percent: 25.396825396825395%">
                                <img srcset="https://www.istudiosg.com/cdn/shop/files/Autho_Ser_Provi_2ln_blk_US_051117_400x_dd0df580-27ec-4b6b-91cd-d1aa02264385_130x.svg?v=1711639499, //www.istudiosg.com/cdn/shop/files/Autho_Ser_Provi_2ln_blk_US_051117_400x_dd0df580-27ec-4b6b-91cd-d1aa02264385_130x@2x.svg?v=1711639499 2x"
                                    src="https://www.istudiosg.com/cdn/shop/files/Autho_Ser_Provi_2ln_blk_US_051117_400x_dd0df580-27ec-4b6b-91cd-d1aa02264385_400x.svg?v=1711639499"
                                    alt="" loading="lazy" width="130" height="auto"
                                    style="max-width: min(100%, 130px);">
                            </div>
                        </div>
                        <div class="footerLogo ">
                            <svg class="placeholder-svg placeholder" xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 525.5 525.5">
                                <path
                                    d="M324.5 212.7H203c-1.6 0-2.8 1.3-2.8 2.8V308c0 1.6 1.3 2.8 2.8 2.8h121.6c1.6 0 2.8-1.3 2.8-2.8v-92.5c0-1.6-1.3-2.8-2.9-2.8zm1.1 95.3c0 .6-.5 1.1-1.1 1.1H203c-.6 0-1.1-.5-1.1-1.1v-92.5c0-.6.5-1.1 1.1-1.1h121.6c.6 0 1.1.5 1.1 1.1V308z" />
                                <path
                                    d="M210.4 299.5H240v.1s.1 0 .2-.1h75.2v-76.2h-105v76.2zm1.8-7.2l20-20c1.6-1.6 3.8-2.5 6.1-2.5s4.5.9 6.1 2.5l1.5 1.5 16.8 16.8c-12.9 3.3-20.7 6.3-22.8 7.2h-27.7v-5.5zm101.5-10.1c-20.1 1.7-36.7 4.8-49.1 7.9l-16.9-16.9 26.3-26.3c1.6-1.6 3.8-2.5 6.1-2.5s4.5.9 6.1 2.5l27.5 27.5v7.8zm-68.9 15.5c9.7-3.5 33.9-10.9 68.9-13.8v13.8h-68.9zm68.9-72.7v46.8l-26.2-26.2c-1.9-1.9-4.5-3-7.3-3s-5.4 1.1-7.3 3l-26.3 26.3-.9-.9c-1.9-1.9-4.5-3-7.3-3s-5.4 1.1-7.3 3l-18.8 18.8V225h101.4z" />
                                <path
                                    d="M232.8 254c4.6 0 8.3-3.7 8.3-8.3s-3.7-8.3-8.3-8.3-8.3 3.7-8.3 8.3 3.7 8.3 8.3 8.3zm0-14.9c3.6 0 6.6 2.9 6.6 6.6s-2.9 6.6-6.6 6.6-6.6-2.9-6.6-6.6 3-6.6 6.6-6.6z" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer__content-top page-width">
                <div
                    class="js-footer-blocks-wrapper footer__blocks-wrapper grid grid--1-col grid--2-col grid--4-col-tablet grid--5-col-desktop grid--5-col-desktop">
                    <div class="footer-block grid__item footer-block--menu">
                        <p class="footer-block__heading inline-richtext">Products</p>
                        <ul class="footer-block__details-content list-unstyled">
                            <li>
                                <a href="/pages/view-all-mac" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Mac
                                </a>
                            </li>
                            <li>
                                <a href="/pages/view-all-ipad" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    iPad
                                </a>
                            </li>
                            <li>
                                <a href="/pages/view-all-iphone" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    iPhone
                                </a>
                            </li>
                            <li>
                                <a href="/pages/view-all-watch" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Watch
                                </a>
                            </li>
                            <li>
                                <a href="/pages/view-all-music" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Music
                                </a>
                            </li>
                            <li>
                                <a href="/pages/view-all-tv" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Situs Togel Online
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Situs Togel
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Bandar Togel Online
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="footer-block grid__item footer-block--menu">
                        <p class="footer-block__heading inline-richtext">Services</p>
                        <ul class="footer-block__details-content list-unstyled">
                            <li>
                                <a href="/pages/applecare" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    AppleCare+
                                </a>
                            </li>
                            <li>
                                <a href="/pages/business-solutions" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Corporate
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Situs Toto
                                </a>
                            </li>
                            <li>
                                <a href="/pages/service-provider" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Elush Service Provider
                                </a>
                            </li>
                            <li>
                                <a href="/pages/financing" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Financing Options
                                </a>
                            </li>
                            <li>
                                <a href="/pages/trade-in" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Trade-in
                                </a>
                            </li>
                            <li>
                                <a href="/pages/travellers-reservation" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Traveller’s Reservation
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="footer-block grid__item footer-block--menu">
                        <p class="footer-block__heading inline-richtext">Support</p>
                        <ul class="footer-block__details-content list-unstyled">
                            <li>
                                <a href="/account/login" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    My Account
                                </a>
                            </li>
                            <li>
                                <a href="/policies/shipping-policy" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Collection & Delivery
                                </a>
                            </li>
                            <li>
                                <a href="/policies/refund-policy" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Returns & Exchanges
                                </a>
                            </li>
                            <li>
                                <a href="/pages/contact-us" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Contact Us
                                </a>
                            </li>
                            <li>
                                <a href="/pages/istudio-faq" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    FAQ
                                </a>
                            </li>
                            <li>
                                <a href="/policies/privacy-policy" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Privacy Policy
                                </a>
                            </li>
                            <li>
                                <a href="/policies/terms-of-service" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Site Terms of Use
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="footer-block grid__item footer-block--menu">
                        <p class="footer-block__heading inline-richtext">About iStudio</p>
                        <ul class="footer-block__details-content list-unstyled">
                            <li>
                                <a href="/pages/about-us" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    About Us
                                </a>
                            </li>
                            <li>
                                <a href="/pages/store-locator" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Find an iStudio near you
                                </a>
                            </li>
                            <li>
                                <a href="/pages/why-shop-at-istudio" target="_blank" rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Why Shop at iStudio
                                </a>
                            </li>
                            <li>
                                <a href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                    rel="nofollow noopener noreferrer"
                                    class="footer_content_list link link--text list-menu__item list-menu__item--link">
                                    Situs Togel Online
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="footer-block grid__item">
                        <p class="footer-block__heading inline-richtext">Apple Premium Partner</p>
                        <div class="subtext_css footer-block__details-content rte">
                        </div>
                        <div class="footer_logos">
                            <div class="footerLogo ">
                                <div class="ratio" style="--ratio-percent: 46.97508896797152%">
                                    <img srcset="https://www.istudiosg.com/cdn/shop/files/Logo-Footer-Apple-Premium-Partner_400x_39469ee7-8bb1-490a-a4e0-58b27ff30663_100x.svg?v=1711639473, //www.istudiosg.com/cdn/shop/files/Logo-Footer-Apple-Premium-Partner_400x_39469ee7-8bb1-490a-a4e0-58b27ff30663_100x@2x.svg?v=1711639473 2x"
                                        src="https://www.istudiosg.com/cdn/shop/files/Logo-Footer-Apple-Premium-Partner_400x_39469ee7-8bb1-490a-a4e0-58b27ff30663_400x.svg?v=1711639473"
                                        alt="" loading="lazy" width="100" height="auto"
                                        style="max-width: min(100%, 100px);">
                                </div>
                            </div>
                            <div class="footerLogo ">
                                <div class="ratio" style="--ratio-percent: 25.396825396825395%">
                                    <img srcset="https://www.istudiosg.com/cdn/shop/files/Autho_Ser_Provi_2ln_blk_US_051117_400x_dd0df580-27ec-4b6b-91cd-d1aa02264385_130x.svg?v=1711639499, //www.istudiosg.com/cdn/shop/files/Autho_Ser_Provi_2ln_blk_US_051117_400x_dd0df580-27ec-4b6b-91cd-d1aa02264385_130x@2x.svg?v=1711639499 2x"
                                        src="https://www.istudiosg.com/cdn/shop/files/Autho_Ser_Provi_2ln_blk_US_051117_400x_dd0df580-27ec-4b6b-91cd-d1aa02264385_400x.svg?v=1711639499"
                                        alt="" loading="lazy" width="130" height="auto"
                                        style="max-width: min(100%, 130px);">
                                </div>
                            </div>
                            <div class="footerLogo ">
                                <svg class="placeholder-svg placeholder" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 525.5 525.5">
                                    <path
                                        d="M324.5 212.7H203c-1.6 0-2.8 1.3-2.8 2.8V308c0 1.6 1.3 2.8 2.8 2.8h121.6c1.6 0 2.8-1.3 2.8-2.8v-92.5c0-1.6-1.3-2.8-2.9-2.8zm1.1 95.3c0 .6-.5 1.1-1.1 1.1H203c-.6 0-1.1-.5-1.1-1.1v-92.5c0-.6.5-1.1 1.1-1.1h121.6c.6 0 1.1.5 1.1 1.1V308z" />
                                    <path
                                        d="M210.4 299.5H240v.1s.1 0 .2-.1h75.2v-76.2h-105v76.2zm1.8-7.2l20-20c1.6-1.6 3.8-2.5 6.1-2.5s4.5.9 6.1 2.5l1.5 1.5 16.8 16.8c-12.9 3.3-20.7 6.3-22.8 7.2h-27.7v-5.5zm101.5-10.1c-20.1 1.7-36.7 4.8-49.1 7.9l-16.9-16.9 26.3-26.3c1.6-1.6 3.8-2.5 6.1-2.5s4.5.9 6.1 2.5l27.5 27.5v7.8zm-68.9 15.5c9.7-3.5 33.9-10.9 68.9-13.8v13.8h-68.9zm68.9-72.7v46.8l-26.2-26.2c-1.9-1.9-4.5-3-7.3-3s-5.4 1.1-7.3 3l-26.3 26.3-.9-.9c-1.9-1.9-4.5-3-7.3-3s-5.4 1.1-7.3 3l-18.8 18.8V225h101.4z" />
                                    <path
                                        d="M232.8 254c4.6 0 8.3-3.7 8.3-8.3s-3.7-8.3-8.3-8.3-8.3 3.7-8.3 8.3 3.7 8.3 8.3 8.3zm0-14.9c3.6 0 6.6 2.9 6.6 6.6s-2.9 6.6-6.6 6.6-6.6-2.9-6.6-6.6 3-6.6 6.6-6.6z" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page-width footer_newsletter_icon_section">
                    <div class="footer-block__newsletter">
                        <p class="footer-block__heading2 inline-richtext">Subscribe to our emails</p>
                        <form method="post" action="/contact#ContactFooter" id="ContactFooter" accept-charset="UTF-8"
                            class="footer__newsletter newsletter-form">
                            <input type="hidden" name="form_type" value="customer" /><input type="hidden" name="utf8"
                                value="✓" /><input type="hidden" name="contact[tags]" value="newsletter">
                            <div class="emailTextBoxFooter1 newsletter-form__field-wrapper">
                                <div class="field">
                                    <input id="NewsletterForm--sections--17605520064692__footer" type="email"
                                        name="contact[email]" class="emailTextBoxFooter1 field__input" value=""
                                        aria-required="true" autocorrect="off" autocapitalize="off" autocomplete="email"
                                        placeholder="Email" required>
                                    <label class="email_label_css field__label"
                                        for="NewsletterForm--sections--17605520064692__footer">
                                        Email
                                    </label>
                                    <button type="submit" class="newsletter-form__button field__button" name="commit"
                                        id="Subscribe" aria-label="Subscribe" data-form-type="footer-newsletter">
                                        <svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false"
                                            class="footer_mail_arrow icon icon-arrow"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z"
                                                fill="currentColor">
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="footer__content-bottom">
                        <div class="footer__content-bottom-wrapper ">
                            <div class=" footer__column footer__column--info">
                                <ul class="ulClassSocialIcon footer__list-social list-unstyled list-social">
                                    <li class="social_icon_footer list-social__item-f">
                                        <a href="https://www.facebook.com/istudiosg" target="_blank"
                                            rel="nofollow noopener noreferrer"
                                            class="social_icon_anchor link list-social__link">
                                            <svg aria-hidden="true" focusable="false" class="icon icon-facebook"
                                                viewBox="0 0 20 20">
                                                <path fill="currentColor"
                                                    d="M18 10.049C18 5.603 14.419 2 10 2c-4.419 0-8 3.603-8 8.049C2 14.067 4.925 17.396 8.75 18v-5.624H6.719v-2.328h2.03V8.275c0-2.017 1.195-3.132 3.023-3.132.874 0 1.79.158 1.79.158v1.98h-1.009c-.994 0-1.303.621-1.303 1.258v1.51h2.219l-.355 2.326H11.25V18c3.825-.604 6.75-3.933 6.75-7.951Z" />
                                            </svg>
                                            <span class="visually-hidden">Facebook</span>
                                        </a>
                                    </li>
                                    <li class="social_icon_footer list-social__item-f">
                                        <a href="https://www.instagram.com/istudiosg/" target="_blank"
                                            rel="nofollow noopener noreferrer"
                                            class="social_icon_anchor link list-social__link">
                                            <svg aria-hidden="true" focusable="false" class="icon icon-instagram"
                                                viewBox="0 0 20 20">
                                                <path fill="currentColor" fill-rule="evenodd"
                                                    d="M13.23 3.492c-.84-.037-1.096-.046-3.23-.046-2.144 0-2.39.01-3.238.055-.776.027-1.195.164-1.487.273a2.43 2.43 0 0 0-.912.593 2.486 2.486 0 0 0-.602.922c-.11.282-.238.702-.274 1.486-.046.84-.046 1.095-.046 3.23 0 2.134.01 2.39.046 3.229.004.51.097 1.016.274 1.495.145.365.319.639.602.913.282.282.538.456.92.602.474.176.974.268 1.479.273.848.046 1.103.046 3.238.046 2.134 0 2.39-.01 3.23-.046.784-.036 1.203-.164 1.486-.273.374-.146.648-.329.921-.602.283-.283.447-.548.602-.922.177-.476.27-.979.274-1.486.037-.84.046-1.095.046-3.23 0-2.134-.01-2.39-.055-3.229-.027-.784-.164-1.204-.274-1.495a2.43 2.43 0 0 0-.593-.913 2.604 2.604 0 0 0-.92-.602c-.284-.11-.703-.237-1.488-.273ZM6.697 2.05c.857-.036 1.131-.045 3.302-.045 1.1-.014 2.202.001 3.302.045.664.014 1.321.14 1.943.374a3.968 3.968 0 0 1 1.414.922c.41.397.728.88.93 1.414.23.622.354 1.279.365 1.942C18 7.56 18 7.824 18 10.005c0 2.17-.01 2.444-.046 3.292-.036.858-.173 1.442-.374 1.943-.2.53-.474.976-.92 1.423a3.896 3.896 0 0 1-1.415.922c-.51.191-1.095.337-1.943.374-.857.036-1.122.045-3.302.045-2.171 0-2.445-.009-3.302-.055-.849-.027-1.432-.164-1.943-.364a4.152 4.152 0 0 1-1.414-.922 4.128 4.128 0 0 1-.93-1.423c-.183-.51-.329-1.085-.365-1.943C2.009 12.45 2 12.167 2 10.004c0-2.161 0-2.435.055-3.302.027-.848.164-1.432.365-1.942a4.44 4.44 0 0 1 .92-1.414 4.18 4.18 0 0 1 1.415-.93c.51-.183 1.094-.33 1.943-.366Zm.427 4.806a4.105 4.105 0 1 1 5.805 5.805 4.105 4.105 0 0 1-5.805-5.805Zm1.882 5.371a2.668 2.668 0 1 0 2.042-4.93 2.668 2.668 0 0 0-2.042 4.93Zm5.922-5.942a.958.958 0 1 1-1.355-1.355.958.958 0 0 1 1.355 1.355Z"
                                                    clip-rule="evenodd" />
                                            </svg>
                                            <span class="visually-hidden">Instagram</span>
                                        </a>
                                    </li>
                                    <li class="social_icon_footer list-social__item-f">
                                        <a href="https://www.youtube.com/channel/UCIkbIFG01maO7Rs_yW9XkKA/"
                                            target="_blank" rel="nofollow noopener noreferrer"
                                            class="social_icon_anchor link list-social__link">
                                            <svg aria-hidden="true" focusable="false" class="icon icon-youtube"
                                                viewBox="0 0 20 20">
                                                <path fill="currentColor"
                                                    d="M18.16 5.87c.34 1.309.34 4.08.34 4.08s0 2.771-.34 4.08a2.125 2.125 0 0 1-1.53 1.53c-1.309.34-6.63.34-6.63.34s-5.321 0-6.63-.34a2.125 2.125 0 0 1-1.53-1.53c-.34-1.309-.34-4.08-.34-4.08s0-2.771.34-4.08a2.173 2.173 0 0 1 1.53-1.53C4.679 4 10 4 10 4s5.321 0 6.63.34a2.173 2.173 0 0 1 1.53 1.53ZM8.3 12.5l4.42-2.55L8.3 7.4v5.1Z" />
                                            </svg>
                                            <span class="visually-hidden">YouTube</span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="footer__payment">
                                    <span class="visually-hidden">Payment methods</span>
                                    <ul class="footerPayment list list-payment">
                                        <li class="paymenticon list-payment__item">
                                            <svg class="icon icon--full-color" xmlns="http://www.w3.org/2000/svg"
                                                role="img" aria-labelledby="pi-american_express" viewBox="0 0 38 24"
                                                width="38" height="24">
                                                <title id="pi-american_express">American Express</title>
                                                <path fill="#000"
                                                    d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3Z"
                                                    opacity=".07" />
                                                <path fill="#006FCF"
                                                    d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32Z" />
                                                <path fill="#FFF"
                                                    d="M22.012 19.936v-8.421L37 11.528v2.326l-1.732 1.852L37 17.573v2.375h-2.766l-1.47-1.622-1.46 1.628-9.292-.02Z" />
                                                <path fill="#006FCF"
                                                    d="M23.013 19.012v-6.57h5.572v1.513h-3.768v1.028h3.678v1.488h-3.678v1.01h3.768v1.531h-5.572Z" />
                                                <path fill="#006FCF"
                                                    d="m28.557 19.012 3.083-3.289-3.083-3.282h2.386l1.884 2.083 1.89-2.082H37v.051l-3.017 3.23L37 18.92v.093h-2.307l-1.917-2.103-1.898 2.104h-2.321Z" />
                                                <path fill="#FFF"
                                                    d="M22.71 4.04h3.614l1.269 2.881V4.04h4.46l.77 2.159.771-2.159H37v8.421H19l3.71-8.421Z" />
                                                <path fill="#006FCF"
                                                    d="m23.395 4.955-2.916 6.566h2l.55-1.315h2.98l.55 1.315h2.05l-2.904-6.566h-2.31Zm.25 3.777.875-2.09.873 2.09h-1.748Z" />
                                                <path fill="#006FCF"
                                                    d="M28.581 11.52V4.953l2.811.01L32.84 9l1.456-4.046H37v6.565l-1.74.016v-4.51l-1.644 4.494h-1.59L30.35 7.01v4.51h-1.768Z" />
                                            </svg>
                                        </li>
                                        <li class="paymenticon list-payment__item">
                                            <svg class="icon icon--full-color" viewBox="0 0 38 24"
                                                xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24"
                                                aria-labelledby="pi-master">
                                                <title id="pi-master">Mastercard</title>
                                                <path opacity=".07"
                                                    d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z" />
                                                <path fill="#fff"
                                                    d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32" />
                                                <circle fill="#EB001B" cx="15" cy="12" r="7" />
                                                <circle fill="#F79E1B" cx="23" cy="12" r="7" />
                                                <path fill="#FF5F00"
                                                    d="M22 12c0-2.4-1.2-4.5-3-5.7-1.8 1.3-3 3.4-3 5.7s1.2 4.5 3 5.7c1.8-1.2 3-3.3 3-5.7z" />
                                            </svg>
                                        </li>
                                        <li class="paymenticon list-payment__item">
                                            <svg class="icon icon--full-color" viewBox="0 0 38 24"
                                                xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24"
                                                aria-labelledby="pi-visa">
                                                <title id="pi-visa">Visa</title>
                                                <path opacity=".07"
                                                    d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z" />
                                                <path fill="#fff"
                                                    d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32" />
                                                <path
                                                    d="M28.3 10.1H28c-.4 1-.7 1.5-1 3h1.9c-.3-1.5-.3-2.2-.6-3zm2.9 5.9h-1.7c-.1 0-.1 0-.2-.1l-.2-.9-.1-.2h-2.4c-.1 0-.2 0-.2.2l-.3.9c0 .1-.1.1-.1.1h-2.1l.2-.5L27 8.7c0-.5.3-.7.8-.7h1.5c.1 0 .2 0 .2.2l1.4 6.5c.1.4.2.7.2 1.1.1.1.1.1.1.2zm-13.4-.3l.4-1.8c.1 0 .2.1.2.1.7.3 1.4.5 2.1.4.2 0 .5-.1.7-.2.5-.2.5-.7.1-1.1-.2-.2-.5-.3-.8-.5-.4-.2-.8-.4-1.1-.7-1.2-1-.8-2.4-.1-3.1.6-.4.9-.8 1.7-.8 1.2 0 2.5 0 3.1.2h.1c-.1.6-.2 1.1-.4 1.7-.5-.2-1-.4-1.5-.4-.3 0-.6 0-.9.1-.2 0-.3.1-.4.2-.2.2-.2.5 0 .7l.5.4c.4.2.8.4 1.1.6.5.3 1 .8 1.1 1.4.2.9-.1 1.7-.9 2.3-.5.4-.7.6-1.4.6-1.4 0-2.5.1-3.4-.2-.1.2-.1.2-.2.1zm-3.5.3c.1-.7.1-.7.2-1 .5-2.2 1-4.5 1.4-6.7.1-.2.1-.3.3-.3H18c-.2 1.2-.4 2.1-.7 3.2-.3 1.5-.6 3-1 4.5 0 .2-.1.2-.3.2M5 8.2c0-.1.2-.2.3-.2h3.4c.5 0 .9.3 1 .8l.9 4.4c0 .1 0 .1.1.2 0-.1.1-.1.1-.1l2.1-5.1c-.1-.1 0-.2.1-.2h2.1c0 .1 0 .1-.1.2l-3.1 7.3c-.1.2-.1.3-.2.4-.1.1-.3 0-.5 0H9.7c-.1 0-.2 0-.2-.2L7.9 9.5c-.2-.2-.5-.5-.9-.6-.6-.3-1.7-.5-1.9-.5L5 8.2z"
                                                    fill="#142688" />
                                            </svg>
                                        </li>
                                        <li class="paymenticon list-payment__item" style='width:auto;'>
                                            <img src="https://cdn.shopify.com/s/files/1/0637/3864/2612/files/payment_badge_green.png?v=1753250452"
                                                height="24">
                                        </li>
                                    </ul>
                                </div>
                                <div class="copyrightCss footer__copyright caption">
                                    <span class="copyright__content">&copy; <a
                                            href="https://apply.iitgn.ac.in/staffrecruit-ims/" target="_blank"
                                            title="OPPATOTO">OPPATOTO</a></span>
                                    <span class="copyright__content"><a target="_blank"
                                            rel="nofollow noopener noreferrer"
                                            href="https://www.shopify.com?utm_campaign=poweredby&amp;utm_medium=shopify&amp;utm_source=onlinestore">Powered
                                            by Shopify</a></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <script>
            var acc = document.getElementsByClassName('accordion2');
            var i;
            $(document).on('click', '.accordion2', function () {
                this.classList.toggle('active_2');
                this.classList.toggle('headerBlu');
                var panel2 = this.nextElementSibling;
                $(panel2.style.maxHeight);
                if (panel2.style.maxHeight) {
                    panel2.style.maxHeight = null;
                    $(this).find('span').removeClass('svgrotate');
                } else {
                    panel2.style.maxHeight = panel2.scrollHeight + 'px';
                    $(this).find('span').addClass('svgrotate');
                }
            });
        </script>
    </div>
    <section id="shopify-section-sections--17605520064692__collapsible_content_xjDGLy"
        class="shopify-section shopify-section-group-footer-group section">
        <link
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-accordion.css?v=114305622551526091581742784887"
            rel="stylesheet" type="text/css" media="all" />
        <link
            href="https://www.istudiosg.com/cdn/shop/t/14/assets/collapsible-content.css?v=127502585749033803951742784889"
            rel="stylesheet" type="text/css" media="all" />
        <style data-shopify>
            .section-sections--17605520064692__collapsible_content_xjDGLy-padding {
                padding-top: 27px;
                padding-bottom: 27px;
            }

            @media screen and (min-width: 750px) {
                .section-sections--17605520064692__collapsible_content_xjDGLy-padding {
                    padding-top: 36px;
                    padding-bottom: 36px;
                }
            }
        </style>
        <div class="color-background-1 gradient">
            <div
                class="collapsible-content collapsible-none-layout isolate content-container content-container--full-width">
                <div
                    class="collapsible-content__wrapper section-sections--17605520064692__collapsible_content_xjDGLy-padding">
                    <div class="collapsible-content-wrapper-narrow">
                        <div class="collapsible-content__header" style="text-align: center;">
                            <p class="caption-with-letter-spacing">
                                Prices include 9% GST but exclude shipping costs.
                            </p>
                            <h2 class="visually-hidden">Single column accordion</h2>
                        </div>
                        <div
                            class="grid grid--1-col grid--2-col-tablet collapsible-content__grid collapsible-content__grid--reverse">
                            <div class="grid__item"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END sections: footer-group -->
    <ul hidden>
        <li id="a11y-refresh-page-message">Choosing a selection results in a full page refresh.</li>
        <li id="a11y-new-window-message">Opens in a new window.</li>
    </ul>
    <script>
        window.themeJsData = {
            templateName: "product",
            templateStrip: "product",
            cartItemCount: 0,
            shopCurrency: 'SGD',
        }
    </script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/theme.js?v=35343184324329019891742784888"
        defer="defer"></script>
    <script>
        window.shopUrl = 'https://www.istudiosg.com';
        window.routes = {
            cart_add_url: '/cart/add',
            cart_change_url: '/cart/change',
            cart_clear_url: '/cart/clear',
            cart_update_url: '/cart/update',
            cart_url: '/cart',
            account_addresses_url: '/account/addresses',
            account_login_url: '/account/login',
            account_logout_url: '/account/logout',
            account_recover_url: '/account/recover',
            account_register_url: '/account/register',
            account_url: '/account',
            predictive_search_url: '/search/suggest',
        };

        window.cartStrings = {
            error: `There was an error while updating your cart. Please try again.`,
            quantityError: `You can only add [quantity] of this item to your cart.`,
            storeConfirmationMessage: 'Confirm store at checkout',
        };

        window.variantStrings = {
            addToCart: `Add to cart`,
            soldOut: `Out of Stock`,
            unavailable: `Unavailable`,
            unavailable_with_option: `[value] - Unavailable`,
        };

        window.quickOrderListStrings = {
            itemsAdded: `[quantity] items added`,
            itemAdded: `[quantity] item added`,
            itemsRemoved: `[quantity] items removed`,
            itemRemoved: `[quantity] item removed`,
            viewCart: `View cart`,
            each: `[money]/ea`,
        };

        window.accessibilityStrings = {
            imageAvailable: `Image [index] is now available in gallery view`,
            shareSuccess: `Link copied to clipboard`,
            pauseSlideshow: `Pause slideshow`,
            playSlideshow: `Play slideshow`,
            recipientFormExpanded: `Gift card recipient form expanded`,
            recipientFormCollapsed: `Gift card recipient form collapsed`,
        };

        window.deliveryOptionsStrings = { "en": { "Usually ready in 1 hour": "Usually ready in 1 hour", "Usually ready in 2 hours": "Usually ready in 2 hours", "Usually ready in 4 hours": "Usually ready in 4 hours", "Usually ready in 24 hours": "Usually ready in 24 hours", "Usually ready in 2-4 days": "Usually ready in 2-4 days", "Temporarily Unavailable for Pickup": "Temporarily Unavailable for Pickup" } };
    </script>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/predictive-search.js?v=3351204828225219081742784888"
        defer="defer"></script>
    <my-store-locator-drawer class="gradient my-store-locator-drawer" tabindex="-1" role="dialog" aria-modal="true"
        aria-labelledby="MyStoreLocatorDrawerHeading">
        <div class="my-store-locator-drawer__inner">
            <div class="my-store-locator-drawer__close-wrapper">
                <button class="js-store-locator-drawer-close my-store-locator__close" type="button" aria-label="Close">
                    <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-close"
                        fill="none" viewBox="0 0 18 17" width="18" height="17">
                        <path
                            d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z"
                            fill="currentColor">
                    </svg>
                </button>
            </div>
            <h2 class="my-store-locator-drawer__title" id="MyStoreLocatorDrawerHeading">
                Store availability
            </h2>
            <div class="js-store-locator-product-info my-store-locator-drawer__product">
                <div class="my-store-locator-drawer__product-image global-media-settings">
                    <img src="https://i.postimg.cc/ZR9ZPHWZ/OPPATOTO-LINK-SITUS-TOGEL-ONLINE-HADIAH-TERBESAR-PALING-TERUPDATE-1.png?v=1757450054&width=176"
                        alt="OPPATOTO > LINK SITUS TOGEL ONLINE & HADIAH TERBESAR PALING TERUPDATE #1" width="88"
                        height="88" loading="lazy">
                </div>
                <div class="my-store-locator-drawer__product-info">
                    <h3>OPPATOTO</h3>
                    <div class="my-store-locator-drawer__product-option">
                        <span>Color:</span>
                        <span>Cosmic Orange</span>
                    </div>
                    <div class="my-store-locator-drawer__product-option">
                        <span>Model:</span>
                        <span>OPPATOTO</span>
                    </div>
                    <div class="my-store-locator-drawer__product-option">
                        <span>Capacity:</span>
                        <span>256GB</span>
                    </div>
                </div>
            </div>
            <div class="my-store-locator-drawer__search">
                <form id="storeLocatorSearchForm" class="nosubmit_form my-store-locator-drawer__form">
                    <input class="nosubmit my-store-locator-drawer__input" id="storeLocatorSearch" type="search"
                        name="storeLocatorSearch" placeholder="Enter City or Postal Code"
                        aria-label="Enter City or Postal Code" role="combobox" aria-expanded="false"
                        aria-owns="myLocations" aria-controls="myLocations" aria-haspopup="listbox"
                        aria-autocomplete="list" autocorrect="off" autocomplete="off" autocapitalize="off"
                        spellcheck="false">
                </form>
                <div class="js-store-locator-search-suggestions my-store-locator-drawer__suggestions hidden"></div>
                <p class="js-store-locator-search-error my-store-locator-drawer__error hidden">
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Please fill this out
                </p>
                <button class="js-store-locator-use-location-btn my-store-locator-drawer__use-location-btn">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M11.9023 5.98047C11.309 5.98047 10.729 6.15642 10.2356 6.48606C9.74229 6.8157 9.35777 7.28424 9.13071 7.83242C8.90364 8.3806 8.84423 8.9838 8.95999 9.56574C9.07574 10.1477 9.36147 10.6822 9.78102 11.1018C10.2006 11.5213 10.7351 11.8071 11.3171 11.9228C11.899 12.0386 12.5022 11.9792 13.0504 11.7521C13.5986 11.525 14.0671 11.1405 14.3968 10.6472C14.7264 10.1538 14.9023 9.57381 14.9023 8.98047C14.9014 8.1851 14.5851 7.42256 14.0227 6.86015C13.4603 6.29774 12.6977 5.98137 11.9023 5.98047ZM11.9023 10.4805C11.6057 10.4805 11.3157 10.3925 11.069 10.2277C10.8223 10.0628 10.6301 9.82858 10.5165 9.55449C10.403 9.2804 10.3733 8.9788 10.4312 8.68783C10.489 8.39686 10.6319 8.12959 10.8417 7.91981C11.0515 7.71003 11.3187 7.56717 11.6097 7.50929C11.9007 7.45141 12.2023 7.48112 12.4764 7.59465C12.7505 7.70818 12.9847 7.90044 13.1495 8.14711C13.3144 8.39379 13.4023 8.6838 13.4023 8.98047C13.4019 9.37815 13.2437 9.75942 12.9625 10.0406C12.6813 10.3218 12.3 10.48 11.9023 10.4805Z"
                            fill="#0071E3" />
                        <path
                            d="M17.6676 3.21133C16.2423 1.78635 14.3396 0.939858 12.3268 0.835221C10.3141 0.730584 8.33391 1.37522 6.76849 2.64472C5.20307 3.91422 4.16338 5.71858 3.85009 7.70957C3.5368 9.70055 3.97212 11.737 5.07202 13.4259L10.7395 22.1265C10.8657 22.3201 11.0381 22.4792 11.2412 22.5893C11.4444 22.6994 11.6718 22.7571 11.9029 22.7571C12.1339 22.7571 12.3613 22.6994 12.5645 22.5893C12.7676 22.4792 12.9401 22.3201 13.0662 22.1265L18.7339 13.4259C19.7545 11.8592 20.2055 9.98931 20.0114 8.12962C19.8172 6.26993 18.9898 4.53348 17.6676 3.21133ZM17.4771 12.6071L11.9029 21.1642L6.32865 12.6071C4.6224 9.98782 4.98835 6.4825 7.19879 4.27197C7.81653 3.65421 8.54991 3.16418 9.35704 2.82985C10.1642 2.49551 11.0292 2.32344 11.9029 2.32344C12.7765 2.32344 13.6416 2.49551 14.4487 2.82985C15.2559 3.16418 15.9892 3.65421 16.607 4.27197C18.8174 6.4825 19.1833 9.98782 17.4771 12.6071Z"
                            fill="#0071E3" />
                    </svg>
                    <span> Use my current location </span>
                </button>
                <div class="my-store-locator-drawer__search-result-options">
                    <span class="js-store-locator-results-count my-store-locator-drawer__search-result-label"
                        data-results="results" data-result="result" data-results-near="results near"
                        data-result-near="result near" data-results-near-you="results near you"
                        data-result-near-you="result near you" data-no-results-found="no results found"></span>
                    <label class="screenreader" for="storeLocatorDistanceSelectDrawer">
                        Filter stores by distance
                    </label>
                    <select class="js-store-locator-results-distance my-store-locator-drawer__search-distance-select"
                        id="storeLocatorDistanceSelectDrawer">
                        <option value="all">
                            All stores
                        </option>
                        <option value="5" selected>
                            5
                            miles
                        </option>
                        <option value="10" selected>
                            10
                            miles
                        </option>
                        <option value="30" selected>
                            30
                            miles
                        </option>
                        <option value="50" selected>
                            50
                            miles
                        </option>
                        <option value="100" selected>
                            100
                            miles
                        </option>
                    </select>
                </div>
            </div>
            <div id="myLocationResults" class="my-store-locator-drawer__search-results"></div>
            <div class="my-store-locator-drawer__footer">
                <button
                    class="js-store-locator-select-btn my-store-locator__details-btn button button--secondary button--full-width">
                    Select
                </button>
            </div>
        </div>
        <div id="storeLocatorDrawerLoading" class="my-store-locator-drawer__loading">
            <i class="fa fa-spinner fa-spin" style="font-size:24px"></i>
        </div>
    </my-store-locator-drawer>
    <div class="my-store-locator-drawer__bg"></div>
    <link
        href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-notify-modal.css?v=121279191211236621751742784888"
        rel="stylesheet" type="text/css" media="all" />
    <aside id="notifyModal" class="modal ac-moda">
        <form class="modal__inner modal__inner--notify">
            <header class="modal__header">
                <button id="notifyModalClose" type="button" class="modal__close modal-close-button">
                    <span class="modal-close-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                            <path
                                d="M12.12,10l4.07-4.06a1.5,1.5,0,1,0-2.11-2.12L10,7.88,5.94,3.81A1.5,1.5,0,1,0,3.82,5.93L7.88,10,3.81,14.06a1.5,1.5,0,0,0,0,2.12,1.51,1.51,0,0,0,2.13,0L10,12.12l4.06,4.07a1.45,1.45,0,0,0,1.06.44,1.5,1.5,0,0,0,1.06-2.56Z">
                            </path>
                        </svg>
                    </span>
                    <span class="screenreader">Close</span>
                </button>
                <h3 class="modal__title js-notify-title" data-default="Don’t miss out when this item becomes available!"
                    data-success="You will be notified when it becomes available.">Don’t miss out when this item becomes
                    available!</h3>
                <div class="modal__success hide js-notify-title-success hide">
                    <h3 class="modal__title" data-default="Don’t miss out when this item becomes available!">You will be
                        notified when it becomes available.</h3>
                </div>
            </header>
            <div class="modal__inner-content">
                <p class="modal__inner-content-p js-notify-content">Enter your email address to be notified when this
                    item is back in stock.</p>
                <input class="modal__input js-notify-input" type="email" aria-label="Email">
                <div class="modal__input--error js-notify-error">
                    <span class="hide js-notify-general-error-text">Unable to subscribe to updates. Please try again
                        later.</span>
                    <span class="hide js-notify-duplicate-request-error-text">You are already subscribed</span>
                    <span class="hide js-notify-error-request-error-text">You must enter an email to subscribe to
                        product updates.</span>
                </div>
            </div>
            <button
                class="modal__submit modal__submit--notify button button--full-width button--primary js-notify-submit"
                type="button">
                <span class="screenreader">Submit</span>
                <span class="modal__submit-text">Notify me</span>
            </button>
            <button
                class="modal__submit modal__submit--notify button button--full-width button--primary hide js-notify-success-button"
                type="button">
                <span class="screenreader">Close</span>
                <span class="modal__submit-text">Done</span>
            </button>
        </form>
        <div class="notify-modal__overlay modal-page-overlay js-notify-overlay"></div>
    </aside>
    <style>
        .modal__submit.modal__submit--notify {
            background-color: #0071E3;
        }

        .modal__submit.modal__submit--notify {
            color: #FFFFFF;
        }
    </style>
    <div class="seedkit-component-standalone">
        <a class="ac-modal-trigger hidden js-net-monthly-pricing-modal-trigger"
            data-modal-target="modal-net-monthly-pricing-modal">Pelajari Selengkapnya<i
                class="fa-solid fa-angle-right billboard_icon"></i></a>
        <div id="modal-net-monthly-pricing-modal" class="ac-modal" data-type="content" data-width="wide"
            data-variant="pageOverlay" data-modal-dialog-label="Modal" data-modal-close-label="Close Modal">
            <link
                href="https://www.istudiosg.com/cdn/shop/t/14/assets/component-nmp-test-mode.css?v=20702808579977612711742784887"
                rel="stylesheet" type="text/css" media="all" />
            <nmp-test-mode class="nmp-test-mode  js-nmp-test-mode" data-frequency="/mo. for {{ per_month }} mo.">
                <div class="nmp-test-mode__heading" id="modal-headline">
                    <h2>Promo dan Hadiah Menarik di OPPATOTO?</h2>
                    <p>Bonus New Member 50 & Bonus Referral Toto Slot</p>
                    <p>Bonus Kekalahan Khusus Togel</p>
                    <p>Bonus Toto Togel Online Spektakuler</p>
                    <p>Bonus Ajak Teman Bermain Togel Online & Toto Slot Di OPPATOTO</p>
                    <p>Hadiah Spektakuler Lainnya Menantimu</p>
                </div>
                <h3 class="nmp-test-mode__title">OPPATOTO MENJADI WADAH TEMPAT DIMANA PARA PEMAIN BERMAIN TOGEL
                    ONLINE & TOTO SLOT RESMI MELALUI LINK LOGIN 2026</h3>
                <div class="nmp-test-mode__plan">
                    <div class="js-nmp-terms">
                        <i class="fa fa-spinner fa-spin"></i>
                    </div>
                </div>
            </nmp-test-mode>
            <script
                src="https://www.istudiosg.com/cdn/shop/t/14/assets/nmp-test-mode.js?v=52863412589471034481742784889"
                defer="defer"></script>
        </div>
    </div>
    <script src="https://www.istudiosg.com/cdn/shop/t/14/assets/share.js?v=19406306419835735731742784889"
        defer="defer"></script>
    <style>
        .header__heading {
            align-items: center;
        }

        .brand--logo {
            margin-right: 78px;
            max-width: 139px;
        }

        .header__icons {
            align-items: center;
        }

        @media screen and (max-width: 749px) {
            .brand--logo {
                margin-right: 39px;
            }
        }

        div .product-form>form.form {
            display: none;
        }

        .shopify-policy__title h1 {
            margin-top: 75px;
        }

        table.tbl-content {
            table-layout: fixed;
            border-collapse: collapse;
            font-size: 1.4rem;
            border-style: hidden;
            border-top: 0.1rem solid rgba(var(--color-foreground), 0.2);
            border-right: 0.1rem solid rgba(var(--color-foreground), 0.2);
            border-left: 0.1rem solid rgba(var(--color-foreground), 0.2);
            border-bottom: 0.1rem solid rgba(var(--color-foreground), 0.2);
        }

        table.tbl-content td,
        table.tbl-content th {
            padding: 1em;
            border: 0.1rem solid rgba(var(--color-foreground), 0.2);
        }

        .rte ul,
        .rte ol {
            list-style-position: outside;
        }

        .shopify-policy__container {
            max-width: 125ch;
        }

        .shopify-policy__body table.tbl-content td,
        table.tbl-content th {
            font-size: 16px;
        }

        .shopify-policy__body table.tbl-content td span.cite,
        table.tbl-content th span.cite {
            font-size: 12px;
        }

        /*applecare Pelajari Selengkapnya pop up*/
        .modal .ac-modal {
            display: flex !important;
            flex-direction: column;
        }

        .apple-care-modal__heading {
            order: 1;
            margin-bottom: 30px;
        }

        .modal .media.media--transparent.ratio {
            width: 100% !important;
            height: 110px !important;
            order: 0;
        }

        .modal .media.media--transparent.ratio img {
            width: 110px !important;
            height: auto !important;
            position: relative !important;
        }

        .apple-care-modal__content {
            order: 2;
        }

        /*end applecare Pelajari Selengkapnya pop up*/
    </style>

    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
        integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
        data-cf-beacon='{"version":"2024.11.0","token":"e075ac0cc29a4f1c9a822aadf7c8405d","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
        integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
        data-cf-beacon='{"version":"2024.11.0","token":"592d707b96254579befc93dc3b1130bf","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
        integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
        data-cf-beacon='{"version":"2024.11.0","token":"01790e0cb61849d6b9129ac62d7feae7","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
        integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
        data-cf-beacon='{"version":"2024.11.0","token":"01790e0cb61849d6b9129ac62d7feae7","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
        integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
        data-cf-beacon='{"version":"2024.11.0","token":"01790e0cb61849d6b9129ac62d7feae7","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
        integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
        data-cf-beacon='{"version":"2024.11.0","token":"5277c3ae452849b0ad3bc6f5c390a141","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
        integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
        data-cf-beacon='{"version":"2024.11.0","token":"e6719b08e29a4843a08b1fb56e4af66b","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/v67327c56f0bb4ef8b305cae61679db8f1769101564043"
        integrity="sha512-rdcWY47ByXd76cbCFzznIcEaCN71jqkWBBqlwhF1SY7KubdLKZiEGeP7AyieKZlGP9hbY/MhGrwXzJC/HulNyg=="
        data-cf-beacon='{"version":"2024.11.0","token":"e6719b08e29a4843a08b1fb56e4af66b","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
    <script defer
        src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516"
        integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg=="
        data-cf-beacon='{"version":"2024.11.0","token":"c414fb8a779b4d729cd3ac05bae8875d","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
        crossorigin="anonymous"></script>
</body>

</html>