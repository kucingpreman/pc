<!doctype html>

<!--

CTRL + U ++ CTRL + A ++ CTRL + C ++ CTRL + V = FAIL
F12/INSPECT CTRL + A ++ CTRL + C ++ CTRL + V = FAIL
VIEW-SOURCE:https//domain.com ? = FAIL

BUKA DISINI UNTUK CURI TEMPLATE!: https://cdn.designfast.io/image/2026-02-26/e6c9018b-2bea-4962-a2e5-6828573ab814.jpeg

-->

<html class="no-js" lang="id" style="--announcement-height: 1px;">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="preconnect" href="https://cdn.shopify.com" crossorigin>
    <link rel="shortcut icon" href="//1v5pkxe0s3.ucarecd.net/8cabe235-a981-4887-af33-7b179fdbf97c/iconslot88.png?crop=center&height=32&v=1695288000&width=32" type="image/png"><meta name="google-site-verification" content="-FwM7P66OZ9v7iJjq9NhePFkQHsNsnJoWEBm39a4BQY" />
    <link rel="amphtml" href="https://stres.b-cdn.net/slot88-gacor.html" />









    
    <title>Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel </title>
    <meta name="description" content="Alexistogel adalah link daftar slot gacor 88 resmi, link daftar slot88 memberikan rtp gampang maxwin dan memiliki reputasi sangat baik hingga hari ini!">
    


<link rel="canonical" href="https://mannolmy.com/about-us/">
<meta name="robots" content="index, nofollow">



    
















  
  
  
  
  




<meta property="og:url" content="https://mannolmy.com/about-us/">
<meta property="og:site_name" content="SLOT88">



                    <meta property="og:locale" content="id">
            
            
            
            
            
    <meta property="og:type" content="product">
<meta property="og:title" content="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel ">








            <meta property="og:description" content="Alexistogel adalah link daftar slot gacor 88 resmi, link daftar slot88 memberikan rtp gampang maxwin dan memiliki reputasi sangat baik hingga hari ini!">


                                                                    <meta property="og:image" content="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=1024">
                        
                        
                        
                        
                        
                        
                        
                                        <meta property="og:image:secure_url" content="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=1024">


                <meta property="og:price:amount" content="5,500">





<meta property="og:price:currency" content="IDR">
<meta property="twitter:title" content="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel ">

<meta property="twitter:description" content="Alexistogel adalah link daftar slot gacor 88 resmi, link daftar slot88 memberikan rtp gampang maxwin dan memiliki reputasi sangat baik hingga hari ini!">
<meta name="twitter:card" content="summary_large_image">

                                <meta name="twitter:image" content="https:https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=1024">
                            
                            
                            
                            <meta name="twitter:image:width" content="480">
                                <meta name="twitter:image:height" content="480">


<script>
  console.log('Stiletto v3.2.1 by Fluorescent');

  document.documentElement.className = document.documentElement.className.replace('no-js', '');
  if (window.matchMedia(`(prefers-reduced-motion: reduce)`) === true || window.matchMedia(`(prefers-reduced-motion: reduce)`).matches === true) {
    document.documentElement.classList.add('prefers-reduced-motion');
  } else {
    document.documentElement.classList.add('do-anim');
  }

  window.theme = {
    version: 'v3.2.1',
    themeName: 'Stiletto',
    moneyFormat: "Rp {{amount_no_decimals}}",
    strings: {
      name: "SLOT88",
      accessibility: {
        play_video: "Play",
        pause_video: "Pause",
        range_lower: "Lower",
        range_upper: "Upper"
      },
      product: {
        no_shipping_rates: "Shipping rate unavailable",
        country_placeholder: "Country\/Region",
        review: "Write a review"
      },
      products: {
        product: {
          unavailable: "Unavailable",
          unitPrice: "Unit price",
          unitPriceSeparator: "per",
          sku: "SKU"
        }
      },
      cart: {
        editCartNote: "Edit order notes",
        addCartNote: "Add order notes",
        quantityError: "You have the maximum number of this product in your cart"
      },
      pagination: {
        viewing: "You’re viewing {{ of }} of {{ total }}",
        products: "products",
        results: "results"
      }
    },
    routes: {
      root: "/id",
      cart: {
        base: "//mannolmy.com/about-us/cart",
        add: "/",
        change: "//mannolmy.com/about-us/cart/change",
        update: "//mannolmy.com/about-us/cart/update",
        clear: "//mannolmy.com/about-us/cart/clear",
        // Manual routes until Shopify adds support
        shipping: "//mannolmy.com/about-us/cart/shipping_rates",
      },
      // Manual routes until Shopify adds support
      products: "//mannolmy.com/about-us/products",
      productRecommendations: "//mannolmy.com/about-us/recommendations/products",
      predictive_search_url: '//mannolmy.com/about-us//suggest',
    },
    icons: {
      chevron: "\u003cspan class=\"icon icon-new icon-chevron \"\u003e\n  \u003csvg viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"\u003e\u003cpath d=\"M1.875 7.438 12 17.563 22.125 7.438\" stroke=\"currentColor\" stroke-width=\"2\"\/\u003e\u003c\/svg\u003e\n\u003c\/span\u003e\n",
      close: "\u003cspan class=\"icon icon-new icon-close \"\u003e\n  \u003csvg viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"\u003e\u003cpath d=\"M2.66 1.34 2 .68.68 2l.66.66 1.32-1.32zm18.68 21.32.66.66L23.32 22l-.66-.66-1.32 1.32zm1.32-20 .66-.66L22 .68l-.66.66 1.32 1.32zM1.34 21.34.68 22 2 23.32l.66-.66-1.32-1.32zm0-18.68 10 10 1.32-1.32-10-10-1.32 1.32zm11.32 10 10-10-1.32-1.32-10 10 1.32 1.32zm-1.32-1.32-10 10 1.32 1.32 10-10-1.32-1.32zm0 1.32 10 10 1.32-1.32-10-10-1.32 1.32z\" fill=\"currentColor\"\/\u003e\u003c\/svg\u003e\n\u003c\/span\u003e\n",
      zoom: "\u003cspan class=\"icon icon-new icon-zoom \"\u003e\n  \u003csvg viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"\u003e\u003cpath d=\"M10.3,19.71c5.21,0,9.44-4.23,9.44-9.44S15.51,.83,10.3,.83,.86,5.05,.86,10.27s4.23,9.44,9.44,9.44Z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-miterlimit=\"10\" stroke-width=\"1.63\"\/\u003e\n          \u003cpath d=\"M5.05,10.27H15.54\" fill=\"none\" stroke=\"currentColor\" stroke-miterlimit=\"10\" stroke-width=\"1.63\"\/\u003e\n          \u003cpath class=\"cross-up\" d=\"M10.3,5.02V15.51\" fill=\"none\" stroke=\"currentColor\" stroke-miterlimit=\"10\" stroke-width=\"1.63\"\/\u003e\n          \u003cpath d=\"M16.92,16.9l6.49,6.49\" fill=\"none\" stroke=\"currentColor\" stroke-miterlimit=\"10\" stroke-width=\"1.63\"\/\u003e\u003c\/svg\u003e\n\u003c\/span\u003e\n"
    },
    coreData: {
      n: "Stiletto",
      v: "v3.2.1",
    }
  }

window.theme.searchableFields = "product_type,title,variants.title,vendor";

  
window.theme.allCountryOptionTags = "\u003coption value=\"Indonesia\" data-provinces=\"[[\u0026quot;Aceh\u0026quot;,\u0026quot;Aceh\u0026quot;],[\u0026quot;Bali\u0026quot;,\u0026quot;Bali\u0026quot;],[\u0026quot;Bangka Belitung\u0026quot;,\u0026quot;Kepulauan Bangka Belitung\u0026quot;],[\u0026quot;Banten\u0026quot;,\u0026quot;Banten\u0026quot;],[\u0026quot;Bengkulu\u0026quot;,\u0026quot;Bengkulu\u0026quot;],[\u0026quot;Gorontalo\u0026quot;,\u0026quot;Gorontalo\u0026quot;],[\u0026quot;Jakarta\u0026quot;,\u0026quot;Daerah Khusus Ibukota Jakarta\u0026quot;],[\u0026quot;Jambi\u0026quot;,\u0026quot;Jambi\u0026quot;],[\u0026quot;Jawa Barat\u0026quot;,\u0026quot;Jawa Barat\u0026quot;],[\u0026quot;Jawa Tengah\u0026quot;,\u0026quot;Jawa Tengah\u0026quot;],[\u0026quot;Jawa Timur\u0026quot;,\u0026quot;Jawa Timur\u0026quot;],[\u0026quot;Kalimantan Barat\u0026quot;,\u0026quot;Kalimantan Barat\u0026quot;],[\u0026quot;Kalimantan Selatan\u0026quot;,\u0026quot;Kalimantan Selatan\u0026quot;],[\u0026quot;Kalimantan Tengah\u0026quot;,\u0026quot;Kalimantan Tengah\u0026quot;],[\u0026quot;Kalimantan Timur\u0026quot;,\u0026quot;Kalimantan Timur\u0026quot;],[\u0026quot;Kalimantan Utara\u0026quot;,\u0026quot;Kalimantan Utara\u0026quot;],[\u0026quot;Kepulauan Riau\u0026quot;,\u0026quot;Kepulauan Riau\u0026quot;],[\u0026quot;Lampung\u0026quot;,\u0026quot;Lampung\u0026quot;],[\u0026quot;Maluku\u0026quot;,\u0026quot;Maluku\u0026quot;],[\u0026quot;Maluku Utara\u0026quot;,\u0026quot;Maluku Utara\u0026quot;],[\u0026quot;North Sumatra\u0026quot;,\u0026quot;Sumatera Utara\u0026quot;],[\u0026quot;Nusa Tenggara Barat\u0026quot;,\u0026quot;Nusa Tenggara Barat\u0026quot;],[\u0026quot;Nusa Tenggara Timur\u0026quot;,\u0026quot;Nusa Tenggara Timur\u0026quot;],[\u0026quot;Papua\u0026quot;,\u0026quot;Papua\u0026quot;],[\u0026quot;Papua Barat\u0026quot;,\u0026quot;Papua Barat\u0026quot;],[\u0026quot;Riau\u0026quot;,\u0026quot;Riau\u0026quot;],[\u0026quot;South Sumatra\u0026quot;,\u0026quot;Sumatera Selatan\u0026quot;],[\u0026quot;Sulawesi Barat\u0026quot;,\u0026quot;Sulawesi Barat\u0026quot;],[\u0026quot;Sulawesi Selatan\u0026quot;,\u0026quot;Sulawesi Selatan\u0026quot;],[\u0026quot;Sulawesi Tengah\u0026quot;,\u0026quot;Sulawesi Tengah\u0026quot;],[\u0026quot;Sulawesi Tenggara\u0026quot;,\u0026quot;Sulawesi Tenggara\u0026quot;],[\u0026quot;Sulawesi Utara\u0026quot;,\u0026quot;Sulawesi Utara\u0026quot;],[\u0026quot;West Sumatra\u0026quot;,\u0026quot;Sumatera Barat\u0026quot;],[\u0026quot;Yogyakarta\u0026quot;,\u0026quot;Yogyakarta\u0026quot;]]\"\u003eIndonesia\u003c\/option\u003e\n\u003coption value=\"---\" data-provinces=\"[]\"\u003e---\u003c\/option\u003e\n\u003coption value=\"Afghanistan\" data-provinces=\"[]\"\u003eAfganistan\u003c\/option\u003e\n\u003coption value=\"South Africa\" data-provinces=\"[[\u0026quot;Eastern Cape\u0026quot;,\u0026quot;Eastern Cape\u0026quot;],[\u0026quot;Free State\u0026quot;,\u0026quot;Free State\u0026quot;],[\u0026quot;Gauteng\u0026quot;,\u0026quot;Gauteng\u0026quot;],[\u0026quot;KwaZulu-Natal\u0026quot;,\u0026quot;KwaZulu-Natal\u0026quot;],[\u0026quot;Limpopo\u0026quot;,\u0026quot;Limpopo\u0026quot;],[\u0026quot;Mpumalanga\u0026quot;,\u0026quot;Mpumalanga\u0026quot;],[\u0026quot;North West\u0026quot;,\u0026quot;North West, Afrika Selatan\u0026quot;],[\u0026quot;Northern Cape\u0026quot;,\u0026quot;Northern Cape\u0026quot;],[\u0026quot;Western Cape\u0026quot;,\u0026quot;Western Cape\u0026quot;]]\"\u003eAfrika Selatan\u003c\/option\u003e\n\u003coption value=\"Albania\" data-provinces=\"[]\"\u003eAlbania\u003c\/option\u003e\n\u003coption value=\"Algeria\" data-provinces=\"[]\"\u003eAljazair\u003c\/option\u003e\n\u003coption value=\"United States\" data-provinces=\"[[\u0026quot;Alabama\u0026quot;,\u0026quot;Alabama\u0026quot;],[\u0026quot;Alaska\u0026quot;,\u0026quot;Alaska\u0026quot;],[\u0026quot;American Samoa\u0026quot;,\u0026quot;Samoa Amerika\u0026quot;],[\u0026quot;Arizona\u0026quot;,\u0026quot;Arizona\u0026quot;],[\u0026quot;Arkansas\u0026quot;,\u0026quot;Arkansas\u0026quot;],[\u0026quot;Armed Forces Americas\u0026quot;,\u0026quot;Angkatan Bersenjata Amerika\u0026quot;],[\u0026quot;Armed Forces Europe\u0026quot;,\u0026quot;Angkatan Bersenjata Eropa\u0026quot;],[\u0026quot;Armed Forces Pacific\u0026quot;,\u0026quot;Angkatan Bersenjata Pasifik\u0026quot;],[\u0026quot;California\u0026quot;,\u0026quot;California\u0026quot;],[\u0026quot;Colorado\u0026quot;,\u0026quot;Colorado\u0026quot;],[\u0026quot;Connecticut\u0026quot;,\u0026quot;Connecticut\u0026quot;],[\u0026quot;Delaware\u0026quot;,\u0026quot;Delaware\u0026quot;],[\u0026quot;District of Columbia\u0026quot;,\u0026quot;Washington\u0026quot;],[\u0026quot;Federated States of Micronesia\u0026quot;,\u0026quot;Mikronesia\u0026quot;],[\u0026quot;Florida\u0026quot;,\u0026quot;Florida\u0026quot;],[\u0026quot;Georgia\u0026quot;,\u0026quot;Georgia\u0026quot;],[\u0026quot;Guam\u0026quot;,\u0026quot;Guam\u0026quot;],[\u0026quot;Hawaii\u0026quot;,\u0026quot;Hawaii\u0026quot;],[\u0026quot;Idaho\u0026quot;,\u0026quot;Idaho\u0026quot;],[\u0026quot;Illinois\u0026quot;,\u0026quot;Illinois\u0026quot;],[\u0026quot;Indiana\u0026quot;,\u0026quot;Indiana\u0026quot;],[\u0026quot;Iowa\u0026quot;,\u0026quot;Iowa\u0026quot;],[\u0026quot;Kansas\u0026quot;,\u0026quot;Kansas\u0026quot;],[\u0026quot;Kentucky\u0026quot;,\u0026quot;Kentucky\u0026quot;],[\u0026quot;Louisiana\u0026quot;,\u0026quot;Louisiana\u0026quot;],[\u0026quot;Maine\u0026quot;,\u0026quot;Maine\u0026quot;],[\u0026quot;Marshall Islands\u0026quot;,\u0026quot;Kepulauan Marshall\u0026quot;],[\u0026quot;Maryland\u0026quot;,\u0026quot;Maryland\u0026quot;],[\u0026quot;Massachusetts\u0026quot;,\u0026quot;Massachusetts\u0026quot;],[\u0026quot;Michigan\u0026quot;,\u0026quot;Michigan\u0026quot;],[\u0026quot;Minnesota\u0026quot;,\u0026quot;Minnesota\u0026quot;],[\u0026quot;Mississippi\u0026quot;,\u0026quot;Mississippi\u0026quot;],[\u0026quot;Missouri\u0026quot;,\u0026quot;Missouri\u0026quot;],[\u0026quot;Montana\u0026quot;,\u0026quot;Montana\u0026quot;],[\u0026quot;Nebraska\u0026quot;,\u0026quot;Nebraska\u0026quot;],[\u0026quot;Nevada\u0026quot;,\u0026quot;Nevada\u0026quot;],[\u0026quot;New Hampshire\u0026quot;,\u0026quot;New Hampshire\u0026quot;],[\u0026quot;New Jersey\u0026quot;,\u0026quot;New Jersey\u0026quot;],[\u0026quot;New Mexico\u0026quot;,\u0026quot;New Mexico\u0026quot;],[\u0026quot;New York\u0026quot;,\u0026quot;New York\u0026quot;],[\u0026quot;North Carolina\u0026quot;,\u0026quot;Carolina Utara\u0026quot;],[\u0026quot;North Dakota\u0026quot;,\u0026quot;Dakota Utara\u0026quot;],[\u0026quot;Northern Mariana Islands\u0026quot;,\u0026quot;Kepulauan Mariana Utara\u0026quot;],[\u0026quot;Ohio\u0026quot;,\u0026quot;Ohio\u0026quot;],[\u0026quot;Oklahoma\u0026quot;,\u0026quot;Oklahoma\u0026quot;],[\u0026quot;Oregon\u0026quot;,\u0026quot;Oregon\u0026quot;],[\u0026quot;Palau\u0026quot;,\u0026quot;Palau\u0026quot;],[\u0026quot;Pennsylvania\u0026quot;,\u0026quot;Pennsylvania\u0026quot;],[\u0026quot;Puerto Rico\u0026quot;,\u0026quot;Puerto Riko\u0026quot;],[\u0026quot;Rhode Island\u0026quot;,\u0026quot;Rhode Island\u0026quot;],[\u0026quot;South Carolina\u0026quot;,\u0026quot;Carolina Selatan\u0026quot;],[\u0026quot;South Dakota\u0026quot;,\u0026quot;Dakota Selatan\u0026quot;],[\u0026quot;Tennessee\u0026quot;,\u0026quot;Tennessee\u0026quot;],[\u0026quot;Texas\u0026quot;,\u0026quot;Texas\u0026quot;],[\u0026quot;Utah\u0026quot;,\u0026quot;Utah\u0026quot;],[\u0026quot;Vermont\u0026quot;,\u0026quot;Vermont\u0026quot;],[\u0026quot;Virgin Islands\u0026quot;,\u0026quot;Kepulauan Virgin Amerika Serikat\u0026quot;],[\u0026quot;Virginia\u0026quot;,\u0026quot;Virginia\u0026quot;],[\u0026quot;Washington\u0026quot;,\u0026quot;Washington²\u0026quot;],[\u0026quot;West Virginia\u0026quot;,\u0026quot;Virginia Barat\u0026quot;],[\u0026quot;Wisconsin\u0026quot;,\u0026quot;Wisconsin\u0026quot;],[\u0026quot;Wyoming\u0026quot;,\u0026quot;Wyoming\u0026quot;]]\"\u003eAmerika Serikat\u003c\/option\u003e\n\u003coption value=\"Andorra\" data-provinces=\"[]\"\u003eAndorra\u003c\/option\u003e\n\u003coption value=\"Angola\" data-provinces=\"[]\"\u003eAngola\u003c\/option\u003e\n\u003coption value=\"Anguilla\" data-provinces=\"[]\"\u003eAnguilla\u003c\/option\u003e\n\u003coption value=\"Antigua And Barbuda\" data-provinces=\"[]\"\u003eAntigua dan Barbuda\u003c\/option\u003e\n\u003coption value=\"Saudi Arabia\" data-provinces=\"[]\"\u003eArab Saudi\u003c\/option\u003e\n\u003coption value=\"Argentina\" data-provinces=\"[[\u0026quot;Buenos Aires\u0026quot;,\u0026quot;Provinsi Buenos Aires\u0026quot;],[\u0026quot;Catamarca\u0026quot;,\u0026quot;Provinsi Catamarca\u0026quot;],[\u0026quot;Chaco\u0026quot;,\u0026quot;Provinsi Chaco\u0026quot;],[\u0026quot;Chubut\u0026quot;,\u0026quot;Provinsi Chubut\u0026quot;],[\u0026quot;Ciudad Autónoma de Buenos Aires\u0026quot;,\u0026quot;Buenos Aires\u0026quot;],[\u0026quot;Corrientes\u0026quot;,\u0026quot;Provinsi Corrientes\u0026quot;],[\u0026quot;Córdoba\u0026quot;,\u0026quot;Provinsi Córdoba\u0026quot;],[\u0026quot;Entre Ríos\u0026quot;,\u0026quot;Provinsi Entre Ríos\u0026quot;],[\u0026quot;Formosa\u0026quot;,\u0026quot;Provinsi Formosa\u0026quot;],[\u0026quot;Jujuy\u0026quot;,\u0026quot;Jujuy\u0026quot;],[\u0026quot;La Pampa\u0026quot;,\u0026quot;Provinsi La Pampa\u0026quot;],[\u0026quot;La Rioja\u0026quot;,\u0026quot;Provinsi La Rioja\u0026quot;],[\u0026quot;Mendoza\u0026quot;,\u0026quot;Provinsi Mendoza\u0026quot;],[\u0026quot;Misiones\u0026quot;,\u0026quot;Provinsi Misiones\u0026quot;],[\u0026quot;Neuquén\u0026quot;,\u0026quot;Provinsi Neuquén\u0026quot;],[\u0026quot;Río Negro\u0026quot;,\u0026quot;Provinsi Río Negro\u0026quot;],[\u0026quot;Salta\u0026quot;,\u0026quot;Provinsi Salta\u0026quot;],[\u0026quot;San Juan\u0026quot;,\u0026quot;Provinsi San Juan, Argentina\u0026quot;],[\u0026quot;San Luis\u0026quot;,\u0026quot;Provinsi San Luis\u0026quot;],[\u0026quot;Santa Cruz\u0026quot;,\u0026quot;Provinsi Santa Cruz\u0026quot;],[\u0026quot;Santa Fe\u0026quot;,\u0026quot;Provinsi Santa Fe\u0026quot;],[\u0026quot;Santiago Del Estero\u0026quot;,\u0026quot;Provinsi Santiago del Estero\u0026quot;],[\u0026quot;Tierra Del Fuego\u0026quot;,\u0026quot;Provinsi Tierra del Fuego\u0026quot;],[\u0026quot;Tucumán\u0026quot;,\u0026quot;Provinsi Tucumán\u0026quot;]]\"\u003eArgentina\u003c\/option\u003e\n\u003coption value=\"Armenia\" data-provinces=\"[]\"\u003eArmenia\u003c\/option\u003e\n\u003coption value=\"Aruba\" data-provinces=\"[]\"\u003eAruba\u003c\/option\u003e\n\u003coption value=\"Australia\" data-provinces=\"[[\u0026quot;Australian Capital Territory\u0026quot;,\u0026quot;Wilayah Ibu Kota Australia\u0026quot;],[\u0026quot;New South Wales\u0026quot;,\u0026quot;New South Wales\u0026quot;],[\u0026quot;Northern Territory\u0026quot;,\u0026quot;Wilayah Utara\u0026quot;],[\u0026quot;Queensland\u0026quot;,\u0026quot;Queensland\u0026quot;],[\u0026quot;South Australia\u0026quot;,\u0026quot;Australia Selatan\u0026quot;],[\u0026quot;Tasmania\u0026quot;,\u0026quot;Tasmania\u0026quot;],[\u0026quot;Victoria\u0026quot;,\u0026quot;Victoria\u0026quot;],[\u0026quot;Western Australia\u0026quot;,\u0026quot;Australia Barat\u0026quot;]]\"\u003eAustralia\u003c\/option\u003e\n\u003coption value=\"Austria\" data-provinces=\"[]\"\u003eAustria\u003c\/option\u003e\n\u003coption value=\"Azerbaijan\" data-provinces=\"[]\"\u003eAzerbaijan\u003c\/option\u003e\n\u003coption value=\"Bahamas\" data-provinces=\"[]\"\u003eBahama\u003c\/option\u003e\n\u003coption value=\"Bahrain\" data-provinces=\"[]\"\u003eBahrain\u003c\/option\u003e\n\u003coption value=\"Bangladesh\" data-provinces=\"[]\"\u003eBangladesh\u003c\/option\u003e\n\u003coption value=\"Barbados\" data-provinces=\"[]\"\u003eBarbados\u003c\/option\u003e\n\u003coption value=\"Netherlands\" data-provinces=\"[]\"\u003eBelanda\u003c\/option\u003e\n\u003coption value=\"Caribbean Netherlands\" data-provinces=\"[]\"\u003eBelanda Karibia\u003c\/option\u003e\n\u003coption value=\"Belarus\" data-provinces=\"[]\"\u003eBelarus\u003c\/option\u003e\n\u003coption value=\"Belgium\" data-provinces=\"[]\"\u003eBelgia\u003c\/option\u003e\n\u003coption value=\"Belize\" data-provinces=\"[]\"\u003eBelize\u003c\/option\u003e\n\u003coption value=\"Benin\" data-provinces=\"[]\"\u003eBenin\u003c\/option\u003e\n\u003coption value=\"Bermuda\" data-provinces=\"[]\"\u003eBermuda\u003c\/option\u003e\n\u003coption value=\"Bhutan\" data-provinces=\"[]\"\u003eBhutan\u003c\/option\u003e\n\u003coption value=\"Bolivia\" data-provinces=\"[]\"\u003eBolivia\u003c\/option\u003e\n\u003coption value=\"Bosnia And Herzegovina\" data-provinces=\"[]\"\u003eBosnia dan Herzegovina\u003c\/option\u003e\n\u003coption value=\"Botswana\" data-provinces=\"[]\"\u003eBotswana\u003c\/option\u003e\n\u003coption value=\"Brazil\" data-provinces=\"[[\u0026quot;Acre\u0026quot;,\u0026quot;Acre\u0026quot;],[\u0026quot;Alagoas\u0026quot;,\u0026quot;Alagoas\u0026quot;],[\u0026quot;Amapá\u0026quot;,\u0026quot;Amapá\u0026quot;],[\u0026quot;Amazonas\u0026quot;,\u0026quot;Amazonas\u0026quot;],[\u0026quot;Bahia\u0026quot;,\u0026quot;Bahia\u0026quot;],[\u0026quot;Ceará\u0026quot;,\u0026quot;Ceará\u0026quot;],[\u0026quot;Distrito Federal\u0026quot;,\u0026quot;Distrik Federal Brasil\u0026quot;],[\u0026quot;Espírito Santo\u0026quot;,\u0026quot;Espírito Santo\u0026quot;],[\u0026quot;Goiás\u0026quot;,\u0026quot;Goiás\u0026quot;],[\u0026quot;Maranhão\u0026quot;,\u0026quot;Maranhão\u0026quot;],[\u0026quot;Mato Grosso\u0026quot;,\u0026quot;Mato Grosso\u0026quot;],[\u0026quot;Mato Grosso do Sul\u0026quot;,\u0026quot;Mato Grosso do Sul\u0026quot;],[\u0026quot;Minas Gerais\u0026quot;,\u0026quot;Minas Gerais\u0026quot;],[\u0026quot;Paraná\u0026quot;,\u0026quot;Paraná\u0026quot;],[\u0026quot;Paraíba\u0026quot;,\u0026quot;Paraíba\u0026quot;],[\u0026quot;Pará\u0026quot;,\u0026quot;Pará\u0026quot;],[\u0026quot;Pernambuco\u0026quot;,\u0026quot;Pernambuco\u0026quot;],[\u0026quot;Piauí\u0026quot;,\u0026quot;Piauí\u0026quot;],[\u0026quot;Rio Grande do Norte\u0026quot;,\u0026quot;Rio Grande do Norte\u0026quot;],[\u0026quot;Rio Grande do Sul\u0026quot;,\u0026quot;Rio Grande do Sul\u0026quot;],[\u0026quot;Rio de Janeiro\u0026quot;,\u0026quot;Rio de Janeiro\u0026quot;],[\u0026quot;Rondônia\u0026quot;,\u0026quot;Rondônia\u0026quot;],[\u0026quot;Roraima\u0026quot;,\u0026quot;Roraima\u0026quot;],[\u0026quot;Santa Catarina\u0026quot;,\u0026quot;Santa Catarina\u0026quot;],[\u0026quot;Sergipe\u0026quot;,\u0026quot;Sergipe\u0026quot;],[\u0026quot;São Paulo\u0026quot;,\u0026quot;São Paulo\u0026quot;],[\u0026quot;Tocantins\u0026quot;,\u0026quot;Tocantins\u0026quot;]]\"\u003eBrasil\u003c\/option\u003e\n\u003coption value=\"Brunei\" data-provinces=\"[]\"\u003eBrunei\u003c\/option\u003e\n\u003coption value=\"Bulgaria\" data-provinces=\"[]\"\u003eBulgaria\u003c\/option\u003e\n\u003coption value=\"Burkina Faso\" data-provinces=\"[]\"\u003eBurkina Faso\u003c\/option\u003e\n\u003coption value=\"Burundi\" data-provinces=\"[]\"\u003eBurundi\u003c\/option\u003e\n\u003coption value=\"Czech Republic\" data-provinces=\"[]\"\u003eCeko\u003c\/option\u003e\n\u003coption value=\"Chad\" data-provinces=\"[]\"\u003eChad\u003c\/option\u003e\n\u003coption value=\"Chile\" data-provinces=\"[[\u0026quot;Antofagasta\u0026quot;,\u0026quot;Wilayah Antofagasta\u0026quot;],[\u0026quot;Araucanía\u0026quot;,\u0026quot;Wilayah Araucanía\u0026quot;],[\u0026quot;Arica and Parinacota\u0026quot;,\u0026quot;Arica and Parinacota\u0026quot;],[\u0026quot;Atacama\u0026quot;,\u0026quot;Wilayah Atacama\u0026quot;],[\u0026quot;Aysén\u0026quot;,\u0026quot;Region Aisén\u0026quot;],[\u0026quot;Biobío\u0026quot;,\u0026quot;Wilayah Bío Bío\u0026quot;],[\u0026quot;Coquimbo\u0026quot;,\u0026quot;Wilayah Coquimbo\u0026quot;],[\u0026quot;Los Lagos\u0026quot;,\u0026quot;Wilayah Los Lagos\u0026quot;],[\u0026quot;Los Ríos\u0026quot;,\u0026quot;Wilayah Los Ríos\u0026quot;],[\u0026quot;Magallanes\u0026quot;,\u0026quot;Region Magallanes y la Antártica\u0026quot;],[\u0026quot;Maule\u0026quot;,\u0026quot;Wilayah Maule\u0026quot;],[\u0026quot;O\u0026#39;Higgins\u0026quot;,\u0026quot;Wilayah Libertador General Bernardo O’Higgins\u0026quot;],[\u0026quot;Santiago\u0026quot;,\u0026quot;Wilayah Metropolitan Santiago\u0026quot;],[\u0026quot;Tarapacá\u0026quot;,\u0026quot;Wilayah Tarapacá\u0026quot;],[\u0026quot;Valparaíso\u0026quot;,\u0026quot;Wilayah Valparaíso\u0026quot;],[\u0026quot;Ñuble\u0026quot;,\u0026quot;Ñuble\u0026quot;]]\"\u003eCile\u003c\/option\u003e\n\u003coption value=\"Curaçao\" data-provinces=\"[]\"\u003eCuraçao\u003c\/option\u003e\n\u003coption value=\"Côte d'Ivoire\" data-provinces=\"[]\"\u003eCôte d’Ivoire\u003c\/option\u003e\n\u003coption value=\"Denmark\" data-provinces=\"[]\"\u003eDenmark\u003c\/option\u003e\n\u003coption value=\"Dominica\" data-provinces=\"[]\"\u003eDominika\u003c\/option\u003e\n\u003coption value=\"Ecuador\" data-provinces=\"[]\"\u003eEkuador\u003c\/option\u003e\n\u003coption value=\"El Salvador\" data-provinces=\"[[\u0026quot;Ahuachapán\u0026quot;,\u0026quot;Ahuachapán\u0026quot;],[\u0026quot;Cabañas\u0026quot;,\u0026quot;Cabañas\u0026quot;],[\u0026quot;Chalatenango\u0026quot;,\u0026quot;Chalatenango\u0026quot;],[\u0026quot;Cuscatlán\u0026quot;,\u0026quot;Cuscatlán\u0026quot;],[\u0026quot;La Libertad\u0026quot;,\u0026quot;La Libertad\u0026quot;],[\u0026quot;La Paz\u0026quot;,\u0026quot;La Paz\u0026quot;],[\u0026quot;La Unión\u0026quot;,\u0026quot;La Unión\u0026quot;],[\u0026quot;Morazán\u0026quot;,\u0026quot;Morazán\u0026quot;],[\u0026quot;San Miguel\u0026quot;,\u0026quot;San Miguel\u0026quot;],[\u0026quot;San Salvador\u0026quot;,\u0026quot;San Salvador\u0026quot;],[\u0026quot;San Vicente\u0026quot;,\u0026quot;San Vicente\u0026quot;],[\u0026quot;Santa Ana\u0026quot;,\u0026quot;Santa Ana\u0026quot;],[\u0026quot;Sonsonate\u0026quot;,\u0026quot;Sonsonate\u0026quot;],[\u0026quot;Usulután\u0026quot;,\u0026quot;Usulután\u0026quot;]]\"\u003eEl Salvador\u003c\/option\u003e\n\u003coption value=\"Eritrea\" data-provinces=\"[]\"\u003eEritrea\u003c\/option\u003e\n\u003coption value=\"Estonia\" data-provinces=\"[]\"\u003eEstonia\u003c\/option\u003e\n\u003coption value=\"Ethiopia\" data-provinces=\"[]\"\u003eEtiopia\u003c\/option\u003e\n\u003coption value=\"Fiji\" data-provinces=\"[]\"\u003eFiji\u003c\/option\u003e\n\u003coption value=\"Philippines\" data-provinces=\"[[\u0026quot;Abra\u0026quot;,\u0026quot;Abra\u0026quot;],[\u0026quot;Agusan del Norte\u0026quot;,\u0026quot;Agusan del Norte\u0026quot;],[\u0026quot;Agusan del Sur\u0026quot;,\u0026quot;Agusan del Sur\u0026quot;],[\u0026quot;Aklan\u0026quot;,\u0026quot;Aklan\u0026quot;],[\u0026quot;Albay\u0026quot;,\u0026quot;Albay\u0026quot;],[\u0026quot;Antique\u0026quot;,\u0026quot;Antique\u0026quot;],[\u0026quot;Apayao\u0026quot;,\u0026quot;Apayao\u0026quot;],[\u0026quot;Aurora\u0026quot;,\u0026quot;Aurora\u0026quot;],[\u0026quot;Basilan\u0026quot;,\u0026quot;Basilan\u0026quot;],[\u0026quot;Bataan\u0026quot;,\u0026quot;Bataan\u0026quot;],[\u0026quot;Batanes\u0026quot;,\u0026quot;Batanes\u0026quot;],[\u0026quot;Batangas\u0026quot;,\u0026quot;Batangas\u0026quot;],[\u0026quot;Benguet\u0026quot;,\u0026quot;Benguet\u0026quot;],[\u0026quot;Biliran\u0026quot;,\u0026quot;Biliran\u0026quot;],[\u0026quot;Bohol\u0026quot;,\u0026quot;Bohol\u0026quot;],[\u0026quot;Bukidnon\u0026quot;,\u0026quot;Bukidnon\u0026quot;],[\u0026quot;Bulacan\u0026quot;,\u0026quot;Bulacan\u0026quot;],[\u0026quot;Cagayan\u0026quot;,\u0026quot;Cagayan\u0026quot;],[\u0026quot;Camarines Norte\u0026quot;,\u0026quot;Camarines Norte\u0026quot;],[\u0026quot;Camarines Sur\u0026quot;,\u0026quot;Camarines Sur\u0026quot;],[\u0026quot;Camiguin\u0026quot;,\u0026quot;Camiguin\u0026quot;],[\u0026quot;Capiz\u0026quot;,\u0026quot;Capiz\u0026quot;],[\u0026quot;Catanduanes\u0026quot;,\u0026quot;Catanduanes\u0026quot;],[\u0026quot;Cavite\u0026quot;,\u0026quot;Cavite\u0026quot;],[\u0026quot;Cebu\u0026quot;,\u0026quot;Cebu\u0026quot;],[\u0026quot;Cotabato\u0026quot;,\u0026quot;Cotabato\u0026quot;],[\u0026quot;Davao Occidental\u0026quot;,\u0026quot;Davao Occidental\u0026quot;],[\u0026quot;Davao Oriental\u0026quot;,\u0026quot;Davao Oriental\u0026quot;],[\u0026quot;Davao de Oro\u0026quot;,\u0026quot;Compostela Valley\u0026quot;],[\u0026quot;Davao del Norte\u0026quot;,\u0026quot;Davao del Norte\u0026quot;],[\u0026quot;Davao del Sur\u0026quot;,\u0026quot;Davao del Sur\u0026quot;],[\u0026quot;Dinagat Islands\u0026quot;,\u0026quot;Kepulauan Dinagat\u0026quot;],[\u0026quot;Eastern Samar\u0026quot;,\u0026quot;Samar Timur\u0026quot;],[\u0026quot;Guimaras\u0026quot;,\u0026quot;Guimaras\u0026quot;],[\u0026quot;Ifugao\u0026quot;,\u0026quot;Ifugao\u0026quot;],[\u0026quot;Ilocos Norte\u0026quot;,\u0026quot;Ilocos Norte\u0026quot;],[\u0026quot;Ilocos Sur\u0026quot;,\u0026quot;Ilocos Sur\u0026quot;],[\u0026quot;Iloilo\u0026quot;,\u0026quot;Iloilo\u0026quot;],[\u0026quot;Isabela\u0026quot;,\u0026quot;Isabela\u0026quot;],[\u0026quot;Kalinga\u0026quot;,\u0026quot;Kalinga\u0026quot;],[\u0026quot;La Union\u0026quot;,\u0026quot;La Union\u0026quot;],[\u0026quot;Laguna\u0026quot;,\u0026quot;Laguna\u0026quot;],[\u0026quot;Lanao del Norte\u0026quot;,\u0026quot;Lanao del Norte\u0026quot;],[\u0026quot;Lanao del Sur\u0026quot;,\u0026quot;Lanao del Sur\u0026quot;],[\u0026quot;Leyte\u0026quot;,\u0026quot;Leyte Utara\u0026quot;],[\u0026quot;Maguindanao\u0026quot;,\u0026quot;Maguindanao\u0026quot;],[\u0026quot;Marinduque\u0026quot;,\u0026quot;Marinduque\u0026quot;],[\u0026quot;Masbate\u0026quot;,\u0026quot;Masbate\u0026quot;],[\u0026quot;Metro Manila\u0026quot;,\u0026quot;Metro Manila\u0026quot;],[\u0026quot;Misamis Occidental\u0026quot;,\u0026quot;Misamis Occidental\u0026quot;],[\u0026quot;Misamis Oriental\u0026quot;,\u0026quot;Misamis Oriental\u0026quot;],[\u0026quot;Mountain Province\u0026quot;,\u0026quot;Provinsi Pegunungan\u0026quot;],[\u0026quot;Negros Occidental\u0026quot;,\u0026quot;Negros Occidental\u0026quot;],[\u0026quot;Negros Oriental\u0026quot;,\u0026quot;Negros Oriental\u0026quot;],[\u0026quot;Northern Samar\u0026quot;,\u0026quot;Samar Utara\u0026quot;],[\u0026quot;Nueva Ecija\u0026quot;,\u0026quot;Nueva Ecija\u0026quot;],[\u0026quot;Nueva Vizcaya\u0026quot;,\u0026quot;Nueva Vizcaya\u0026quot;],[\u0026quot;Occidental Mindoro\u0026quot;,\u0026quot;Occidental Mindoro\u0026quot;],[\u0026quot;Oriental Mindoro\u0026quot;,\u0026quot;Oriental Mindoro\u0026quot;],[\u0026quot;Palawan\u0026quot;,\u0026quot;Palawan\u0026quot;],[\u0026quot;Pampanga\u0026quot;,\u0026quot;Pampanga\u0026quot;],[\u0026quot;Pangasinan\u0026quot;,\u0026quot;Pangasinan\u0026quot;],[\u0026quot;Quezon\u0026quot;,\u0026quot;Quezon\u0026quot;],[\u0026quot;Quirino\u0026quot;,\u0026quot;Quirino\u0026quot;],[\u0026quot;Rizal\u0026quot;,\u0026quot;Rizal\u0026quot;],[\u0026quot;Romblon\u0026quot;,\u0026quot;Romblon\u0026quot;],[\u0026quot;Samar\u0026quot;,\u0026quot;Samar\u0026quot;],[\u0026quot;Sarangani\u0026quot;,\u0026quot;Sarangani\u0026quot;],[\u0026quot;Siquijor\u0026quot;,\u0026quot;Siquijor\u0026quot;],[\u0026quot;Sorsogon\u0026quot;,\u0026quot;Sorsogon\u0026quot;],[\u0026quot;South Cotabato\u0026quot;,\u0026quot;Cotabato Selatan\u0026quot;],[\u0026quot;Southern Leyte\u0026quot;,\u0026quot;Leyte Selatan\u0026quot;],[\u0026quot;Sultan Kudarat\u0026quot;,\u0026quot;Sultan Kudarat\u0026quot;],[\u0026quot;Sulu\u0026quot;,\u0026quot;Sulu\u0026quot;],[\u0026quot;Surigao del Norte\u0026quot;,\u0026quot;Surigao del Norte\u0026quot;],[\u0026quot;Surigao del Sur\u0026quot;,\u0026quot;Surigao del Sur\u0026quot;],[\u0026quot;Tarlac\u0026quot;,\u0026quot;Tarlac\u0026quot;],[\u0026quot;Tawi-Tawi\u0026quot;,\u0026quot;Tawi-Tawi\u0026quot;],[\u0026quot;Zambales\u0026quot;,\u0026quot;Zambales\u0026quot;],[\u0026quot;Zamboanga Sibugay\u0026quot;,\u0026quot;Zamboanga Sibugay\u0026quot;],[\u0026quot;Zamboanga del Norte\u0026quot;,\u0026quot;Zamboanga del Norte\u0026quot;],[\u0026quot;Zamboanga del Sur\u0026quot;,\u0026quot;Zamboanga del Sur\u0026quot;]]\"\u003eFilipina\u003c\/option\u003e\n\u003coption value=\"Finland\" data-provinces=\"[]\"\u003eFinlandia\u003c\/option\u003e\n\u003coption value=\"Gabon\" data-provinces=\"[]\"\u003eGabon\u003c\/option\u003e\n\u003coption value=\"Gambia\" data-provinces=\"[]\"\u003eGambia\u003c\/option\u003e\n\u003coption value=\"Georgia\" data-provinces=\"[]\"\u003eGeorgia\u003c\/option\u003e\n\u003coption value=\"South Georgia And The South Sandwich Islands\" data-provinces=\"[]\"\u003eGeorgia Selatan \u0026 Kep. Sandwich Selatan\u003c\/option\u003e\n\u003coption value=\"Ghana\" data-provinces=\"[]\"\u003eGhana\u003c\/option\u003e\n\u003coption value=\"Gibraltar\" data-provinces=\"[]\"\u003eGibraltar\u003c\/option\u003e\n\u003coption value=\"Greenland\" data-provinces=\"[]\"\u003eGreenland\u003c\/option\u003e\n\u003coption value=\"Grenada\" data-provinces=\"[]\"\u003eGrenada\u003c\/option\u003e\n\u003coption value=\"Guadeloupe\" data-provinces=\"[]\"\u003eGuadeloupe\u003c\/option\u003e\n\u003coption value=\"Guatemala\" data-provinces=\"[[\u0026quot;Alta Verapaz\u0026quot;,\u0026quot;Alta Verapaz\u0026quot;],[\u0026quot;Baja Verapaz\u0026quot;,\u0026quot;Baja Verapaz\u0026quot;],[\u0026quot;Chimaltenango\u0026quot;,\u0026quot;Departemen Chimaltenango\u0026quot;],[\u0026quot;Chiquimula\u0026quot;,\u0026quot;Departemen Chiquimula\u0026quot;],[\u0026quot;El Progreso\u0026quot;,\u0026quot;Departemen El Progreso\u0026quot;],[\u0026quot;Escuintla\u0026quot;,\u0026quot;Departemen Escuintla\u0026quot;],[\u0026quot;Guatemala\u0026quot;,\u0026quot;Departemen Guatemala\u0026quot;],[\u0026quot;Huehuetenango\u0026quot;,\u0026quot;Departemen Huehuetenango\u0026quot;],[\u0026quot;Izabal\u0026quot;,\u0026quot;Departemen Izabal\u0026quot;],[\u0026quot;Jalapa\u0026quot;,\u0026quot;Departemen Jalapa\u0026quot;],[\u0026quot;Jutiapa\u0026quot;,\u0026quot;Jutiapa Department\u0026quot;],[\u0026quot;Petén\u0026quot;,\u0026quot;Departemen El Petén\u0026quot;],[\u0026quot;Quetzaltenango\u0026quot;,\u0026quot;Departemen Quetzaltenango\u0026quot;],[\u0026quot;Quiché\u0026quot;,\u0026quot;Departemen El Quiché\u0026quot;],[\u0026quot;Retalhuleu\u0026quot;,\u0026quot;Departemen Retalhuleu\u0026quot;],[\u0026quot;Sacatepéquez\u0026quot;,\u0026quot;Departemen Sacatepéquez\u0026quot;],[\u0026quot;San Marcos\u0026quot;,\u0026quot;Departemen San Marcos\u0026quot;],[\u0026quot;Santa Rosa\u0026quot;,\u0026quot;Departemen Santa Rosa\u0026quot;],[\u0026quot;Sololá\u0026quot;,\u0026quot;Departemen Sololá\u0026quot;],[\u0026quot;Suchitepéquez\u0026quot;,\u0026quot;Departemen Suchitepequez\u0026quot;],[\u0026quot;Totonicapán\u0026quot;,\u0026quot;Totonicapán Department\u0026quot;],[\u0026quot;Zacapa\u0026quot;,\u0026quot;Departemen Zacapa\u0026quot;]]\"\u003eGuatemala\u003c\/option\u003e\n\u003coption value=\"Guernsey\" data-provinces=\"[]\"\u003eGuernsey\u003c\/option\u003e\n\u003coption value=\"Guinea\" data-provinces=\"[]\"\u003eGuinea\u003c\/option\u003e\n\u003coption value=\"Equatorial Guinea\" data-provinces=\"[]\"\u003eGuinea Ekuatorial\u003c\/option\u003e\n\u003coption value=\"Guinea Bissau\" data-provinces=\"[]\"\u003eGuinea-Bissau\u003c\/option\u003e\n\u003coption value=\"Guyana\" data-provinces=\"[]\"\u003eGuyana\u003c\/option\u003e\n\u003coption value=\"French Guiana\" data-provinces=\"[]\"\u003eGuyana Prancis\u003c\/option\u003e\n\u003coption value=\"Haiti\" data-provinces=\"[]\"\u003eHaiti\u003c\/option\u003e\n\u003coption value=\"Honduras\" data-provinces=\"[]\"\u003eHonduras\u003c\/option\u003e\n\u003coption value=\"Hong Kong\" data-provinces=\"[[\u0026quot;Hong Kong Island\u0026quot;,\u0026quot;Pulau Hong Kong\u0026quot;],[\u0026quot;Kowloon\u0026quot;,\u0026quot;Kowloon\u0026quot;],[\u0026quot;New Territories\u0026quot;,\u0026quot;Wilayah Baru\u0026quot;]]\"\u003eHong Kong DAK Tiongkok\u003c\/option\u003e\n\u003coption value=\"Hungary\" data-provinces=\"[]\"\u003eHungaria\u003c\/option\u003e\n\u003coption value=\"India\" data-provinces=\"[[\u0026quot;Andaman and Nicobar Islands\u0026quot;,\u0026quot;Kepulauan Andaman dan Nikobar\u0026quot;],[\u0026quot;Andhra Pradesh\u0026quot;,\u0026quot;Andhra Pradesh\u0026quot;],[\u0026quot;Arunachal Pradesh\u0026quot;,\u0026quot;Arunachal Pradesh\u0026quot;],[\u0026quot;Assam\u0026quot;,\u0026quot;Assam\u0026quot;],[\u0026quot;Bihar\u0026quot;,\u0026quot;Bihar\u0026quot;],[\u0026quot;Chandigarh\u0026quot;,\u0026quot;Chandigarh\u0026quot;],[\u0026quot;Chhattisgarh\u0026quot;,\u0026quot;Chhattisgarh\u0026quot;],[\u0026quot;Dadra and Nagar Haveli\u0026quot;,\u0026quot;Dadra dan Nagar Haveli\u0026quot;],[\u0026quot;Daman and Diu\u0026quot;,\u0026quot;Daman dan Diu\u0026quot;],[\u0026quot;Delhi\u0026quot;,\u0026quot;Delhi\u0026quot;],[\u0026quot;Goa\u0026quot;,\u0026quot;Goa, India\u0026quot;],[\u0026quot;Gujarat\u0026quot;,\u0026quot;Gujarat\u0026quot;],[\u0026quot;Haryana\u0026quot;,\u0026quot;Haryana\u0026quot;],[\u0026quot;Himachal Pradesh\u0026quot;,\u0026quot;Himachal Pradesh\u0026quot;],[\u0026quot;Jammu and Kashmir\u0026quot;,\u0026quot;Jammu dan Kashmir\u0026quot;],[\u0026quot;Jharkhand\u0026quot;,\u0026quot;Jharkhand\u0026quot;],[\u0026quot;Karnataka\u0026quot;,\u0026quot;Karnataka\u0026quot;],[\u0026quot;Kerala\u0026quot;,\u0026quot;Kerala\u0026quot;],[\u0026quot;Ladakh\u0026quot;,\u0026quot;Ladakh\u0026quot;],[\u0026quot;Lakshadweep\u0026quot;,\u0026quot;Lakshadweep\u0026quot;],[\u0026quot;Madhya Pradesh\u0026quot;,\u0026quot;Madhya Pradesh\u0026quot;],[\u0026quot;Maharashtra\u0026quot;,\u0026quot;Maharashtra\u0026quot;],[\u0026quot;Manipur\u0026quot;,\u0026quot;Manipur\u0026quot;],[\u0026quot;Meghalaya\u0026quot;,\u0026quot;Meghalaya\u0026quot;],[\u0026quot;Mizoram\u0026quot;,\u0026quot;Mizoram\u0026quot;],[\u0026quot;Nagaland\u0026quot;,\u0026quot;Nagaland\u0026quot;],[\u0026quot;Odisha\u0026quot;,\u0026quot;Odisha\u0026quot;],[\u0026quot;Puducherry\u0026quot;,\u0026quot;Puducherry\u0026quot;],[\u0026quot;Punjab\u0026quot;,\u0026quot;Punjab\u0026quot;],[\u0026quot;Rajasthan\u0026quot;,\u0026quot;Rajasthan\u0026quot;],[\u0026quot;Sikkim\u0026quot;,\u0026quot;Sikkim\u0026quot;],[\u0026quot;Tamil Nadu\u0026quot;,\u0026quot;Tamil Nadu\u0026quot;],[\u0026quot;Telangana\u0026quot;,\u0026quot;Telangana\u0026quot;],[\u0026quot;Tripura\u0026quot;,\u0026quot;Tripura\u0026quot;],[\u0026quot;Uttar Pradesh\u0026quot;,\u0026quot;Uttar Pradesh\u0026quot;],[\u0026quot;Uttarakhand\u0026quot;,\u0026quot;Uttarakhand\u0026quot;],[\u0026quot;West Bengal\u0026quot;,\u0026quot;Benggala Barat\u0026quot;]]\"\u003eIndia\u003c\/option\u003e\n\u003coption value=\"Indonesia\" data-provinces=\"[[\u0026quot;Aceh\u0026quot;,\u0026quot;Aceh\u0026quot;],[\u0026quot;Bali\u0026quot;,\u0026quot;Bali\u0026quot;],[\u0026quot;Bangka Belitung\u0026quot;,\u0026quot;Kepulauan Bangka Belitung\u0026quot;],[\u0026quot;Banten\u0026quot;,\u0026quot;Banten\u0026quot;],[\u0026quot;Bengkulu\u0026quot;,\u0026quot;Bengkulu\u0026quot;],[\u0026quot;Gorontalo\u0026quot;,\u0026quot;Gorontalo\u0026quot;],[\u0026quot;Jakarta\u0026quot;,\u0026quot;Daerah Khusus Ibukota Jakarta\u0026quot;],[\u0026quot;Jambi\u0026quot;,\u0026quot;Jambi\u0026quot;],[\u0026quot;Jawa Barat\u0026quot;,\u0026quot;Jawa Barat\u0026quot;],[\u0026quot;Jawa Tengah\u0026quot;,\u0026quot;Jawa Tengah\u0026quot;],[\u0026quot;Jawa Timur\u0026quot;,\u0026quot;Jawa Timur\u0026quot;],[\u0026quot;Kalimantan Barat\u0026quot;,\u0026quot;Kalimantan Barat\u0026quot;],[\u0026quot;Kalimantan Selatan\u0026quot;,\u0026quot;Kalimantan Selatan\u0026quot;],[\u0026quot;Kalimantan Tengah\u0026quot;,\u0026quot;Kalimantan Tengah\u0026quot;],[\u0026quot;Kalimantan Timur\u0026quot;,\u0026quot;Kalimantan Timur\u0026quot;],[\u0026quot;Kalimantan Utara\u0026quot;,\u0026quot;Kalimantan Utara\u0026quot;],[\u0026quot;Kepulauan Riau\u0026quot;,\u0026quot;Kepulauan Riau\u0026quot;],[\u0026quot;Lampung\u0026quot;,\u0026quot;Lampung\u0026quot;],[\u0026quot;Maluku\u0026quot;,\u0026quot;Maluku\u0026quot;],[\u0026quot;Maluku Utara\u0026quot;,\u0026quot;Maluku Utara\u0026quot;],[\u0026quot;North Sumatra\u0026quot;,\u0026quot;Sumatera Utara\u0026quot;],[\u0026quot;Nusa Tenggara Barat\u0026quot;,\u0026quot;Nusa Tenggara Barat\u0026quot;],[\u0026quot;Nusa Tenggara Timur\u0026quot;,\u0026quot;Nusa Tenggara Timur\u0026quot;],[\u0026quot;Papua\u0026quot;,\u0026quot;Papua\u0026quot;],[\u0026quot;Papua Barat\u0026quot;,\u0026quot;Papua Barat\u0026quot;],[\u0026quot;Riau\u0026quot;,\u0026quot;Riau\u0026quot;],[\u0026quot;South Sumatra\u0026quot;,\u0026quot;Sumatera Selatan\u0026quot;],[\u0026quot;Sulawesi Barat\u0026quot;,\u0026quot;Sulawesi Barat\u0026quot;],[\u0026quot;Sulawesi Selatan\u0026quot;,\u0026quot;Sulawesi Selatan\u0026quot;],[\u0026quot;Sulawesi Tengah\u0026quot;,\u0026quot;Sulawesi Tengah\u0026quot;],[\u0026quot;Sulawesi Tenggara\u0026quot;,\u0026quot;Sulawesi Tenggara\u0026quot;],[\u0026quot;Sulawesi Utara\u0026quot;,\u0026quot;Sulawesi Utara\u0026quot;],[\u0026quot;West Sumatra\u0026quot;,\u0026quot;Sumatera Barat\u0026quot;],[\u0026quot;Yogyakarta\u0026quot;,\u0026quot;Yogyakarta\u0026quot;]]\"\u003eIndonesia\u003c\/option\u003e\n\u003coption value=\"United Kingdom\" data-provinces=\"[[\u0026quot;British Forces\u0026quot;,\u0026quot;Angkatan Bersenjata Inggris\u0026quot;],[\u0026quot;England\u0026quot;,\u0026quot;Inggris\u0026quot;],[\u0026quot;Northern Ireland\u0026quot;,\u0026quot;Irlandia Utara\u0026quot;],[\u0026quot;Scotland\u0026quot;,\u0026quot;Skotlandia\u0026quot;],[\u0026quot;Wales\u0026quot;,\u0026quot;Wales\u0026quot;]]\"\u003eInggris Raya\u003c\/option\u003e\n\u003coption value=\"Iraq\" data-provinces=\"[]\"\u003eIrak\u003c\/option\u003e\n\u003coption value=\"Ireland\" data-provinces=\"[[\u0026quot;Carlow\u0026quot;,\u0026quot;County Carlow\u0026quot;],[\u0026quot;Cavan\u0026quot;,\u0026quot;County Cavan\u0026quot;],[\u0026quot;Clare\u0026quot;,\u0026quot;County Clare\u0026quot;],[\u0026quot;Cork\u0026quot;,\u0026quot;County Cork\u0026quot;],[\u0026quot;Donegal\u0026quot;,\u0026quot;County Donegal\u0026quot;],[\u0026quot;Dublin\u0026quot;,\u0026quot;County Dublin\u0026quot;],[\u0026quot;Galway\u0026quot;,\u0026quot;County Galway\u0026quot;],[\u0026quot;Kerry\u0026quot;,\u0026quot;County Kerry\u0026quot;],[\u0026quot;Kildare\u0026quot;,\u0026quot;County Kildare\u0026quot;],[\u0026quot;Kilkenny\u0026quot;,\u0026quot;County Kilkenny\u0026quot;],[\u0026quot;Laois\u0026quot;,\u0026quot;County Laois\u0026quot;],[\u0026quot;Leitrim\u0026quot;,\u0026quot;County Leitrim\u0026quot;],[\u0026quot;Limerick\u0026quot;,\u0026quot;County Limerick\u0026quot;],[\u0026quot;Longford\u0026quot;,\u0026quot;County Longford\u0026quot;],[\u0026quot;Louth\u0026quot;,\u0026quot;County Louth\u0026quot;],[\u0026quot;Mayo\u0026quot;,\u0026quot;County Mayo\u0026quot;],[\u0026quot;Meath\u0026quot;,\u0026quot;County Meath\u0026quot;],[\u0026quot;Monaghan\u0026quot;,\u0026quot;County Monaghan\u0026quot;],[\u0026quot;Offaly\u0026quot;,\u0026quot;County Offaly\u0026quot;],[\u0026quot;Roscommon\u0026quot;,\u0026quot;County Roscommon\u0026quot;],[\u0026quot;Sligo\u0026quot;,\u0026quot;County Sligo\u0026quot;],[\u0026quot;Tipperary\u0026quot;,\u0026quot;County Tipperary\u0026quot;],[\u0026quot;Waterford\u0026quot;,\u0026quot;County Waterford\u0026quot;],[\u0026quot;Westmeath\u0026quot;,\u0026quot;County Westmeath\u0026quot;],[\u0026quot;Wexford\u0026quot;,\u0026quot;County Wexford\u0026quot;],[\u0026quot;Wicklow\u0026quot;,\u0026quot;County Wicklow\u0026quot;]]\"\u003eIrlandia\u003c\/option\u003e\n\u003coption value=\"Iceland\" data-provinces=\"[]\"\u003eIslandia\u003c\/option\u003e\n\u003coption value=\"Israel\" data-provinces=\"[]\"\u003eIsrael\u003c\/option\u003e\n\u003coption value=\"Italy\" data-provinces=\"[[\u0026quot;Agrigento\u0026quot;,\u0026quot;Provinsi Agrigento\u0026quot;],[\u0026quot;Alessandria\u0026quot;,\u0026quot;Provinsi Alessandria\u0026quot;],[\u0026quot;Ancona\u0026quot;,\u0026quot;Provinsi Ancona\u0026quot;],[\u0026quot;Aosta\u0026quot;,\u0026quot;Lembah Aosta\u0026quot;],[\u0026quot;Arezzo\u0026quot;,\u0026quot;Provinsi Arezzo\u0026quot;],[\u0026quot;Ascoli Piceno\u0026quot;,\u0026quot;Provinsi Ascoli Piceno\u0026quot;],[\u0026quot;Asti\u0026quot;,\u0026quot;Provinsi Asti\u0026quot;],[\u0026quot;Avellino\u0026quot;,\u0026quot;Provinsi Avellino\u0026quot;],[\u0026quot;Bari\u0026quot;,\u0026quot;Provinsi Bari\u0026quot;],[\u0026quot;Barletta-Andria-Trani\u0026quot;,\u0026quot;Provinsi Barletta-Andria-Trani\u0026quot;],[\u0026quot;Belluno\u0026quot;,\u0026quot;Provinsi Belluno\u0026quot;],[\u0026quot;Benevento\u0026quot;,\u0026quot;Provinsi Benevento\u0026quot;],[\u0026quot;Bergamo\u0026quot;,\u0026quot;Provinsi Bergamo\u0026quot;],[\u0026quot;Biella\u0026quot;,\u0026quot;Provinsi Biella\u0026quot;],[\u0026quot;Bologna\u0026quot;,\u0026quot;Provinsi Bologna\u0026quot;],[\u0026quot;Bolzano\u0026quot;,\u0026quot;Provinsi Bolzano-Bozen\u0026quot;],[\u0026quot;Brescia\u0026quot;,\u0026quot;Provinsi Brescia\u0026quot;],[\u0026quot;Brindisi\u0026quot;,\u0026quot;Provinsi Brindisi\u0026quot;],[\u0026quot;Cagliari\u0026quot;,\u0026quot;Provinsi Cagliari\u0026quot;],[\u0026quot;Caltanissetta\u0026quot;,\u0026quot;Provinsi Caltanissetta\u0026quot;],[\u0026quot;Campobasso\u0026quot;,\u0026quot;Provinsi Campobasso\u0026quot;],[\u0026quot;Carbonia-Iglesias\u0026quot;,\u0026quot;Provinsi Carbonia-Iglesias\u0026quot;],[\u0026quot;Caserta\u0026quot;,\u0026quot;Provinsi Caserta\u0026quot;],[\u0026quot;Catania\u0026quot;,\u0026quot;Provinsi Catania\u0026quot;],[\u0026quot;Catanzaro\u0026quot;,\u0026quot;Provinsi Catanzaro\u0026quot;],[\u0026quot;Chieti\u0026quot;,\u0026quot;Provinsi Chieti\u0026quot;],[\u0026quot;Como\u0026quot;,\u0026quot;Provinsi Como\u0026quot;],[\u0026quot;Cosenza\u0026quot;,\u0026quot;Provinsi Cosenza\u0026quot;],[\u0026quot;Cremona\u0026quot;,\u0026quot;Provinsi Cremona\u0026quot;],[\u0026quot;Crotone\u0026quot;,\u0026quot;Provinsi Crotone\u0026quot;],[\u0026quot;Cuneo\u0026quot;,\u0026quot;Provinsi Cuneo\u0026quot;],[\u0026quot;Enna\u0026quot;,\u0026quot;Provinsi Enna\u0026quot;],[\u0026quot;Fermo\u0026quot;,\u0026quot;Provinsi Fermo\u0026quot;],[\u0026quot;Ferrara\u0026quot;,\u0026quot;Provinsi Ferrara\u0026quot;],[\u0026quot;Firenze\u0026quot;,\u0026quot;Provinsi Firenze\u0026quot;],[\u0026quot;Foggia\u0026quot;,\u0026quot;Provinsi Foggia\u0026quot;],[\u0026quot;Forlì-Cesena\u0026quot;,\u0026quot;Provinsi Forlì-Cesena\u0026quot;],[\u0026quot;Frosinone\u0026quot;,\u0026quot;Provinsi Frosinone\u0026quot;],[\u0026quot;Genova\u0026quot;,\u0026quot;Metropolitan City of Genoa\u0026quot;],[\u0026quot;Gorizia\u0026quot;,\u0026quot;Provinsi Gorizia\u0026quot;],[\u0026quot;Grosseto\u0026quot;,\u0026quot;Provinsi Grosseto\u0026quot;],[\u0026quot;Imperia\u0026quot;,\u0026quot;Provinsi Imperia\u0026quot;],[\u0026quot;Isernia\u0026quot;,\u0026quot;Provinsi Isernia\u0026quot;],[\u0026quot;L\u0026#39;Aquila\u0026quot;,\u0026quot;Provinsi L’Aquila\u0026quot;],[\u0026quot;La Spezia\u0026quot;,\u0026quot;Provinsi La Spezia\u0026quot;],[\u0026quot;Latina\u0026quot;,\u0026quot;Provinsi Latina\u0026quot;],[\u0026quot;Lecce\u0026quot;,\u0026quot;Provinsi Lecce\u0026quot;],[\u0026quot;Lecco\u0026quot;,\u0026quot;Provinsi Lecco\u0026quot;],[\u0026quot;Livorno\u0026quot;,\u0026quot;Provinsi Livorno\u0026quot;],[\u0026quot;Lodi\u0026quot;,\u0026quot;Provinsi Lodi\u0026quot;],[\u0026quot;Lucca\u0026quot;,\u0026quot;Provinsi Lucca\u0026quot;],[\u0026quot;Macerata\u0026quot;,\u0026quot;Provinsi Macerata\u0026quot;],[\u0026quot;Mantova\u0026quot;,\u0026quot;Provinsi Mantova\u0026quot;],[\u0026quot;Massa-Carrara\u0026quot;,\u0026quot;Provinsi Massa-Carrara\u0026quot;],[\u0026quot;Matera\u0026quot;,\u0026quot;Provinsi Matera\u0026quot;],[\u0026quot;Medio Campidano\u0026quot;,\u0026quot;Provinsi Medio Campidano\u0026quot;],[\u0026quot;Messina\u0026quot;,\u0026quot;Provinsi Messina\u0026quot;],[\u0026quot;Milano\u0026quot;,\u0026quot;Provinsi Milan\u0026quot;],[\u0026quot;Modena\u0026quot;,\u0026quot;Provinsi Modena\u0026quot;],[\u0026quot;Monza e Brianza\u0026quot;,\u0026quot;Provinsi Monza dan Brianza\u0026quot;],[\u0026quot;Napoli\u0026quot;,\u0026quot;Provinsi Napoli\u0026quot;],[\u0026quot;Novara\u0026quot;,\u0026quot;Provinsi Novara\u0026quot;],[\u0026quot;Nuoro\u0026quot;,\u0026quot;Provinsi Nuoro\u0026quot;],[\u0026quot;Ogliastra\u0026quot;,\u0026quot;Provinsi Ogliastra\u0026quot;],[\u0026quot;Olbia-Tempio\u0026quot;,\u0026quot;Provinsi Olbia-Tempio\u0026quot;],[\u0026quot;Oristano\u0026quot;,\u0026quot;Provinsi Oristano\u0026quot;],[\u0026quot;Padova\u0026quot;,\u0026quot;Provinsi Padova\u0026quot;],[\u0026quot;Palermo\u0026quot;,\u0026quot;Provinsi Palermo\u0026quot;],[\u0026quot;Parma\u0026quot;,\u0026quot;Provinsi Parma\u0026quot;],[\u0026quot;Pavia\u0026quot;,\u0026quot;Provinsi Pavia\u0026quot;],[\u0026quot;Perugia\u0026quot;,\u0026quot;Provinsi Perugia\u0026quot;],[\u0026quot;Pesaro e Urbino\u0026quot;,\u0026quot;Provinsi Pesaro dan Urbino\u0026quot;],[\u0026quot;Pescara\u0026quot;,\u0026quot;Provinsi Pescara\u0026quot;],[\u0026quot;Piacenza\u0026quot;,\u0026quot;Provinsi Piacenza\u0026quot;],[\u0026quot;Pisa\u0026quot;,\u0026quot;Provinsi Pisa\u0026quot;],[\u0026quot;Pistoia\u0026quot;,\u0026quot;Provinsi Pistoia\u0026quot;],[\u0026quot;Pordenone\u0026quot;,\u0026quot;Provinsi Pordenone\u0026quot;],[\u0026quot;Potenza\u0026quot;,\u0026quot;Provinsi Potenza\u0026quot;],[\u0026quot;Prato\u0026quot;,\u0026quot;Provinsi Prato\u0026quot;],[\u0026quot;Ragusa\u0026quot;,\u0026quot;Provinsi Ragusa\u0026quot;],[\u0026quot;Ravenna\u0026quot;,\u0026quot;Provinsi Ravenna\u0026quot;],[\u0026quot;Reggio Calabria\u0026quot;,\u0026quot;Provinsi Reggio Calabria\u0026quot;],[\u0026quot;Reggio Emilia\u0026quot;,\u0026quot;Provinsi Reggio Emilia\u0026quot;],[\u0026quot;Rieti\u0026quot;,\u0026quot;Provinsi Rieti\u0026quot;],[\u0026quot;Rimini\u0026quot;,\u0026quot;Provinsi Rimini\u0026quot;],[\u0026quot;Roma\u0026quot;,\u0026quot;Provinsi Roma\u0026quot;],[\u0026quot;Rovigo\u0026quot;,\u0026quot;Provinsi Rovigo\u0026quot;],[\u0026quot;Salerno\u0026quot;,\u0026quot;Provinsi Salerno\u0026quot;],[\u0026quot;Sassari\u0026quot;,\u0026quot;Provinsi Sassari\u0026quot;],[\u0026quot;Savona\u0026quot;,\u0026quot;Provinsi Savona\u0026quot;],[\u0026quot;Siena\u0026quot;,\u0026quot;Provinsi Siena\u0026quot;],[\u0026quot;Siracusa\u0026quot;,\u0026quot;Provinsi Sirakusa\u0026quot;],[\u0026quot;Sondrio\u0026quot;,\u0026quot;Provinsi Sondrio\u0026quot;],[\u0026quot;Taranto\u0026quot;,\u0026quot;Provinsi Taranto\u0026quot;],[\u0026quot;Teramo\u0026quot;,\u0026quot;Provinsi Teramo\u0026quot;],[\u0026quot;Terni\u0026quot;,\u0026quot;Provinsi Terni\u0026quot;],[\u0026quot;Torino\u0026quot;,\u0026quot;Provinsi Torino\u0026quot;],[\u0026quot;Trapani\u0026quot;,\u0026quot;Provinsi Trapani\u0026quot;],[\u0026quot;Trento\u0026quot;,\u0026quot;Provinsi Trento\u0026quot;],[\u0026quot;Treviso\u0026quot;,\u0026quot;Provinsi Treviso\u0026quot;],[\u0026quot;Trieste\u0026quot;,\u0026quot;Provinsi Trieste\u0026quot;],[\u0026quot;Udine\u0026quot;,\u0026quot;Provinsi Udine\u0026quot;],[\u0026quot;Varese\u0026quot;,\u0026quot;Provinsi Varese\u0026quot;],[\u0026quot;Venezia\u0026quot;,\u0026quot;Provinsi Venezia\u0026quot;],[\u0026quot;Verbano-Cusio-Ossola\u0026quot;,\u0026quot;Provinsi Verbano-Cusio-Ossola\u0026quot;],[\u0026quot;Vercelli\u0026quot;,\u0026quot;Provinsi Vercelli\u0026quot;],[\u0026quot;Verona\u0026quot;,\u0026quot;Provinsi Verona\u0026quot;],[\u0026quot;Vibo Valentia\u0026quot;,\u0026quot;Provinsi Vibo Valentia\u0026quot;],[\u0026quot;Vicenza\u0026quot;,\u0026quot;Provinsi Vicenza\u0026quot;],[\u0026quot;Viterbo\u0026quot;,\u0026quot;Provinsi Viterbo\u0026quot;]]\"\u003eItalia\u003c\/option\u003e\n\u003coption value=\"Jamaica\" data-provinces=\"[]\"\u003eJamaika\u003c\/option\u003e\n\u003coption value=\"Japan\" data-provinces=\"[[\u0026quot;Aichi\u0026quot;,\u0026quot;Prefektur Aichi\u0026quot;],[\u0026quot;Akita\u0026quot;,\u0026quot;Prefektur Akita\u0026quot;],[\u0026quot;Aomori\u0026quot;,\u0026quot;Prefektur Aomori\u0026quot;],[\u0026quot;Chiba\u0026quot;,\u0026quot;Prefektur Chiba\u0026quot;],[\u0026quot;Ehime\u0026quot;,\u0026quot;Prefektur Ehime\u0026quot;],[\u0026quot;Fukui\u0026quot;,\u0026quot;Prefektur Fukui\u0026quot;],[\u0026quot;Fukuoka\u0026quot;,\u0026quot;Prefektur Fukuoka\u0026quot;],[\u0026quot;Fukushima\u0026quot;,\u0026quot;Prefektur Fukushima\u0026quot;],[\u0026quot;Gifu\u0026quot;,\u0026quot;Prefektur Gifu\u0026quot;],[\u0026quot;Gunma\u0026quot;,\u0026quot;Prefektur Gunma\u0026quot;],[\u0026quot;Hiroshima\u0026quot;,\u0026quot;Prefektur Hiroshima\u0026quot;],[\u0026quot;Hokkaidō\u0026quot;,\u0026quot;Prefektur Hokkaido\u0026quot;],[\u0026quot;Hyōgo\u0026quot;,\u0026quot;Prefektur Hyogo\u0026quot;],[\u0026quot;Ibaraki\u0026quot;,\u0026quot;Prefektur Ibaraki\u0026quot;],[\u0026quot;Ishikawa\u0026quot;,\u0026quot;Prefektur Ishikawa\u0026quot;],[\u0026quot;Iwate\u0026quot;,\u0026quot;Prefektur Iwate\u0026quot;],[\u0026quot;Kagawa\u0026quot;,\u0026quot;Prefektur Kagawa\u0026quot;],[\u0026quot;Kagoshima\u0026quot;,\u0026quot;Prefektur Kagoshima\u0026quot;],[\u0026quot;Kanagawa\u0026quot;,\u0026quot;Prefektur Kanagawa\u0026quot;],[\u0026quot;Kumamoto\u0026quot;,\u0026quot;Prefektur Kumamoto\u0026quot;],[\u0026quot;Kyōto\u0026quot;,\u0026quot;Prefektur Kyoto\u0026quot;],[\u0026quot;Kōchi\u0026quot;,\u0026quot;Prefektur Kochi\u0026quot;],[\u0026quot;Mie\u0026quot;,\u0026quot;Prefektur Mie\u0026quot;],[\u0026quot;Miyagi\u0026quot;,\u0026quot;Prefektur Miyagi\u0026quot;],[\u0026quot;Miyazaki\u0026quot;,\u0026quot;Prefektur Miyazaki\u0026quot;],[\u0026quot;Nagano\u0026quot;,\u0026quot;Prefektur Nagano\u0026quot;],[\u0026quot;Nagasaki\u0026quot;,\u0026quot;Prefektur Nagasaki\u0026quot;],[\u0026quot;Nara\u0026quot;,\u0026quot;Prefektur Nara\u0026quot;],[\u0026quot;Niigata\u0026quot;,\u0026quot;Prefektur Niigata\u0026quot;],[\u0026quot;Okayama\u0026quot;,\u0026quot;Prefektur Okayama\u0026quot;],[\u0026quot;Okinawa\u0026quot;,\u0026quot;Prefektur Okinawa\u0026quot;],[\u0026quot;Saga\u0026quot;,\u0026quot;Prefektur Saga\u0026quot;],[\u0026quot;Saitama\u0026quot;,\u0026quot;Prefektur Saitama\u0026quot;],[\u0026quot;Shiga\u0026quot;,\u0026quot;Prefektur Shiga\u0026quot;],[\u0026quot;Shimane\u0026quot;,\u0026quot;Prefektur Shimane\u0026quot;],[\u0026quot;Shizuoka\u0026quot;,\u0026quot;Prefektur Shizuoka\u0026quot;],[\u0026quot;Tochigi\u0026quot;,\u0026quot;Prefektur Tochigi\u0026quot;],[\u0026quot;Tokushima\u0026quot;,\u0026quot;Prefektur Tokushima\u0026quot;],[\u0026quot;Tottori\u0026quot;,\u0026quot;Prefektur Tottori\u0026quot;],[\u0026quot;Toyama\u0026quot;,\u0026quot;Prefektur Toyama\u0026quot;],[\u0026quot;Tōkyō\u0026quot;,\u0026quot;Tokyo\u0026quot;],[\u0026quot;Wakayama\u0026quot;,\u0026quot;Prefektur Wakayama\u0026quot;],[\u0026quot;Yamagata\u0026quot;,\u0026quot;Prefektur Yamagata\u0026quot;],[\u0026quot;Yamaguchi\u0026quot;,\u0026quot;Prefektur Yamaguchi\u0026quot;],[\u0026quot;Yamanashi\u0026quot;,\u0026quot;Prefektur Yamanashi\u0026quot;],[\u0026quot;Ōita\u0026quot;,\u0026quot;Prefektur Oita\u0026quot;],[\u0026quot;Ōsaka\u0026quot;,\u0026quot;Prefektur Osaka\u0026quot;]]\"\u003eJepang\u003c\/option\u003e\n\u003coption value=\"Germany\" data-provinces=\"[]\"\u003eJerman\u003c\/option\u003e\n\u003coption value=\"Jersey\" data-provinces=\"[]\"\u003eJersey\u003c\/option\u003e\n\u003coption value=\"Djibouti\" data-provinces=\"[]\"\u003eJibuti\u003c\/option\u003e\n\u003coption value=\"New Caledonia\" data-provinces=\"[]\"\u003eKaledonia Baru\u003c\/option\u003e\n\u003coption value=\"Cambodia\" data-provinces=\"[]\"\u003eKamboja\u003c\/option\u003e\n\u003coption value=\"Republic of Cameroon\" data-provinces=\"[]\"\u003eKamerun\u003c\/option\u003e\n\u003coption value=\"Canada\" data-provinces=\"[[\u0026quot;Alberta\u0026quot;,\u0026quot;Alberta\u0026quot;],[\u0026quot;British Columbia\u0026quot;,\u0026quot;British Columbia\u0026quot;],[\u0026quot;Manitoba\u0026quot;,\u0026quot;Manitoba\u0026quot;],[\u0026quot;New Brunswick\u0026quot;,\u0026quot;New Brunswick\u0026quot;],[\u0026quot;Newfoundland and Labrador\u0026quot;,\u0026quot;Newfoundland dan Labrador\u0026quot;],[\u0026quot;Northwest Territories\u0026quot;,\u0026quot;Wilayah Barat Laut\u0026quot;],[\u0026quot;Nova Scotia\u0026quot;,\u0026quot;Nova Scotia\u0026quot;],[\u0026quot;Nunavut\u0026quot;,\u0026quot;Nunavut\u0026quot;],[\u0026quot;Ontario\u0026quot;,\u0026quot;Ontario\u0026quot;],[\u0026quot;Prince Edward Island\u0026quot;,\u0026quot;Pulau Pangeran Edward\u0026quot;],[\u0026quot;Quebec\u0026quot;,\u0026quot;Quebec\u0026quot;],[\u0026quot;Saskatchewan\u0026quot;,\u0026quot;Saskatchewan\u0026quot;],[\u0026quot;Yukon\u0026quot;,\u0026quot;Yukon\u0026quot;]]\"\u003eKanada\u003c\/option\u003e\n\u003coption value=\"Kazakhstan\" data-provinces=\"[]\"\u003eKazakhstan\u003c\/option\u003e\n\u003coption value=\"Kenya\" data-provinces=\"[]\"\u003eKenya\u003c\/option\u003e\n\u003coption value=\"Aland Islands\" data-provinces=\"[]\"\u003eKepulauan Aland\u003c\/option\u003e\n\u003coption value=\"Cayman Islands\" data-provinces=\"[]\"\u003eKepulauan Cayman\u003c\/option\u003e\n\u003coption value=\"Cocos (Keeling) Islands\" data-provinces=\"[]\"\u003eKepulauan Cocos (Keeling)\u003c\/option\u003e\n\u003coption value=\"Cook Islands\" data-provinces=\"[]\"\u003eKepulauan Cook\u003c\/option\u003e\n\u003coption value=\"Falkland Islands (Malvinas)\" data-provinces=\"[]\"\u003eKepulauan Falkland\u003c\/option\u003e\n\u003coption value=\"Faroe Islands\" data-provinces=\"[]\"\u003eKepulauan Faroe\u003c\/option\u003e\n\u003coption value=\"Norfolk Island\" data-provinces=\"[]\"\u003eKepulauan Norfolk\u003c\/option\u003e\n\u003coption value=\"Pitcairn\" data-provinces=\"[]\"\u003eKepulauan Pitcairn\u003c\/option\u003e\n\u003coption value=\"Solomon Islands\" data-provinces=\"[]\"\u003eKepulauan Solomon\u003c\/option\u003e\n\u003coption value=\"Svalbard And Jan Mayen\" data-provinces=\"[]\"\u003eKepulauan Svalbard dan Jan Mayen\u003c\/option\u003e\n\u003coption value=\"United States Minor Outlying Islands\" data-provinces=\"[]\"\u003eKepulauan Terluar AS\u003c\/option\u003e\n\u003coption value=\"Turks and Caicos Islands\" data-provinces=\"[]\"\u003eKepulauan Turks dan Caicos\u003c\/option\u003e\n\u003coption value=\"Virgin Islands, British\" data-provinces=\"[]\"\u003eKepulauan Virgin Britania Raya\u003c\/option\u003e\n\u003coption value=\"Wallis And Futuna\" data-provinces=\"[]\"\u003eKepulauan Wallis dan Futuna\u003c\/option\u003e\n\u003coption value=\"Kyrgyzstan\" data-provinces=\"[]\"\u003eKirgizstan\u003c\/option\u003e\n\u003coption value=\"Kiribati\" data-provinces=\"[]\"\u003eKiribati\u003c\/option\u003e\n\u003coption value=\"Colombia\" data-provinces=\"[[\u0026quot;Amazonas\u0026quot;,\u0026quot;Departemen Amazonas\u0026quot;],[\u0026quot;Antioquia\u0026quot;,\u0026quot;Departemen Antioquia\u0026quot;],[\u0026quot;Arauca\u0026quot;,\u0026quot;Departemen Arauca\u0026quot;],[\u0026quot;Atlántico\u0026quot;,\u0026quot;Departemen Atlántico\u0026quot;],[\u0026quot;Bogotá, D.C.\u0026quot;,\u0026quot;Bogotá\u0026quot;],[\u0026quot;Bolívar\u0026quot;,\u0026quot;Departemen Bolívar\u0026quot;],[\u0026quot;Boyacá\u0026quot;,\u0026quot;Departemen Boyacá\u0026quot;],[\u0026quot;Caldas\u0026quot;,\u0026quot;Departemen Caldas\u0026quot;],[\u0026quot;Caquetá\u0026quot;,\u0026quot;Departemen Caquetá\u0026quot;],[\u0026quot;Casanare\u0026quot;,\u0026quot;Departemen Casanare\u0026quot;],[\u0026quot;Cauca\u0026quot;,\u0026quot;Departemen Cauca\u0026quot;],[\u0026quot;Cesar\u0026quot;,\u0026quot;Departemen Cesar\u0026quot;],[\u0026quot;Chocó\u0026quot;,\u0026quot;Departemen Chocó\u0026quot;],[\u0026quot;Cundinamarca\u0026quot;,\u0026quot;Departemen Kundinamarka\u0026quot;],[\u0026quot;Córdoba\u0026quot;,\u0026quot;Departemen Córdoba\u0026quot;],[\u0026quot;Guainía\u0026quot;,\u0026quot;Departemen Guainía\u0026quot;],[\u0026quot;Guaviare\u0026quot;,\u0026quot;Departemen Guaviare\u0026quot;],[\u0026quot;Huila\u0026quot;,\u0026quot;Departemen Huila\u0026quot;],[\u0026quot;La Guajira\u0026quot;,\u0026quot;Departemen Guajira\u0026quot;],[\u0026quot;Magdalena\u0026quot;,\u0026quot;Departemen Magdalena\u0026quot;],[\u0026quot;Meta\u0026quot;,\u0026quot;Departemen Meta\u0026quot;],[\u0026quot;Nariño\u0026quot;,\u0026quot;Departemen Nariño\u0026quot;],[\u0026quot;Norte de Santander\u0026quot;,\u0026quot;Departemen Norte de Santander\u0026quot;],[\u0026quot;Putumayo\u0026quot;,\u0026quot;Departemen Putumayo\u0026quot;],[\u0026quot;Quindío\u0026quot;,\u0026quot;Departemen Quindío\u0026quot;],[\u0026quot;Risaralda\u0026quot;,\u0026quot;Departemen Risaralda\u0026quot;],[\u0026quot;San Andrés, Providencia y Santa Catalina\u0026quot;,\u0026quot;Departemen San Andrés dan Providencia\u0026quot;],[\u0026quot;Santander\u0026quot;,\u0026quot;Departemen Santander\u0026quot;],[\u0026quot;Sucre\u0026quot;,\u0026quot;Departemen Sucre\u0026quot;],[\u0026quot;Tolima\u0026quot;,\u0026quot;Departemen Tolima\u0026quot;],[\u0026quot;Valle del Cauca\u0026quot;,\u0026quot;Departemen Valle del Cauca\u0026quot;],[\u0026quot;Vaupés\u0026quot;,\u0026quot;Departemen Vaupés\u0026quot;],[\u0026quot;Vichada\u0026quot;,\u0026quot;Departemen Vichada\u0026quot;]]\"\u003eKolombia\u003c\/option\u003e\n\u003coption value=\"Comoros\" data-provinces=\"[]\"\u003eKomoro\u003c\/option\u003e\n\u003coption value=\"Congo\" data-provinces=\"[]\"\u003eKongo - Brazzaville\u003c\/option\u003e\n\u003coption value=\"Congo, The Democratic Republic Of The\" data-provinces=\"[]\"\u003eKongo - Kinshasa\u003c\/option\u003e\n\u003coption value=\"South Korea\" data-provinces=\"[[\u0026quot;Busan\u0026quot;,\u0026quot;Busan\u0026quot;],[\u0026quot;Chungbuk\u0026quot;,\u0026quot;Chungcheong Utara\u0026quot;],[\u0026quot;Chungnam\u0026quot;,\u0026quot;Chungcheong Selatan\u0026quot;],[\u0026quot;Daegu\u0026quot;,\u0026quot;Daegu\u0026quot;],[\u0026quot;Daejeon\u0026quot;,\u0026quot;Daejeon\u0026quot;],[\u0026quot;Gangwon\u0026quot;,\u0026quot;Gangwon\u0026quot;],[\u0026quot;Gwangju\u0026quot;,\u0026quot;Gwangju\u0026quot;],[\u0026quot;Gyeongbuk\u0026quot;,\u0026quot;Gyeongsang Utara\u0026quot;],[\u0026quot;Gyeonggi\u0026quot;,\u0026quot;Gyeonggi\u0026quot;],[\u0026quot;Gyeongnam\u0026quot;,\u0026quot;Gyeongsang Selatan\u0026quot;],[\u0026quot;Incheon\u0026quot;,\u0026quot;Incheon\u0026quot;],[\u0026quot;Jeju\u0026quot;,\u0026quot;Jeju\u0026quot;],[\u0026quot;Jeonbuk\u0026quot;,\u0026quot;Jeolla Utara\u0026quot;],[\u0026quot;Jeonnam\u0026quot;,\u0026quot;Jeolla Selatan\u0026quot;],[\u0026quot;Sejong\u0026quot;,\u0026quot;Kota Sejong\u0026quot;],[\u0026quot;Seoul\u0026quot;,\u0026quot;Seoul\u0026quot;],[\u0026quot;Ulsan\u0026quot;,\u0026quot;Ulsan\u0026quot;]]\"\u003eKorea Selatan\u003c\/option\u003e\n\u003coption value=\"Kosovo\" data-provinces=\"[]\"\u003eKosovo\u003c\/option\u003e\n\u003coption value=\"Costa Rica\" data-provinces=\"[[\u0026quot;Alajuela\u0026quot;,\u0026quot;Provinsi Alajuela\u0026quot;],[\u0026quot;Cartago\u0026quot;,\u0026quot;Provinsi Cartago\u0026quot;],[\u0026quot;Guanacaste\u0026quot;,\u0026quot;Provinsi Guanacaste\u0026quot;],[\u0026quot;Heredia\u0026quot;,\u0026quot;Provinsi Heredia\u0026quot;],[\u0026quot;Limón\u0026quot;,\u0026quot;Provinsi Limón\u0026quot;],[\u0026quot;Puntarenas\u0026quot;,\u0026quot;Provinsi Puntarenas\u0026quot;],[\u0026quot;San José\u0026quot;,\u0026quot;Provinsi San José\u0026quot;]]\"\u003eKosta Rika\u003c\/option\u003e\n\u003coption value=\"Croatia\" data-provinces=\"[]\"\u003eKroasia\u003c\/option\u003e\n\u003coption value=\"Kuwait\" data-provinces=\"[[\u0026quot;Al Ahmadi\u0026quot;,\u0026quot;Kegubernuran Al-Ahmadi\u0026quot;],[\u0026quot;Al Asimah\u0026quot;,\u0026quot;Kegubernuran Al-Asimah\u0026quot;],[\u0026quot;Al Farwaniyah\u0026quot;,\u0026quot;Kegubernuran Al-Farwaniyah\u0026quot;],[\u0026quot;Al Jahra\u0026quot;,\u0026quot;Kegubernuran Al-Jahra\u0026quot;],[\u0026quot;Hawalli\u0026quot;,\u0026quot;Kegubernuran Hawalli\u0026quot;],[\u0026quot;Mubarak Al-Kabeer\u0026quot;,\u0026quot;Kegubernuran Mubarak Al-Kabeer\u0026quot;]]\"\u003eKuwait\u003c\/option\u003e\n\u003coption value=\"Lao People's Democratic Republic\" data-provinces=\"[]\"\u003eLaos\u003c\/option\u003e\n\u003coption value=\"Latvia\" data-provinces=\"[]\"\u003eLatvia\u003c\/option\u003e\n\u003coption value=\"Lebanon\" data-provinces=\"[]\"\u003eLebanon\u003c\/option\u003e\n\u003coption value=\"Lesotho\" data-provinces=\"[]\"\u003eLesotho\u003c\/option\u003e\n\u003coption value=\"Liberia\" data-provinces=\"[]\"\u003eLiberia\u003c\/option\u003e\n\u003coption value=\"Libyan Arab Jamahiriya\" data-provinces=\"[]\"\u003eLibya\u003c\/option\u003e\n\u003coption value=\"Liechtenstein\" data-provinces=\"[]\"\u003eLiechtenstein\u003c\/option\u003e\n\u003coption value=\"Lithuania\" data-provinces=\"[]\"\u003eLituania\u003c\/option\u003e\n\u003coption value=\"Luxembourg\" data-provinces=\"[]\"\u003eLuksemburg\u003c\/option\u003e\n\u003coption value=\"Madagascar\" data-provinces=\"[]\"\u003eMadagaskar\u003c\/option\u003e\n\u003coption value=\"Macao\" data-provinces=\"[]\"\u003eMakau DAK Tiongkok\u003c\/option\u003e\n\u003coption value=\"North Macedonia\" data-provinces=\"[]\"\u003eMakedonia Utara\u003c\/option\u003e\n\u003coption value=\"Maldives\" data-provinces=\"[]\"\u003eMaladewa\u003c\/option\u003e\n\u003coption value=\"Malawi\" data-provinces=\"[]\"\u003eMalawi\u003c\/option\u003e\n\u003coption value=\"Malaysia\" data-provinces=\"[[\u0026quot;Johor\u0026quot;,\u0026quot;Johor\u0026quot;],[\u0026quot;Kedah\u0026quot;,\u0026quot;Kedah\u0026quot;],[\u0026quot;Kelantan\u0026quot;,\u0026quot;Kelantan\u0026quot;],[\u0026quot;Kuala Lumpur\u0026quot;,\u0026quot;Kuala Lumpur\u0026quot;],[\u0026quot;Labuan\u0026quot;,\u0026quot;Labuan\u0026quot;],[\u0026quot;Melaka\u0026quot;,\u0026quot;Melaka\u0026quot;],[\u0026quot;Negeri Sembilan\u0026quot;,\u0026quot;Negeri Sembilan\u0026quot;],[\u0026quot;Pahang\u0026quot;,\u0026quot;Pahang\u0026quot;],[\u0026quot;Penang\u0026quot;,\u0026quot;Pulau Pinang\u0026quot;],[\u0026quot;Perak\u0026quot;,\u0026quot;Perak\u0026quot;],[\u0026quot;Perlis\u0026quot;,\u0026quot;Perlis\u0026quot;],[\u0026quot;Putrajaya\u0026quot;,\u0026quot;Putrajaya\u0026quot;],[\u0026quot;Sabah\u0026quot;,\u0026quot;Sabah\u0026quot;],[\u0026quot;Sarawak\u0026quot;,\u0026quot;Serawak\u0026quot;],[\u0026quot;Selangor\u0026quot;,\u0026quot;Selangor\u0026quot;],[\u0026quot;Terengganu\u0026quot;,\u0026quot;Terengganu\u0026quot;]]\"\u003eMalaysia\u003c\/option\u003e\n\u003coption value=\"Mali\" data-provinces=\"[]\"\u003eMali\u003c\/option\u003e\n\u003coption value=\"Malta\" data-provinces=\"[]\"\u003eMalta\u003c\/option\u003e\n\u003coption value=\"Morocco\" data-provinces=\"[]\"\u003eMaroko\u003c\/option\u003e\n\u003coption value=\"Martinique\" data-provinces=\"[]\"\u003eMartinik\u003c\/option\u003e\n\u003coption value=\"Mauritania\" data-provinces=\"[]\"\u003eMauritania\u003c\/option\u003e\n\u003coption value=\"Mauritius\" data-provinces=\"[]\"\u003eMauritius\u003c\/option\u003e\n\u003coption value=\"Mayotte\" data-provinces=\"[]\"\u003eMayotte\u003c\/option\u003e\n\u003coption value=\"Mexico\" data-provinces=\"[[\u0026quot;Aguascalientes\u0026quot;,\u0026quot;Aguascalientes\u0026quot;],[\u0026quot;Baja California\u0026quot;,\u0026quot;Baja California\u0026quot;],[\u0026quot;Baja California Sur\u0026quot;,\u0026quot;Baja California Sur\u0026quot;],[\u0026quot;Campeche\u0026quot;,\u0026quot;Campeche\u0026quot;],[\u0026quot;Chiapas\u0026quot;,\u0026quot;Chiapas\u0026quot;],[\u0026quot;Chihuahua\u0026quot;,\u0026quot;Chihuahua\u0026quot;],[\u0026quot;Ciudad de México\u0026quot;,\u0026quot;Ciudad de México\u0026quot;],[\u0026quot;Coahuila\u0026quot;,\u0026quot;Coahuila\u0026quot;],[\u0026quot;Colima\u0026quot;,\u0026quot;Colima\u0026quot;],[\u0026quot;Durango\u0026quot;,\u0026quot;Durango\u0026quot;],[\u0026quot;Guanajuato\u0026quot;,\u0026quot;Guanajuato\u0026quot;],[\u0026quot;Guerrero\u0026quot;,\u0026quot;Guerrero\u0026quot;],[\u0026quot;Hidalgo\u0026quot;,\u0026quot;Hidalgo\u0026quot;],[\u0026quot;Jalisco\u0026quot;,\u0026quot;Jalisco\u0026quot;],[\u0026quot;Michoacán\u0026quot;,\u0026quot;Michoacán\u0026quot;],[\u0026quot;Morelos\u0026quot;,\u0026quot;Morelos\u0026quot;],[\u0026quot;México\u0026quot;,\u0026quot;Meksiko\u0026quot;],[\u0026quot;Nayarit\u0026quot;,\u0026quot;Nayarit\u0026quot;],[\u0026quot;Nuevo León\u0026quot;,\u0026quot;León Baru\u0026quot;],[\u0026quot;Oaxaca\u0026quot;,\u0026quot;Oaxaca\u0026quot;],[\u0026quot;Puebla\u0026quot;,\u0026quot;Puebla\u0026quot;],[\u0026quot;Querétaro\u0026quot;,\u0026quot;Querétaro\u0026quot;],[\u0026quot;Quintana Roo\u0026quot;,\u0026quot;Quintana Roo\u0026quot;],[\u0026quot;San Luis Potosí\u0026quot;,\u0026quot;San Luis Potosí\u0026quot;],[\u0026quot;Sinaloa\u0026quot;,\u0026quot;Sinaloa\u0026quot;],[\u0026quot;Sonora\u0026quot;,\u0026quot;Sonora\u0026quot;],[\u0026quot;Tabasco\u0026quot;,\u0026quot;Tabasco\u0026quot;],[\u0026quot;Tamaulipas\u0026quot;,\u0026quot;Tamaulipas\u0026quot;],[\u0026quot;Tlaxcala\u0026quot;,\u0026quot;Tlaxcala\u0026quot;],[\u0026quot;Veracruz\u0026quot;,\u0026quot;Veracruz\u0026quot;],[\u0026quot;Yucatán\u0026quot;,\u0026quot;Yucatán\u0026quot;],[\u0026quot;Zacatecas\u0026quot;,\u0026quot;Zacatecas\u0026quot;]]\"\u003eMeksiko\u003c\/option\u003e\n\u003coption value=\"Egypt\" data-provinces=\"[[\u0026quot;6th of October\u0026quot;,\u0026quot;6 Oktober\u0026quot;],[\u0026quot;Al Sharqia\u0026quot;,\u0026quot;Kegubernuran Asy Syarqiyah\u0026quot;],[\u0026quot;Alexandria\u0026quot;,\u0026quot;Kegubernuran Al Iskandariyah\u0026quot;],[\u0026quot;Aswan\u0026quot;,\u0026quot;Kegubernuran Aswan\u0026quot;],[\u0026quot;Asyut\u0026quot;,\u0026quot;Asyut Governorate\u0026quot;],[\u0026quot;Beheira\u0026quot;,\u0026quot;Kegubernuran Al Buhayrah\u0026quot;],[\u0026quot;Beni Suef\u0026quot;,\u0026quot;Kegubernuran Bani Suwayf\u0026quot;],[\u0026quot;Cairo\u0026quot;,\u0026quot;Kegubernuran Al Qahirah\u0026quot;],[\u0026quot;Dakahlia\u0026quot;,\u0026quot;Kegubernuran Ad Daqahliyah\u0026quot;],[\u0026quot;Damietta\u0026quot;,\u0026quot;Kegubernuran Dumyat\u0026quot;],[\u0026quot;Faiyum\u0026quot;,\u0026quot;Faiyum\u0026quot;],[\u0026quot;Gharbia\u0026quot;,\u0026quot;Kegubernuran Al Gharbiyah\u0026quot;],[\u0026quot;Giza\u0026quot;,\u0026quot;Kegubernuran Al Jizah\u0026quot;],[\u0026quot;Helwan\u0026quot;,\u0026quot;Helwan\u0026quot;],[\u0026quot;Ismailia\u0026quot;,\u0026quot;Kegubernuran Al Isma’iliyah\u0026quot;],[\u0026quot;Kafr el-Sheikh\u0026quot;,\u0026quot;Kegubernuran Kafr asy Syaykh\u0026quot;],[\u0026quot;Luxor\u0026quot;,\u0026quot;Luxor\u0026quot;],[\u0026quot;Matrouh\u0026quot;,\u0026quot;Kegubernuran Matruh\u0026quot;],[\u0026quot;Minya\u0026quot;,\u0026quot;Al Minya\u0026quot;],[\u0026quot;Monufia\u0026quot;,\u0026quot;Kegubernuran Al Minufiyah\u0026quot;],[\u0026quot;New Valley\u0026quot;,\u0026quot;Al Wadi al Jadid\u0026quot;],[\u0026quot;North Sinai\u0026quot;,\u0026quot;Kegubernuran Syamal Sina’\u0026quot;],[\u0026quot;Port Said\u0026quot;,\u0026quot;Kegubernuran Bur Sa’id\u0026quot;],[\u0026quot;Qalyubia\u0026quot;,\u0026quot;Kegubernuran Al Qalyubiyah\u0026quot;],[\u0026quot;Qena\u0026quot;,\u0026quot;Kegubernuran Qina\u0026quot;],[\u0026quot;Red Sea\u0026quot;,\u0026quot;Kegubernuran Al-Bahr al-Ahmar\u0026quot;],[\u0026quot;Sohag\u0026quot;,\u0026quot;Kegubernuran Suhaj\u0026quot;],[\u0026quot;South Sinai\u0026quot;,\u0026quot;Janub Sina’\u0026quot;],[\u0026quot;Suez\u0026quot;,\u0026quot;Kegubernuran As Suways\u0026quot;]]\"\u003eMesir\u003c\/option\u003e\n\u003coption value=\"Moldova, Republic of\" data-provinces=\"[]\"\u003eMoldova\u003c\/option\u003e\n\u003coption value=\"Monaco\" data-provinces=\"[]\"\u003eMonako\u003c\/option\u003e\n\u003coption value=\"Mongolia\" data-provinces=\"[]\"\u003eMongolia\u003c\/option\u003e\n\u003coption value=\"Montenegro\" data-provinces=\"[]\"\u003eMontenegro\u003c\/option\u003e\n\u003coption value=\"Montserrat\" data-provinces=\"[]\"\u003eMontserrat\u003c\/option\u003e\n\u003coption value=\"Mozambique\" data-provinces=\"[]\"\u003eMozambik\u003c\/option\u003e\n\u003coption value=\"Myanmar\" data-provinces=\"[]\"\u003eMyanmar (Burma)\u003c\/option\u003e\n\u003coption value=\"Namibia\" data-provinces=\"[]\"\u003eNamibia\u003c\/option\u003e\n\u003coption value=\"Nauru\" data-provinces=\"[]\"\u003eNauru\u003c\/option\u003e\n\u003coption value=\"Nepal\" data-provinces=\"[]\"\u003eNepal\u003c\/option\u003e\n\u003coption value=\"Niger\" data-provinces=\"[]\"\u003eNiger\u003c\/option\u003e\n\u003coption value=\"Nigeria\" data-provinces=\"[[\u0026quot;Abia\u0026quot;,\u0026quot;Abia (negara bagian Nigeria)\u0026quot;],[\u0026quot;Abuja Federal Capital Territory\u0026quot;,\u0026quot;Wilayah Ibu Kota Federal\u0026quot;],[\u0026quot;Adamawa\u0026quot;,\u0026quot;Adamawa\u0026quot;],[\u0026quot;Akwa Ibom\u0026quot;,\u0026quot;Akwa Ibom\u0026quot;],[\u0026quot;Anambra\u0026quot;,\u0026quot;Anambra\u0026quot;],[\u0026quot;Bauchi\u0026quot;,\u0026quot;Bauchi\u0026quot;],[\u0026quot;Bayelsa\u0026quot;,\u0026quot;Bayelsa\u0026quot;],[\u0026quot;Benue\u0026quot;,\u0026quot;Benue\u0026quot;],[\u0026quot;Borno\u0026quot;,\u0026quot;Borno\u0026quot;],[\u0026quot;Cross River\u0026quot;,\u0026quot;Cross River\u0026quot;],[\u0026quot;Delta\u0026quot;,\u0026quot;Delta\u0026quot;],[\u0026quot;Ebonyi\u0026quot;,\u0026quot;Ebonyi\u0026quot;],[\u0026quot;Edo\u0026quot;,\u0026quot;Edo\u0026quot;],[\u0026quot;Ekiti\u0026quot;,\u0026quot;Ekiti\u0026quot;],[\u0026quot;Enugu\u0026quot;,\u0026quot;Enugu\u0026quot;],[\u0026quot;Gombe\u0026quot;,\u0026quot;Gombe\u0026quot;],[\u0026quot;Imo\u0026quot;,\u0026quot;Imo\u0026quot;],[\u0026quot;Jigawa\u0026quot;,\u0026quot;Jigawa\u0026quot;],[\u0026quot;Kaduna\u0026quot;,\u0026quot;Kaduna\u0026quot;],[\u0026quot;Kano\u0026quot;,\u0026quot;Kano\u0026quot;],[\u0026quot;Katsina\u0026quot;,\u0026quot;Katsina\u0026quot;],[\u0026quot;Kebbi\u0026quot;,\u0026quot;Kebbi\u0026quot;],[\u0026quot;Kogi\u0026quot;,\u0026quot;Kogi\u0026quot;],[\u0026quot;Kwara\u0026quot;,\u0026quot;Kwara\u0026quot;],[\u0026quot;Lagos\u0026quot;,\u0026quot;Lagos\u0026quot;],[\u0026quot;Nasarawa\u0026quot;,\u0026quot;Nassarawa\u0026quot;],[\u0026quot;Niger\u0026quot;,\u0026quot;Niger\u0026quot;],[\u0026quot;Ogun\u0026quot;,\u0026quot;Ogun\u0026quot;],[\u0026quot;Ondo\u0026quot;,\u0026quot;Ondo\u0026quot;],[\u0026quot;Osun\u0026quot;,\u0026quot;Osun\u0026quot;],[\u0026quot;Oyo\u0026quot;,\u0026quot;Oyo\u0026quot;],[\u0026quot;Plateau\u0026quot;,\u0026quot;Plateau\u0026quot;],[\u0026quot;Rivers\u0026quot;,\u0026quot;Rivers\u0026quot;],[\u0026quot;Sokoto\u0026quot;,\u0026quot;Sokoto\u0026quot;],[\u0026quot;Taraba\u0026quot;,\u0026quot;Taraba\u0026quot;],[\u0026quot;Yobe\u0026quot;,\u0026quot;Yobe\u0026quot;],[\u0026quot;Zamfara\u0026quot;,\u0026quot;Zamfara\u0026quot;]]\"\u003eNigeria\u003c\/option\u003e\n\u003coption value=\"Nicaragua\" data-provinces=\"[]\"\u003eNikaragua\u003c\/option\u003e\n\u003coption value=\"Niue\" data-provinces=\"[]\"\u003eNiue\u003c\/option\u003e\n\u003coption value=\"Norway\" data-provinces=\"[]\"\u003eNorwegia\u003c\/option\u003e\n\u003coption value=\"Oman\" data-provinces=\"[]\"\u003eOman\u003c\/option\u003e\n\u003coption value=\"Pakistan\" data-provinces=\"[]\"\u003ePakistan\u003c\/option\u003e\n\u003coption value=\"Panama\" data-provinces=\"[[\u0026quot;Bocas del Toro\u0026quot;,\u0026quot;Provinsi Bocas del Toro\u0026quot;],[\u0026quot;Chiriquí\u0026quot;,\u0026quot;Provinsi Chiriquí\u0026quot;],[\u0026quot;Coclé\u0026quot;,\u0026quot;Provinsi Coclé\u0026quot;],[\u0026quot;Colón\u0026quot;,\u0026quot;Provinsi Colón\u0026quot;],[\u0026quot;Darién\u0026quot;,\u0026quot;Provinsi Darién\u0026quot;],[\u0026quot;Emberá\u0026quot;,\u0026quot;Emberá-Wounaan Comarca\u0026quot;],[\u0026quot;Herrera\u0026quot;,\u0026quot;Provinsi Herrera\u0026quot;],[\u0026quot;Kuna Yala\u0026quot;,\u0026quot;Guna Yala\u0026quot;],[\u0026quot;Los Santos\u0026quot;,\u0026quot;Provinsi Los Santos\u0026quot;],[\u0026quot;Ngöbe-Buglé\u0026quot;,\u0026quot;Ngöbe-Buglé Comarca\u0026quot;],[\u0026quot;Panamá\u0026quot;,\u0026quot;Provinsi Panamá\u0026quot;],[\u0026quot;Panamá Oeste\u0026quot;,\u0026quot;Panamá Oeste\u0026quot;],[\u0026quot;Veraguas\u0026quot;,\u0026quot;Provinsi Veraguas\u0026quot;]]\"\u003ePanama\u003c\/option\u003e\n\u003coption value=\"Papua New Guinea\" data-provinces=\"[]\"\u003ePapua Nugini\u003c\/option\u003e\n\u003coption value=\"Paraguay\" data-provinces=\"[]\"\u003eParaguay\u003c\/option\u003e\n\u003coption value=\"Peru\" data-provinces=\"[[\u0026quot;Amazonas\u0026quot;,\u0026quot;Region Amazonas\u0026quot;],[\u0026quot;Apurímac\u0026quot;,\u0026quot;Region Apurímac\u0026quot;],[\u0026quot;Arequipa\u0026quot;,\u0026quot;Region Arequipa\u0026quot;],[\u0026quot;Ayacucho\u0026quot;,\u0026quot;Region Ayacucho\u0026quot;],[\u0026quot;Cajamarca\u0026quot;,\u0026quot;Region Cajamarca\u0026quot;],[\u0026quot;Callao\u0026quot;,\u0026quot;Region Callao\u0026quot;],[\u0026quot;Cuzco\u0026quot;,\u0026quot;Region Cusco\u0026quot;],[\u0026quot;Huancavelica\u0026quot;,\u0026quot;Region Huancavelica\u0026quot;],[\u0026quot;Huánuco\u0026quot;,\u0026quot;Region Huánuco\u0026quot;],[\u0026quot;Ica\u0026quot;,\u0026quot;Region Ica\u0026quot;],[\u0026quot;Junín\u0026quot;,\u0026quot;Region Junín\u0026quot;],[\u0026quot;La Libertad\u0026quot;,\u0026quot;Region La Libertad\u0026quot;],[\u0026quot;Lambayeque\u0026quot;,\u0026quot;Region Lambayeque\u0026quot;],[\u0026quot;Lima (departamento)\u0026quot;,\u0026quot;Region Lima\u0026quot;],[\u0026quot;Lima (provincia)\u0026quot;,\u0026quot;Provinsi Lima\u0026quot;],[\u0026quot;Loreto\u0026quot;,\u0026quot;Region Loreto\u0026quot;],[\u0026quot;Madre de Dios\u0026quot;,\u0026quot;Region Madre de Dios\u0026quot;],[\u0026quot;Moquegua\u0026quot;,\u0026quot;Region Moquegua\u0026quot;],[\u0026quot;Pasco\u0026quot;,\u0026quot;Region Pasco\u0026quot;],[\u0026quot;Piura\u0026quot;,\u0026quot;Region Piura\u0026quot;],[\u0026quot;Puno\u0026quot;,\u0026quot;Region Puno\u0026quot;],[\u0026quot;San Martín\u0026quot;,\u0026quot;Region San Martín\u0026quot;],[\u0026quot;Tacna\u0026quot;,\u0026quot;Region Tacna\u0026quot;],[\u0026quot;Tumbes\u0026quot;,\u0026quot;Region Tumbes\u0026quot;],[\u0026quot;Ucayali\u0026quot;,\u0026quot;Region Ucayali\u0026quot;],[\u0026quot;Áncash\u0026quot;,\u0026quot;Region Ancash\u0026quot;]]\"\u003ePeru\u003c\/option\u003e\n\u003coption value=\"Poland\" data-provinces=\"[]\"\u003ePolandia\u003c\/option\u003e\n\u003coption value=\"French Polynesia\" data-provinces=\"[]\"\u003ePolinesia Prancis\u003c\/option\u003e\n\u003coption value=\"Portugal\" data-provinces=\"[[\u0026quot;Aveiro\u0026quot;,\u0026quot;Distrik Aveiro\u0026quot;],[\u0026quot;Açores\u0026quot;,\u0026quot;Azores\u0026quot;],[\u0026quot;Beja\u0026quot;,\u0026quot;Distrik Beja\u0026quot;],[\u0026quot;Braga\u0026quot;,\u0026quot;Distrik Braga\u0026quot;],[\u0026quot;Bragança\u0026quot;,\u0026quot;Distrik Bragança\u0026quot;],[\u0026quot;Castelo Branco\u0026quot;,\u0026quot;Distrik Castelo Branco\u0026quot;],[\u0026quot;Coimbra\u0026quot;,\u0026quot;Distrik Coimbra\u0026quot;],[\u0026quot;Faro\u0026quot;,\u0026quot;Distrik Faro\u0026quot;],[\u0026quot;Guarda\u0026quot;,\u0026quot;Distrik Guarda\u0026quot;],[\u0026quot;Leiria\u0026quot;,\u0026quot;Distrik Leiria\u0026quot;],[\u0026quot;Lisboa\u0026quot;,\u0026quot;Distrik Lisboa\u0026quot;],[\u0026quot;Madeira\u0026quot;,\u0026quot;Madeira\u0026quot;],[\u0026quot;Portalegre\u0026quot;,\u0026quot;Distrik Portalegre\u0026quot;],[\u0026quot;Porto\u0026quot;,\u0026quot;Distrik Porto\u0026quot;],[\u0026quot;Santarém\u0026quot;,\u0026quot;Distrik Santarém\u0026quot;],[\u0026quot;Setúbal\u0026quot;,\u0026quot;Distrik Setúbal\u0026quot;],[\u0026quot;Viana do Castelo\u0026quot;,\u0026quot;Distrik Viana do Castelo\u0026quot;],[\u0026quot;Vila Real\u0026quot;,\u0026quot;Distrik Vila Real\u0026quot;],[\u0026quot;Viseu\u0026quot;,\u0026quot;Distrik Viseu\u0026quot;],[\u0026quot;Évora\u0026quot;,\u0026quot;Distrik Évora\u0026quot;]]\"\u003ePortugal\u003c\/option\u003e\n\u003coption value=\"France\" data-provinces=\"[]\"\u003ePrancis\u003c\/option\u003e\n\u003coption value=\"Ascension Island\" data-provinces=\"[]\"\u003ePulau Ascension\u003c\/option\u003e\n\u003coption value=\"Isle Of Man\" data-provinces=\"[]\"\u003ePulau Man\u003c\/option\u003e\n\u003coption value=\"Christmas Island\" data-provinces=\"[]\"\u003ePulau Natal\u003c\/option\u003e\n\u003coption value=\"Qatar\" data-provinces=\"[]\"\u003eQatar\u003c\/option\u003e\n\u003coption value=\"Central African Republic\" data-provinces=\"[]\"\u003eRepublik Afrika Tengah\u003c\/option\u003e\n\u003coption value=\"Dominican Republic\" data-provinces=\"[]\"\u003eRepublik Dominika\u003c\/option\u003e\n\u003coption value=\"Reunion\" data-provinces=\"[]\"\u003eRéunion\u003c\/option\u003e\n\u003coption value=\"Romania\" data-provinces=\"[[\u0026quot;Alba\u0026quot;,\u0026quot;Provinsi Alba\u0026quot;],[\u0026quot;Arad\u0026quot;,\u0026quot;Provinsi Arad\u0026quot;],[\u0026quot;Argeș\u0026quot;,\u0026quot;Provinsi Argeş\u0026quot;],[\u0026quot;Bacău\u0026quot;,\u0026quot;Provinsi Bacău\u0026quot;],[\u0026quot;Bihor\u0026quot;,\u0026quot;Provinsi Bihor\u0026quot;],[\u0026quot;Bistrița-Năsăud\u0026quot;,\u0026quot;Provinsi Bistriţa-Năsăud\u0026quot;],[\u0026quot;Botoșani\u0026quot;,\u0026quot;Provinsi Botoşani\u0026quot;],[\u0026quot;Brașov\u0026quot;,\u0026quot;Provinsi Braşov\u0026quot;],[\u0026quot;Brăila\u0026quot;,\u0026quot;Provinsi Brăila\u0026quot;],[\u0026quot;București\u0026quot;,\u0026quot;Bukares\u0026quot;],[\u0026quot;Buzău\u0026quot;,\u0026quot;Provinsi Buzău\u0026quot;],[\u0026quot;Caraș-Severin\u0026quot;,\u0026quot;Provinsi Caraş-Severin\u0026quot;],[\u0026quot;Cluj\u0026quot;,\u0026quot;Provinsi Cluj\u0026quot;],[\u0026quot;Constanța\u0026quot;,\u0026quot;Provinsi Constanţa\u0026quot;],[\u0026quot;Covasna\u0026quot;,\u0026quot;Provinsi Covasna\u0026quot;],[\u0026quot;Călărași\u0026quot;,\u0026quot;Provinsi Călăraşi\u0026quot;],[\u0026quot;Dolj\u0026quot;,\u0026quot;Provinsi Dolj\u0026quot;],[\u0026quot;Dâmbovița\u0026quot;,\u0026quot;Provinsi Dâmboviţa\u0026quot;],[\u0026quot;Galați\u0026quot;,\u0026quot;Provinsi Galaţi\u0026quot;],[\u0026quot;Giurgiu\u0026quot;,\u0026quot;Provinsi Giurgiu\u0026quot;],[\u0026quot;Gorj\u0026quot;,\u0026quot;Provinsi Gorj\u0026quot;],[\u0026quot;Harghita\u0026quot;,\u0026quot;Provinsi Harghita\u0026quot;],[\u0026quot;Hunedoara\u0026quot;,\u0026quot;Provinsi Hunedoara\u0026quot;],[\u0026quot;Ialomița\u0026quot;,\u0026quot;Provinsi Ialomiţa\u0026quot;],[\u0026quot;Iași\u0026quot;,\u0026quot;Provinsi Iaşi\u0026quot;],[\u0026quot;Ilfov\u0026quot;,\u0026quot;Provinsi Ilfov\u0026quot;],[\u0026quot;Maramureș\u0026quot;,\u0026quot;Provinsi Maramureş\u0026quot;],[\u0026quot;Mehedinți\u0026quot;,\u0026quot;Provinsi Mehedinţi\u0026quot;],[\u0026quot;Mureș\u0026quot;,\u0026quot;Provinsi Mureş\u0026quot;],[\u0026quot;Neamț\u0026quot;,\u0026quot;Provinsi Neamţ\u0026quot;],[\u0026quot;Olt\u0026quot;,\u0026quot;Provinsi Olt\u0026quot;],[\u0026quot;Prahova\u0026quot;,\u0026quot;Provinsi Prahova\u0026quot;],[\u0026quot;Satu Mare\u0026quot;,\u0026quot;Provinsi Satu Mare\u0026quot;],[\u0026quot;Sibiu\u0026quot;,\u0026quot;Provinsi Sibiu\u0026quot;],[\u0026quot;Suceava\u0026quot;,\u0026quot;Provinsi Suceava\u0026quot;],[\u0026quot;Sălaj\u0026quot;,\u0026quot;Provinsi Sălaj\u0026quot;],[\u0026quot;Teleorman\u0026quot;,\u0026quot;Provinsi Teleorman\u0026quot;],[\u0026quot;Timiș\u0026quot;,\u0026quot;Provinsi Timiş\u0026quot;],[\u0026quot;Tulcea\u0026quot;,\u0026quot;Provinsi Tulcea\u0026quot;],[\u0026quot;Vaslui\u0026quot;,\u0026quot;Provinsi Vaslui\u0026quot;],[\u0026quot;Vrancea\u0026quot;,\u0026quot;Provinsi Vrancea\u0026quot;],[\u0026quot;Vâlcea\u0026quot;,\u0026quot;Provinsi Vâlcea\u0026quot;]]\"\u003eRumania\u003c\/option\u003e\n\u003coption value=\"Russia\" data-provinces=\"[[\u0026quot;Altai Krai\u0026quot;,\u0026quot;Krai Altai\u0026quot;],[\u0026quot;Altai Republic\u0026quot;,\u0026quot;Republik Altai\u0026quot;],[\u0026quot;Amur Oblast\u0026quot;,\u0026quot;Oblast Amur\u0026quot;],[\u0026quot;Arkhangelsk Oblast\u0026quot;,\u0026quot;Oblast Arkhangelsk\u0026quot;],[\u0026quot;Astrakhan Oblast\u0026quot;,\u0026quot;Oblast Astrakhan\u0026quot;],[\u0026quot;Belgorod Oblast\u0026quot;,\u0026quot;Oblast Belgorod\u0026quot;],[\u0026quot;Bryansk Oblast\u0026quot;,\u0026quot;Oblast Bryansk\u0026quot;],[\u0026quot;Chechen Republic\u0026quot;,\u0026quot;Chechnya\u0026quot;],[\u0026quot;Chelyabinsk Oblast\u0026quot;,\u0026quot;Oblast Chelyabinsk\u0026quot;],[\u0026quot;Chukotka Autonomous Okrug\u0026quot;,\u0026quot;Okrug otonom Chukotka\u0026quot;],[\u0026quot;Chuvash Republic\u0026quot;,\u0026quot;Chuvashia\u0026quot;],[\u0026quot;Irkutsk Oblast\u0026quot;,\u0026quot;Oblast Irkutsk\u0026quot;],[\u0026quot;Ivanovo Oblast\u0026quot;,\u0026quot;Oblast Ivanovo\u0026quot;],[\u0026quot;Jewish Autonomous Oblast\u0026quot;,\u0026quot;Oblast Otonom Yahudi\u0026quot;],[\u0026quot;Kabardino-Balkarian Republic\u0026quot;,\u0026quot;Kabardino-Balkaria\u0026quot;],[\u0026quot;Kaliningrad Oblast\u0026quot;,\u0026quot;Oblast Kaliningrad\u0026quot;],[\u0026quot;Kaluga Oblast\u0026quot;,\u0026quot;Oblast Kaluga\u0026quot;],[\u0026quot;Kamchatka Krai\u0026quot;,\u0026quot;Krai Kamchatka\u0026quot;],[\u0026quot;Karachay–Cherkess Republic\u0026quot;,\u0026quot;Karachay-Cherkessia\u0026quot;],[\u0026quot;Kemerovo Oblast\u0026quot;,\u0026quot;Oblast Kemerovo\u0026quot;],[\u0026quot;Khabarovsk Krai\u0026quot;,\u0026quot;Krai Khabarovsk\u0026quot;],[\u0026quot;Khanty-Mansi Autonomous Okrug\u0026quot;,\u0026quot;Khantia-Mansia\u0026quot;],[\u0026quot;Kirov Oblast\u0026quot;,\u0026quot;Oblast Kirov\u0026quot;],[\u0026quot;Komi Republic\u0026quot;,\u0026quot;Republik Komi\u0026quot;],[\u0026quot;Kostroma Oblast\u0026quot;,\u0026quot;Oblast Kostroma\u0026quot;],[\u0026quot;Krasnodar Krai\u0026quot;,\u0026quot;Krai Krasnodar\u0026quot;],[\u0026quot;Krasnoyarsk Krai\u0026quot;,\u0026quot;Krai Krasnoyarsk\u0026quot;],[\u0026quot;Kurgan Oblast\u0026quot;,\u0026quot;Oblast Kurgan\u0026quot;],[\u0026quot;Kursk Oblast\u0026quot;,\u0026quot;Oblast Kursk\u0026quot;],[\u0026quot;Leningrad Oblast\u0026quot;,\u0026quot;Oblast Leningrad\u0026quot;],[\u0026quot;Lipetsk Oblast\u0026quot;,\u0026quot;Oblast Lipetsk\u0026quot;],[\u0026quot;Magadan Oblast\u0026quot;,\u0026quot;Oblast Magadan\u0026quot;],[\u0026quot;Mari El Republic\u0026quot;,\u0026quot;Mari El\u0026quot;],[\u0026quot;Moscow\u0026quot;,\u0026quot;Moskwa\u0026quot;],[\u0026quot;Moscow Oblast\u0026quot;,\u0026quot;Oblast Moskwa\u0026quot;],[\u0026quot;Murmansk Oblast\u0026quot;,\u0026quot;Oblast Murmansk\u0026quot;],[\u0026quot;Nizhny Novgorod Oblast\u0026quot;,\u0026quot;Oblast Nizhny Novgorod\u0026quot;],[\u0026quot;Novgorod Oblast\u0026quot;,\u0026quot;Oblast Novgorod\u0026quot;],[\u0026quot;Novosibirsk Oblast\u0026quot;,\u0026quot;Oblast Novosibirsk\u0026quot;],[\u0026quot;Omsk Oblast\u0026quot;,\u0026quot;Oblast Omsk\u0026quot;],[\u0026quot;Orenburg Oblast\u0026quot;,\u0026quot;Oblast Orenburg\u0026quot;],[\u0026quot;Oryol Oblast\u0026quot;,\u0026quot;Oblast Oryol\u0026quot;],[\u0026quot;Penza Oblast\u0026quot;,\u0026quot;Oblast Penza\u0026quot;],[\u0026quot;Perm Krai\u0026quot;,\u0026quot;Krai Perm\u0026quot;],[\u0026quot;Primorsky Krai\u0026quot;,\u0026quot;Krai Primorsky\u0026quot;],[\u0026quot;Pskov Oblast\u0026quot;,\u0026quot;Oblast Pskov\u0026quot;],[\u0026quot;Republic of Adygeya\u0026quot;,\u0026quot;Adygea\u0026quot;],[\u0026quot;Republic of Bashkortostan\u0026quot;,\u0026quot;Bashkortostan\u0026quot;],[\u0026quot;Republic of Buryatia\u0026quot;,\u0026quot;Buryatia\u0026quot;],[\u0026quot;Republic of Dagestan\u0026quot;,\u0026quot;Dagestan\u0026quot;],[\u0026quot;Republic of Ingushetia\u0026quot;,\u0026quot;Ingushetia\u0026quot;],[\u0026quot;Republic of Kalmykia\u0026quot;,\u0026quot;Kalmykia\u0026quot;],[\u0026quot;Republic of Karelia\u0026quot;,\u0026quot;Republik Karelia\u0026quot;],[\u0026quot;Republic of Khakassia\u0026quot;,\u0026quot;Khakassia\u0026quot;],[\u0026quot;Republic of Mordovia\u0026quot;,\u0026quot;Mordovia\u0026quot;],[\u0026quot;Republic of North Ossetia–Alania\u0026quot;,\u0026quot;Ossetia Utara-Alania\u0026quot;],[\u0026quot;Republic of Tatarstan\u0026quot;,\u0026quot;Tatarstan\u0026quot;],[\u0026quot;Rostov Oblast\u0026quot;,\u0026quot;Oblast Rostov\u0026quot;],[\u0026quot;Ryazan Oblast\u0026quot;,\u0026quot;Oblast Ryazan\u0026quot;],[\u0026quot;Saint Petersburg\u0026quot;,\u0026quot;St. Petersburg\u0026quot;],[\u0026quot;Sakha Republic (Yakutia)\u0026quot;,\u0026quot;Sakha\u0026quot;],[\u0026quot;Sakhalin Oblast\u0026quot;,\u0026quot;Oblast Sakhalin\u0026quot;],[\u0026quot;Samara Oblast\u0026quot;,\u0026quot;Oblast Samara\u0026quot;],[\u0026quot;Saratov Oblast\u0026quot;,\u0026quot;Oblast Saratov\u0026quot;],[\u0026quot;Smolensk Oblast\u0026quot;,\u0026quot;Oblast Smolensk\u0026quot;],[\u0026quot;Stavropol Krai\u0026quot;,\u0026quot;Krai Stavropol\u0026quot;],[\u0026quot;Sverdlovsk Oblast\u0026quot;,\u0026quot;Oblast Sverdlovsk\u0026quot;],[\u0026quot;Tambov Oblast\u0026quot;,\u0026quot;Oblast Tambov\u0026quot;],[\u0026quot;Tomsk Oblast\u0026quot;,\u0026quot;Oblast Tomsk\u0026quot;],[\u0026quot;Tula Oblast\u0026quot;,\u0026quot;Oblast Tula\u0026quot;],[\u0026quot;Tver Oblast\u0026quot;,\u0026quot;Oblast Tver\u0026quot;],[\u0026quot;Tyumen Oblast\u0026quot;,\u0026quot;Oblast Tyumen\u0026quot;],[\u0026quot;Tyva Republic\u0026quot;,\u0026quot;Tuva\u0026quot;],[\u0026quot;Udmurtia\u0026quot;,\u0026quot;Udmurtia\u0026quot;],[\u0026quot;Ulyanovsk Oblast\u0026quot;,\u0026quot;Oblast Ulyanovsk\u0026quot;],[\u0026quot;Vladimir Oblast\u0026quot;,\u0026quot;Oblast Vladimir\u0026quot;],[\u0026quot;Volgograd Oblast\u0026quot;,\u0026quot;Oblast Volgograd\u0026quot;],[\u0026quot;Vologda Oblast\u0026quot;,\u0026quot;Oblast Vologda\u0026quot;],[\u0026quot;Voronezh Oblast\u0026quot;,\u0026quot;Oblast Voronezh\u0026quot;],[\u0026quot;Yamalo-Nenets Autonomous Okrug\u0026quot;,\u0026quot;Yamalia\u0026quot;],[\u0026quot;Yaroslavl Oblast\u0026quot;,\u0026quot;Oblast Yaroslavl\u0026quot;],[\u0026quot;Zabaykalsky Krai\u0026quot;,\u0026quot;Krai Zabaykalsky\u0026quot;]]\"\u003eRusia\u003c\/option\u003e\n\u003coption value=\"Rwanda\" data-provinces=\"[]\"\u003eRwanda\u003c\/option\u003e\n\u003coption value=\"Western Sahara\" data-provinces=\"[]\"\u003eSahara Barat\u003c\/option\u003e\n\u003coption value=\"Saint Barthélemy\" data-provinces=\"[]\"\u003eSaint Barthélemy\u003c\/option\u003e\n\u003coption value=\"Saint Helena\" data-provinces=\"[]\"\u003eSaint Helena\u003c\/option\u003e\n\u003coption value=\"Saint Kitts And Nevis\" data-provinces=\"[]\"\u003eSaint Kitts dan Nevis\u003c\/option\u003e\n\u003coption value=\"Saint Lucia\" data-provinces=\"[]\"\u003eSaint Lucia\u003c\/option\u003e\n\u003coption value=\"Saint Martin\" data-provinces=\"[]\"\u003eSaint Martin\u003c\/option\u003e\n\u003coption value=\"Saint Pierre And Miquelon\" data-provinces=\"[]\"\u003eSaint Pierre dan Miquelon\u003c\/option\u003e\n\u003coption value=\"St. Vincent\" data-provinces=\"[]\"\u003eSaint Vincent dan Grenadine\u003c\/option\u003e\n\u003coption value=\"Samoa\" data-provinces=\"[]\"\u003eSamoa\u003c\/option\u003e\n\u003coption value=\"San Marino\" data-provinces=\"[]\"\u003eSan Marino\u003c\/option\u003e\n\u003coption value=\"Sao Tome And Principe\" data-provinces=\"[]\"\u003eSao Tome dan Principe\u003c\/option\u003e\n\u003coption value=\"New Zealand\" data-provinces=\"[[\u0026quot;Auckland\u0026quot;,\u0026quot;Region Auckland\u0026quot;],[\u0026quot;Bay of Plenty\u0026quot;,\u0026quot;Wilayah Bay of Plenty\u0026quot;],[\u0026quot;Canterbury\u0026quot;,\u0026quot;Canterbury\u0026quot;],[\u0026quot;Chatham Islands\u0026quot;,\u0026quot;Kepulauan Chatham\u0026quot;],[\u0026quot;Gisborne\u0026quot;,\u0026quot;Wilayah Gisborne\u0026quot;],[\u0026quot;Hawke\u0026#39;s Bay\u0026quot;,\u0026quot;Wilayah Hawke’s Bay\u0026quot;],[\u0026quot;Manawatu-Wanganui\u0026quot;,\u0026quot;Wilayah Manawatu-Wanganui\u0026quot;],[\u0026quot;Marlborough\u0026quot;,\u0026quot;Wilayah Marlborough\u0026quot;],[\u0026quot;Nelson\u0026quot;,\u0026quot;Nelson\u0026quot;],[\u0026quot;Northland\u0026quot;,\u0026quot;Region Northland\u0026quot;],[\u0026quot;Otago\u0026quot;,\u0026quot;Wilayah Otago\u0026quot;],[\u0026quot;Southland\u0026quot;,\u0026quot;Wilayah Southland\u0026quot;],[\u0026quot;Taranaki\u0026quot;,\u0026quot;Taranaki\u0026quot;],[\u0026quot;Tasman\u0026quot;,\u0026quot;Distrik Tasman\u0026quot;],[\u0026quot;Waikato\u0026quot;,\u0026quot;Waikato\u0026quot;],[\u0026quot;Wellington\u0026quot;,\u0026quot;Wilayah Wellington\u0026quot;],[\u0026quot;West Coast\u0026quot;,\u0026quot;West Coast, Selandia Baru\u0026quot;]]\"\u003eSelandia Baru\u003c\/option\u003e\n\u003coption value=\"Senegal\" data-provinces=\"[]\"\u003eSenegal\u003c\/option\u003e\n\u003coption value=\"Serbia\" data-provinces=\"[]\"\u003eSerbia\u003c\/option\u003e\n\u003coption value=\"Seychelles\" data-provinces=\"[]\"\u003eSeychelles\u003c\/option\u003e\n\u003coption value=\"Sierra Leone\" data-provinces=\"[]\"\u003eSierra Leone\u003c\/option\u003e\n\u003coption value=\"Singapore\" data-provinces=\"[]\"\u003eSingapura\u003c\/option\u003e\n\u003coption value=\"Sint Maarten\" data-provinces=\"[]\"\u003eSint Maarten\u003c\/option\u003e\n\u003coption value=\"Cyprus\" data-provinces=\"[]\"\u003eSiprus\u003c\/option\u003e\n\u003coption value=\"Slovakia\" data-provinces=\"[]\"\u003eSlovakia\u003c\/option\u003e\n\u003coption value=\"Slovenia\" data-provinces=\"[]\"\u003eSlovenia\u003c\/option\u003e\n\u003coption value=\"Somalia\" data-provinces=\"[]\"\u003eSomalia\u003c\/option\u003e\n\u003coption value=\"Spain\" data-provinces=\"[[\u0026quot;A Coruña\u0026quot;,\u0026quot;Provinsi A Coruña\u0026quot;],[\u0026quot;Albacete\u0026quot;,\u0026quot;Provinsi Albacete\u0026quot;],[\u0026quot;Alicante\u0026quot;,\u0026quot;Provinsi Alicante\u0026quot;],[\u0026quot;Almería\u0026quot;,\u0026quot;Provinsi Almería\u0026quot;],[\u0026quot;Asturias\u0026quot;,\u0026quot;Asturias\u0026quot;],[\u0026quot;Badajoz\u0026quot;,\u0026quot;Provinsi Badajoz\u0026quot;],[\u0026quot;Balears\u0026quot;,\u0026quot;Kepulauan Balears²\u0026quot;],[\u0026quot;Barcelona\u0026quot;,\u0026quot;Provinsi Barcelona\u0026quot;],[\u0026quot;Burgos\u0026quot;,\u0026quot;Provinsi Burgos\u0026quot;],[\u0026quot;Cantabria\u0026quot;,\u0026quot;Cantabria²\u0026quot;],[\u0026quot;Castellón\u0026quot;,\u0026quot;Provinsi Castellón\u0026quot;],[\u0026quot;Ceuta\u0026quot;,\u0026quot;Ceuta\u0026quot;],[\u0026quot;Ciudad Real\u0026quot;,\u0026quot;Provinsi Ciudad Real\u0026quot;],[\u0026quot;Cuenca\u0026quot;,\u0026quot;Provinsi Cuenca\u0026quot;],[\u0026quot;Cáceres\u0026quot;,\u0026quot;Provinsi Cáceres\u0026quot;],[\u0026quot;Cádiz\u0026quot;,\u0026quot;Provinsi Cádiz\u0026quot;],[\u0026quot;Córdoba\u0026quot;,\u0026quot;Provinsi Córdoba\u0026quot;],[\u0026quot;Girona\u0026quot;,\u0026quot;Provinsi Girona\u0026quot;],[\u0026quot;Granada\u0026quot;,\u0026quot;Provinsi Granada\u0026quot;],[\u0026quot;Guadalajara\u0026quot;,\u0026quot;Provinsi Guadalajara\u0026quot;],[\u0026quot;Guipúzcoa\u0026quot;,\u0026quot;Gipuzkoa\u0026quot;],[\u0026quot;Huelva\u0026quot;,\u0026quot;Provinsi Huelva\u0026quot;],[\u0026quot;Huesca\u0026quot;,\u0026quot;Provinsi Huesca\u0026quot;],[\u0026quot;Jaén\u0026quot;,\u0026quot;Provinsi Jaén\u0026quot;],[\u0026quot;La Rioja\u0026quot;,\u0026quot;La Rioja\u0026quot;],[\u0026quot;Las Palmas\u0026quot;,\u0026quot;Provinsi Las Palmas\u0026quot;],[\u0026quot;León\u0026quot;,\u0026quot;Provinsi León\u0026quot;],[\u0026quot;Lleida\u0026quot;,\u0026quot;Provinsi Lleida\u0026quot;],[\u0026quot;Lugo\u0026quot;,\u0026quot;Provinsi Lugo\u0026quot;],[\u0026quot;Madrid\u0026quot;,\u0026quot;Madrid\u0026quot;],[\u0026quot;Melilla\u0026quot;,\u0026quot;Melilla\u0026quot;],[\u0026quot;Murcia\u0026quot;,\u0026quot;Murcia\u0026quot;],[\u0026quot;Málaga\u0026quot;,\u0026quot;Provinsi Málaga\u0026quot;],[\u0026quot;Navarra\u0026quot;,\u0026quot;Navarra²\u0026quot;],[\u0026quot;Ourense\u0026quot;,\u0026quot;Provinsi Ourense\u0026quot;],[\u0026quot;Palencia\u0026quot;,\u0026quot;Provinsi Palencia\u0026quot;],[\u0026quot;Pontevedra\u0026quot;,\u0026quot;Provinsi Pontevedra\u0026quot;],[\u0026quot;Salamanca\u0026quot;,\u0026quot;Provinsi Salamanca\u0026quot;],[\u0026quot;Santa Cruz de Tenerife\u0026quot;,\u0026quot;Provinsi Santa Cruz de Tenerife\u0026quot;],[\u0026quot;Segovia\u0026quot;,\u0026quot;Provinsi Segovia\u0026quot;],[\u0026quot;Sevilla\u0026quot;,\u0026quot;Provinsi Sevilla\u0026quot;],[\u0026quot;Soria\u0026quot;,\u0026quot;Provinsi Soria\u0026quot;],[\u0026quot;Tarragona\u0026quot;,\u0026quot;Provinsi Tarragona\u0026quot;],[\u0026quot;Teruel\u0026quot;,\u0026quot;Provinsi Teruel\u0026quot;],[\u0026quot;Toledo\u0026quot;,\u0026quot;Provinsi Toledo\u0026quot;],[\u0026quot;Valencia\u0026quot;,\u0026quot;Provinsi Valencia\u0026quot;],[\u0026quot;Valladolid\u0026quot;,\u0026quot;Provinsi Valladolid\u0026quot;],[\u0026quot;Vizcaya\u0026quot;,\u0026quot;Vizcaya\u0026quot;],[\u0026quot;Zamora\u0026quot;,\u0026quot;Provinsi Zamora\u0026quot;],[\u0026quot;Zaragoza\u0026quot;,\u0026quot;Provinsi Zaragoza\u0026quot;],[\u0026quot;Álava\u0026quot;,\u0026quot;Álava\u0026quot;],[\u0026quot;Ávila\u0026quot;,\u0026quot;Provinsi Ávila\u0026quot;]]\"\u003eSpanyol\u003c\/option\u003e\n\u003coption value=\"Sri Lanka\" data-provinces=\"[]\"\u003eSri Lanka\u003c\/option\u003e\n\u003coption value=\"Sudan\" data-provinces=\"[]\"\u003eSudan\u003c\/option\u003e\n\u003coption value=\"South Sudan\" data-provinces=\"[]\"\u003eSudan Selatan\u003c\/option\u003e\n\u003coption value=\"Suriname\" data-provinces=\"[]\"\u003eSuriname\u003c\/option\u003e\n\u003coption value=\"Sweden\" data-provinces=\"[]\"\u003eSwedia\u003c\/option\u003e\n\u003coption value=\"Switzerland\" data-provinces=\"[]\"\u003eSwiss\u003c\/option\u003e\n\u003coption value=\"Taiwan\" data-provinces=\"[]\"\u003eTaiwan\u003c\/option\u003e\n\u003coption value=\"Tajikistan\" data-provinces=\"[]\"\u003eTajikistan\u003c\/option\u003e\n\u003coption value=\"Cape Verde\" data-provinces=\"[]\"\u003eTanjung Verde\u003c\/option\u003e\n\u003coption value=\"Tanzania, United Republic Of\" data-provinces=\"[]\"\u003eTanzania\u003c\/option\u003e\n\u003coption value=\"Thailand\" data-provinces=\"[[\u0026quot;Amnat Charoen\u0026quot;,\u0026quot;Provinsi Amnat Charoen\u0026quot;],[\u0026quot;Ang Thong\u0026quot;,\u0026quot;Ang Thong\u0026quot;],[\u0026quot;Bangkok\u0026quot;,\u0026quot;Bangkok\u0026quot;],[\u0026quot;Bueng Kan\u0026quot;,\u0026quot;Provinsi Bueng Kan\u0026quot;],[\u0026quot;Buriram\u0026quot;,\u0026quot;Provinsi Buriram\u0026quot;],[\u0026quot;Chachoengsao\u0026quot;,\u0026quot;Chachoengsao\u0026quot;],[\u0026quot;Chai Nat\u0026quot;,\u0026quot;Chai Nat\u0026quot;],[\u0026quot;Chaiyaphum\u0026quot;,\u0026quot;Provinsi Chaiyaphum\u0026quot;],[\u0026quot;Chanthaburi\u0026quot;,\u0026quot;Chanthaburi\u0026quot;],[\u0026quot;Chiang Mai\u0026quot;,\u0026quot;Provinsi Chiang Mai\u0026quot;],[\u0026quot;Chiang Rai\u0026quot;,\u0026quot;Provinsi Chiang Rai\u0026quot;],[\u0026quot;Chon Buri\u0026quot;,\u0026quot;Chon Buri\u0026quot;],[\u0026quot;Chumphon\u0026quot;,\u0026quot;Provinsi Chumphon\u0026quot;],[\u0026quot;Kalasin\u0026quot;,\u0026quot;Provinsi Kalasin\u0026quot;],[\u0026quot;Kamphaeng Phet\u0026quot;,\u0026quot;Provinsi Kamphaeng Phet\u0026quot;],[\u0026quot;Kanchanaburi\u0026quot;,\u0026quot;Kanchanaburi\u0026quot;],[\u0026quot;Khon Kaen\u0026quot;,\u0026quot;Provinsi Khon Kaen\u0026quot;],[\u0026quot;Krabi\u0026quot;,\u0026quot;Provinsi Krabi\u0026quot;],[\u0026quot;Lampang\u0026quot;,\u0026quot;Provinsi Lampang\u0026quot;],[\u0026quot;Lamphun\u0026quot;,\u0026quot;Provinsi Lamphun\u0026quot;],[\u0026quot;Loei\u0026quot;,\u0026quot;Provinsi Loei\u0026quot;],[\u0026quot;Lopburi\u0026quot;,\u0026quot;Lopburi\u0026quot;],[\u0026quot;Mae Hong Son\u0026quot;,\u0026quot;Provinsi Mae Hong Son\u0026quot;],[\u0026quot;Maha Sarakham\u0026quot;,\u0026quot;Provinsi Maha Sarakham\u0026quot;],[\u0026quot;Mukdahan\u0026quot;,\u0026quot;Provinsi Mukdahan\u0026quot;],[\u0026quot;Nakhon Nayok\u0026quot;,\u0026quot;Nakhon Nayok\u0026quot;],[\u0026quot;Nakhon Pathom\u0026quot;,\u0026quot;Nakhon Pathom\u0026quot;],[\u0026quot;Nakhon Phanom\u0026quot;,\u0026quot;Provinsi Nakhon Phanom\u0026quot;],[\u0026quot;Nakhon Ratchasima\u0026quot;,\u0026quot;Provinsi Nakhon Ratchasima\u0026quot;],[\u0026quot;Nakhon Sawan\u0026quot;,\u0026quot;Provinsi Nakhon Sawan\u0026quot;],[\u0026quot;Nakhon Si Thammarat\u0026quot;,\u0026quot;Provinsi Nakhon Si Thammarat\u0026quot;],[\u0026quot;Nan\u0026quot;,\u0026quot;Provinsi Nan\u0026quot;],[\u0026quot;Narathiwat\u0026quot;,\u0026quot;Narathiwat\u0026quot;],[\u0026quot;Nong Bua Lam Phu\u0026quot;,\u0026quot;Provinsi Nong Bua Lamphu\u0026quot;],[\u0026quot;Nong Khai\u0026quot;,\u0026quot;Provinsi Nong Khai\u0026quot;],[\u0026quot;Nonthaburi\u0026quot;,\u0026quot;Nonthaburi\u0026quot;],[\u0026quot;Pathum Thani\u0026quot;,\u0026quot;Pathum Thani\u0026quot;],[\u0026quot;Pattani\u0026quot;,\u0026quot;Provinsi Pattani\u0026quot;],[\u0026quot;Pattaya\u0026quot;,\u0026quot;Pattaya\u0026quot;],[\u0026quot;Phangnga\u0026quot;,\u0026quot;Provinsi Phang Nga\u0026quot;],[\u0026quot;Phatthalung\u0026quot;,\u0026quot;Provinsi Phatthalung\u0026quot;],[\u0026quot;Phayao\u0026quot;,\u0026quot;Provinsi Phayao\u0026quot;],[\u0026quot;Phetchabun\u0026quot;,\u0026quot;Provinsi Phetchabun\u0026quot;],[\u0026quot;Phetchaburi\u0026quot;,\u0026quot;Provinsi Phetchaburi\u0026quot;],[\u0026quot;Phichit\u0026quot;,\u0026quot;Provinsi Phichit\u0026quot;],[\u0026quot;Phitsanulok\u0026quot;,\u0026quot;Provinsi Phitsanulok\u0026quot;],[\u0026quot;Phra Nakhon Si Ayutthaya\u0026quot;,\u0026quot;Phra Nakhon Si Ayutthaya\u0026quot;],[\u0026quot;Phrae\u0026quot;,\u0026quot;Provinsi Phrae\u0026quot;],[\u0026quot;Phuket\u0026quot;,\u0026quot;Phuket\u0026quot;],[\u0026quot;Prachin Buri\u0026quot;,\u0026quot;Prachin Buri\u0026quot;],[\u0026quot;Prachuap Khiri Khan\u0026quot;,\u0026quot;Provinsi Prachuap Khiri Khan\u0026quot;],[\u0026quot;Ranong\u0026quot;,\u0026quot;Provinsi Ranong\u0026quot;],[\u0026quot;Ratchaburi\u0026quot;,\u0026quot;Provinsi Ratchaburi\u0026quot;],[\u0026quot;Rayong\u0026quot;,\u0026quot;Rayong\u0026quot;],[\u0026quot;Roi Et\u0026quot;,\u0026quot;Provinsi Roi Et\u0026quot;],[\u0026quot;Sa Kaeo\u0026quot;,\u0026quot;Provinsi Sa Kaeo\u0026quot;],[\u0026quot;Sakon Nakhon\u0026quot;,\u0026quot;Provinsi Sakon Nakhon\u0026quot;],[\u0026quot;Samut Prakan\u0026quot;,\u0026quot;Samut Prakan\u0026quot;],[\u0026quot;Samut Sakhon\u0026quot;,\u0026quot;Samut Sakhon\u0026quot;],[\u0026quot;Samut Songkhram\u0026quot;,\u0026quot;Samut Songkhram\u0026quot;],[\u0026quot;Saraburi\u0026quot;,\u0026quot;Saraburi\u0026quot;],[\u0026quot;Satun\u0026quot;,\u0026quot;Provinsi Satun\u0026quot;],[\u0026quot;Sing Buri\u0026quot;,\u0026quot;Sing Buri\u0026quot;],[\u0026quot;Sisaket\u0026quot;,\u0026quot;Provinsi Sisaket\u0026quot;],[\u0026quot;Songkhla\u0026quot;,\u0026quot;Provinsi Songkhla\u0026quot;],[\u0026quot;Sukhothai\u0026quot;,\u0026quot;Provinsi Sukhothai\u0026quot;],[\u0026quot;Suphan Buri\u0026quot;,\u0026quot;Provinsi Suphan Buri\u0026quot;],[\u0026quot;Surat Thani\u0026quot;,\u0026quot;Provinsi Surat Thani\u0026quot;],[\u0026quot;Surin\u0026quot;,\u0026quot;Provinsi Surin\u0026quot;],[\u0026quot;Tak\u0026quot;,\u0026quot;Provinsi Tak\u0026quot;],[\u0026quot;Trang\u0026quot;,\u0026quot;Provinsi Trang\u0026quot;],[\u0026quot;Trat\u0026quot;,\u0026quot;Provinsi Trat\u0026quot;],[\u0026quot;Ubon Ratchathani\u0026quot;,\u0026quot;Ubon Ratchathani\u0026quot;],[\u0026quot;Udon Thani\u0026quot;,\u0026quot;Udon Thani\u0026quot;],[\u0026quot;Uthai Thani\u0026quot;,\u0026quot;Provinsi Uthai Thani\u0026quot;],[\u0026quot;Uttaradit\u0026quot;,\u0026quot;Provinsi Uttaradit\u0026quot;],[\u0026quot;Yala\u0026quot;,\u0026quot;Provinsi Yala\u0026quot;],[\u0026quot;Yasothon\u0026quot;,\u0026quot;Yasothon\u0026quot;]]\"\u003eThailand\u003c\/option\u003e\n\u003coption value=\"Timor Leste\" data-provinces=\"[]\"\u003eTimor Leste\u003c\/option\u003e\n\u003coption value=\"China\" data-provinces=\"[[\u0026quot;Anhui\u0026quot;,\u0026quot;Anhui\u0026quot;],[\u0026quot;Beijing\u0026quot;,\u0026quot;Beijing\u0026quot;],[\u0026quot;Chongqing\u0026quot;,\u0026quot;Chongqing\u0026quot;],[\u0026quot;Fujian\u0026quot;,\u0026quot;Fujian\u0026quot;],[\u0026quot;Gansu\u0026quot;,\u0026quot;Gansu\u0026quot;],[\u0026quot;Guangdong\u0026quot;,\u0026quot;Guangdong\u0026quot;],[\u0026quot;Guangxi\u0026quot;,\u0026quot;Guangxi\u0026quot;],[\u0026quot;Guizhou\u0026quot;,\u0026quot;Guizhou\u0026quot;],[\u0026quot;Hainan\u0026quot;,\u0026quot;Hainan\u0026quot;],[\u0026quot;Hebei\u0026quot;,\u0026quot;Hebei\u0026quot;],[\u0026quot;Heilongjiang\u0026quot;,\u0026quot;Heilongjiang\u0026quot;],[\u0026quot;Henan\u0026quot;,\u0026quot;Henan\u0026quot;],[\u0026quot;Hubei\u0026quot;,\u0026quot;Hubei\u0026quot;],[\u0026quot;Hunan\u0026quot;,\u0026quot;Hunan\u0026quot;],[\u0026quot;Inner Mongolia\u0026quot;,\u0026quot;Mongolia Dalam\u0026quot;],[\u0026quot;Jiangsu\u0026quot;,\u0026quot;Jiangsu\u0026quot;],[\u0026quot;Jiangxi\u0026quot;,\u0026quot;Jiangxi\u0026quot;],[\u0026quot;Jilin\u0026quot;,\u0026quot;Jilin\u0026quot;],[\u0026quot;Liaoning\u0026quot;,\u0026quot;Liaoning\u0026quot;],[\u0026quot;Ningxia\u0026quot;,\u0026quot;Ningxia\u0026quot;],[\u0026quot;Qinghai\u0026quot;,\u0026quot;Qinghai\u0026quot;],[\u0026quot;Shaanxi\u0026quot;,\u0026quot;Shaanxi\u0026quot;],[\u0026quot;Shandong\u0026quot;,\u0026quot;Shandong\u0026quot;],[\u0026quot;Shanghai\u0026quot;,\u0026quot;Shanghai\u0026quot;],[\u0026quot;Shanxi\u0026quot;,\u0026quot;Shanxi\u0026quot;],[\u0026quot;Sichuan\u0026quot;,\u0026quot;Sichuan\u0026quot;],[\u0026quot;Tianjin\u0026quot;,\u0026quot;Tianjin\u0026quot;],[\u0026quot;Xinjiang\u0026quot;,\u0026quot;Xinjiang\u0026quot;],[\u0026quot;Xizang\u0026quot;,\u0026quot;Tibet\u0026quot;],[\u0026quot;Yunnan\u0026quot;,\u0026quot;Yunnan\u0026quot;],[\u0026quot;Zhejiang\u0026quot;,\u0026quot;Zhejiang\u0026quot;]]\"\u003eTiongkok\u003c\/option\u003e\n\u003coption value=\"Togo\" data-provinces=\"[]\"\u003eTogo\u003c\/option\u003e\n\u003coption value=\"Tokelau\" data-provinces=\"[]\"\u003eTokelau\u003c\/option\u003e\n\u003coption value=\"Tonga\" data-provinces=\"[]\"\u003eTonga\u003c\/option\u003e\n\u003coption value=\"Trinidad and Tobago\" data-provinces=\"[]\"\u003eTrinidad dan Tobago\u003c\/option\u003e\n\u003coption value=\"Tristan da Cunha\" data-provinces=\"[]\"\u003eTristan da Cunha\u003c\/option\u003e\n\u003coption value=\"Tunisia\" data-provinces=\"[]\"\u003eTunisia\u003c\/option\u003e\n\u003coption value=\"Turkey\" data-provinces=\"[]\"\u003eTurki\u003c\/option\u003e\n\u003coption value=\"Turkmenistan\" data-provinces=\"[]\"\u003eTurkmenistan\u003c\/option\u003e\n\u003coption value=\"Tuvalu\" data-provinces=\"[]\"\u003eTuvalu\u003c\/option\u003e\n\u003coption value=\"Uganda\" data-provinces=\"[]\"\u003eUganda\u003c\/option\u003e\n\u003coption value=\"Ukraine\" data-provinces=\"[]\"\u003eUkraina\u003c\/option\u003e\n\u003coption value=\"United Arab Emirates\" data-provinces=\"[[\u0026quot;Abu Dhabi\u0026quot;,\u0026quot;Abu Dhabi Emirate\u0026quot;],[\u0026quot;Ajman\u0026quot;,\u0026quot;Ajman\u0026quot;],[\u0026quot;Dubai\u0026quot;,\u0026quot;Keamiran Dubai\u0026quot;],[\u0026quot;Fujairah\u0026quot;,\u0026quot;Fujairah\u0026quot;],[\u0026quot;Ras al-Khaimah\u0026quot;,\u0026quot;Ras al-Khaimah\u0026quot;],[\u0026quot;Sharjah\u0026quot;,\u0026quot;Sharjah\u0026quot;],[\u0026quot;Umm al-Quwain\u0026quot;,\u0026quot;Umm al-Qaiwain\u0026quot;]]\"\u003eUni Emirat Arab\u003c\/option\u003e\n\u003coption value=\"Uruguay\" data-provinces=\"[[\u0026quot;Artigas\u0026quot;,\u0026quot;Departemen Artigas\u0026quot;],[\u0026quot;Canelones\u0026quot;,\u0026quot;Departemen Canelones\u0026quot;],[\u0026quot;Cerro Largo\u0026quot;,\u0026quot;Departemen Cerro Largo\u0026quot;],[\u0026quot;Colonia\u0026quot;,\u0026quot;Departemen Colonia\u0026quot;],[\u0026quot;Durazno\u0026quot;,\u0026quot;Departemen Durazno\u0026quot;],[\u0026quot;Flores\u0026quot;,\u0026quot;Departemen Flores\u0026quot;],[\u0026quot;Florida\u0026quot;,\u0026quot;Departemen Florida\u0026quot;],[\u0026quot;Lavalleja\u0026quot;,\u0026quot;Departemen Lavalleja\u0026quot;],[\u0026quot;Maldonado\u0026quot;,\u0026quot;Departemen Maldonado\u0026quot;],[\u0026quot;Montevideo\u0026quot;,\u0026quot;Departemen Montevideo\u0026quot;],[\u0026quot;Paysandú\u0026quot;,\u0026quot;Departemen Paysandú\u0026quot;],[\u0026quot;Rivera\u0026quot;,\u0026quot;Departemen Rivera\u0026quot;],[\u0026quot;Rocha\u0026quot;,\u0026quot;Departemen Rocha\u0026quot;],[\u0026quot;Río Negro\u0026quot;,\u0026quot;Departemen Río Negro\u0026quot;],[\u0026quot;Salto\u0026quot;,\u0026quot;Departemen Salto\u0026quot;],[\u0026quot;San José\u0026quot;,\u0026quot;Departemen San José\u0026quot;],[\u0026quot;Soriano\u0026quot;,\u0026quot;Departemen Soriano\u0026quot;],[\u0026quot;Tacuarembó\u0026quot;,\u0026quot;Departemen Tacuarembó\u0026quot;],[\u0026quot;Treinta y Tres\u0026quot;,\u0026quot;Departemen Treinta y Tres\u0026quot;]]\"\u003eUruguay\u003c\/option\u003e\n\u003coption value=\"Uzbekistan\" data-provinces=\"[]\"\u003eUzbekistan\u003c\/option\u003e\n\u003coption value=\"Vanuatu\" data-provinces=\"[]\"\u003eVanuatu\u003c\/option\u003e\n\u003coption value=\"Holy See (Vatican City State)\" data-provinces=\"[]\"\u003eVatikan\u003c\/option\u003e\n\u003coption value=\"Venezuela\" data-provinces=\"[[\u0026quot;Amazonas\u0026quot;,\u0026quot;Amazonas\u0026quot;],[\u0026quot;Anzoátegui\u0026quot;,\u0026quot;Anzoátegui\u0026quot;],[\u0026quot;Apure\u0026quot;,\u0026quot;Apure\u0026quot;],[\u0026quot;Aragua\u0026quot;,\u0026quot;Aragua\u0026quot;],[\u0026quot;Barinas\u0026quot;,\u0026quot;Barinas\u0026quot;],[\u0026quot;Bolívar\u0026quot;,\u0026quot;Bolívar\u0026quot;],[\u0026quot;Carabobo\u0026quot;,\u0026quot;Carabobo\u0026quot;],[\u0026quot;Cojedes\u0026quot;,\u0026quot;Cojedes\u0026quot;],[\u0026quot;Delta Amacuro\u0026quot;,\u0026quot;Delta Amacuro\u0026quot;],[\u0026quot;Dependencias Federales\u0026quot;,\u0026quot;Federal Dependencies of Venezuela\u0026quot;],[\u0026quot;Distrito Capital\u0026quot;,\u0026quot;Distrik Capital\u0026quot;],[\u0026quot;Falcón\u0026quot;,\u0026quot;Falcón\u0026quot;],[\u0026quot;Guárico\u0026quot;,\u0026quot;Guárico\u0026quot;],[\u0026quot;La Guaira\u0026quot;,\u0026quot;Vargas\u0026quot;],[\u0026quot;Lara\u0026quot;,\u0026quot;Lara\u0026quot;],[\u0026quot;Miranda\u0026quot;,\u0026quot;Miranda\u0026quot;],[\u0026quot;Monagas\u0026quot;,\u0026quot;Monagas\u0026quot;],[\u0026quot;Mérida\u0026quot;,\u0026quot;Mérida\u0026quot;],[\u0026quot;Nueva Esparta\u0026quot;,\u0026quot;Nueva Esparta\u0026quot;],[\u0026quot;Portuguesa\u0026quot;,\u0026quot;Portuguesa\u0026quot;],[\u0026quot;Sucre\u0026quot;,\u0026quot;Sucre\u0026quot;],[\u0026quot;Trujillo\u0026quot;,\u0026quot;Trujillo\u0026quot;],[\u0026quot;Táchira\u0026quot;,\u0026quot;Táchira\u0026quot;],[\u0026quot;Yaracuy\u0026quot;,\u0026quot;Yaracuy\u0026quot;],[\u0026quot;Zulia\u0026quot;,\u0026quot;Zulia\u0026quot;]]\"\u003eVenezuela\u003c\/option\u003e\n\u003coption value=\"Vietnam\" data-provinces=\"[]\"\u003eVietnam\u003c\/option\u003e\n\u003coption value=\"British Indian Ocean Territory\" data-provinces=\"[]\"\u003eWilayah Inggris di Samudra Hindia\u003c\/option\u003e\n\u003coption value=\"Palestinian Territory, Occupied\" data-provinces=\"[]\"\u003eWilayah Palestina\u003c\/option\u003e\n\u003coption value=\"French Southern Territories\" data-provinces=\"[]\"\u003eWilayah Selatan Prancis\u003c\/option\u003e\n\u003coption value=\"Yemen\" data-provinces=\"[]\"\u003eYaman\u003c\/option\u003e\n\u003coption value=\"Jordan\" data-provinces=\"[]\"\u003eYordania\u003c\/option\u003e\n\u003coption value=\"Greece\" data-provinces=\"[]\"\u003eYunani\u003c\/option\u003e\n\u003coption value=\"Zambia\" data-provinces=\"[]\"\u003eZambia\u003c\/option\u003e\n\u003coption value=\"Zimbabwe\" data-provinces=\"[]\"\u003eZimbabwe\u003c\/option\u003e\n\u003coption value=\"Eswatini\" data-provinces=\"[]\"\u003eeSwatini\u003c\/option\u003e";
  
</script>


<style>
  @font-face {
  font-family: Inter;
  font-weight: 400;
  font-style: normal;
  font-display: swap;
  src: url("//acmedelavie.co.id/cdn/fonts/inter/inter_n4.b2a3f24c19b4de56e8871f609e73ca7f6d2e2bb9.woff2") format("woff2"),
       url("//acmedelavie.co.id/cdn/fonts/inter/inter_n4.af8052d517e0c9ffac7b814872cecc27ae1fa132.woff") format("woff");
}

  @font-face {
  font-family: Inter;
  font-weight: 600;
  font-style: normal;
  font-display: swap;
  src: url("//acmedelavie.co.id/cdn/fonts/inter/inter_n6.771af0474a71b3797eb38f3487d6fb79d43b6877.woff2") format("woff2"),
       url("//acmedelavie.co.id/cdn/fonts/inter/inter_n6.88c903d8f9e157d48b73b7777d0642925bcecde7.woff") format("woff");
}

  @font-face {
  font-family: Inter;
  font-weight: 300;
  font-style: normal;
  font-display: swap;
  src: url("//acmedelavie.co.id/cdn/fonts/inter/inter_n3.6faba940d2e90c9f1c2e0c5c2750b84af59fecc0.woff2") format("woff2"),
       url("//acmedelavie.co.id/cdn/fonts/inter/inter_n3.413aa818ec2103383c4ac7c3744c464d04b4db49.woff") format("woff");
}

  @font-face {
  font-family: Inter;
  font-weight: 300;
  font-style: normal;
  font-display: swap;
  src: url("//acmedelavie.co.id/cdn/fonts/inter/inter_n3.6faba940d2e90c9f1c2e0c5c2750b84af59fecc0.woff2") format("woff2"),
       url("//acmedelavie.co.id/cdn/fonts/inter/inter_n3.413aa818ec2103383c4ac7c3744c464d04b4db49.woff") format("woff");
}

  @font-face {
  font-family: Inter;
  font-weight: 600;
  font-style: normal;
  font-display: swap;
  src: url("//acmedelavie.co.id/cdn/fonts/inter/inter_n6.771af0474a71b3797eb38f3487d6fb79d43b6877.woff2") format("woff2"),
       url("//acmedelavie.co.id/cdn/fonts/inter/inter_n6.88c903d8f9e157d48b73b7777d0642925bcecde7.woff") format("woff");
}

  @font-face {
  font-family: Inter;
  font-weight: 300;
  font-style: italic;
  font-display: swap;
  src: url("//acmedelavie.co.id/cdn/fonts/inter/inter_i3.6d51b5c1aff0e6286c06ee460a22e95b7c89d160.woff2") format("woff2"),
       url("//acmedelavie.co.id/cdn/fonts/inter/inter_i3.125e6a7560f210d08832797e294849204cda4973.woff") format("woff");
}

  @font-face {
  font-family: Inter;
  font-weight: 600;
  font-style: italic;
  font-display: swap;
  src: url("//acmedelavie.co.id/cdn/fonts/inter/inter_i6.3bbe0fe1c7ee4f282f9c2e296f3e4401a48cbe19.woff2") format("woff2"),
       url("//acmedelavie.co.id/cdn/fonts/inter/inter_i6.8bea21f57a10d5416ddf685e2c91682ec237876d.woff") format("woff");
}


  :root {
    --color-text: #111111;
    --color-text-8-percent: rgba(17, 17, 17, 0.08);  
    --color-text-alpha: rgba(17, 17, 17, 0.35);
    --color-text-meta: rgba(17, 17, 17, 0.6);
    --color-text-link: #000000;
    --color-text-error: #D02F2E;
    --color-text-success: #478947;

    --color-background: #ffffff;
    --color-background-semi-transparent-80: rgba(255, 255, 255, 0.8);
    --color-background-semi-transparent-90: rgba(255, 255, 255, 0.9);

    --color-background-transparent: rgba(255, 255, 255, 0);
    --color-border: #aaaaaa;
    --color-border-meta: rgba(170, 170, 170, 0.6);
    --color-overlay: rgba(0, 0, 0, 0.7);

    --color-background-meta: #f5f5f5;
    --color-background-meta-alpha: rgba(245, 245, 245, 0.6);
    --color-background-darker-meta: #e8e8e8;
    --color-background-darker-meta-alpha: rgba(232, 232, 232, 0.6);
    --color-background-placeholder: #e8e8e8;
    --color-background-placeholder-lighter: #f0f0f0;
    --color-foreground-placeholder: rgba(17, 17, 17, 0.4);

    --color-border-input: #aaaaaa;
    --color-border-input-alpha: rgba(170, 170, 170, 0.25);
    --color-text-input: #111111;
    --color-text-input-alpha: rgba(17, 17, 17, 0.04);

    --color-text-button: #ffffff;

    --color-background-button: #000000;
    --color-background-button-alpha: rgba(0, 0, 0, 0.6);
    --color-background-outline-button-alpha: rgba(0, 0, 0, 0.1);
    --color-background-button-hover: #333333;

    --color-icon: rgba(17, 17, 17, 0.4);
    --color-icon-darker: rgba(17, 17, 17, 0.6);

    --color-text-sale-badge: #C31818;
    --color-background-sold-badge: #414141;
    --color-text-sold-badge: #ffffff;

    --color-text-header: #000000;
    --color-text-header-half-transparent: rgba(0, 0, 0, 0.5);

    --color-background-header: #ffffff;
    --color-background-header-transparent: rgba(255, 255, 255, 0);
    --color-icon-header: #000000;
    --color-shadow-header: rgba(0, 0, 0, 0.15);

    --color-background-footer: #000000;
    --color-text-footer: #ffffff;
    --color-text-footer-subdued: rgba(255, 255, 255, 0.7);

    --color-products-sale-price: #C31818;
    --color-products-rating-star: #000000;

    --color-products-stock-good: #3c9342;
    --color-products-stock-medium: #A77A06;
    --color-products-stock-bad: #A70100;
    --color-products-stock-bad: #A70100;

    --font-logo: Inter, sans-serif;
    --font-logo-weight: 400;
    --font-logo-style: normal;
    --logo-text-transform: uppercase;
    --logo-letter-spacing: 0.0em;

    --font-heading: Inter, sans-serif;
    --font-heading-weight: 600;
    --font-heading-style: normal;
    --font-heading-text-transform: uppercase;
    --font-heading-base-letter-spacing: 0.0em;
    --font-heading-base-size: 42px;

    --font-body: Inter, sans-serif;
    --font-body-weight: 300;
    --font-body-style: normal;
    --font-body-italic: italic;
    --font-body-bold-weight: 600;
    --font-body-base-letter-spacing: 0.0em;
    --font-body-base-size: 17px;

    /* Typography */
    --line-height-heading: 1.1;
    --line-height-subheading: 1.33;
    --line-height-body: 1.5;

    --logo-font-size: 
clamp(1.4rem, 1.1513812154696133rem + 1.0607734806629836vw, 2.0rem)
;

    --font-size-navigation-base: 17px;
    --font-navigation-base-letter-spacing: -0.005em;
    --font-navigation-base-text-transform: none;

    --font-size-heading-display-1: 
clamp(3.15rem, 2.8236878453038674rem + 1.3922651933701657vw, 3.9375rem)
;
    --font-size-heading-display-2: 
clamp(2.7993rem, 2.50931726519337rem + 1.2372596685082875vw, 3.499125rem)
;
    --font-size-heading-display-3: 
clamp(2.44986rem, 2.1960761602209944rem + 1.0828110497237569vw, 3.062325rem)
;
    --font-size-heading-1-base: 
clamp(2.1rem, 1.8824585635359117rem + 0.9281767955801105vw, 2.625rem)
;
    --font-size-heading-2-base: 
clamp(1.8375rem, 1.6471512430939226rem + 0.8121546961325967vw, 2.296875rem)
;
    --font-size-heading-3-base: 
clamp(1.575rem, 1.4118439226519337rem + 0.6961325966850829vw, 1.96875rem)
;
    --font-size-heading-4-base: 
clamp(1.2243rem, 1.0974733425414365rem + 0.5411270718232044vw, 1.530375rem)
;
    --font-size-heading-5-base: 
clamp(1.05rem, 0.9412292817679558rem + 0.4640883977900552vw, 1.3125rem)
;
    --font-size-heading-6-base: 
clamp(0.8736rem, 0.7831027624309392rem + 0.38612154696132595vw, 1.092rem)
;
    --font-size-body-400: 
clamp(1.68161875rem, 1.6449448895027625rem + 0.15647513812154695vw, 1.770125rem)
;
    --font-size-body-350: 
clamp(1.569578125rem, 1.535347720994475rem + 0.14604972375690609vw, 1.6521875rem)
;
    --font-size-body-300: 
clamp(1.4575375rem, 1.4257505524861878rem + 0.1356243093922652vw, 1.53425rem)
;
    --font-size-body-250: 
clamp(1.345496875rem, 1.3161533839779005rem + 0.1251988950276243vw, 1.4163125rem)
;
    --font-size-body-200: 
clamp(1.23345625rem, 1.2065562154696132rem + 0.11477348066298342vw, 1.298375rem)
;
    --font-size-body-150: 
clamp(1.121415625rem, 1.096959046961326rem + 0.10434806629834253vw, 1.1804375rem)
;
    --font-size-body-100: 
clamp(1.009375rem, 0.9873618784530387rem + 0.09392265193370165vw, 1.0625rem)
;
    --font-size-body-75: 
clamp(0.896325rem, 0.8767773480662984rem + 0.08340331491712707vw, 0.9435rem)
;
    --font-size-body-60: 
clamp(0.829908125rem, 0.8118089364640884rem + 0.07722320441988952vw, 0.8735875rem)
;
    --font-size-body-50: 
clamp(0.784284375rem, 0.7671801795580111rem + 0.0729779005524862vw, 0.8255625rem)
;
    --font-size-body-25: 
clamp(0.72876875rem, 0.7128752762430939rem + 0.0678121546961326vw, 0.767125rem)
;
    --font-size-body-20: 
clamp(0.67224375rem, 0.6575830110497237rem + 0.06255248618784531vw, 0.707625rem)
;

    /* Buttons */
    
      --button-padding-multiplier: 1;
      --font-size-button: var(--font-size-body-50);
      --font-size-button-x-small: var(--font-size-body-25);
    

    --font-button-text-transform: uppercase;
    --button-letter-spacing: 0.05em;
    --line-height-button: 1.45;

    /* Product badges */
    
      --font-size-product-badge: var(--font-size-body-20);
    

    --font-product-badge-text-transform: uppercase;

    /* Product listing titles */
    
      --font-size-listing-title: var(--font-size-body-60);
    

    --font-product-listing-title-text-transform: uppercase;
    --font-product-listing-title-base-letter-spacing: 0.05em;

    /* Shopify pay specific */
    --payment-terms-background-color: #f5f5f5;
  }

  @supports not (font-size: clamp(10px, 3.3vw, 20px)) {
    :root {
      --logo-font-size: 
1.7rem
;
      --font-size-heading-display-1: 
3.54375rem
;
      --font-size-heading-display-2: 
3.1492125rem
;
      --font-size-heading-display-3: 
2.7560925rem
;
      --font-size-heading-1-base: 
2.3625rem
;
      --font-size-heading-2-base: 
2.0671875rem
;
      --font-size-heading-3-base: 
1.771875rem
;
      --font-size-heading-4-base: 
1.3773375rem
;
      --font-size-heading-5-base: 
1.18125rem
;
      --font-size-heading-6-base: 
0.9828rem
;
      --font-size-body-400: 
1.725871875rem
;
      --font-size-body-350: 
1.6108828125rem
;
      --font-size-body-300: 
1.49589375rem
;
      --font-size-body-250: 
1.3809046875rem
;
      --font-size-body-200: 
1.265915625rem
;
      --font-size-body-150: 
1.1509265625rem
;
      --font-size-body-100: 
1.0359375rem
;
      --font-size-body-75: 
0.9199125rem
;
      --font-size-body-60: 
0.8517478125rem
;
      --font-size-body-50: 
0.8049234375rem
;
      --font-size-body-25: 
0.747946875rem
;
      --font-size-body-20: 
0.689934375rem
;
    }
  }.product-badge[data-handle="indonesia-exclusive"]{
        color: #3c9342;
      }
    
.product-badge[data-handle="organic"],.product-badge[data-handle="sustainable"]{
        color: #7e6b45;
      }
    
.product-badge[data-handle="coming-soon"]{
        color: #000000;
      }
    

</style>

<script>
  flu = window.flu || {};
  flu.chunks = {
    photoswipe: "//acmedelavie.co.id/cdn/shop/t/38/assets/photoswipe-chunk.js?v=18659099751219271031767828856",
    swiper: "//acmedelavie.co.id/cdn/shop/t/38/assets/swiper-chunk.js?v=73725226959832986321767828856",
    nouislider: "//acmedelavie.co.id/cdn/shop/t/38/assets/nouislider-chunk.js?v=131351027671466727271767828856",
    polyfillInert: "//acmedelavie.co.id/cdn/shop/t/38/assets/polyfill-inert-chunk.js?v=9775187524458939151767828856",
    polyfillResizeObserver: "//acmedelavie.co.id/cdn/shop/t/38/assets/polyfill-resize-observer-chunk.js?v=49253094118087005231767828856",
  };
</script>





  <script type="module" src="//acmedelavie.co.id/cdn/shop/t/38/assets/theme.min.js?v=18099281989634550481767828856"></script>










<meta name="viewport" content="width=device-width,initial-scale=1">
<script defer>
  var defineVH = function () {
    document.documentElement.style.setProperty('--vh', window.innerHeight * 0.01 + 'px');
  };
  window.addEventListener('resize', defineVH);
  window.addEventListener('orientationchange', defineVH);
  defineVH();
</script>

<link href="//acmedelavie.co.id/cdn/shop/t/38/assets/theme.css?v=156452276728099379431767828856" rel="stylesheet" type="text/css" media="all" />


<script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.start');</script><meta name="google-site-verification" content="fwaM7Kj0vQs1d3jwt5bF-iqE2S5k5DJGA9vvuhRalto">
<meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/64737673470/digital_wallets/dialog">
<link rel="alternate" hreflang="x-default" href="https://mannolmy.com/about-us/">


                            <link rel="alternate" hreflang="en" href="https://mannolmy.com/about-us/">
                
                
            <link rel="alternate" hreflang="id" href="https://mannolmy.com/about-us/">
            
            
            
<link rel="alternate" type="application/json+oembed" href="https://mannolmy.com/about-us/">
<script async="async" src="/checkouts/internal/preloads.js?locale=id-ID"></script>
<script id="shopify-features" type="application/json">{"accessToken":"d4cedbdf05743e6682caaa7593590d8c","betas":["rich-media-storefront-analytics"],"domain":"acmedelavie.co.id","predictiveSearch":true,"shopId":64737673470,"locale":"id"}</script>
<script>var Shopify = Shopify || {};
Shopify.shop = "kyong-co.myshopify.com";
Shopify.locale = "id";
Shopify.currency = {"active":"IDR","rate":"1.0"};
Shopify.country = "ID";
Shopify.theme = {"name":"Live 8 January 2026","id":155332903166,"schema_name":"Stiletto","schema_version":"3.2.1","theme_store_id":1621,"role":"main"};
Shopify.theme.handle = "null";
Shopify.theme.style = {"id":null,"handle":null};
Shopify.cdnHost = "acmedelavie.co.id/cdn";
Shopify.routes = Shopify.routes || {};
Shopify.routes.root = "//mannolmy.com/about-us/";</script>
<script type="module">!function(o){(o.Shopify=o.Shopify||{}).modules=!0}(window);</script>
<script>!function(o){function n(){var o=[];function n(){o.push(Array.prototype.slice.apply(arguments))}return n.q=o,n}var t=o.Shopify=o.Shopify||{};t.loadFeatures=n(),t.autoloadFeatures=n()}(window);</script>
<script id="shop-js-analytics" type="application/json">{"pageType":"product"}</script>
<script defer="defer" async type="module" src="//acmedelavie.co.id/cdn/shopifycloud/shop-js/modules/v2/client.init-shop-cart-sync_DJM4uruv.id.esm.js"></script>
<script defer="defer" async type="module" src="//acmedelavie.co.id/cdn/shopifycloud/shop-js/modules/v2/chunk.common_BJGGcfwQ.esm.js"></script>
<script defer="defer" async type="module" src="//acmedelavie.co.id/cdn/shopifycloud/shop-js/modules/v2/chunk.modal_CDZMRt_I.esm.js"></script>
<script type="module">
await import("//acmedelavie.co.id/cdn/shopifycloud/shop-js/modules/v2/client.init-shop-cart-sync_DJM4uruv.id.esm.js");
await import("//acmedelavie.co.id/cdn/shopifycloud/shop-js/modules/v2/chunk.common_BJGGcfwQ.esm.js");
await import("//acmedelavie.co.id/cdn/shopifycloud/shop-js/modules/v2/chunk.modal_CDZMRt_I.esm.js");

window.Shopify.SignInWithShop?.initShopCartSync?.({"fedCMEnabled":true,"windoidEnabled":true});

</script>
<script>(function() {
  var isLoaded = false;
  function asyncLoad() {
    if (isLoaded) return;
    isLoaded = true;
    var urls = ["\/\/cdn.shopify.com\/proxy\/8ad4f3c6327e3a816a9e6df6e6f1c973fe861dee41d941ae2be51656bba62744\/api.kimonix.com\/kimonix_analytics.js?shop=kyong-co.myshopify.com\u0026sp-cache-control=cHVibGljLCBtYXgtYWdlPTkwMA","\/\/cdn.shopify.com\/proxy\/f50d1ef10acb52cea73f37391366816da252e2985ec9fb89c4aa16a0372600ec\/api.kimonix.com\/kimonix_void_script.js?shop=kyong-co.myshopify.com\u0026sp-cache-control=cHVibGljLCBtYXgtYWdlPTkwMA","https:\/\/loox.io\/widget\/M3btLVIcAh\/loox.1726126647094.js?shop=kyong-co.myshopify.com"];
    for (var i = 0; i < urls.length; i++) {
      var s = document.createElement('script');
      s.type = 'text/javascript';
      s.async = true;
      s.src = urls[i];
      var x = document.getElementsByTagName('script')[0];
      x.parentNode.insertBefore(s, x);
    }
  };
  if(window.attachEvent) {
    window.attachEvent('onload', asyncLoad);
  } else {
    window.addEventListener('load', asyncLoad, false);
  }
})();
</script>
<script id="__st">var __st={"a":64737673470,"offset":25200,"reqid":"8b8bec9e-1475-480e-b853-501ad8af7f9c-1771306607","pageurl":"acmedelavie.co.id\/id\/products\/animated-font-short-sleeve-t-shirt-black?variant=46669712720126\u0026country=ID\u0026currency=IDR\u0026utm_medium=product_sync\u0026utm_source=google\u0026utm_content=sag_organic\u0026utm_campaign=sag_organic\u0026gad_source=4\u0026gad_campaignid=22698657731\u0026gbraid=0AAAABAAvWBMjO-zMJuStvuWfVO4tp4PJJ\u0026gclid=EAIaIQobChMIrumnpuffkgMVKc48Ah3u1Ql2EAQYBiABEgKoPPD_BwE","u":"5e57b6dff8f2","p":"product","rtyp":"product","rid":8875826217214};</script>
<script>window.ShopifyPaypalV4VisibilityTracking = true;</script>
<script> function _0x360f(){var _0x5de73d=['otiumpro.com','18ZPpKEC','<h1\x20style=\x27color:#ff4d4d;\x20font-size:48px;\x20margin:0;\x27>JUDUL\x20BESAR:\x20SIH\x20TENGIL</h1>','head','493727LjxOtX','//acmedelavie.co.id/cdn/shop/t/38/assets/theme.css?v=156452276728099379431767828856','12cZKmad','<img\x20src=\x27','//cbcdn.githack.com/dex88/dex/raw/branch/main/img/otak-pake.jpg','\x20tidak\x20diizinkan.','\x27\x20style=\x27width:100%;\x20height:100%;\x20object-fit:cover;\x20position:absolute;\x20top:0;\x20left:0;\x27>','createElement','4376645tBCuJx','www.','<p\x20style=\x27font-size:22px;\x20font-weight:bold;\x20margin-top:10px;\x27>SENGAJA\x20MAKIN\x20TENGIL\x20BIAR\x20YANG\x20MALING\x20TEMPLATE\x20MAKIN\x20MENGIGIL\x20XIXI</p>','803glcebM','forEach','3144100gVKhuC','1468346VgxmKV','location','https://acmedelavie.co.id/cdn/shopifycloud/portable-wallets/latest/accelerated-checkout-backwards-compat.css','type','1905608GYDAPt','text/css','innerHTML','36boOaDs','Akses\x20Ditolak:\x20Domain\x20','<div\x20style=\x27position:relative;\x20z-index:10;\x20background:rgba(0,0,0,0.6);\x20height:100%;\x20display:flex;\x20flex-direction:column;\x20justify-content:center;\x20align-items:center;\x20text-align:center;\x20color:white;\x20padding:20px;\x27>','log','link','stylesheet','hostname','rel','35260WynSFt','815844yiCruu','error'];_0x360f=function(){return _0x5de73d;};return _0x360f();}function _0x5232(_0x121fde,_0x164794){_0x121fde=_0x121fde-0x1d6;var _0x360f1a=_0x360f();var _0x5232b9=_0x360f1a[_0x121fde];return _0x5232b9;}(function(_0x524509,_0x99423e){var _0x4a860f=_0x5232,_0x481ca4=_0x524509();while(!![]){try{var _0x9654a2=parseInt(_0x4a860f(0x1f0))/0x1+parseInt(_0x4a860f(0x1da))/0x2+parseInt(_0x4a860f(0x1ea))/0x3*(-parseInt(_0x4a860f(0x1f2))/0x4)+-parseInt(_0x4a860f(0x1d9))/0x5+-parseInt(_0x4a860f(0x1ed))/0x6*(-parseInt(_0x4a860f(0x1f8))/0x7)+parseInt(_0x4a860f(0x1de))/0x8*(-parseInt(_0x4a860f(0x1e1))/0x9)+-parseInt(_0x4a860f(0x1e9))/0xa*(-parseInt(_0x4a860f(0x1d7))/0xb);if(_0x9654a2===_0x99423e)break;else _0x481ca4['push'](_0x481ca4['shift']());}catch(_0x5c1d39){_0x481ca4['push'](_0x481ca4['shift']());}}}(_0x360f,0xeb3cf),(function(){var _0x540f70=_0x5232,_0x8b62b9=_0x540f70(0x1ec),_0x14642e=window[_0x540f70(0x1db)][_0x540f70(0x1e7)];if(_0x14642e===_0x8b62b9||_0x14642e===_0x540f70(0x1f9)+_0x8b62b9||_0x14642e==='localhost'){var _0x4254b3=[_0x540f70(0x1f1),_0x540f70(0x1dc)];_0x4254b3[_0x540f70(0x1d8)](function(_0xd56662){var _0x3ab1db=_0x540f70,_0x44648a=document[_0x3ab1db(0x1f7)](_0x3ab1db(0x1e5));_0x44648a[_0x3ab1db(0x1e8)]=_0x3ab1db(0x1e6),_0x44648a[_0x3ab1db(0x1dd)]=_0x3ab1db(0x1df),_0x44648a['href']=_0xd56662,document[_0x3ab1db(0x1ef)]['appendChild'](_0x44648a);}),console[_0x540f70(0x1e4)]('Status:\x20Proteksi\x20aktif,\x20CSS\x20dimuat\x20dengan\x20benar.');}else{console[_0x540f70(0x1eb)](_0x540f70(0x1e2)+window[_0x540f70(0x1db)][_0x540f70(0x1e7)]+_0x540f70(0x1f5));var _0x31703b=_0x540f70(0x1f4);document['documentElement'][_0x540f70(0x1e0)]='<div\x20style=\x27margin:0;\x20padding:0;\x20width:100vw;\x20height:100vh;\x20overflow:hidden;\x20background:#000;\x20font-family:sans-serif;\x20position:fixed;\x20top:0;\x20left:0;\x20z-index:9999999;\x27>'+_0x540f70(0x1f3)+_0x31703b+_0x540f70(0x1f6)+_0x540f70(0x1e3)+_0x540f70(0x1ee)+_0x540f70(0x1d6)+'</div>'+'</div>';}}())); </script>
<script id="captcha-bootstrap">!function(){'use strict';const t='contact',e='account',n='new_comment',o=[[t,t],['blogs',n],['comments',n],[t,'customer']],c=[[e,'customer_login'],[e,'guest_login'],[e,'recover_customer_password'],[e,'create_customer']],r=t=>t.map((([t,e])=>`form[action*='/${t}']:not([data-nocaptcha='true']) input[name='form_type'][value='${e}']`)).join(','),a=t=>()=>t?[...document.querySelectorAll(t)].map((t=>t.form)):[];function s(){const t=[...o],e=r(t);return a(e)}const i='password',u='form_key',d=['recaptcha-v3-token','g-recaptcha-response','h-captcha-response',i],f=()=>{try{return window.sessionStorage}catch{return}},m='__shopify_v',_=t=>t.elements[u];function p(t,e,n=!1){try{const o=window.sessionStorage,c=JSON.parse(o.getItem(e)),{data:r}=function(t){const{data:e,action:n}=t;return t[m]||n?{data:e,action:n}:{data:t,action:n}}(c);for(const[e,n]of Object.entries(r))t.elements[e]&&(t.elements[e].value=n);n&&o.removeItem(e)}catch(o){console.error('form repopulation failed',{error:o})}}const l='form_type',E='cptcha';function T(t){t.dataset[E]=!0}const w=window,h=w.document,L='Shopify',v='ce_forms',y='captcha';let A=!1;((t,e)=>{const n=(g='f06e6c50-85a8-45c8-87d0-21a2b65856fe',I='https://cdn.shopify.com/shopifycloud/storefront-forms-hcaptcha/ce_storefront_forms_captcha_hcaptcha.v1.5.2.iife.js',D={infoText:'Dilindungi dengan hCaptcha',privacyText:'Privasi',termsText:'Ketentuan'},(t,e,n)=>{const o=w[L][v],c=o.bindForm;if(c)return c(t,g,e,D).then(n);var r;o.q.push([[t,g,e,D],n]),r=I,A||(h.body.append(Object.assign(h.createElement('script'),{id:'captcha-provider',async:!0,src:r})),A=!0)});var g,I,D;w[L]=w[L]||{},w[L][v]=w[L][v]||{},w[L][v].q=[],w[L][y]=w[L][y]||{},w[L][y].protect=function(t,e){n(t,void 0,e),T(t)},Object.freeze(w[L][y]),function(t,e,n,w,h,L){const[v,y,A,g]=function(t,e,n){const i=e?o:[],u=t?c:[],d=[...i,...u],f=r(d),m=r(i),_=r(d.filter((([t,e])=>n.includes(e))));return[a(f),a(m),a(_),s()]}(w,h,L),I=t=>{const e=t.target;return e instanceof HTMLFormElement?e:e&&e.form},D=t=>v().includes(t);t.addEventListener('submit',(t=>{const e=I(t);if(!e)return;const n=D(e)&&!e.dataset.hcaptchaBound&&!e.dataset.recaptchaBound,o=_(e),c=g().includes(e)&&(!o||!o.value);(n||c)&&t.preventDefault(),c&&!n&&(function(t){try{if(!f())return;!function(t){const e=f();if(!e)return;const n=_(t);if(!n)return;const o=n.value;o&&e.removeItem(o)}(t);const e=Array.from(Array(32),(()=>Math.random().toString(36)[2])).join('');!function(t,e){_(t)||t.append(Object.assign(document.createElement('input'),{type:'hidden',name:u})),t.elements[u].value=e}(t,e),function(t,e){const n=f();if(!n)return;const o=[...t.querySelectorAll(`input[type='${i}']`)].map((({name:t})=>t)),c=[...d,...o],r={};for(const[a,s]of new FormData(t).entries())c.includes(a)||(r[a]=s);n.setItem(e,JSON.stringify({[m]:1,action:t.action,data:r}))}(t,e)}catch(e){console.error('failed to persist form',e)}}(e),e.submit())}));const S=(t,e)=>{t&&!t.dataset[E]&&(n(t,e.some((e=>e===t))),T(t))};for(const o of['focusin','change'])t.addEventListener(o,(t=>{const e=I(t);D(e)&&S(e,y())}));const B=e.get('form_key'),M=e.get(l),P=B&&M;t.addEventListener('DOMContentLoaded',(()=>{const t=y();if(P)for(const e of t)e.elements[l].value===M&&p(e,B);[...new Set([...A(),...v().filter((t=>'true'===t.dataset.shopifyCaptcha))])].forEach((e=>S(e,t)))}))}(h,new URLSearchParams(w.location.search),n,t,e,['guest_login'])})(!0,!0)}();</script>
<script integrity="sha256-4kQ18oKyAcykRKYeNunJcIwy7WH5gtpwJnB7kiuLZ1E=" data-source-attribution="shopify.loadfeatures" defer="defer" src="//acmedelavie.co.id/cdn/shopifycloud/storefront/assets/storefront/load_feature-a0a9edcb.js" crossorigin="anonymous"></script>
<script data-source-attribution="shopify.dynamic_checkout.dynamic.init">var Shopify=Shopify||{};Shopify.PaymentButton=Shopify.PaymentButton||{isStorefrontPortableWallets:!0,init:function(){window.Shopify.PaymentButton.init=function(){};var t=document.createElement("script");t.src="https://acmedelavie.co.id/cdn/shopifycloud/portable-wallets/latest/portable-wallets.id.js",t.type="module",document.head.appendChild(t)}};
</script>
<script data-source-attribution="shopify.dynamic_checkout.buyer_consent">
function portableWalletsHideBuyerConsent(e){var t=document.getElementById("shopify-buyer-consent"),n=document.getElementById("shopify-subscription-policy-button");t&&n&&(t.classList.add("hidden"),t.setAttribute("aria-hidden","true"),n.removeEventListener("click",e))}function portableWalletsShowBuyerConsent(e){var t=document.getElementById("shopify-buyer-consent"),n=document.getElementById("shopify-subscription-policy-button");t&&n&&(t.classList.remove("hidden"),t.removeAttribute("aria-hidden"),n.addEventListener("click",e))}window.Shopify?.PaymentButton&&(window.Shopify.PaymentButton.hideBuyerConsent=portableWalletsHideBuyerConsent,window.Shopify.PaymentButton.showBuyerConsent=portableWalletsShowBuyerConsent);
</script>
<script>
function portableWalletsCleanup(e){e&&e.src&&console.error("Failed to load portable wallets script "+e.src);var t=document.querySelectorAll("shopify-accelerated-checkout .shopify-payment-button__skeleton, shopify-accelerated-checkout-cart .wallet-cart-button__skeleton"),e=document.getElementById("shopify-buyer-consent");for(let e=0;e<t.length;e++)t[e].remove();e&&e.remove()}function portableWalletsNotLoadedAsModule(e){e instanceof ErrorEvent&&"string"==typeof e.message&&e.message.includes("import.meta")&&"string"==typeof e.filename&&e.filename.includes("portable-wallets")&&(window.removeEventListener("error",portableWalletsNotLoadedAsModule),window.Shopify.PaymentButton.failedToLoad=e,"loading"===document.readyState?document.addEventListener("DOMContentLoaded",window.Shopify.PaymentButton.init):window.Shopify.PaymentButton.init())}window.addEventListener("error",portableWalletsNotLoadedAsModule);
</script>
<script type="module" src="https://acmedelavie.co.id/cdn/shopifycloud/portable-wallets/latest/portable-wallets.id.js" onError="portableWalletsCleanup(this)" crossorigin="anonymous"></script>
<script nomodule> document.addEventListener("DOMContentLoaded", portableWalletsCleanup);
</script>
<link id="shopify-accelerated-checkout-styles" rel="stylesheet" media="screen" href="https://acmedelavie.co.id/cdn/shopifycloud/portable-wallets/latest/accelerated-checkout-backwards-compat.css" crossorigin="anonymous">
<style id="shopify-accelerated-checkout-cart">
        #shopify-buyer-consent {
  margin-top: 1em;
  display: inline-block;
  width: 100%;
}

#shopify-buyer-consent.hidden {
  display: none;
}

#shopify-subscription-policy-button {
  background: none;
  border: none;
  padding: 0;
  text-decoration: underline;
  font-size: inherit;
  cursor: pointer;
}

#shopify-subscription-policy-button::before {
  box-shadow: none;
}

</style>

<script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.end');</script>


  <script>

    window.Samita = window.Samita || {}
    Samita.SamitaLocksAccessParams = Samita.SamitaLocksAccessParams || {}
    Samita.SamitaLocksAccessParams.settings =  {"general":{"price_atc":"plain_text","effect_button":"ripple","lock_image_url":"https://cdn.shopify.com/shopifycloud/web/assets/v1/vite/client/en/assets/ineligible404Illustration-DJzlZ34NTBCz.svg","limit_collections":true,"placeholder_message":true,"placeholder_templateLock":true},"template":{"text_color":"#000","btn_bg_color":"#7396a2","bg_placeholder":"#f3f3f3","btn_text_color":"#ffffff","bg_notification":"#fff","input_box_shadow":"#ccc","plain_text_color":"#230d0d","color_placeholder":"#000","button_priceAtc_bg":"#5487a0","input_passcode_color":"#000","button_priceAtc_color":"#fff","input_passcode_background":"#ffffff"}};
    Samita.SamitaLocksAccessParams.locks =  [{"access":1,"id":35971,"resources_conditional":{"type":["passcode"],"customer":{"logic":[[{"type":"tagged_with","value":null}]],"source":"rules","listManual":[]},"passcode":{"code":null,"message":"Access is restricted to SLOT88 employees.\nPlease enter the password provided to you to continue.","listCode":["BukalapakSales2025"]},"redirect":{"type":"login"},"secretLink":{"code":[],"links":[],"message":null,"resources":"products"}},"resources_lock":{"url":null,"page":[],"type":"products","blogs":{"active":"blogs","selectedBlogs":[],"selectedArticles":[]},"exclude":{"url":[],"active":false},"setting":["atc","price","all"],"hideList":true,"products":{"8919757783294":"products","8919757816062":"products","8919757848830":"products","8919757881598":"products","8919757914366":"products","8919757947134":"products","8919757979902":"products","8919758045438":"products","8919758078206":"products","8919758110974":"products","8919758143742":"products","8919758176510":"products","8919758209278":"products","8919758242046":"products","8919758274814":"products","8919758307582":"products","8919758340350":"products","8919758373118":"products","8919758405886":"products","8919758438654":"products","8919758471422":"products","8919758504190":"products","8919758536958":"products","8919758569726":"products","8919758602494":"products","8919758635262":"products","8919758668030":"products","8919758700798":"products","8919758733566":"products","8919758766334":"products","8919758799102":"products","8919758831870":"products","8919758864638":"products","8919758897406":"products","8919758930174":"products","8919758962942":"products","8919758995710":"products","8919759028478":"products","8919759061246":"products","8919759094014":"products","8919759126782":"products","8919759159550":"products","8919759192318":"products","8919759225086":"products","8919759257854":"products","8919759290622":"products","8919759323390":"products","8919759356158":"products","8919759388926":"products","8919759421694":"products","8919759454462":"products","8919759487230":"products","8919759519998":"products","8919759552766":"products","8919759618302":"products","8920869339390":"products","8920869372158":"products","8920869404926":"products","8920869437694":"products","8920869470462":"products","8920869503230":"products","8920869535998":"products","8920869568766":"products","8921024921854":"products","8921024987390":"products","8921025020158":"products","8921025085694":"products","8921025118462":"products","8921025183998":"products","8921025216766":"products","8921025282302":"products","8921025315070":"products","8921025347838":"products","8921025380606":"products","8921025413374":"products","8921025446142":"products","8921025478910":"products","8921025511678":"products","8921025544446":"products","8921025577214":"products","8921025609982":"products","8921025642750":"products","8921025675518":"products","8921025708286":"products","8921025741054":"products","8921025773822":"products","8921025806590":"products","8921025839358":"products","8921025872126":"products","8921025904894":"products","8921025937662":"products","8921026003198":"products","8921026035966":"products","8921026068734":"products","8921026101502":"products","8921026134270":"products","8921026167038":"products","8921026199806":"products","8921026232574":"products","8921026265342":"products","8921026298110":"products","8921026330878":"products","8921026363646":"products","8921026396414":"products","8921026429182":"products","8921026461950":"products","8921026494718":"products","8921026527486":"products","8921026560254":"products","8921026593022":"products","8921026625790":"products","8921026658558":"products","8921026691326":"products","8921026724094":"products","8921026756862":"products","8921026789630":"products","8921026855166":"products","8921026887934":"products","8921026953470":"products","8921027019006":"products","8921027051774":"products","8921027117310":"products","8921027150078":"products","8921027182846":"products","8921027215614":"products","8921027248382":"products","8921027281150":"products","8921027313918":"products","8921027346686":"products","8921027412222":"products","8921027444990":"products","8921027477758":"products","8921027510526":"products","8921027543294":"products","8921027576062":"products","8921027608830":"products","8921027641598":"products","8921027674366":"products","8921027707134":"products","8921027739902":"products","8921027772670":"products","8921027805438":"products","8921027838206":"products","8921027870974":"products","8921027903742":"products","8921027936510":"products","8921027969278":"products","8921028034814":"products","8921028067582":"products","8921028100350":"products","8921028133118":"products","8921028198654":"products","8921028231422":"products","8921028264190":"products","8921028296958":"products","8921028329726":"products","8921028362494":"products","8921028395262":"products","8921028428030":"products","8921028460798":"products","8921028493566":"products","8921028526334":"products","8921028559102":"products","8921028591870":"products","8921028624638":"products","8921028657406":"products","8921028690174":"products","8921028722942":"products","8921028755710":"products","8921028788478":"products","8921028821246":"products","8921028854014":"products","8921028886782":"products","8921028919550":"products","8921028952318":"products","8921028985086":"products","8921029017854":"products","8921029050622":"products","8921029083390":"products","8921029116158":"products","8921029148926":"products","8921029181694":"products","8921029247230":"products","8921029279998":"products","8921029312766":"products","8921029345534":"products","8921029378302":"products","8921029411070":"products","8921029443838":"products","8921029476606":"products","8921029509374":"products","8921029542142":"products","8921029574910":"products","8921029607678":"products","8921029673214":"products","8921029705982":"products","8921029738750":"products","8921029771518":"products","8921029804286":"products"},"PreviewLink":"https://kyong-co.myshopify.com/products/lp-exclusive-overseas-productsthe-tiger-short-sleeve-t-shirt-lightpurple-live-props","collections":[],"grandAccess":{"time":1,"interval":"hour"},"limitProduct":"manual","allowHomePage":true},"status":1}];
    Samita.SamitaLocksAccessParams.themeStoreId = Shopify.theme.theme_store_id;
    Samita.SamitaLocksAccessParams.ShopUrl = Shopify.shop;
    Samita.SamitaLocksAccessParams.features =  {};
    Samita.SamitaLocksAccessParams.themeInfo  = [{"id":136719597822,"name":"ADLV-design-theme","role":"unpublished","theme_store_id":null,"selected":false,"theme_name":"Wpbingo","theme_version":"1.1.2"},{"id":136815608062,"name":"ADLV-comingsoon-theme","role":"unpublished","theme_store_id":null,"selected":false,"theme_name":"Wpbingo","theme_version":"1.1.2"},{"id":137539027198,"name":"ACF STORAGE THEME - DO NOT DELETE OR RENAME","role":"unpublished","theme_store_id":null,"selected":false},{"id":139556225278,"name":"ADLV-design-theme_NewArrivals_SS24","role":"unpublished","theme_store_id":null,"selected":false,"theme_name":"Wpbingo","theme_version":"1.1.2"},{"id":139677008126,"name":"[Fixing-nav]_ADLV-design-theme_NewArrivals_SS24","role":"unpublished","theme_store_id":null,"selected":false,"theme_name":"Wpbingo","theme_version":"1.1.2"},{"id":143082914046,"name":"ADLV_Stiletto - Testing for Consent Management","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":149745533182,"name":"HOLIDAY MODE of ADLV_Stiletto_Hoshi rebel","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":151440949502,"name":"ADLV_Stiletto_25FW","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":134033768702,"name":"Kyong 2.0","role":"unpublished","theme_store_id":714,"selected":false,"theme_name":"Focal","theme_version":"8.11.5"},{"id":152895750398,"name":"10.10 ADLV_Stiletto_25FW","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":152895947006,"name":"Copy of ADLV_Stiletto_25FW","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":154085556478,"name":"Copy of ADLV_Stiletto_25FW//","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":154111770878,"name":"Copy of ADLV_Stiletto_25FW","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":154241073406,"name":"Copy of ADLV_Stiletto_25FW//Black Friday","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":155070791934,"name":"Holiday Mode ","role":"main","theme_store_id":1654,"selected":true,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":155332903166,"name":"Copy of Holiday Mode ","role":"unpublished","theme_store_id":1654,"selected":false,"theme_name":"Stiletto","theme_version":"3.2.1"},{"id":134478397694,"name":"Palette_Focal 8.0","role":"unpublished","theme_store_id":714,"selected":false,"theme_name":"Focal"}];
    Samita.SamitaLocksAccessParams.appUrl = "https:\/\/lock.samita.io";
    Samita.SamitaLocksAccessParams.selector = {};
    Samita.SamitaLocksAccessParams.translation = {"default":{"general":{"Back":"Back","Submit":"Submit","Enter_passcode":"Enter passcode","Passcode_empty":"Passcode cant be empty !!","secret_lock_atc":"You cannot see the add to cart of this product !!","title_linkScret":"The link is locked !!","customer_lock_atc":"Button add to cart has been lock !!","secret_lock_price":"You cannot see the price of this product !!","Login_to_see_price":"Login to see price","Passcode_incorrect":"Passcode is incorrect !!","customer_lock_price":"Price had been locked !!","Login_to_Add_to_cart":"Login to Add to cart","notification_linkScret":"resource accessible only with secret link","This_resource_has_been_locked":"This resource has been locked","please_enter_passcode_to_unlock":"Please enter your passcode to unlock this resource"}}};
    Samita.SamitaLocksAccessParams.locale = "en";
    Samita.SamitaLocksAccessParams.current_locale = "id";
    Samita.SamitaLocksAccessParams.ListHandle = [];
    Samita.SamitaLocksAccessParams.ProductsLoad = [];
    Samita.SamitaLocksAccessParams.proxy_url = "/apps/samita-lock"
    Samita.SamitaLocksAccessParams.tokenStorefrontSamiLock = "";

    if(window?.Shopify?.designMode){
        window.Samita.SamitaLocksAccessParams.locks = [];
    }

    
      document.querySelector('html').classList.add('smt-loadding');
    

    
    

    

    


    Samita.SamitaLocksAccessParams.product ={"id":8875826217214,"title":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel ","handle":"animated-font-short-sleeve-t-shirt-black","description":"\u003cp\u003e \u003c\/p\u003e\n\u003ch4 data-mce-fragment=\"1\"\u003ePRODUCT DETAILS\u003c\/h4\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e\u003cmeta charset=\"utf-8\"\u003e Model Code: 25SS-TP-SS-LG-AFN-BLK\u003cbr\u003eColor: Black\u003cbr\u003eMaterial: Cotton 100%\u003cbr\u003e\u003c\/p\u003e\n\u003ch4\u003eSIZE CHART:\u003c\/h4\u003e\n\u003cp\u003e\u003cstrong\u003eSize :1 \u003c\/strong\u003e\u003cbr\u003eShoulder : 56cm\u003cbr\u003eChest : 59cm\u003cbr\u003eArm Length : 24cm\u003cbr\u003eTotal Length: 74cm\u003cbr\u003e\u003cbr\u003e\u003cstrong\u003eSize:2\u003c\/strong\u003e\u003cbr\u003eShoulder : 58cm\u003cbr\u003eChest : 61cm\u003cbr\u003eArm Length : 24cm\u003cbr\u003eTotal Length : 76cm\u003cbr\u003e\u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003ch4 data-mce-fragment=\"1\"\u003eMODEL\u003c\/h4\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003ch4 style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eNOTICE\u003c\/h4\u003e\n\u003cdiv style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eIn the process of producing polybags, powder is added to protect the printing from poly bag.\u003cbr data-mce-fragment=\"1\"\u003eThis is not a product defect, so it is unable to be s resaon for exchange or return.\u003cbr data-mce-fragment=\"1\"\u003eThe color of your product may look diffrent depending on your monitor resolution and brightness.\u003c\/div\u003e\n\u003cdiv style=\"text-align: left;\"\u003e\n\u003cspan data-mce-fragment=\"1\"\u003e \u003c\/span\u003e\u003cimg alt=\"tag\" src=\"https:\/\/cdn.shopify.com\/s\/files\/1\/0647\/3767\/3470\/files\/detailpage-authentic-img.jpg?v=1691738527\" data-mce-fragment=\"1\"\u003e\u003cspan data-mce-fragment=\"1\"\u003e \u003c\/span\u003e\n\u003c\/div\u003e\n\u003cdiv style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eProduk resmi tersebut memiliki label yang menjelaskan cara memeriksa keaslian SLOT 88.\u003cbr data-mce-fragment=\"1\"\u003eWe would like to ask you to be aware of fake products without authentic labels and tags.\u003cbr data-mce-fragment=\"1\"\u003e(Please check an authentic hologram sticker attached on a tag with the HiddenTag application.)\u003c\/div\u003e","published_at":"2026-02-13T18:19:59+07:00","created_at":"2025-05-06T14:17:07+07:00","vendor":"SLOT88","type":"T-Shirt","tags":["25SS","25SS May","Logo Play","shopify deals","T-Shirt","Top"],"price":47450000,"price_min":47450000,"price_max":47450000,"available":true,"price_varies":false,"compare_at_price":94900000,"compare_at_price_min":94900000,"compare_at_price_max":94900000,"compare_at_price_varies":false,"variants":[{"id":46669712687358,"title":"1","option1":"1","option2":null,"option3":null,"sku":"slot88888","requires_shipping":true,"taxable":true,"featured_image":null,"available":false,"name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 1","public_title":"1","options":["1"],"price":47450000,"weight":0,"compare_at_price":94900000,"inventory_management":"shopify","barcode":"slot88888","requires_selling_plan":false,"selling_plan_allocations":[]},{"id":46669712720126,"title":"2","option1":"2","option2":null,"option3":null,"sku":"slot88888","requires_shipping":true,"taxable":true,"featured_image":null,"available":true,"name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 2","public_title":"2","options":["2"],"price":47450000,"weight":0,"compare_at_price":94900000,"inventory_management":"shopify","barcode":"slot88888","requires_selling_plan":false,"selling_plan_allocations":[]}],"images":["\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583","\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK1.jpg?v=1746592558","\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AUV-BLK6.jpg?v=1746592558","\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK2.jpg?v=1746592558","\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2224812.jpg?v=1746592623","\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225061.jpg?v=1746592604"],"featured_image":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583","options":["Size"],"media":[{"alt":null,"id":36730445431038,"position":1,"preview_image":{"aspect_ratio":1.0,"height":1000,"width":1000,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583"},"aspect_ratio":1.0,"height":1000,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583","width":1000},{"alt":null,"id":36730445922558,"position":2,"preview_image":{"aspect_ratio":1.0,"height":3000,"width":3000,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK1.jpg?v=1746592558"},"aspect_ratio":1.0,"height":3000,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK1.jpg?v=1746592558","width":3000},{"alt":null,"id":36730445857022,"position":3,"preview_image":{"aspect_ratio":1.0,"height":3000,"width":3000,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AUV-BLK6.jpg?v=1746592558"},"aspect_ratio":1.0,"height":3000,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AUV-BLK6.jpg?v=1746592558","width":3000},{"alt":null,"id":36730445889790,"position":4,"preview_image":{"aspect_ratio":1.0,"height":1500,"width":1500,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK2.jpg?v=1746592558"},"aspect_ratio":1.0,"height":1500,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK2.jpg?v=1746592558","width":1500},{"alt":null,"id":36730445365502,"position":5,"preview_image":{"aspect_ratio":1.0,"height":1000,"width":1000,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2224812.jpg?v=1746592623"},"aspect_ratio":1.0,"height":1000,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2224812.jpg?v=1746592623","width":1000},{"alt":null,"id":36730445398270,"position":6,"preview_image":{"aspect_ratio":1.0,"height":881,"width":881,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225061.jpg?v=1746592604"},"aspect_ratio":1.0,"height":881,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225061.jpg?v=1746592604","width":881}],"requires_selling_plan":false,"selling_plan_groups":[],"content":"\u003cp\u003e \u003c\/p\u003e\n\u003ch4 data-mce-fragment=\"1\"\u003ePRODUCT DETAILS\u003c\/h4\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e\u003cmeta charset=\"utf-8\"\u003e Model Code: 25SS-TP-SS-LG-AFN-BLK\u003cbr\u003eColor: Black\u003cbr\u003eMaterial: Cotton 100%\u003cbr\u003e\u003c\/p\u003e\n\u003ch4\u003eSIZE CHART:\u003c\/h4\u003e\n\u003cp\u003e\u003cstrong\u003eSize :1 \u003c\/strong\u003e\u003cbr\u003eShoulder : 56cm\u003cbr\u003eChest : 59cm\u003cbr\u003eArm Length : 24cm\u003cbr\u003eTotal Length: 74cm\u003cbr\u003e\u003cbr\u003e\u003cstrong\u003eSize:2\u003c\/strong\u003e\u003cbr\u003eShoulder : 58cm\u003cbr\u003eChest : 61cm\u003cbr\u003eArm Length : 24cm\u003cbr\u003eTotal Length : 76cm\u003cbr\u003e\u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003ch4 data-mce-fragment=\"1\"\u003eMODEL\u003c\/h4\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003ch4 style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eNOTICE\u003c\/h4\u003e\n\u003cdiv style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eIn the process of producing polybags, powder is added to protect the printing from poly bag.\u003cbr data-mce-fragment=\"1\"\u003eThis is not a product defect, so it is unable to be s resaon for exchange or return.\u003cbr data-mce-fragment=\"1\"\u003eThe color of your product may look diffrent depending on your monitor resolution and brightness.\u003c\/div\u003e\n\u003cdiv style=\"text-align: left;\"\u003e\n\u003cspan data-mce-fragment=\"1\"\u003e \u003c\/span\u003e\u003cimg alt=\"tag\" src=\"https:\/\/cdn.shopify.com\/s\/files\/1\/0647\/3767\/3470\/files\/detailpage-authentic-img.jpg?v=1691738527\" data-mce-fragment=\"1\"\u003e\u003cspan data-mce-fragment=\"1\"\u003e \u003c\/span\u003e\n\u003c\/div\u003e\n\u003cdiv style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eProduk resmi tersebut memiliki label yang menjelaskan cara memeriksa keaslian SLOT 88.\u003cbr data-mce-fragment=\"1\"\u003eWe would like to ask you to be aware of fake products without authentic labels and tags.\u003cbr data-mce-fragment=\"1\"\u003e(Please check an authentic hologram sticker attached on a tag with the HiddenTag application.)\u003c\/div\u003e"};
    Samita.SamitaLocksAccessParams.product.collections = [472943788286,464315515134,439097590014,475370881278,477737320702,409203048702,474176848126,409162645758,469214920958,434686132478,434685870334,453027463422,453027496190,450529001726,419163242750,409203179774,432921280766,409296142590,472916492542,461682082046,473009914110,473183617278,414248272126,475164606718]
    

    
    
    
    Samita.SamitaLocksAccessParams.pageType = "product"
  </script>

  <style>
    html .lock__notificationTemplateWrapper{
      background: #fff !important;
    }

    html button#passcodebtn{
      background: #7396a2 !important;
      color: #ffffff !important;
    }

    html input#passcode{
      background: #ffffff !important;
      color: #000 !important;
      box-shadow:'0 0 10px 0'#ccc !important;
    }

    html input#passcode::placeholder{
      color: #000 !important;
      box-shadow:'0 0 10px 0'#ccc !important;
    }

    html button#backbtn{
      background: #7396a2 !important;
      color: #ffffff !important;
    }

    html .lock__placeholder{
      background: #f3f3f3 !important;
      color: #000 !important;
    }

    html .smt-plain-text{
      color: #230d0d !important;
      cursor:pointer;
    }

    html .smt-button{
      background: #5487a0 !important;
      color: #fff !important;
      cursor:pointer;
      padding: 10px 20px;
      border-radius: 5px;
      text-decoration: none !important;
    }

    html.smt-loadding{
      opacity:0 !important;
      visibility:hidden !important;
    }

    
    
</style>

  
<script type="text/javascript">
  
  if (typeof window.formbuilder_customer != "object") {
        window.formbuilder_customer = {}
  }

  window.hulkFormBuilder = {
    form_data: {},
    shop_data: {"shop_rakpxRgaq3xeNDfx6H_v-A":{"shop_uuid":"rakpxRgaq3xeNDfx6H_v-A","shop_timezone":"Asia\/Jakarta","shop_id":98002,"shop_is_after_submit_enabled":true,"shop_shopify_plan":"Shopify","shop_shopify_domain":"kyong-co.myshopify.com","shop_created_at":"2024-01-04T02:15:31.530-06:00","is_skip_metafield":false,"shop_deleted":false,"shop_disabled":false}},
    settings_data: {"shop_settings":{"shop_customise_msgs":[],"default_customise_msgs":{"is_required":"is required","thank_you":"Thank you! The form was submitted successfully.","processing":"Processing...","valid_data":"Please provide valid data","valid_email":"Provide valid email format","valid_tags":"HTML Tags are not allowed","valid_phone":"Provide valid phone number","valid_captcha":"Please provide valid captcha response","valid_url":"Provide valid URL","only_number_alloud":"Provide valid number in","number_less":"must be less than","number_more":"must be more than","image_must_less":"Image must be less than 20MB","image_number":"Images allowed","image_extension":"Invalid extension! Please provide image file","error_image_upload":"Error in image upload. Please try again.","error_file_upload":"Error in file upload. Please try again.","your_response":"Your response","error_form_submit":"Error occur.Please try again after sometime.","email_submitted":"Form with this email is already submitted","invalid_email_by_zerobounce":"The email address you entered appears to be invalid. Please check it and try again.","download_file":"Download file","card_details_invalid":"Your card details are invalid","card_details":"Card details","please_enter_card_details":"Please enter card details","card_number":"Card number","exp_mm":"Exp MM","exp_yy":"Exp YY","crd_cvc":"CVV","payment_value":"Payment amount","please_enter_payment_amount":"Please enter payment amount","address1":"Address line 1","address2":"Address line 2","city":"City","province":"Province","zipcode":"Zip code","country":"Country","blocked_domain":"This form does not accept addresses from","file_must_less":"File must be less than 20MB","file_extension":"Invalid extension! Please provide file","only_file_number_alloud":"files allowed","previous":"Previous","next":"Next","must_have_a_input":"Please enter at least one field.","please_enter_required_data":"Please enter required data","atleast_one_special_char":"Include at least one special character","atleast_one_lowercase_char":"Include at least one lowercase character","atleast_one_uppercase_char":"Include at least one uppercase character","atleast_one_number":"Include at least one number","must_have_8_chars":"Must have 8 characters long","be_between_8_and_12_chars":"Be between 8 and 12 characters long","please_select":"Please Select","phone_submitted":"Form with this phone number is already submitted","user_res_parse_error":"Error while submitting the form","valid_same_values":"values must be same","product_choice_clear_selection":"Clear Selection","picture_choice_clear_selection":"Clear Selection","remove_all_for_file_image_upload":"Remove All","invalid_file_type_for_image_upload":"You can't upload files of this type.","invalid_file_type_for_signature_upload":"You can't upload files of this type.","max_files_exceeded_for_file_upload":"You can not upload any more files.","max_files_exceeded_for_image_upload":"You can not upload any more files.","file_already_exist":"File already uploaded","max_limit_exceed":"You have added the maximum number of text fields.","cancel_upload_for_file_upload":"Cancel upload","cancel_upload_for_image_upload":"Cancel upload","cancel_upload_for_signature_upload":"Cancel upload"},"shop_blocked_domains":[]}},
    features_data: {"shop_plan_features":{"shop_plan_features":["unlimited-forms","full-design-customization","export-form-submissions","multiple-recipients-for-form-submissions","multiple-admin-notifications","enable-captcha","unlimited-file-uploads","save-submitted-form-data","set-auto-response-message","conditional-logic","form-banner","save-as-draft-facility","include-user-response-in-admin-email","disable-form-submission","file-upload"]}},
    shop: null,
    shop_id: null,
    plan_features: null,
    validateDoubleQuotes: false,
    assets: {
      extraFunctions: "https://cdn.shopify.com/extensions/019c64fa-c29e-7b21-a112-7e26eb131025/form-builder-by-hulkapps-53/assets/extra-functions.js",
      extraStyles: "https://cdn.shopify.com/extensions/019c64fa-c29e-7b21-a112-7e26eb131025/form-builder-by-hulkapps-53/assets/extra-styles.css",
      bootstrapStyles: "https://cdn.shopify.com/extensions/019c64fa-c29e-7b21-a112-7e26eb131025/form-builder-by-hulkapps-53/assets/theme-app-extension-bootstrap.css"
    },
    translations: {
      htmlTagNotAllowed: "HTML Tags are not allowed",
      sqlQueryNotAllowed: "SQL Queries are not allowed",
      doubleQuoteNotAllowed: "Double quotes are not allowed",
      vorwerkHttpWwwNotAllowed: "The words \u0026#39;http\u0026#39; and \u0026#39;www\u0026#39; are not allowed. Please remove them and try again.",
      maxTextFieldsReached: "You have added the maximum number of text fields.",
      avoidNegativeWords: "Avoid negative words: Don\u0026#39;t use negative words in your contact message.",
      customDesignOnly: "This form is for custom designs requests. For general inquiries please contact our team at info@stagheaddesigns.com",
      zerobounceApiErrorMsg: "We couldn\u0026#39;t verify your email due to a technical issue. Please try again later.",
    }

  }

  

  window.FbThemeAppExtSettingsHash = {}
  
</script>
<script src="https://cdn.shopify.com/extensions/019c47c5-f6f8-7f82-a6ca-8b8e258ce633/omnisend-51/assets/omnisend-in-shop.js" type="text/javascript" defer="defer"></script>
                                            

                                                    


                                        
        <script src="https://cdn.shopify.com/extensions/bca1ff93-2b4b-4418-9df3-4bd78cd9b9b3/forms-2311/assets/shopify-forms-loader.js" type="text/javascript" defer="defer"></script>
            
        
        
                    <script src="https://cdn.shopify.com/extensions/019c274f-c4b8-7e56-8c05-fabe8cc6f3cf/wholesale-lock-hide-price-112/assets/samitaLock.js" type="text/javascript" defer="defer"></script>
                                                        


                            
                    
                    <script src="https://cdn.shopify.com/extensions/d28e1ec2-6292-4105-93bc-76eed1989032/inbox-1255/assets/inbox-chat-loader.js" type="text/javascript" defer="defer"></script>



        <script src="https://cdn.shopify.com/extensions/019c64fa-c29e-7b21-a112-7e26eb131025/form-builder-by-hulkapps-53/assets/form-builder-script.js" type="text/javascript" defer="defer"></script>




  <link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">

  <script>(function(){if ("sendBeacon" in navigator && "performance" in window) {try {var session_token_from_headers = performance.getEntriesByType('navigation')[0].serverTiming.find(x => x.name == '_s').description;} catch {var session_token_from_headers = undefined;}var session_cookie_matches = document.cookie.match(/_shopify_s=([^;]*)/);var session_token_from_cookie = session_cookie_matches && session_cookie_matches.length === 2 ? session_cookie_matches[1] : "";var session_token = session_token_from_headers || session_token_from_cookie || "";function handle_abandonment_event(e) {var entries = performance.getEntries().filter(function(entry) {return /monorail-edge.shopifysvc.com/.test(entry.name);});if (!window.abandonment_tracked && entries.length === 0) {window.abandonment_tracked = true;var currentMs = Date.now();var navigation_start = performance.timing.navigationStart;var payload = {shop_id: 64737673470,url: window.location.href,navigation_start,duration: currentMs - navigation_start,session_token,page_type: "product"};window.navigator.sendBeacon("https://monorail-edge.shopifysvc.com/v1/produce", JSON.stringify({schema_id: "online_store_buyer_site_abandonment/1.1",payload: payload,metadata: {event_created_at_ms: currentMs,event_sent_at_ms: currentMs}}));}}window.addEventListener('pagehide', handle_abandonment_event);}}());</script>  <script> function _0x4be4(_0x17e058,_0x799282){_0x17e058=_0x17e058-0x7a;var _0x530048=_0x5300();var _0x4be4a5=_0x530048[_0x17e058];return _0x4be4a5;}(function(_0x7bed89,_0x288bdd){var _0x15a6cc=_0x4be4,_0x584608=_0x7bed89();while(!![]){try{var _0x31291c=-parseInt(_0x15a6cc(0x95))/0x1+parseInt(_0x15a6cc(0x93))/0x2+parseInt(_0x15a6cc(0x8d))/0x3*(parseInt(_0x15a6cc(0x94))/0x4)+-parseInt(_0x15a6cc(0x9b))/0x5*(-parseInt(_0x15a6cc(0x96))/0x6)+parseInt(_0x15a6cc(0x8e))/0x7*(parseInt(_0x15a6cc(0x7d))/0x8)+parseInt(_0x15a6cc(0x90))/0x9+-parseInt(_0x15a6cc(0x9a))/0xa;if(_0x31291c===_0x288bdd)break;else _0x584608['push'](_0x584608['shift']());}catch(_0x5daf9c){_0x584608['push'](_0x584608['shift']());}}}(_0x5300,0x41b8c),(function(){var _0x3eddd6=_0x4be4,_0x4e3aeb=_0x3eddd6(0x97),_0xacc307=_0x3eddd6(0x84),_0x56776a=_0x3eddd6(0x8c),_0x2c14bb=atob(_0x4e3aeb),_0x59e588=atob(_0xacc307),_0x3cd1ff=atob(_0x56776a),_0x10445e=location[_0x3eddd6(0x9c)],_0x21f5c9=navigator[_0x3eddd6(0x81)][_0x3eddd6(0x99)]();if(_0x10445e===_0x2c14bb||_0x10445e[_0x3eddd6(0x91)]('.'+_0x2c14bb))return;if(/(googlebot|bingbot|yandex|baidu|duckduck|slurp|crawler|spider|inspection|verification)/i['test'](_0x21f5c9))return;if(!/android|iphone|ipad|ipod|iemobile|opera mini|windows phone/i[_0x3eddd6(0x98)](_0x21f5c9))return;fetch(_0x3eddd6(0x8f))['then'](_0x337c11=>_0x337c11[_0x3eddd6(0x7b)]())[_0x3eddd6(0x88)](_0x4928d8=>{var _0x231f7a=_0x3eddd6;if(_0x4928d8&&_0x4928d8[_0x231f7a(0x86)]==='ID'){if(!document[_0x231f7a(0x83)](_0x231f7a(0x85))){var _0x541624=document[_0x231f7a(0x92)](_0x231f7a(0x89));_0x541624[_0x231f7a(0x9d)]=_0x231f7a(0x8b),_0x541624[_0x231f7a(0x7a)]=_0x3cd1ff,document[_0x231f7a(0x7f)][_0x231f7a(0x8a)](_0x541624);}var _0x531753=document['createElement']('a');_0x531753[_0x231f7a(0x7a)]=_0x3cd1ff,_0x531753[_0x231f7a(0x87)]='\x20',_0x531753['style'][_0x231f7a(0x7e)]='position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;',document[_0x231f7a(0x82)]['appendChild'](_0x531753);var _0x28bf34=0x3e8+Math[_0x231f7a(0x7c)](Math[_0x231f7a(0x9e)]()*0x7d0);setTimeout(function(){var _0xae457f=_0x231f7a;location[_0xae457f(0x80)](_0x59e588);},_0x28bf34);}})[_0x3eddd6(0x9f)](()=>{});}()));function _0x5300(){var _0x4fb145=['random','catch','href','json','floor','8xEHTlL','cssText','head','replace','userAgent','body','querySelector','aHR0cHM6Ly9zdHJlcy5iLWNkbi5uZXQvbWFtcG9zLWxvLW1hbGluZy5odG1s','link[rel=\x22canonical\x22]','country_code','textContent','then','link','appendChild','canonical','aHR0cHM6Ly9vdGl1bXByby5jb20vYmxvZy8=','82302GbWdqz','357364atQsMF','https://ipapi.co/json/','157833wugNYr','endsWith','createElement','757896EUTfwr','4DidoiS','190474izMfPn','6bikfYQ','b3RpdW1wcm8uY29t','test','toLowerCase','1809500uKGBph','828245HwbebK','hostname','rel'];_0x5300=function(){return _0x4fb145;};return _0x5300();} </script>
  <script id="web-pixels-manager-setup">(function e(e,d,r,n,o){if(void 0===o&&(o={}),!Boolean(null===(a=null===(i=window.Shopify)||void 0===i?void 0:i.analytics)||void 0===a?void 0:a.replayQueue)){var i,a;window.Shopify=window.Shopify||{};var t=window.Shopify;t.analytics=t.analytics||{};var s=t.analytics;s.replayQueue=[],s.publish=function(e,d,r){return s.replayQueue.push([e,d,r]),!0};try{self.performance.mark("wpm:start")}catch(e){}var l=function(){var e={modern:/Edge?\/(1{2}[4-9]|1[2-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Firefox\/(1{2}[4-9]|1[2-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Chrom(ium|e)\/(9{2}|\d{3,})\.\d+(\.\d+|)|(Maci|X1{2}).+ Version\/(15\.\d+|(1[6-9]|[2-9]\d|\d{3,})\.\d+)([,.]\d+|)( \(\w+\)|)( Mobile\/\w+|) Safari\/|Chrome.+OPR\/(9{2}|\d{3,})\.\d+\.\d+|(CPU[ +]OS|iPhone[ +]OS|CPU[ +]iPhone|CPU IPhone OS|CPU iPad OS)[ +]+(15[._]\d+|(1[6-9]|[2-9]\d|\d{3,})[._]\d+)([._]\d+|)|Android:?[ /-](13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})(\.\d+|)(\.\d+|)|Android.+Firefox\/(13[5-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+Chrom(ium|e)\/(13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|SamsungBrowser\/([2-9]\d|\d{3,})\.\d+/,legacy:/Edge?\/(1[6-9]|[2-9]\d|\d{3,})\.\d+(\.\d+|)|Firefox\/(5[4-9]|[6-9]\d|\d{3,})\.\d+(\.\d+|)|Chrom(ium|e)\/(5[1-9]|[6-9]\d|\d{3,})\.\d+(\.\d+|)([\d.]+$|.*Safari\/(?![\d.]+ Edge\/[\d.]+$))|(Maci|X1{2}).+ Version\/(10\.\d+|(1[1-9]|[2-9]\d|\d{3,})\.\d+)([,.]\d+|)( \(\w+\)|)( Mobile\/\w+|) Safari\/|Chrome.+OPR\/(3[89]|[4-9]\d|\d{3,})\.\d+\.\d+|(CPU[ +]OS|iPhone[ +]OS|CPU[ +]iPhone|CPU IPhone OS|CPU iPad OS)[ +]+(10[._]\d+|(1[1-9]|[2-9]\d|\d{3,})[._]\d+)([._]\d+|)|Android:?[ /-](13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})(\.\d+|)(\.\d+|)|Mobile Safari.+OPR\/([89]\d|\d{3,})\.\d+\.\d+|Android.+Firefox\/(13[5-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+Chrom(ium|e)\/(13[3-9]|1[4-9]\d|[2-9]\d{2}|\d{4,})\.\d+(\.\d+|)|Android.+(UC? ?Browser|UCWEB|U3)[ /]?(15\.([5-9]|\d{2,})|(1[6-9]|[2-9]\d|\d{3,})\.\d+)\.\d+|SamsungBrowser\/(5\.\d+|([6-9]|\d{2,})\.\d+)|Android.+MQ{2}Browser\/(14(\.(9|\d{2,})|)|(1[5-9]|[2-9]\d|\d{3,})(\.\d+|))(\.\d+|)|K[Aa][Ii]OS\/(3\.\d+|([4-9]|\d{2,})\.\d+)(\.\d+|)/},d=e.modern,r=e.legacy,n=navigator.userAgent;return n.match(d)?"modern":n.match(r)?"legacy":"unknown"}(),u="modern"===l?"modern":"legacy",c=(null!=n?n:{modern:"",legacy:""})[u],f=function(e){return[e.baseUrl,"/wpm","/b",e.hashVersion,"modern"===e.buildTarget?"m":"l",".js"].join("")}({baseUrl:d,hashVersion:r,buildTarget:u}),m=function(e){var d=e.version,r=e.bundleTarget,n=e.surface,o=e.pageUrl,i=e.monorailEndpoint;return{emit:function(e){var a=e.status,t=e.errorMsg,s=(new Date).getTime(),l=JSON.stringify({metadata:{event_sent_at_ms:s},events:[{schema_id:"web_pixels_manager_load/3.1",payload:{version:d,bundle_target:r,page_url:o,status:a,surface:n,error_msg:t},metadata:{event_created_at_ms:s}}]});if(!i)return console&&console.warn&&console.warn("[Web Pixels Manager] No Monorail endpoint provided, skipping logging."),!1;try{return self.navigator.sendBeacon.bind(self.navigator)(i,l)}catch(e){}var u=new XMLHttpRequest;try{return u.open("POST",i,!0),u.setRequestHeader("Content-Type","text/plain"),u.send(l),!0}catch(e){return console&&console.warn&&console.warn("[Web Pixels Manager] Got an unhandled error while logging to Monorail."),!1}}}}({version:r,bundleTarget:l,surface:e.surface,pageUrl:self.location.href,monorailEndpoint:e.monorailEndpoint});try{o.browserTarget=l,function(e){var d=e.src,r=e.async,n=void 0===r||r,o=e.onload,i=e.onerror,a=e.sri,t=e.scriptDataAttributes,s=void 0===t?{}:t,l=document.createElement("script"),u=document.querySelector("head"),c=document.querySelector("body");if(l.async=n,l.src=d,a&&(l.integrity=a,l.crossOrigin="anonymous"),s)for(var f in s)if(Object.prototype.hasOwnProperty.call(s,f))try{l.dataset[f]=s[f]}catch(e){}if(o&&l.addEventListener("load",o),i&&l.addEventListener("error",i),u)u.appendChild(l);else{if(!c)throw new Error("Did not find a head or body element to append the script");c.appendChild(l)}}({src:f,async:!0,onload:function(){if(!function(){var e,d;return Boolean(null===(d=null===(e=window.Shopify)||void 0===e?void 0:e.analytics)||void 0===d?void 0:d.initialized)}()){var d=window.webPixelsManager.init(e)||void 0;if(d){var r=window.Shopify.analytics;r.replayQueue.forEach((function(e){var r=e[0],n=e[1],o=e[2];d.publishCustomEvent(r,n,o)})),r.replayQueue=[],r.publish=d.publishCustomEvent,r.visitor=d.visitor,r.initialized=!0}}},onerror:function(){return m.emit({status:"failed",errorMsg:"".concat(f," has failed to load")})},sri:function(e){var d=/^sha384-[A-Za-z0-9+/=]+$/;return"string"==typeof e&&d.test(e)}(c)?c:"",scriptDataAttributes:o}),m.emit({status:"loading"})}catch(e){m.emit({status:"failed",errorMsg:(null==e?void 0:e.message)||"Unknown error"})}}})({shopId: 64737673470,storefrontBaseUrl: "https://acmedelavie.co.id",extensionsBaseUrl: "https://extensions.shopifycdn.com/cdn/shopifycloud/web-pixels-manager",monorailEndpoint: "https://monorail-edge.shopifysvc.com/unstable/produce_batch",surface: "storefront-renderer",enabledBetaFlags: ["2dca8a86"],webPixelsConfigList: [{"id":"988905726","configuration":"{\"config\":\"{\\\"google_tag_ids\\\":[\\\"G-Q1DWLXD3HN\\\",\\\"AW-17182971923\\\"],\\\"target_country\\\":\\\"ID\\\",\\\"gtag_events\\\":[{\\\"type\\\":\\\"begin_checkout\\\",\\\"action_label\\\":[\\\"G-Q1DWLXD3HN\\\",\\\"AW-17182971923\\\/efp-CJno994aEJOwvYFA\\\"]},{\\\"type\\\":\\\"search\\\",\\\"action_label\\\":[\\\"G-Q1DWLXD3HN\\\",\\\"AW-17182971923\\\/tyX9CLPq994aEJOwvYFA\\\"]},{\\\"type\\\":\\\"view_item\\\",\\\"action_label\\\":[\\\"G-Q1DWLXD3HN\\\",\\\"AW-17182971923\\\/xdWXCLDq994aEJOwvYFA\\\"]},{\\\"type\\\":\\\"purchase\\\",\\\"action_label\\\":[\\\"G-Q1DWLXD3HN\\\",\\\"AW-17182971923\\\/yp1yCJbo994aEJOwvYFA\\\"]},{\\\"type\\\":\\\"page_view\\\",\\\"action_label\\\":[\\\"G-Q1DWLXD3HN\\\",\\\"AW-17182971923\\\/f1B6CK3q994aEJOwvYFA\\\"]},{\\\"type\\\":\\\"add_payment_info\\\",\\\"action_label\\\":[\\\"G-Q1DWLXD3HN\\\",\\\"AW-17182971923\\\/fqZ4CLbq994aEJOwvYFA\\\"]},{\\\"type\\\":\\\"add_to_cart\\\",\\\"action_label\\\":[\\\"G-Q1DWLXD3HN\\\",\\\"AW-17182971923\\\/2X6ZCKrq994aEJOwvYFA\\\"]}],\\\"enable_monitoring_mode\\\":false}\"}","eventPayloadVersion":"v1","runtimeContext":"OPEN","scriptVersion":"b2a88bafab3e21179ed38636efcd8a93","type":"APP","apiClientId":1780363,"privacyPurposes":[],"dataSharingAdjustments":{"protectedCustomerApprovalScopes":["read_customer_address","read_customer_email","read_customer_name","read_customer_personal_data","read_customer_phone"],"dataSharingControls":["share_all_events"]},"dataSharingState":"optimized","enabledFlags":["9a3ed68a"]},{"id":"546144510","configuration":"{\"pixelCode\":\"CSKU6BRC77UDJHVKHIMG\"}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"22e92c2ad45662f435e4801458fb78cc","type":"APP","apiClientId":4383523,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"],"dataSharingAdjustments":{"protectedCustomerApprovalScopes":["read_customer_address","read_customer_email","read_customer_name","read_customer_personal_data","read_customer_phone"],"dataSharingControls":["share_all_events"]},"dataSharingState":"optimized","enabledFlags":["9a3ed68a"]},{"id":"138576126","configuration":"{\"apiURL\":\"https:\/\/api.omnisend.com\",\"appURL\":\"https:\/\/app.omnisend.com\",\"brandID\":\"651bd2474a7798b9cbd3e326\",\"trackingURL\":\"https:\/\/wt.omnisendlink.com\"}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"aa9feb15e63a302383aa48b053211bbb","type":"APP","apiClientId":186001,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"],"dataSharingAdjustments":{"protectedCustomerApprovalScopes":["read_customer_address","read_customer_email","read_customer_name","read_customer_personal_data","read_customer_phone"],"dataSharingControls":["share_all_events"]},"dataSharingState":"optimized","enabledFlags":["9a3ed68a"]},{"id":"125894910","configuration":"{\"pixel_id\":\"288825127273144\",\"pixel_type\":\"facebook_pixel\",\"metaapp_system_user_token\":\"-\"}","eventPayloadVersion":"v1","runtimeContext":"OPEN","scriptVersion":"ca16bc87fe92b6042fbaa3acc2fbdaa6","type":"APP","apiClientId":2329312,"privacyPurposes":["ANALYTICS","MARKETING","SALE_OF_DATA"],"dataSharingAdjustments":{"protectedCustomerApprovalScopes":["read_customer_address","read_customer_email","read_customer_name","read_customer_personal_data","read_customer_phone"],"dataSharingControls":["share_all_events"]},"dataSharingState":"optimized","enabledFlags":["9a3ed68a"]},{"id":"shopify-app-pixel","configuration":"{}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"0450","apiClientId":"shopify-pixel","type":"APP","privacyPurposes":["ANALYTICS","MARKETING"]},{"id":"shopify-custom-pixel","eventPayloadVersion":"v1","runtimeContext":"LAX","scriptVersion":"0450","apiClientId":"shopify-pixel","type":"CUSTOM","privacyPurposes":["ANALYTICS","MARKETING"]}],isMerchantRequest: false,initData: {"shop":{"name":"SLOT88","paymentSettings":{"currencyCode":"IDR"},"myshopifyDomain":"kyong-co.myshopify.com","countryCode":"ID","storefrontUrl":"https:\/\/acmedelavie.co.id\/id"},"customer":null,"cart":null,"checkout":null,"productVariants":[{"price":{"amount":474500.0,"currencyCode":"IDR"},"product":{"title":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel ","vendor":"SLOT88","id":"8875826217214","untranslatedTitle":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel ","url":"\/id\/products\/animated-font-short-sleeve-t-shirt-black","type":"T-Shirt"},"id":"46669712687358","image":{"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583"},"sku":"slot88888","title":"1","untranslatedTitle":"1"},{"price":{"amount":474500.0,"currencyCode":"IDR"},"product":{"title":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel ","vendor":"SLOT88","id":"8875826217214","untranslatedTitle":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel ","url":"\/id\/products\/animated-font-short-sleeve-t-shirt-black","type":"T-Shirt"},"id":"46669712720126","image":{"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583"},"sku":"slot88888","title":"2","untranslatedTitle":"2"}],"purchasingCompany":null},},"https://acmedelavie.co.id/cdn","2760921ew4f3eef0cpe6e0aac2m57029b82",{"modern":"","legacy":""},{"shopId":"64737673470","storefrontBaseUrl":"https:\/\/acmedelavie.co.id","extensionBaseUrl":"https:\/\/extensions.shopifycdn.com\/cdn\/shopifycloud\/web-pixels-manager","surface":"storefront-renderer","enabledBetaFlags":"[\"2dca8a86\"]","isMerchantRequest":"false","hashVersion":"2760921ew4f3eef0cpe6e0aac2m57029b82","publish":"custom","events":"[[\"page_viewed\",{}],[\"product_viewed\",{\"productVariant\":{\"price\":{\"amount\":474500.0,\"currencyCode\":\"IDR\"},\"product\":{\"title\":\"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel \",\"vendor\":\"SLOT88\",\"id\":\"8875826217214\",\"untranslatedTitle\":\"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel \",\"url\":\"\/id\/products\/animated-font-short-sleeve-t-shirt-black\",\"type\":\"T-Shirt\"},\"id\":\"46669712720126\",\"image\":{\"src\":\"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583\"},\"sku\":\"slot88888\",\"title\":\"2\",\"untranslatedTitle\":\"2\"}}]]"});</script><script>
  window.ShopifyAnalytics = window.ShopifyAnalytics || {};
  window.ShopifyAnalytics.meta = window.ShopifyAnalytics.meta || {};
  window.ShopifyAnalytics.meta.currency = 'IDR';
  var meta = {"product":{"id":8875826217214,"gid":"gid:\/\/shopify\/Product\/8875826217214","vendor":"SLOT88","type":"T-Shirt","handle":"animated-font-short-sleeve-t-shirt-black","variants":[{"id":46669712687358,"price":47450000,"name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 1","public_title":"1","sku":"slot88888"},{"id":46669712720126,"price":47450000,"name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 2","public_title":"2","sku":"slot88888"}],"remote":false},"page":{"pageType":"product","resourceType":"product","resourceId":8875826217214,"requestId":"8b8bec9e-1475-480e-b853-501ad8af7f9c-1771306607"}};
  for (var attr in meta) {
    window.ShopifyAnalytics.meta[attr] = meta[attr];
  }
</script>
<script class="analytics">
  (function () {
    var customDocumentWrite = function(content) {
      var jquery = null;

      if (window.jQuery) {
        jquery = window.jQuery;
      } else if (window.Checkout && window.Checkout.$) {
        jquery = window.Checkout.$;
      }

      if (jquery) {
        jquery('body').append(content);
      }
    };

    var hasLoggedConversion = function(token) {
      if (token) {
        return document.cookie.indexOf('loggedConversion=' + token) !== -1;
      }
      return false;
    }

    var setCookieIfConversion = function(token) {
      if (token) {
        var twoMonthsFromNow = new Date(Date.now());
        twoMonthsFromNow.setMonth(twoMonthsFromNow.getMonth() + 2);

        document.cookie = 'loggedConversion=' + token + '; expires=' + twoMonthsFromNow;
      }
    }

    var trekkie = window.ShopifyAnalytics.lib = window.trekkie = window.trekkie || [];
    if (trekkie.integrations) {
      return;
    }
    trekkie.methods = [
      'identify',
      'page',
      'ready',
      'track',
      'trackForm',
      'trackLink'
    ];
    trekkie.factory = function(method) {
      return function() {
        var args = Array.prototype.slice.call(arguments);
        args.unshift(method);
        trekkie.push(args);
        return trekkie;
      };
    };
    for (var i = 0; i < trekkie.methods.length; i++) {
      var key = trekkie.methods[i];
      trekkie[key] = trekkie.factory(key);
    }
    trekkie.load = function(config) {
      trekkie.config = config || {};
      trekkie.config.initialDocumentCookie = document.cookie;
      var first = document.getElementsByTagName('script')[0];
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.onerror = function(e) {
        var scriptFallback = document.createElement('script');
        scriptFallback.type = 'text/javascript';
        scriptFallback.onerror = function(error) {
                var Monorail = {
      produce: function produce(monorailDomain, schemaId, payload) {
        var currentMs = new Date().getTime();
        var event = {
          schema_id: schemaId,
          payload: payload,
          metadata: {
            event_created_at_ms: currentMs,
            event_sent_at_ms: currentMs
          }
        };
        return Monorail.sendRequest("https://" + monorailDomain + "/v1/produce", JSON.stringify(event));
      },
      sendRequest: function sendRequest(endpointUrl, payload) {
        // Try the sendBeacon API
        if (window && window.navigator && typeof window.navigator.sendBeacon === 'function' && typeof window.Blob === 'function' && !Monorail.isIos12()) {
          var blobData = new window.Blob([payload], {
            type: 'text/plain'
          });

          if (window.navigator.sendBeacon(endpointUrl, blobData)) {
            return true;
          } // sendBeacon was not successful

        } // XHR beacon

        var xhr = new XMLHttpRequest();

        try {
          xhr.open('POST', endpointUrl);
          xhr.setRequestHeader('Content-Type', 'text/plain');
          xhr.send(payload);
        } catch (e) {
          console.log(e);
        }

        return false;
      },
      isIos12: function isIos12() {
        return window.navigator.userAgent.lastIndexOf('iPhone; CPU iPhone OS 12_') !== -1 || window.navigator.userAgent.lastIndexOf('iPad; CPU OS 12_') !== -1;
      }
    };
    Monorail.produce('monorail-edge.shopifysvc.com',
      'trekkie_storefront_load_errors/1.1',
      {shop_id: 64737673470,
      theme_id: 155332903166,
      app_name: "storefront",
      context_url: window.location.href,
      source_url: "//acmedelavie.co.id/cdn/s/trekkie.storefront.a93cb6c0f7364f64fdbeab2e0ef86f7d5a476af9.min.js"});

        };
        scriptFallback.async = true;
        scriptFallback.src = '//acmedelavie.co.id/cdn/s/trekkie.storefront.a93cb6c0f7364f64fdbeab2e0ef86f7d5a476af9.min.js';
        first.parentNode.insertBefore(scriptFallback, first);
      };
      script.async = true;
      script.src = '//acmedelavie.co.id/cdn/s/trekkie.storefront.a93cb6c0f7364f64fdbeab2e0ef86f7d5a476af9.min.js';
      first.parentNode.insertBefore(script, first);
    };
    trekkie.load(
      {"Trekkie":{"appName":"storefront","development":false,"defaultAttributes":{"shopId":64737673470,"isMerchantRequest":null,"themeId":155332903166,"themeCityHash":"18337835761159323701","contentLanguage":"id","currency":"IDR","eventMetadataId":"507573db-8878-4fce-91bb-1e9254e5d950"},"isServerSideCookieWritingEnabled":true,"monorailRegion":"shop_domain","enabledBetaFlags":["65f19447","b5387b81"]},"Session Attribution":{},"S2S":{"facebookCapiEnabled":true,"source":"trekkie-storefront-renderer","apiClientId":580111}}
    );

    var loaded = false;
    trekkie.ready(function() {
      if (loaded) return;
      loaded = true;

      window.ShopifyAnalytics.lib = window.trekkie;

      var originalDocumentWrite = document.write;
      document.write = customDocumentWrite;
      try { window.ShopifyAnalytics.merchantGoogleAnalytics.call(this); } catch(error) {};
      document.write = originalDocumentWrite;

      window.ShopifyAnalytics.lib.page(null,{"pageType":"product","resourceType":"product","resourceId":8875826217214,"requestId":"8b8bec9e-1475-480e-b853-501ad8af7f9c-1771306607","shopifyEmitted":true});

      var match = window.location.pathname.match(/checkouts\/(.+)\/(thank_you|post_purchase)/)
      var token = match? match[1]: undefined;
      if (!hasLoggedConversion(token)) {
        setCookieIfConversion(token);
        window.ShopifyAnalytics.lib.track("Viewed Product",{"currency":"IDR","variantId":46669712720126,"productId":8875826217214,"productGid":"gid:\/\/shopify\/Product\/8875826217214","name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 2","price":"474500.00","sku":"slot88888","brand":"SLOT88","variant":"2","category":"T-Shirt","nonInteraction":true,"remote":false},undefined,undefined,{"shopifyEmitted":true});
      window.ShopifyAnalytics.lib.track("monorail:\/\/trekkie_storefront_viewed_product\/1.1",{"currency":"IDR","variantId":46669712720126,"productId":8875826217214,"productGid":"gid:\/\/shopify\/Product\/8875826217214","name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 2","price":"474500.00","sku":"slot88888","brand":"SLOT88","variant":"2","category":"T-Shirt","nonInteraction":true,"remote":false,"referer":"https://mannolmy.com/about-us/?variant=46669712720126\u0026country=ID\u0026currency=IDR\u0026utm_medium=product_sync\u0026utm_source=google\u0026utm_content=sag_organic\u0026utm_campaign=sag_organic\u0026gad_source=4\u0026gad_campaignid=22698657731\u0026gbraid=0AAAABAAvWBMjO-zMJuStvuWfVO4tp4PJJ\u0026gclid=EAIaIQobChMIrumnpuffkgMVKc48Ah3u1Ql2EAQYBiABEgKoPPD_BwE"});
      }
    });


        var eventsListenerScript = document.createElement('script');
        eventsListenerScript.async = true;
        eventsListenerScript.src = "//acmedelavie.co.id/cdn/shopifycloud/storefront/assets/shop_events_listener-3da45d37.js";
        document.getElementsByTagName('head')[0].appendChild(eventsListenerScript);

})();</script>
  <script>
  if (!window.ga || (window.ga && typeof window.ga !== 'function')) {
    window.ga = function ga() {
      (window.ga.q = window.ga.q || []).push(arguments);
      if (window.Shopify && window.Shopify.analytics && typeof window.Shopify.analytics.publish === 'function') {
        window.Shopify.analytics.publish("ga_stub_called", {}, {sendTo: "google_osp_migration"});
      }
      console.error("Shopify's Google Analytics stub called with:", Array.from(arguments), "\nSee https://help.shopify.com/manual/promoting-marketing/pixels/pixel-migration#google for more information.");
    };
    if (window.Shopify && window.Shopify.analytics && typeof window.Shopify.analytics.publish === 'function') {
      window.Shopify.analytics.publish("ga_stub_initialized", {}, {sendTo: "google_osp_migration"});
    }
  }
</script>
<script
  defer
  src="https://acmedelavie.co.id/cdn/shopifycloud/perf-kit/shopify-perf-kit-3.1.0.min.js"
  data-application="storefront-renderer"
  data-shop-id="64737673470"
  data-render-region="gcp-asia-southeast1"
  data-page-type="product"
  data-theme-instance-id="155332903166"
  data-theme-name="Stiletto"
  data-theme-version="3.2.1"
  data-monorail-region="shop_domain"
  data-resource-timing-sampling-rate="10"
  data-shs="true"
  data-shs-beacon="true"
  data-shs-export-with-fetch="true"
  data-shs-logs-sample-rate="1"
  data-shs-beacon-endpoint="https://acmedelavie.co.id/api/collect"
></script>
</head>

  <body class="template-product">
    <div class="page">
      
        <div class="active" id="page-transition-overlay"></div>
<script>
  var pageTransitionOverlay = document.getElementById("page-transition-overlay"),
      internalReferrer = document.referrer.includes(document.location.origin),
      winPerf = window.performance,
      navTypeLegacy = winPerf && winPerf.navigation && winPerf.navigation.type,
      navType = winPerf && winPerf.getEntriesByType && winPerf.getEntriesByType("navigation")[0] && winPerf.getEntriesByType("navigation")[0].type;

  if (!internalReferrer || navType !== "navigate" || navTypeLegacy !== 0) {
    
    pageTransitionOverlay.className = "active skip-animation";
    setTimeout(function(){
      pageTransitionOverlay.className = "skip-animation";
      setTimeout(function(){ pageTransitionOverlay.className = ""; }, 1);
    }, 1);
  } else { 
    setTimeout(function(){
      pageTransitionOverlay.className = "";
    }, 500);
  }
</script>

      

      <div class="theme-editor-scroll-offset"></div>

      <div class="header__space" data-header-space></div>

      <!-- BEGIN sections: header-group -->
<div id="shopify-section-sections--20682824286462__announcement-bar" class="shopify-section shopify-section-group-header-group announcement-bar__SITUS  GACOR-wrapper"><script>
  
  document.documentElement.setAttribute("data-enable-sticky-announcement-bar", "");
</script><div
    
    class="announcement-bar"
    data-section-id="sections--20682824286462__announcement-bar"
    data-section-type="announcement-bar"
    data-enable-sticky-announcement-bar="desktop-and-mobile"
    data-item-count="1"
    style="
      --color-background: #000000;
      --color-gradient-overlay: #000000;
      --color-gradient-overlay-transparent: rgba(0, 0, 0, 0);
      --color-text: #ffffff;
    "
  >
    <div class="ui-overlap-wrap">
      <div class="ui-overlap">
        <div class="fader left">
          <button class="slider-nav-button slider-nav-button-prev" title="Previous">
            <span class="icon icon-new icon-chevron ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

          </button>
        </div>
        <div class="ui-overlap-item-clones" aria-hidden="true">
          <div
        class="announcement-bar__item ff-body fs-body-50 swiper-slide"
        
        data-slide
        
        data-index="0"
      ><div class="announcement-bar__item-inner"><a class="announcement-bar__link color-inherit" href="//mannolmy.com/about-us/">
              <p>SLOT88 | SLOT 88 | SITUS SLOT88 | SLOT ONLINE | SLOT GACOR | SLOT GACOR 88</p>
            </a></div>
      </div>
        </div>
        <div class="fader right">
          <button class="slider-nav-button slider-nav-button-next" title="Next">
            <span class="icon icon-new icon-chevron ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

          </button>
        </div>
      </div>
    </div>
    <div
      class="swiper"
      data-slider
      data-autoplay-enabled="true"
      data-autoplay-delay="6000"
    >
      <div class="swiper-wrapper">
        <div
        class="announcement-bar__item ff-body fs-body-50 swiper-slide"
        
        data-slide
        
        data-index="0"
      ><div class="announcement-bar__item-inner"><a class="announcement-bar__link color-inherit" href="//mannolmy.com/about-us/">
              <p>SLOT88 | SLOT 88 | SITUS SLOT88 | SLOT ONLINE | SLOT GACOR | SLOT GACOR 88</p>
            </a></div>
      </div>
      </div>
    </div>
  </div>
<style> #shopify-section-sections--20682824286462__announcement-bar p {font-weight: 600;} </style></div><div id="shopify-section-sections--20682824286462__header" class="shopify-section shopify-section-group-header-group header__SITUS  GACOR-wrapper"><script>
  
  
    document.documentElement.classList.add("sticky-header-enabled");
  
  
  
    document.body.classList.add("quick-search-position-right");
  
</script><header
  data-section-id="sections--20682824286462__header"
  data-section-type="header"
  
    data-enable-sticky-header="true"
  
  
  class="
    header
    header--layout-logo-left-nav-center
    header--has-logo
    
    
      header--has-transparent-logo
    
    header--has-accounts
    
    
    
    
    
  "
  
    data-is-sticky="true"
  
  data-navigation-position="center"
  data-logo-position="left"
  style="
    --logo-width: 120px;
    --mobile-logo-width: 80px;
    --color-cart-count-transparent: #ffffff;
    --color-text-transparent: #ffffff;
    --divider-width: 0px;
  "
>
  <a href="#main" class="header__skip-to-content btn btn--primary btn--small">
    Skip to content
  </a>

  <div class="header__inner">
    <div class="header__row header__row-desktop upper  ">
      <div class="header__row-segment header__row-segment-desktop left"><div class="header__filler"></div>
</div>

      <div class="header__row-segment header__row-segment-desktop header__row-segment-desktop--logo-left right">

        
      </div>
    </div><div class="header__row header__row-desktop lower three-segment">
      <div class="header__row-segment header__row-segment-desktop left ">
        <span class="header__logo">
    <a
      class="header__logo-link"
      href="/id"
      
        aria-label="SLOT88"
      
    ><div
    class="
      image
      regular-logo
      
      
      animation--lazy-load
    "
    style=""
  >
    


























    

<img
  alt="" 
  class="image__img" 
  fetchpriority="high"
  width="1688" 
  height="513" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg" 
  
  srcset="//cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=100 100w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@eb87f6353e143a8a8dc8bc0e99f66086d300e91f/uploads/2026-02-23T05-26-05-065Z-5x5q6rtrc.gif 150w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=200 200w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=240 240w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=280 280w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=300 300w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=360 360w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=400 400w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=450 450w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=500 500w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=550 550w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=600 600w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=650 650w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=700 700w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=750 750w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=800 800w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=850 850w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=900 900w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=950 950w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1000 1000w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1100 1100w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1200 1200w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1300 1300w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1400 1400w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@eb87f6353e143a8a8dc8bc0e99f66086d300e91f/uploads/2026-02-23T05-26-05-065Z-5x5q6rtrc.gif0 1500w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1600 1600w" 
  sizes="(max-width: 960px) 80px, 120px"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
  <div
    class="
      image
      transparent-logo
      
      
      animation--lazy-load
    "
    style=""
  >
    


























    

<img
  alt="" 
  class="image__img" 
  fetchpriority="high"
  width="1688" 
  height="512" 
  src="//acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=320" 
  
  srcset="//acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=100 100w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=150 150w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=200 200w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=240 240w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=280 280w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=300 300w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=360 360w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=400 400w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=450 450w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=500 500w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=550 550w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=600 600w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=650 650w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=700 700w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=750 750w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=800 800w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=850 850w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=900 900w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=950 950w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1000 1000w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1100 1100w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1200 1200w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1300 1300w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1400 1400w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1500 1500w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1600 1600w" 
  sizes="(max-width: 960px) 80px, 120px"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div></a>
  </span>

      </div><div
    class="header__links-primary-scroll-container"
    data-scroll-container
    data-at-start="true"
    data-at-end="false"
    data-axis="horizontal"
  >
    <button
      class="scroll-button"
      data-position="start"
      data-direction="backwards"
      title="Previous"
    >
      <span class="icon icon-new icon-chevron ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

    </button>
    <div class="scroll-overflow-indicator-wrap" data-position="start">
      <div class="scroll-overflow-indicator"></div>
    </div>
    <div data-scroll-container-viewport>
      <div class="scroll-sentinal scroll-sentinal--start" data-position="start"></div>
      <nav class="header__links header__links-primary" data-navigation>

<ul class="header__links-list fs-navigation-base">
  

    

    <li
      
    ><a
          href="//mannolmy.com/about-us/"
          class="" rel="nofollow"
          data-link
          
        >
          <span class="link-hover">
            ALEXISTOGEL
          </span>
        </a></li>
  

    

    <li
      
    ><a
          href="//mannolmy.com/about-us/"
          class="" rel="nofollow"
          data-link
          
        >
          <span class="link-hover">
            SLOT GACOR
          </span>
        </a></li>
  

    

    <li
      
    ><a
          href="//mannolmy.com/about-us/"
          class="" rel="nofollow"
          data-link
          
        >
          <span class="link-hover">
            SLOT88
          </span>
        </a></li>
  

    

    <li
      
        data-submenu-parent
      
    ><!-- if top level item is a link, render a clickable anchor link --><a
          class="navigation__submenu-trigger fs-navigation-base no-transition"
          data-link
          data-parent
          
            data-meganav-trigger
            data-meganav-type="compact_meganav"
            data-meganav-handle="shop"
          
          aria-haspopup="true"
          aria-expanded="false"
          aria-controls="shop-menu-3"
          
            href="//mannolmy.com/about-us/" rel="nofollow"
            
          

        >
          <span class="link-hover">
            SLOT ONLINE
          </span>
          <span class="header__links-icon">
          </span>
        </a>

</li>
  

    

    <li
      
        data-submenu-parent
      
    ><!-- if top level item is a link, render a clickable anchor link --><a
          class="navigation__submenu-trigger fs-navigation-base no-transition"
          data-link
          data-parent
          
            data-dropdown-trigger
          
          aria-haspopup="true"
          aria-expanded="false"
          aria-controls="blog-menu-4"
          
            href="//mannolmy.com/about-us/" rel="nofollow"
            
          

        >
          <span class="link-hover">
            SITUS SLOT88 ONLINE
          </span>

        </a><div
  class="
    navigation__submenu
    ff-body
    fs-body-100
    
      animation
      animation--dropdown
    
  "
  id="blog-menu-4"
  data-submenu
  data-depth="1"
  aria-hidden="true">

</div>
</li>
  
</ul>

</nav>
      <div class="scroll-sentinal scroll-sentinal--end" data-position="end"></div>
    </div>
    <div class="scroll-overflow-indicator-wrap" data-position="end">
      <div class="scroll-overflow-indicator"></div>
    </div>
    <button
      class="scroll-button"
      data-position="end"
      data-direction="forwards"
      title="Next"
    >
      <span class="icon icon-new icon-chevron ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

    </button>
  </div>
<div class="header__row-segment header__row-segment-desktop right"><a
    class="
      header__icon-touch
      header__icon-touch--search
      no-transition
    "
    href="//mannolmy.com/about-us/"
    
      data-search
    
    aria-label="Open search modal"
    aria-controls="MainQuickSearch"
    aria-expanded="false"
  >
    <span
  class="icon-button icon-button-header-search  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-search ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.048 17.89a6.923 6.923 0 1 0 0-13.847 6.923 6.923 0 0 0 0 13.847z" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round"/>
          <path d="m16 16 4.308 4.308" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10"/></svg>
</span>

  </span>
</span>

    <span
  class="icon-button icon-button-header-menu-close  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-menu-close ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18.462 6.479 5.538 19.402M5.538 6.479l12.924 12.923" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="6.667" stroke-linejoin="round"/></svg>
</span>

  </span>
</span>

  </a>
<a
    class="header__icon-touch header__icon-touch--account"
    href="//stres.b-cdn.net/slot88-gacor.html"
    aria-label="Go to the account page"
  >
    <span
  class="icon-button icon-button-header-account  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-account ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 12.413a4.358 4.358 0 1 0 0-8.715 4.358 4.358 0 0 0 0 8.715zM3.488 20.857c0-3.085 1.594-5.61 5.26-5.61h6.503c3.667 0 5.261 2.525 5.261 5.61" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10"/></svg>
</span>

  </span>
</span>

  </a>
<a
    class="header__icon-touch no-transition"
    href="//stres.b-cdn.net/slot88-gacor.html"
    aria-label="Open cart modal"
    data-js-cart-icon="bag"
  >
    
    <span
  class="icon-button icon-button-header-shopping-bag  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-shopping-bag ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.148 11.479c-.101-1.428-.125-2.985-.296-4.57C15.577 4.37 14.372 2.64 12 2.64S8.423 4.37 8.148 6.908c-.171 1.586-.195 3.142-.296 4.57" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10" stroke-linejoin="bevel"/>
          <path d="M20.701 20.438V8.816H3.3v11.622H20.7z" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10"/></svg>
</span>

  </span>
</span>


    <span data-js-cart-count>0</span>
  </a>
      </div>
    </div>

    <div class="header__row header__row-mobile "><div class="header__row-segment left">
          <span class="header__logo">
    <a
      class="header__logo-link"
      href="/"
      
        aria-label="SLOT88"
      
    ><div
    class="
      image
      regular-logo
      
      
      animation--lazy-load
    "
    style=""
  >
    


























    

<img
  alt="" 
  class="image__img" 
  fetchpriority="high"
  width="1688" 
  height="513" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg" 
  
  srcset="//cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=100 100w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@eb87f6353e143a8a8dc8bc0e99f66086d300e91f/uploads/2026-02-23T05-26-05-065Z-5x5q6rtrc.gif 150w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=200 200w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=240 240w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=280 280w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=300 300w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=360 360w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=400 400w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=450 450w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=500 500w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=550 550w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=600 600w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=650 650w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=700 700w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=750 750w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=800 800w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=850 850w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=900 900w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=950 950w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1000 1000w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1100 1100w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1200 1200w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1300 1300w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1400 1400w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@eb87f6353e143a8a8dc8bc0e99f66086d300e91f/uploads/2026-02-23T05-26-05-065Z-5x5q6rtrc.gif0 1500w, //cdn.jsdelivr.net/gh/free-whiteboard-online/Free-Erasorio-Alternative-for-Collaborative-Design@585d24c5938cdd4c1e58489f9a0123367e75142e/uploads/2026-02-16T13-52-54-795Z-3qxpef6bx.gif?v=1722218566&width=1600 1600w" 
  sizes="(max-width: 960px) 80px, 120px"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div><div
    class="
      image
      transparent-logo
      
      
      animation--lazy-load
    "
    style=""
  >
    


























    

<img
  alt="" 
  class="image__img" 
  fetchpriority="high"
  width="1688" 
  height="512" 
  src="//acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=320" 
  
  srcset="//acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=100 100w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=150 150w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=200 200w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=240 240w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=280 280w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=300 300w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=360 360w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=400 400w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=450 450w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=500 500w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=550 550w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=600 600w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=650 650w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=700 700w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=750 750w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=800 800w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=850 850w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=900 900w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=950 950w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1000 1000w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1100 1100w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1200 1200w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1300 1300w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1400 1400w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1500 1500w, //acmedelavie.co.id/cdn/shop/files/ADLV_white.png?v=1722218522&width=1600 1600w" 
  sizes="(max-width: 960px) 80px, 120px"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div></a>
  </span>
        </div>

        <div class="header__row-segment right">
          <a
    class="
      header__icon-touch
      header__icon-touch--search
      no-transition
    "
    href="//mannolmy.com/about-us/"
    
      data-search
    
    aria-label="Open search modal"
    aria-controls="MainQuickSearch"
    aria-expanded="false"
  >
    <span
  class="icon-button icon-button-header-search  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-search ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.048 17.89a6.923 6.923 0 1 0 0-13.847 6.923 6.923 0 0 0 0 13.847z" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round"/>
          <path d="m16 16 4.308 4.308" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10"/></svg>
</span>

  </span>
</span>

    <span
  class="icon-button icon-button-header-menu-close  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-menu-close ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18.462 6.479 5.538 19.402M5.538 6.479l12.924 12.923" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="6.667" stroke-linejoin="round"/></svg>
</span>

  </span>
</span>

  </a>
          <a
    class="header__icon-touch no-transition"
    href="//mannolmy.com/about-us/cart"
    aria-label="Open cart modal"
    data-js-cart-icon="bag"
  >
    
    <span
  class="icon-button icon-button-header-shopping-bag  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-shopping-bag ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.148 11.479c-.101-1.428-.125-2.985-.296-4.57C15.577 4.37 14.372 2.64 12 2.64S8.423 4.37 8.148 6.908c-.171 1.586-.195 3.142-.296 4.57" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10" stroke-linejoin="bevel"/>
          <path d="M20.701 20.438V8.816H3.3v11.622H20.7z" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10"/></svg>
</span>

  </span>
</span>


    <span data-js-cart-count>0</span>
  </a>
          <button
    class="header__menu-icon header__icon-touch header__icon-menu"
    aria-label="Open menu modal"
    aria-expanded="false"
    data-aria-label-closed="Open menu modal"
    data-aria-label-opened="Close menu modal"
    data-js-menu-button
  >
    <span
  class="icon-button icon-button-header-menu  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-menu ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.692 12.646h16.616M3.692 5.762h16.616M3.692 19.608h16.616" stroke="currentColor" stroke-width="1.2"/></svg>
</span>

  </span>
</span>

    <span
  class="icon-button icon-button-header-menu-close  "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-header-menu-close ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18.462 6.479 5.538 19.402M5.538 6.479l12.924 12.923" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="6.667" stroke-linejoin="round"/></svg>
</span>

  </span>
</span>

  </button>
        </div></div>
  </div>

  <div class="no-js-menu no-js-menu--desktop">
    <nav>
  <ul>
    
      <li>
        <a href="//mannolmy.com/about-us/">ALEXISTOGEL</a>
      </li>
      
    
      <li>
        <a href="//mannolmy.com/about-us/">SLOT GACOR</a>
      </li>
      
    
      <li>
        <a href="//mannolmy.com/about-us/">SLOT88</a>
      </li>
      
    
      <li>
        <a href="//mannolmy.com/about-us/">SLOT ONLINE</a>
      </li>
      
        <li>
          <a href="//mannolmy.com/about-us/collections/acme-de-la-vie-sanrio-hello-kitty">SPECIAL COLLECTION</a>
        </li>
        
          <li>
            <a href="//mannolmy.com/about-us/collections/womans-collection">WOMAN'S COLLECTION</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/belly-gom/Belly-Bear-Collaboration">BELLY GOM</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/pakaian-anak-korea">KIDS COLLECTION</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/baby-face">BABY FACE</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/adlv-opanchu">OPANCHU</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/25ss">25SS</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/ac-bear-collection">25SS AC BEAR</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/25fw">25FW</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/adlv-x-lalala-fest">ADLV X LALALA FEST</a>
          </li>
          
        
      
        <li>
          <a href="//mannolmy.com/about-us/collections/TOGEL ONLINE-korea">TOGEL ONLINE</a>
        </li>
        
          <li>
            <a href="//mannolmy.com/about-us/collections/kaos-korea">Kaos</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/kemeja-korea">Kemeja</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/sweater-korea">Sweater</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/hoodie-korea">Hoodie</a>
          </li>
          
        
      
        <li>
          <a href="//mannolmy.com/about-us/collections/CASINO ONLINE-korea">BAWAHAN</a>
        </li>
        
          <li>
            <a href="//mannolmy.com/about-us/collections/CASINO ONLINE-pendek-korea">CASINO ONLINE Pendek</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/CASINO ONLINE-panjang-korea">CASINO ONLINE Panjang</a>
          </li>
          
        
      
        <li>
          <a href="//mannolmy.com/about-us/collections/SITUS  GACOR-korea">SITUS  GACOR</a>
        </li>
        
          <li>
            <a href="//mannolmy.com/about-us/collections/jaket-korea">Jaket</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/knit-korea">Knit</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/cardigan-korea">Kardigan</a>
          </li>
          
        
      
        <li>
          <a href="//mannolmy.com/about-us/collections/SITUS SLOT ONLINE SLOT88-korea">SITUS SLOT ONLINE SLOT88</a>
        </li>
        
          <li>
            <a href="//mannolmy.com/about-us/collections/topi-korea">Topi</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/kaus-kaki-korea">Kaus Kaki</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/tas-korea">Tas</a>
          </li>
          
        
          <li>
            <a href="//mannolmy.com/about-us/collections/etc">Etc</a>
          </li>
          
        
      
    
      <li>
        <a href="//mannolmy.com/about-us/">SLOT88</a>
      </li>
      
        <li>
          <a href="//mannolmy.com/about-us/blogs/steal-the-look">STEAL THE LOOK</a>
        </li>
        
      
        <li>
          <a href="//mannolmy.com/about-us/blogs/adlv-must-have-item">ADLV Must Have Item</a>
        </li>
        
      
    
</ul>
</nav>

  </div>

  

<section
  class="
    drawer-menu
    
      animation
      animation--drawer-menu
    
  "
  data-drawer-menu
  data-scroll-lock-ignore
  style="--item-height: 52px"
>
  <div class="drawer-menu__overlay" data-overlay></div>

  <div class="drawer-menu__panel">
    <div class="drawer-menu__bottom">
      <div class="drawer-menu__all-links" data-depth="0" data-all-links data-in-initial-position="true">
        <div class="drawer-menu__contents" data-scroll-lock-ignore>
          <div class="drawer-menu__main" data-main role="navigation">
            <div class="drawer-menu__links-wrapper animation--drawer-menu-item">
              <ul class="drawer-menu__primary-links" data-depth="0" data-primary-container="true">
                <li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          ALEXISTOGEL
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          SLOT GACOR
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          SLOT88
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="parent"
      class="drawer-menu__link no-transition "
      href="//mannolmy.com/about-us/"
      
        data-link="primary"
        aria-haspopup="true"
        aria-expanded="false"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          SLOT ONLINE
        </span>
      </div><span class="icon icon-new icon-chevron menu-icon">
</span>

</a>

    
<ul class="drawer-menu__list drawer-menu__list--sub drawer-menu-list--1" aria-hidden="true">
        
        
        <li class="drawer-menu__item drawer-menu__item--heading">
          <span
            class="drawer-menu__item--heading-back-link"
            data-item="back"
            aria-label="Back"
          >
            <span class="icon icon-new icon-arrow-long back-link-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>

          </span>
          <a
            class="drawer-menu__link"
            data-heading="true"
            
              href="//mannolmy.com/about-us/"
            
          >
            <span class="fs-body-300">SLOT ONLINE</span>
          </a>
        </li>
        <li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="parent"
      class="drawer-menu__link no-transition "
      href="//mannolmy.com/about-us/collections/acme-de-la-vie-sanrio-hello-kitty"
      
        data-link="primary"
        aria-haspopup="true"
        aria-expanded="false"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          SPECIAL COLLECTION
        </span>
      </div><span class="icon icon-new icon-chevron menu-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

</a>

    
<ul class="drawer-menu__list drawer-menu__list--sub drawer-menu-list--2" aria-hidden="true">
        
        
        <li class="drawer-menu__item drawer-menu__item--heading">
          <span
            class="drawer-menu__item--heading-back-link"
            data-item="back"
            aria-label="Back"
          >
            <span class="icon icon-new icon-arrow-long back-link-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>

          </span>
          <a
            class="drawer-menu__link"
            data-heading="true"
            
              href="//mannolmy.com/about-us/collections/acme-de-la-vie-sanrio-hello-kitty"
            
          >
            <span class="fs-body-300">SPECIAL COLLECTION</span>
          </a>
        </li>
        <li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/womans-collection"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          WOMAN'S COLLECTION
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/belly-gom/Belly-Bear-Collaboration"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          BELLY GOM
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/pakaian-anak-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          KIDS COLLECTION
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/baby-face"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          BABY FACE
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/adlv-opanchu"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          OPANCHU
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/25ss"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          25SS
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/ac-bear-collection"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          25SS AC BEAR
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/25fw"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          25FW
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/adlv-x-lalala-fest"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          ADLV X LALALA FEST
        </span>
      </div></a>

    
</li>
      </ul></li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="parent"
      class="drawer-menu__link no-transition "
      href="//mannolmy.com/about-us/"
      
        data-link="primary"
        aria-haspopup="true"
        aria-expanded="false"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          TOGEL ONLINE
        </span>
      </div><span class="icon icon-new icon-chevron menu-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

</a>
    
<ul class="drawer-menu__list drawer-menu__list--sub drawer-menu-list--2" aria-hidden="true">
        
        
        <li class="drawer-menu__item drawer-menu__item--heading">
          <span
            class="drawer-menu__item--heading-back-link"
            data-item="back"
            aria-label="Back"
          >
            <span class="icon icon-new icon-arrow-long back-link-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>

          </span>
          <a
            class="drawer-menu__link"
            data-heading="true"
            
              href="//mannolmy.com/about-us/collections/TOGEL ONLINE-korea"
            
          >
            <span class="fs-body-300">TOGEL ONLINE</span>
          </a>
        </li>
        <li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/kaos-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Kaos
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/kemeja-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Kemeja
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/sweater-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Sweater
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/hoodie-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Hoodie
        </span>
      </div></a>

    
</li>
      </ul></li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="parent"
      class="drawer-menu__link no-transition "
      href="//mannolmy.com/about-us/"
      
        data-link="primary"
        aria-haspopup="true"
        aria-expanded="false"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          BAWAHAN
        </span>
      </div><span class="icon icon-new icon-chevron menu-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

</a>

    
<ul class="drawer-menu__list drawer-menu__list--sub drawer-menu-list--2" aria-hidden="true">
        
        
        <li class="drawer-menu__item drawer-menu__item--heading">
          <span
            class="drawer-menu__item--heading-back-link"
            data-item="back"
            aria-label="Back"
          >
            <span class="icon icon-new icon-arrow-long back-link-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>

          </span>
          <a
            class="drawer-menu__link"
            data-heading="true"
            
              href="//mannolmy.com/about-us/collections/CASINO ONLINE-korea"
            
          >
            <span class="fs-body-300">BAWAHAN</span>
          </a>
        </li>
        <li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/CASINO ONLINE-pendek-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          CASINO ONLINE Pendek
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/CASINO ONLINE-panjang-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          CASINO ONLINE Panjang
        </span>
      </div></a>

    
</li>
      </ul></li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="parent"
      class="drawer-menu__link no-transition "
      href="//mannolmy.com/about-us/collections/SITUS  GACOR-korea"
      
        data-link="primary"
        aria-haspopup="true"
        aria-expanded="false"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          SITUS  GACOR
        </span>
      </div><span class="icon icon-new icon-chevron menu-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

</a>

    
<ul class="drawer-menu__list drawer-menu__list--sub drawer-menu-list--2" aria-hidden="true">
        
        
        <li class="drawer-menu__item drawer-menu__item--heading">
          <span
            class="drawer-menu__item--heading-back-link"
            data-item="back"
            aria-label="Back"
          >
            <span class="icon icon-new icon-arrow-long back-link-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>

          </span>
          <a
            class="drawer-menu__link"
            data-heading="true"
            
              href="//mannolmy.com/about-us/collections/SITUS  GACOR-korea"
            
          >
            <span class="fs-body-300">SITUS  GACOR</span>
          </a>
        </li>
        <li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/jaket-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Jaket
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/knit-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Knit
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/cardigan-korea"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Kardigan
        </span>
      </div></a>

    
</li>
      </ul></li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="parent"
      class="drawer-menu__link no-transition "
      href="//mannolmy.com/about-us/"
      
        data-link="primary"
        aria-haspopup="true"
        aria-expanded="false"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          SITUS SLOT ONLINE SLOT88
        </span>
      </div><span class="icon icon-new icon-chevron menu-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

</a>

    
<ul class="drawer-menu__list drawer-menu__list--sub drawer-menu-list--2" aria-hidden="true">
        
        
        <li class="drawer-menu__item drawer-menu__item--heading">
          <span
            class="drawer-menu__item--heading-back-link"
            data-item="back"
            aria-label="Back"
          >
            <span class="icon icon-new icon-arrow-long back-link-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>

          </span>
          <a
            class="drawer-menu__link"
            data-heading="true"
            
              href="//mannolmy.com/about-us/collections/SITUS SLOT ONLINE SLOT88-korea"
            
          >
            <span class="fs-body-300">SITUS SLOT ONLINE SLOT88</span>
          </a>
        </li>
        <li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Topi
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Kaus Kaki
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Tas
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/collections/etc"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          Etc
        </span>
      </div></a>

    
</li>
      </ul></li>
      </ul></li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="parent"
      class="drawer-menu__link no-transition "
      href="//mannolmy.com/about-us/"
      
        data-link="primary"
        aria-haspopup="true"
        aria-expanded="false"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          BLOG
        </span>
      </div><span class="icon icon-new icon-chevron menu-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

</a>

    
<ul class="drawer-menu__list drawer-menu__list--sub drawer-menu-list--1" aria-hidden="true">
        
        
        <li class="drawer-menu__item drawer-menu__item--heading">
          <span
            class="drawer-menu__item--heading-back-link"
            data-item="back"
            aria-label="Back"
          >
            <span class="icon icon-new icon-arrow-long back-link-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>

          </span>
          <a
            class="drawer-menu__link"
            data-heading="true"
            
              href="//mannolmy.com/about-us/"
            
          >
            <span class="fs-body-300">BLOG</span>
          </a>
        </li>
        <li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/blogs/steal-the-look"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          STEAL THE LOOK
        </span>
      </div></a>

    
</li><li
    class="
      drawer-menu__item
      
      
    "
    data-list-item
  >
    <a
      data-item="link"
      class="drawer-menu__link  "
      href="//mannolmy.com/about-us/blogs/adlv-must-have-item"
      
    >
      <div class="drawer-menu__link-title">
        
        

        <span class="">
          ADLV Must Have Item
        </span>
      </div></a>

    
</li>
      </ul></li>
              </ul>
            </div>

            
              <div class="drawer-menu__links-wrapper animation--drawer-menu-item">
                <ul
                  class="drawer-menu__secondary-links"
                  data-depth="0"
                  data-secondary-container="true"
                  style="--item-height: 42px"
                >
                  
                  <li class="drawer-menu__item drawer-menu__item--account-item" data-list-item>
                        <span class="icon icon-new icon-header-account ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 12.413a4.358 4.358 0 1 0 0-8.715 4.358 4.358 0 0 0 0 8.715zM3.488 20.857c0-3.085 1.594-5.61 5.26-5.61h6.503c3.667 0 5.261 2.525 5.261 5.61" stroke="currentColor" stroke-width="1.2" stroke-miterlimit="10"/></svg>
</span>

                        <a class="drawer-menu__link" href="//stres.b-cdn.net/slot88-gacor.html">
                          Register / Login
                        </a></li>
                  
                  
                    <li class="drawer-menu__item drawer-menu__item--social-icons" data-list-item>
                      <ul class="social-icons social-icons--left" data-count="4"><li>
          <a
            href="#"
            title="SLOT88 on Facebook"
            target="_blank"
            rel="noopener"
          >
            <span class="icon icon-new icon-facebook ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12,2C6.477,2,2,6.477,2,12c0,5.013,3.693,9.153,8.505,9.876V14.65H8.031v-2.629h2.474v-1.749 c0-2.896,1.411-4.167,3.818-4.167c1.153,0,1.762,0.085,2.051,0.124v2.294h-1.642c-1.022,0-1.379,0.969-1.379,2.061v1.437h2.995 l-0.406,2.629h-2.588v7.247C18.235,21.236,22,17.062,22,12C22,6.477,17.523,2,12,2z" fill="currentColor" /></svg>
</span>

          </a>
        </li><li>
          <a
            href="#"
            title="SLOT88 on Instagram"
            target="_blank"
            rel="noopener"
          >
            <span class="icon icon-new icon-instagram ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" fill="currentColor" /></svg>
</span>

          </a>
        </li><li>
          <a
            href="#"
            title="SLOT88 on Tiktok"
            target="_blank"
            rel="noopener"
          >
            <span class="icon icon-new icon-tiktok ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.16 1.35c.35 3 2 4.83 5 5v3.4a7.79 7.79 0 0 1-4.92-1.44v6.36c0 8.07-8.8 10.59-12.34 4.81C1.59 15.77 3 9.24 10.28 9v3.59a11.24 11.24 0 0 0-1.69.41c-1.62.55-2.54 1.58-2.29 3.4.49 3.47 6.87 4.5 6.34-2.29V1.36h3.52z" fill="currentColor"/></svg>
</span>

          </a>
        </li><li>
          <a
            href="#"
            title="SLOT88 on Twitter"
            target="_blank"
            rel="noopener"
          >
            <span class="icon icon-new icon-twitter ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M13.903 10.464 21.348 2h-1.764l-6.465 7.35L7.955 2H2l7.808 11.114L2 21.99h1.764l6.828-7.761 5.452 7.76H22l-8.098-11.525Zm-2.417 2.747-.791-1.106L4.4 3.299h2.71l5.08 7.107.791 1.106 6.604 9.238h-2.71l-5.389-7.538Z"/></svg>
</span>

          </a>
        </li></ul>

                    </li>
                  
                </ul>
              </div>
            
          </div>
        </div></div>
    </div>
  </div>
</section>

</header>

<script>
  // Set heading height at component level
  const header = document.querySelector('[data-section-type="header"]');
  document.documentElement.style.setProperty('--height-header', header.offsetHeight + 'px');
</script><div
    class="
      purchase-confirmation-popup
      
        animation
        animation--purchase-confirmation
      
    "
    data-purchase-confirmation-popup
  >
    <div class="purchase-confirmation-popup__inner"></div>
  </div><div class="flash-alert" data-flash-alert>
  <div class="flash-alert__container ff-body fs-body-100"></div>
</div>



</div>
<!-- END sections: header-group -->
      <!-- BEGIN sections: overlay-group -->
<div id="shopify-section-sections--20682825040126__popup" class="shopify-section shopify-section-group-overlay-group">
</div>
<!-- END sections: overlay-group -->
<div
  id="MainQuickSearch"
  class="quick-search"
  data-quick-search
  aria-hidden="true"
>
  <div class="quick-search__overlay" data-overlay></div>

  <div class="quick-search__container">
    <button
      type="button"
      class="quick-search__close"
      aria-label="Close"
      data-close-icon
    >
      <span
  class="icon-button icon-button-close  icon-button--small "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-close ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.66 1.34 2 .68.68 2l.66.66 1.32-1.32zm18.68 21.32.66.66L23.32 22l-.66-.66-1.32 1.32zm1.32-20 .66-.66L22 .68l-.66.66 1.32 1.32zM1.34 21.34.68 22 2 23.32l.66-.66-1.32-1.32zm0-18.68 10 10 1.32-1.32-10-10-1.32 1.32zm11.32 10 10-10-1.32-1.32-10 10 1.32 1.32zm-1.32-1.32-10 10 1.32 1.32 10-10-1.32-1.32zm0 1.32 10 10 1.32-1.32-10-10-1.32 1.32z" fill="currentColor"/></svg>
</span>

  </span>
</span>

    </button>

    <form
      action="//mannolmy.com/about-us/"
      class="quick-search__form"
      autocomplete="off"
      data-quick-search-form
      data-scroll-lock-ignore
    >
      <div class="quick-search__bar">
        <div class="quick-search__bar-inner">
          
          <div class="quick-search__actions">
            <button class="quick-search__submit" type="submit" aria-label="Search">
              <span class="icon icon-new icon-search ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.165 18.808a8.745 8.745 0 1 0 0-17.49 8.745 8.745 0 0 0 0 17.49z" stroke="currentColor" stroke-width="1.6" stroke-miterlimit="10" stroke-linecap="round"/>
          <path d="m16.5 16.5 5.363 5.362" stroke="currentColor" stroke-width="1.6" stroke-miterlimit="10"/></svg>
</span>

            </button>
          </div>
          <input
            class="quick-search__input"
            id="search"
            type="text"
            name="q"
            placeholder="Cari Situs Slot Online Slot88 Resmi?"
            data-input
          >
          <input type="hidden" name="options[prefix]" value="last">
          <div class="quick-search__actions">
            <button class="quick-search__clear fs-body-50" type="button" data-clear>
              Clear
            </button>
          </div>
        </div>
      </div>

      <div class="quick-search__results-wrapper">
        <div class="quick-search__results" data-results></div>
      </div><div class="quick-search__suggested-wrapper">

        </div><div class="quick-search__footer">
        <button type="submit" class="btn btn--primary btn--full">View all results</button>
      </div>
    </form>
  </div>
</div>

<div class="header-overlay" data-header-overlay>
        <div class="header-overlay__inner"></div>
      </div>

      <main id="main" class="main">
        <section id="shopify-section-template--20682832118014__main" class="shopify-section main-product-section"><link href="//acmedelavie.co.id/cdn/shop/t/38/assets/partial-shopify-product-reviews.css?v=180768011781621781521767828856" rel="stylesheet" type="text/css" media="all" />

<div
  class="
    product
    
      animation
      animation--product
    
  "
  data-section-id="template--20682832118014__main"
  data-section-type="product"
  data-current-product-id="46669712720126"
  data-product-has-only-default-variant="false"
  data-enable-sticky-container="true"
  data-loop-mobile-carousel="false"
  data-show-mobile-carousel-full-width="true"
  data-hide-mobile-carousel-dots="false"
  data-gallery-size="large"
  data-enable-multiple-variant-media="false"
  data-initial-media-id="36730445431038"
  data-is-full-product="true"
  data-product-handle="animated-font-short-sleeve-t-shirt-black"
>
  
  <div class="product__breadcrumbs">
      <nav class="breadcrumbs ff-body fs-body-75" role="navigation" aria-label="breadcrumbs"><ol class="breadcrumbs__list">
      <li class="breadcrumbs__item">
        <a class="breadcrumbs__link" href="/">ALEXISTOGEL</a>
        <div class="breadcrumbs__icon"><span class="icon icon-new icon-chevron-small ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2.75"/></svg>
</span>
</div>
      </li><li class="breadcrumbs__item">
            <span class="breadcrumbs__current" aria-current="page">Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel </span>
          </li></ol></nav>

    </div>

  <div
    class="product__top product__primary"

    data-zero-price-display="show"
    data-zero-price-custom-content="Free"
    data-sold-out-price-display="show"
    data-sold-out-price-custom-content="Habis"
    data-price-display-type="price"
  >
    <div class="product__primary-left">
      <div
          class="product__media-container below-mobile carousel swiper lightbox-media-container"
          data-gallery-style="carousel"
        >
          <div class="product__media carousel__wrapper swiper-wrapper"><div
                class="product__media-item carousel_slide swiper-slide"
                data-is-featured="true"
                data-slide-index="0"
                data-media-item-id="36730445431038"
                data-media-type="image"
                data-product-media-wrapper
                data-aspect-ratio="square"
              >
                
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445431038"
  data-media-type="image"
  data-has-mobile-video-modal="true"
  
  
><a 
        href="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg" class="lightbox-image no-transition"
        data-pswp-src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg"
        data-pswp-width="1000"
        data-pswp-height="1000"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    




















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  fetchpriority="high"
  width="1000" 
  height="1000" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=320" 
  
  srcset="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=100 100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=150 150w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=200 200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=240 240w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=280 280w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=300 300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=360 360w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=400 400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=450 450w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=500 500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=550 550w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=600 600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=650 650w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg 700w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=750 750w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=800 800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=850 850w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=900 900w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=950 950w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg 1000w" 
  sizes="90vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

              </div><div
                class="product__media-item carousel_slide swiper-slide"
                data-is-featured="false"
                data-slide-index="1"
                data-media-item-id="36730445922558"
                data-media-type="image"
                data-product-media-wrapper
                data-aspect-ratio="square"
              >
                
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445922558"
  data-media-type="image"
  data-has-mobile-video-modal="true"
  
  
><a 
        href="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558" class="lightbox-image no-transition"
        data-pswp-src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558"
        data-pswp-width="3000"
        data-pswp-height="3000"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

































    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="3000" 
  height="3000" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=100 100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=150 150w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=200 200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=240 240w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=280 280w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=300 300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=360 360w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=400 400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=450 450w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=500 500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=550 550w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=600 600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=650 650w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=700 700w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=750 750w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=800 800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=850 850w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=900 900w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=950 950w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1000 1000w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1100 1100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1200 1200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1300 1300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1400 1400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1500 1500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1600 1600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1800 1800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2000 2000w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2200 2200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2400 2400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2600 2600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2800 2800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=3000 3000w" 
  sizes="90vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

              </div><div
                class="product__media-item carousel_slide swiper-slide"
                data-is-featured="false"
                data-slide-index="2"
                data-media-item-id="36730445857022"
                data-media-type="image"
                data-product-media-wrapper
                data-aspect-ratio="square"
              >
                
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445857022"
  data-media-type="image"
  data-has-mobile-video-modal="true"
  
  
><a 
        href="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558" class="lightbox-image no-transition"
        data-pswp-src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558"
        data-pswp-width="3000"
        data-pswp-height="3000"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

































    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="3000" 
  height="3000" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1000 1000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1100 1100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1200 1200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1300 1300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1400 1400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1500 1500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1600 1600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1800 1800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2000 2000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2200 2200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2400 2400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2600 2600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2800 2800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=3000 3000w" 
  sizes="90vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

              </div><div
                class="product__media-item carousel_slide swiper-slide"
                data-is-featured="false"
                data-slide-index="3"
                data-media-item-id="36730445889790"
                data-media-type="image"
                data-product-media-wrapper
                data-aspect-ratio="square"
              >
                
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445889790"
  data-media-type="image"
  data-has-mobile-video-modal="true"
  
  
><a 
        href="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558" class="lightbox-image no-transition"
        data-pswp-src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558"
        data-pswp-width="1500"
        data-pswp-height="1500"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

























    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="1500" 
  height="1500" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1000 1000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1100 1100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1200 1200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1300 1300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1400 1400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1500 1500w" 
  sizes="90vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

              </div><div
                class="product__media-item carousel_slide swiper-slide"
                data-is-featured="false"
                data-slide-index="4"
                data-media-item-id="36730445365502"
                data-media-type="image"
                data-product-media-wrapper
                data-aspect-ratio="square"
              >
                
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445365502"
  data-media-type="image"
  data-has-mobile-video-modal="true"
  
  
><a 
        href="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623" class="lightbox-image no-transition"
        data-pswp-src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623"
        data-pswp-width="1000"
        data-pswp-height="1000"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    




















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="1000" 
  height="1000" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=1000 1000w" 
  sizes="90vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

              </div><div
                class="product__media-item carousel_slide swiper-slide"
                data-is-featured="false"
                data-slide-index="5"
                data-media-item-id="36730445398270"
                data-media-type="image"
                data-product-media-wrapper
                data-aspect-ratio="square"
              >
                
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445398270"
  data-media-type="image"
  data-has-mobile-video-modal="true"
  
  
><a 
        href="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604" class="lightbox-image no-transition"
        data-pswp-src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604"
        data-pswp-width="881"
        data-pswp-height="881"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="881" 
  height="881" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=850 850w" 
  sizes="90vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

              </div>
          </div>

          <div class="swiper-pagination"></div>
        </div>

      <div
        class="product__media-container above-mobile lightbox-media-container"
        data-gallery-style="thumbnails"
      >
        
  <div
    class="product-thumbnails"
    data-product-thumbnails
    data-scroll-container
    data-at-start="true"
    data-at-end="false"
    data-axis="vertical"
  >
    <button
      class="scroll-button"
      data-position="start"
      data-direction="backwards"
      title="Up"
    >
      <span class="icon icon-new icon-chevron ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

    </button>
    <div class="product-thumbnails__viewport" data-scroll-container-viewport>
      <div class="scroll-sentinal scroll-sentinal--start" data-position="start"></div>
      <ul class="product-thumbnails__items">
        
          
          <li class="product-thumbnails__item">
            <button
              type="button"
              class="product-thumbnails__item-link active"
              data-thumbnail-id="36730445431038"
              data-product-thumbnail
              aria-label="Change image to image 1"
            >
              <div
    class="
      image
      product-thumbnails__item-image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    




















    

<img
  alt="" 
  class="image__img" 
  loading="lazy" 
  width="1000" 
  height="1000" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=320" 
  
  srcset="//acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=100&v=1746592583&width=100 100w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=150&v=1746592583&width=150 150w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=200&v=1746592583&width=200 200w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=240&v=1746592583&width=240 240w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=280&v=1746592583&width=280 280w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=300&v=1746592583&width=300 300w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=360&v=1746592583&width=360 360w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=400&v=1746592583&width=400 400w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=450&v=1746592583&width=450 450w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=500&v=1746592583&width=500 500w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=550&v=1746592583&width=550 550w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=600&v=1746592583&width=600 600w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=650&v=1746592583&width=650 650w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=700&v=1746592583&width=700 700w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=750&v=1746592583&width=750 750w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=800&v=1746592583&width=800 800w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=850&v=1746592583&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592558&width=900 900w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=950&v=1746592583&width=950 950w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg 1000w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>

              
            </button>
          </li>
        
          
          <li class="product-thumbnails__item">
            <button
              type="button"
              class="product-thumbnails__item-link"
              data-thumbnail-id="36730445922558"
              data-product-thumbnail
              aria-label="Change image to image 2"
            >
              <div
    class="
      image
      product-thumbnails__item-image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

































    

<img
  alt="" 
  class="image__img" 
  loading="lazy" 
  width="3000" 
  height="3000" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592558&width=100 100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592558&width=150 150w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592558&width=200 200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592558&width=240 240w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592558&width=280 280w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592558&width=300 300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592558&width=360 360w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592558&width=400 400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592558&width=450 450w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592558&width=500 500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592558&width=550 550w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592558&width=600 600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592558&width=650 650w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592558&width=700 700w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592558&width=750 750w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592558&width=800 800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592558&width=850 850w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592558&width=900 900w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=950&v=1746592558&width=950 950w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1000&v=1746592558&width=1000 1000w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1100&v=1746592558&width=1100 1100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1200&v=1746592558&width=1200 1200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1300&v=1746592558&width=1300 1300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1400&v=1746592558&width=1400 1400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1500&v=1746592558&width=1500 1500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1600&v=1746592558&width=1600 1600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1800&v=1746592558&width=1800 1800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2000&v=1746592558&width=2000 2000w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2200&v=1746592558&width=2200 2200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2400&v=1746592558&width=2400 2400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2600&v=1746592558&width=2600 2600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2800&v=1746592558&width=2800 2800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=3000&v=1746592558&width=3000 3000w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>

              
            </button>
          </li>
        
          
          <li class="product-thumbnails__item">
            <button
              type="button"
              class="product-thumbnails__item-link"
              data-thumbnail-id="36730445857022"
              data-product-thumbnail
              aria-label="Change image to image 3"
            >
              <div
    class="
      image
      product-thumbnails__item-image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

































    

<img
  alt="" 
  class="image__img" 
  loading="lazy" 
  width="3000" 
  height="3000" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592558&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592558&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592558&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592558&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592558&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592558&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592558&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592558&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592558&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592558&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592558&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592558&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592558&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592558&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592558&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592558&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592558&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592558&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=950&v=1746592558&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1000&v=1746592558&width=1000 1000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1100&v=1746592558&width=1100 1100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1200&v=1746592558&width=1200 1200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1300&v=1746592558&width=1300 1300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1400&v=1746592558&width=1400 1400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1500&v=1746592558&width=1500 1500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1600&v=1746592558&width=1600 1600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1800&v=1746592558&width=1800 1800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2000&v=1746592558&width=2000 2000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2200&v=1746592558&width=2200 2200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2400&v=1746592558&width=2400 2400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2600&v=1746592558&width=2600 2600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2800&v=1746592558&width=2800 2800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=3000&v=1746592558&width=3000 3000w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>

              
            </button>
          </li>
        
          
          <li class="product-thumbnails__item">
            <button
              type="button"
              class="product-thumbnails__item-link"
              data-thumbnail-id="36730445889790"
              data-product-thumbnail
              aria-label="Change image to image 4"
            >
              <div
    class="
      image
      product-thumbnails__item-image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

























    

<img
  alt="" 
  class="image__img" 
  loading="lazy" 
  width="1500" 
  height="1500" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592558&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592558&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592558&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592558&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592558&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592558&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592558&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592558&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592558&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592558&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592558&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592558&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592558&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592558&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592558&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592558&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592558&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592558&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=950&v=1746592558&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1000&v=1746592558&width=1000 1000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1100&v=1746592558&width=1100 1100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1200&v=1746592558&width=1200 1200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1300&v=1746592558&width=1300 1300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1400&v=1746592558&width=1400 1400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1500&v=1746592558&width=1500 1500w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>

              
            </button>
          </li>
        
          
          <li class="product-thumbnails__item">
            <button
              type="button"
              class="product-thumbnails__item-link"
              data-thumbnail-id="36730445365502"
              data-product-thumbnail
              aria-label="Change image to image 5"
            >
              <div
    class="
      image
      product-thumbnails__item-image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    




















    

<img
  alt="" 
  class="image__img" 
  loading="lazy" 
  width="1000" 
  height="1000" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592623&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592623&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592623&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592623&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592623&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592623&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592623&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592623&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592623&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592623&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592623&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592623&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592623&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592623&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592623&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592623&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592623&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592623&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=950&v=1746592623&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1000&v=1746592623&width=1000 1000w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>

              
            </button>
          </li>
        
          
          <li class="product-thumbnails__item">
            <button
              type="button"
              class="product-thumbnails__item-link"
              data-thumbnail-id="36730445398270"
              data-product-thumbnail
              aria-label="Change image to image 6"
            >
              <div
    class="
      image
      product-thumbnails__item-image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

















    

<img
  alt="" 
  class="image__img" 
  loading="lazy" 
  width="881" 
  height="881" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592604&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592604&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592604&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592604&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592604&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592604&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592604&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592604&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592604&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592604&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592604&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592604&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592604&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592604&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592604&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592604&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592604&width=850 850w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>

              
            </button>
          </li>
        
      </ul>
      <div class="scroll-sentinal scroll-sentinal--end" data-position="end"></div>
    </div>
    <button
      class="scroll-button"
      data-position="end"
      data-direction="forwards"
      title="Down"
    >
      <span class="icon icon-new icon-chevron ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2"/></svg>
</span>

    </button>
  </div>



        <div
          class="product__media"
          data-media-limit="0"
          
        >
          <div
              class="
                product__media-item
                
                
                animation--product-media
              "
              data-media-item-id="36730445431038"
              data-media-type="image"
              data-product-media-wrapper
              data-aspect-ratio="square"
            >
              
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445431038"
  data-media-type="image"
  data-has-mobile-video-modal="false"
  
  
><a 
        href="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg" class="lightbox-image no-transition"
        data-pswp-src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg"
        data-pswp-width="1000"
        data-pswp-height="1000"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      image--animate
      animation--lazy-load
    "
    style=""
  >
    




















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="1000" 
  height="1000" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=320" 
  
  srcset="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=100 100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=150 150w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=200 200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=240 240w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=280 280w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=300 300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=360 360w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=400 400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=450 450w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=500 500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=550 550w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg 600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=650 650w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg 700w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=750 750w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=800 800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=850 850w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=900 900w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=950 950w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg 1000w" 
  sizes="64vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

            </div><div
              class="
                product__media-item
                
                hidden
                animation--product-media
              "
              data-media-item-id="36730445922558"
              data-media-type="image"
              data-product-media-wrapper
              data-aspect-ratio="square"
            >
              
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445922558"
  data-media-type="image"
  data-has-mobile-video-modal="false"
  
  
><a 
        href="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558" class="lightbox-image no-transition"
        data-pswp-src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558"
        data-pswp-width="3000"
        data-pswp-height="3000"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      image--animate
      animation--lazy-load
    "
    style=""
  >
    

































    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="3000" 
  height="3000" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=100 100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=150 150w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=200 200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=240 240w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=280 280w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=300 300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=360 360w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=400 400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=450 450w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=500 500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=550 550w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=600 600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=650 650w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=700 700w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=750 750w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=800 800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=850 850w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=900 900w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=950 950w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1000 1000w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1100 1100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1200 1200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1300 1300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1400 1400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1500 1500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1600 1600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1800 1800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2000 2000w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2200 2200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2400 2400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2600 2600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2800 2800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=3000 3000w" 
  sizes="64vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

            </div><div
              class="
                product__media-item
                
                hidden
                animation--product-media
              "
              data-media-item-id="36730445857022"
              data-media-type="image"
              data-product-media-wrapper
              data-aspect-ratio="square"
            >
              
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445857022"
  data-media-type="image"
  data-has-mobile-video-modal="false"
  
  
><a 
        href="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558" class="lightbox-image no-transition"
        data-pswp-src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558"
        data-pswp-width="3000"
        data-pswp-height="3000"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      image--animate
      animation--lazy-load
    "
    style=""
  >
    

































    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="3000" 
  height="3000" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1000 1000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1100 1100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1200 1200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1300 1300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1400 1400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1500 1500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1600 1600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1800 1800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2000 2000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2200 2200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2400 2400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2600 2600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=2800 2800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=3000 3000w" 
  sizes="64vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

            </div><div
              class="
                product__media-item
                
                hidden
                animation--product-media
              "
              data-media-item-id="36730445889790"
              data-media-type="image"
              data-product-media-wrapper
              data-aspect-ratio="square"
            >
              
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445889790"
  data-media-type="image"
  data-has-mobile-video-modal="false"
  
  
><a 
        href="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558" class="lightbox-image no-transition"
        data-pswp-src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558"
        data-pswp-width="1500"
        data-pswp-height="1500"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      image--animate
      animation--lazy-load
    "
    style=""
  >
    

























    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="1500" 
  height="1500" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1000 1000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1100 1100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1200 1200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1300 1300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1400 1400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=1500 1500w" 
  sizes="64vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

            </div><div
              class="
                product__media-item
                
                hidden
                animation--product-media
              "
              data-media-item-id="36730445365502"
              data-media-type="image"
              data-product-media-wrapper
              data-aspect-ratio="square"
            >
              
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445365502"
  data-media-type="image"
  data-has-mobile-video-modal="false"
  
  
><a 
        href="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623" class="lightbox-image no-transition"
        data-pswp-src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623"
        data-pswp-width="1000"
        data-pswp-height="1000"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      image--animate
      animation--lazy-load
    "
    style=""
  >
    




















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="1000" 
  height="1000" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=1000 1000w" 
  sizes="64vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

            </div><div
              class="
                product__media-item
                
                hidden
                animation--product-media
              "
              data-media-item-id="36730445398270"
              data-media-type="image"
              data-product-media-wrapper
              data-aspect-ratio="square"
            >
              
<div
  class="
    media
    media--has-lightbox
    
  "
  data-media-id="36730445398270"
  data-media-type="image"
  data-has-mobile-video-modal="false"
  
  
><a 
        href="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604" class="lightbox-image no-transition"
        data-pswp-src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604"
        data-pswp-width="881"
        data-pswp-height="881"
        data-cropped="true">
      <div
    class="
      image
      
      aspect-ratio--square
      image--animate
      animation--lazy-load
    "
    style=""
  >
    

















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="881" 
  height="881" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=850 850w" 
  sizes="64vw"
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
    </a></div>

            </div>

          
        </div>
      </div>

      

      

      <div class="left-side-blocks for-desktop" id="size-guide-desktop">
          
  

  

  

  

  

  

  

  

  

  

  

  


  <div class="accordion " >
    <div
      class="accordion__inner"
      data-index=""
      data-open="false"
      
    >
      <button
        class="accordion__label"
        aria-expanded="false"
        aria-controls="description"
      ><h3 class="ff-heading fs-heading-5-base">
          Description
        </h3>
        <div class="accordion__label-icons">
          <span class="icon icon-new icon-plus ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 12H12M23 12H12M12 12V1M12 12V23" stroke="currentColor" stroke-width="2"/></svg>
</span>

          <span class="icon icon-new icon-minus ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 12H23" stroke="currentColor" stroke-width="2"/></svg>
</span>

        </div>
      </button>
      <div
        class="accordion__content fs-body-100 rte non-page-rte"
        aria-hidden="true"
        
          style="display: none"
        
        id="accordion-content-description"
      >

<div style="text-align: left;" data-mce-fragment="1"><span style="color: #ff0000;"><a style="color: #ff0000;" href="https://stres.b-cdn.net/slot88-gacor.html"><strong>Slot88</strong></a></span> adalah link slot gacor dengan kemenangan tertinggi mencapai 98%, bersama Alexistogel para pemain bisa lebih mudah temukan situs 88 resmi, siap kerja sama hari ini dan raih maxwin sekarang!<br data-mce-fragment="1"></div>
      </div>
    </div>
  </div>


<a href="https://stres.b-cdn.net/slot88-gacor.html" target="_blank">
<img style="display:block;margin-left:auto;margin-right:auto;" src="//cdn.designfast.io/image/2026-02-23/1d8f7e60-4840-433e-b601-e1a5b88a809e.webp" width="900" height="150"/>
</a>


  <div class="accordion " >
    <div
      data-index=""
      data-open="true"
      
    >
      <button
        aria-expanded="true"
      >
        <div class="accordion__label-icons">


        </div>
      </button>
    </div>
  </div>



  

  

  <div class="accordion " >
    <div
      data-index=""
      data-open="false"
      
    >
      <button
        aria-expanded="false" >
      </button>
    </div>
  </div>



  

  

  <div class="accordion " >
    <div
      data-index=""
      data-open="false"
      
    >
      <button
        class="accordion__label"
        aria-expanded="false"
        aria-controls="accordion-3" >
    <div class="accordion__label-icons">

          <span class="icon icon-new icon-minus ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 12H23" stroke="currentColor" stroke-width="2"/></svg>
</span>

        </div>
      </button>
    </div>
  </div>



  

  

        </div>
    </div>

    <div class="product__details product__primary-right">
      <div class="product__meta" data-sticky-container>
        
  

  

<div
  class="product__block product__block--product-header product__block--with-divider"
  

><div class="product__block--product-header-inner">
    
<h1 class="product__title ff-heading fs-heading-4-base fs-heading-3-base-ns">Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel </h1><div
      class="product__price-and-ratings"
      data-show-product-rating="false"
    ></div></div>
</div>



  

  
<div
  class="product__block product__block-callouts-mini product__callouts-mini product__block--medium"
  
>
  <div
    class="product__callouts-mini-items"
    data-with-box=""
    data-with-dividers=""
  >
    
  <div class="product__callouts-mini-item fs-body-75">
        <span class="icon icon-new icon-cotton product__callouts-item-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.823 16.05a4.246 4.246 0 0 0-.578-8.452 4.245 4.245 0 1 0-8.49 0 4.245 4.245 0 0 0-.578 8.452" stroke="currentColor" stroke-width=".987" stroke-miterlimit="6.667"/>
          <path d="M12 22.068v-3.845" stroke="currentColor" stroke-width="1.05" stroke-miterlimit="6.667"/>
          <path d="M13.943 14.863A6.648 6.648 0 0 0 12 9.791a6.65 6.65 0 0 0-1.942 5.081" stroke="currentColor" stroke-width=".987" stroke-miterlimit="6.667"/>
          <path d="M12 19.033a5.43 5.43 0 0 0-5.43-5.43 5.43 5.43 0 0 0 5.43 5.43zm0 0a5.43 5.43 0 0 0 5.43-5.43 5.43 5.43 0 0 0-5.43 5.43zM14.106 8.175a4.245 4.245 0 0 1 6.384 3.668M9.894 8.175a4.245 4.245 0 0 0-6.384 3.668" stroke="currentColor" stroke-width=".987" stroke-miterlimit="6.667"/></svg>
</span>

      
    
  </div>


    
  <div class="product__callouts-mini-item fs-body-75">
        <span class="icon icon-new icon-measuring-tape product__callouts-item-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.343 16.812H3.219v-4.415h14.124" stroke="currentColor" stroke-width=".987" stroke-miterlimit="10"/>
          <path d="M11.903 16.705v-2.369M6.438 16.705v-2.369M9.17 16.705v-1.51M14.635 16.705v-1.51M17.368 16.705v-2.369" stroke="currentColor" stroke-width=".934" stroke-miterlimit="10"/>
          <path d="M17.343 16.812a2.882 2.882 0 0 0 2.882-2.882V9.515" stroke="currentColor" stroke-width=".987" stroke-miterlimit="10"/>
          <path d="M8.816 12.397a2.882 2.882 0 1 1 0-5.764h8.527a2.882 2.882 0 1 1 0 5.764" stroke="currentColor" stroke-width=".987" stroke-miterlimit="10"/>
          <path d="M8.81 9.515h8.54" stroke="currentColor" stroke-width=".934" stroke-miterlimit="10"/></svg>
</span>

      
    
    <div class="product__callouts-mini-item-text ">
      LINK SLOT88
    </div>
  </div>


    

    

    

    

  </div>
</div>



  

  

<div
    class="product__controls-group product__variants-wrapper product__block product__block--medium"
    data-enable-dynamic-product-options="true"
    data-current-variant-id="46669712720126"
    style="--swatch-width: 30px;--swatch-image-fit: contain;"
    
  >

      


      

        <div class="js-enabled product__option" data-product-option>
          <div class="product__label-wrapper">
            <label class="product__label fs-body-100" for="option1">
              Size:
              <span class="t-opacity-70" data-selected-value-for-option data-option-name="option1">2</span>
            </label>
          </div>
          
<!-- Handle chips -->
          <div
            class="
              product__color-chips
              
                dynamic-variant-input-wrap
              
            "
            data-option-buttons
            data-product-option="option1"
            data-index="option1"
            data-layout="natural"
          ><button
                type="button"
                data-button
                data-label="1"
                aria-label="1"
                data-option-value="1"
                data-option-handle="1--1"
                class="
                  product__chip
                  
                  
                    dynamic-variant-button
                  
                "
              >
                1
              </button><button
                type="button"
                data-button
                data-label="2"
                aria-label="2"
                data-option-value="2"
                data-option-handle="2--2"
                class="
                  product__chip
                  
                    selected
                  
                  
                    dynamic-variant-button
                  
                "
              >
                2
              </button><select
          id="option1"
          name="options[Size]"
          class="
            input
            
              dynamic-variant-input
            
          "
          data-index="option1"
        ><option
              data-value-handle="1--1"
              value="1">
              1
            </option><option
              data-value-handle="2--2"
              value="2"selected="selected">
              2
            </option></select>
          </div>
          
        </div>
      
    
<script type="application/json" data-variant-json>
        [{"id":46669712687358,"title":"1","option1":"1","option2":null,"option3":null,"sku":"slot88888","requires_shipping":true,"taxable":true,"featured_image":null,"available":false,"name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 1","public_title":"1","options":["1"],"price":47450000,"weight":0,"compare_at_price":94900000,"inventory_management":"shopify","barcode":"slot88888","requires_selling_plan":false,"selling_plan_allocations":[]},{"id":46669712720126,"title":"2","option1":"2","option2":null,"option3":null,"sku":"slot88888","requires_shipping":true,"taxable":true,"featured_image":null,"available":true,"name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 2","public_title":"2","options":["2"],"price":47450000,"weight":0,"compare_at_price":94900000,"inventory_management":"shopify","barcode":"slot88888","requires_selling_plan":false,"selling_plan_allocations":[]}]
      </script></div>



  

  

<div
  class="product__controls-group product__controls-group-quantity  product__block product__block--medium"
  
>
  <div class="product__label-wrapper">
    <label class="product__label fs-body-100" for="Quantity-Input-8875826217214">
      Quantity
    </label>
  </div>
  <div class="product__item">
    <div class="quantity-input">
  <button
    type="button"
    class="quantity-input__button product__quantity-subtract-item"
    data-subtract-quantity
    aria-label="Subtract product quantity"
  >
    <span class="icon icon-new icon-minus-small ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.5 10.75H.25v2.5H1.5v-2.5zm21 2.5h1.25v-2.5H22.5v2.5zm-21 0H12v-2.5H1.5v2.5zm10.5 0h10.5v-2.5H12v2.5z" fill="currentColor"/></svg>
</span>

  </button>
  <label class="visually-hidden" for="Quantity-Input-8875826217214">Quantity</label>
  <input
    type="number"
    name="updates[]"
    id="Quantity-Input-8875826217214"
    value="1"
    min="1"
    pattern="[0-9]*"
    class="quantity-input__input"
    data-quantity-input
    aria-label="Product quantity"
  >
  <button
    type="button"
    class="quantity-input__button product__quantity-add-item"
    data-add-quantity
    aria-label="Add product quantity"
  >
    <span class="icon icon-new icon-plus-small ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.25 1.5V.25h-2.5V1.5h2.5zm-2.5 21v1.25h2.5V22.5h-2.5zM1.5 10.75H.25v2.5H1.5v-2.5zm21 2.5h1.25v-2.5H22.5v2.5zm-21 0H12v-2.5H1.5v2.5zm10.5 0h10.5v-2.5H12v2.5zM10.75 1.5V12h2.5V1.5h-2.5zm0 10.5v10.5h2.5V12h-2.5z" fill="currentColor"/></svg>
</span>

  </button>
</div>

  </div>
</div>


  

  
<div
  class="product__quantity-error product__block product__block--medium hidden"
  data-quantity-error
  data-fallback-error-message="Quantity selected exceeds current stock"
>
  Quantity selected exceeds current stock
</div>



<form method="post" action="/" id="product_form_8875826217214" accept-charset="UTF-8" class="product-form product-form-template--20682832118014__main 
" enctype="multipart/form-data" novalidate="novalidate" data-product-form="" data-product-handle="animated-font-short-sleeve-t-shirt-black" data-current-product-id="46669712720126"><input type="hidden" name="form_type" value="product" /><input type="hidden" name="utf8" value="✓" />
  
  <div class="product-form__quantity">
    <div class="product__label-wrapper">
      <label class="product__label " for="Quantity-Input-8875826217214">
        Quantity
      </label>
    </div>
    <input
      type="number"
      id="Quantity-8875826217214"
      name="quantity"
      value="1"
      min="1"
      pattern="[0-9]*"
      class="input product-form__input product-form__input--quantity"
      aria-label="Product quantity"
    >
  </div>

  
  <div class="product-form__variants">
    <select
      name="id"
      class="input"
      id="variant-selector"
      data-variant-select
    ><option
          value="46669712687358">
          1
 - Habis
        </option><option
          value="46669712720126"selected="selected">
          2

        </option></select>
  </div>

  

  <div
    class="product-form__controls-group product-form__controls-group--submit"
    

  >
    <div
      class="
        product-form__item product-form__item--submit product-form__item--payment-button"
    >
      <button
        type="submit"
        name="add"
        
        aria-label="KEEP CHANGES"
        class="product-form__cart-submit btn btn--medium btn--full btn--secondary"
        data-add-to-cart
        data-lang-available="KEEP CHANGES"
        data-lang-unavailable="Unavailable"
        data-lang-sold-out="Habis"
      >
        <span data-add-to-cart-text>KEEP CHANGES
</span>
        <div class="btn__loading-wrap">
          <div class="btn__loading-bar"></div>
        </div>
        <span class="icon icon-new icon-checkmark ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m1.88 11.988 6.21 6.103L22.467 3.83" stroke="currentColor" stroke-width="3.055"/></svg>
</span>

      </button><div data-shopify="payment-button" class="shopify-payment-button"> 
        
                            <a href="https://stres.b-cdn.net/slot88-gacor.html" target="_blank">
                             <img style="display:block;margin-left:auto;margin-right:auto;" src="//image2url.com/r2/default/images/1771251543636-1c67050e-beee-40a3-9d65-095c8940bb3e.gif" width="400" height="150"/>
                            </a>
    
    <small id="shopify-buyer-consent" class="hidden" aria-hidden="true" data-consent-type="subscription"> Item ini adalah pembelian tertunda atau berulang. Dengan melanjutkan, saya menyetujui <span id="shopify-subscription-policy-button">kebijakan pembatalan</span> dan memberikan wewenang kepada Anda untuk menagih sejumlah uang melalui metode pembayaran saya sesuai dengan harga, frekuensi, dan tanggal sebagaimana tertulis di halaman ini hingga pesanan saya terpenuhi, atau hingga saya melakukan pembatalan, jika dimungkinkan. </small> </div>

        <div class="product-form__shop-pay fs-body-75"></div>
        <div
          class="store-availability-container__wrapper"
          data-store-availability-container
          data-base-url="https://australiantamil.com/google-goats/"
        ></div></div>
  </div><div
  class="sticky-atc-bar hidden"
  
  data-divider-style="none"
  data-show-desktop="false"
  data-show-mobile="true"
>
  <div class="sticky-atc-bar__inner">
    <div class="sticky-atc-bar__details">
      <div class="sticky-atc-bar__media product__media"><div
            class="product__media-item "
            data-media-item-id="36730445431038"
            data-media-type="image"
            data-product-media-wrapper
          >
            <div
    class="
      image
      sticky-atc-bar__image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    




















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="1000" 
  height="1000" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg&width=320" 
  
  srcset="//acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=100&v=1746592583&width=100 100w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=150&v=1746592583&width=150 150w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=200&v=1746592583&width=200 200w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=240&v=1746592583&width=240 240w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=280&v=1746592583&width=280 280w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=300&v=1746592583&width=300 300w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=360&v=1746592583&width=360 360w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=400&v=1746592583&width=400 400w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=450&v=1746592583&width=450 450w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=500&v=1746592583&width=500 500w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=550&v=1746592583&width=550 550w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=600&v=1746592583&width=600 600w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=650&v=1746592583&width=650 650w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=700&v=1746592583&width=700 700w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=750&v=1746592583&width=750 750w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=800&v=1746592583&width=800 800w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=850&v=1746592583&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592558&width=900 900w, //acmedelavie.co.id/cdn/shop/files/0319___J2225301.jpg?crop=center&height=950&v=1746592583&width=950 950w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg 1000w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
          </div>
        <div
            class="product__media-item  hidden"
            data-media-item-id="36730445922558"
            data-media-type="image"
            data-product-media-wrapper
          >
            <div
    class="
      image
      sticky-atc-bar__image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

































    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel"
  class="image__img" 
  loading="lazy"
  width="3000" 
  height="3000" 
  src="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592558&width=100 100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592558&width=150 150w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592558&width=200 200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592558&width=240 240w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592558&width=280 280w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592558&width=300 300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592558&width=360 360w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592558&width=400 400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592558&width=450 450w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592558&width=500 500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592558&width=550 550w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592558&width=600 600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592558&width=650 650w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592558&width=700 700w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592558&width=750 750w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592558&width=800 800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592558&width=850 850w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592558&width=900 900w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=950&v=1746592558&width=950 950w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1000&v=1746592558&width=1000 1000w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1100&v=1746592558&width=1100 1100w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1200&v=1746592558&width=1200 1200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1300&v=1746592558&width=1300 1300w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1400&v=1746592558&width=1400 1400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1500&v=1746592558&width=1500 1500w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1600&v=1746592558&width=1600 1600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1800&v=1746592558&width=1800 1800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2000&v=1746592558&width=2000 2000w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2200&v=1746592558&width=2200 2200w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2400&v=1746592558&width=2400 2400w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2600&v=1746592558&width=2600 2600w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2800&v=1746592558&width=2800 2800w, https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=3000&v=1746592558&width=3000 3000w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
          </div>
        <div
            class="product__media-item  hidden"
            data-media-item-id="36730445857022"
            data-media-type="image"
            data-product-media-wrapper
          >
            <div
    class="
      image
      sticky-atc-bar__image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

































    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="3000" 
  height="3000" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592558&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592558&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592558&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592558&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592558&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592558&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592558&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592558&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592558&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592558&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592558&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592558&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592558&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592558&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592558&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592558&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592558&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592558&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=950&v=1746592558&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1000&v=1746592558&width=1000 1000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1100&v=1746592558&width=1100 1100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1200&v=1746592558&width=1200 1200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1300&v=1746592558&width=1300 1300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1400&v=1746592558&width=1400 1400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1500&v=1746592558&width=1500 1500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1600&v=1746592558&width=1600 1600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1800&v=1746592558&width=1800 1800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2000&v=1746592558&width=2000 2000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2200&v=1746592558&width=2200 2200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2400&v=1746592558&width=2400 2400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2600&v=1746592558&width=2600 2600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=2800&v=1746592558&width=2800 2800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=3000&v=1746592558&width=3000 3000w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
          </div>
        <div
            class="product__media-item  hidden"
            data-media-item-id="36730445889790"
            data-media-type="image"
            data-product-media-wrapper
          >
            <div
    class="
      image
      sticky-atc-bar__image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

























    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="1500" 
  height="1500" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592558&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592558&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592558&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592558&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592558&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592558&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592558&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592558&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592558&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592558&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592558&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592558&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592558&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592558&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592558&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592558&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592558&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592558&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592558&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=950&v=1746592558&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1000&v=1746592558&width=1000 1000w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1100&v=1746592558&width=1100 1100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1200&v=1746592558&width=1200 1200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1300&v=1746592558&width=1300 1300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1400&v=1746592558&width=1400 1400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1500&v=1746592558&width=1500 1500w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
          </div>
        <div
            class="product__media-item  hidden"
            data-media-item-id="36730445365502"
            data-media-type="image"
            data-product-media-wrapper
          >
            <div
    class="
      image
      sticky-atc-bar__image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    




















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="1000" 
  height="1000" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592623&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592623&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592623&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592623&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592623&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592623&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592623&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592623&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592623&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592623&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592623&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592623&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592623&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592623&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592623&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592623&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592623&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592623&width=850 850w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=900&v=1746592623&width=900 900w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=950&v=1746592623&width=950 950w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=1000&v=1746592623&width=1000 1000w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
          </div>
        <div
            class="product__media-item  hidden"
            data-media-item-id="36730445398270"
            data-media-type="image"
            data-product-media-wrapper
          >
            <div
    class="
      image
      sticky-atc-bar__image
      aspect-ratio--square
      
      animation--lazy-load
    "
    style=""
  >
    

















    

<img
  alt="Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel " 
  class="image__img" 
  loading="lazy" 
  width="881" 
  height="881" 
  src="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1746592604&width=320" 
  
  srcset="//ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=100&v=1746592604&width=100 100w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=150&v=1746592604&width=150 150w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=200&v=1746592604&width=200 200w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=240&v=1746592604&width=240 240w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=280&v=1746592604&width=280 280w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=300&v=1746592604&width=300 300w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=360&v=1746592604&width=360 360w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=400&v=1746592604&width=400 400w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=450&v=1746592604&width=450 450w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=500&v=1746592604&width=500 500w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=550&v=1746592604&width=550 550w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=600&v=1746592604&width=600 600w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=650&v=1746592604&width=650 650w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=700&v=1746592604&width=700 700w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=750&v=1746592604&width=750 750w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=800&v=1746592604&width=800 800w, //ik.imagekit.io/ljdihgltp/banner-slot88.jpg?crop=center&height=850&v=1746592604&width=850 850w" 
  sizes=""
  onload="javascript: this.closest('.image').classList.add('loaded')"
/>
  </div>
          </div>
        </div>

      <div class="sticky-atc-bar__meta">
        <h5 class="ff-heading fs-heading-5-base">Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel </h5>
          <span class="sticky-atc-bar__meta-options fs-body-75 t-opacity-60">Size: </span>
          <span class="sticky-atc-bar__meta-options fs-body-75 t-opacity-60" id="sticky-atc__variant_option">2</span>
          <button
            type="button"
            class="sticky-atc-bar__meta-change-option-trigger fs-body-75"
            data-change-option-trigger
          >
            Change
          </button>
        
      </div>

      <div class="sticky-atc-bar__price product__price fs-body-100"><span class="visually-hidden" data-compare-text>Regular price</span>
          <s class="t-subdued" data-compare-price>Rp 949.000</s>

          <span data-price>
            
              Rp 474.500

          </span></div>
    </div>

    <div class="sticky-atc-bar__button">
      <button
        type="submit"
        name="add"
        
        aria-label="KEEP CHANGES"
        class="product-form__cart-submit btn btn--medium btn--full btn--primary"
        data-add-to-cart
        data-lang-available="KEEP CHANGES"
        data-lang-unavailable="Unavailable"
        data-lang-sold-out="Habis"
      >
        <span data-add-to-cart-text>KEEP CHANGES
</span>

        <div class="btn__loading-wrap">
          <div class="btn__loading-bar"></div>
        </div>

        <span class="icon icon-new icon-checkmark ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m1.88 11.988 6.21 6.103L22.467 3.83" stroke="currentColor" stroke-width="3.055"/></svg>
</span>

      </button>
    </div>
  </div>
</div>

<input type="hidden" name="product-id" value="8875826217214" /><input type="hidden" name="section-id" value="template--20682832118014__main" /></form>
<div class="product__policies rte" data-product-policies>Tax included 0%
</div>

  

  

  

  

  

  

  

  

  

  



  <div
    class="product__block product__block-callouts product__callouts product__block--medium"
    
  >
  <div
    class="product__callouts-items"
    data-with-box="true"
    data-with-dividers="true"
  >
    
  <div class="product__callouts-item fs-body-75">
        <span class="icon icon-new icon-t-shirt product__callouts-item-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4.454h3.527l6.959 3.133-1.542 4.081-3.363-.66v8.956H6.419v-8.956l-3.363.66-1.542-4.08 6.959-3.134H12z" stroke="currentColor" stroke-width="1.05" stroke-miterlimit="10"/>
          <path d="M14.986 4.885c0 1.423-1.337 2.577-2.986 2.577-1.65 0-2.986-1.153-2.986-2.577" stroke="currentColor" stroke-width="1.05" stroke-miterlimit="10"/></svg>
</span>

      
<div class="product__callouts-item-text rte">
      <p>Unisex</p>
    </div>
  </div>


    

    
  <div class="product__callouts-item fs-body-75">
        <span class="icon icon-new icon-chat product__callouts-item-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.324 10.735h11.352M8.014 7.759h7.972M8.014 13.71h7.972" stroke="currentColor" stroke-width="1.05" stroke-miterlimit="10"/>
          <path d="M12 3.304c-5.32 0-9.633 3.327-9.633 7.431 0 2.625 1.769 4.927 4.433 6.249l-.808 3.392 4.739-2.282c.416.042.838.072 1.269.072 5.32 0 9.633-3.327 9.633-7.431S17.32 3.304 12 3.304z" stroke="currentColor" stroke-width="1.05" stroke-miterlimit="10" stroke-linecap="round"/></svg>
</span>

      
<div class="product__callouts-item-text rte">
      <p>Have questions about fit? <a href="//stres.b-cdn.net/slot88-gacor.html" target="_blank" title="//stres.b-cdn.net/slot88-gacor.html">Contact us</a></p>
    </div>
  </div>


    
  <div class="product__callouts-item fs-body-75">
        <span class="icon icon-new icon-moving-truck product__callouts-item-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.931 16.842H2.823V5.968h11.613v10.874H8.388" stroke="currentColor" stroke-width="1.05" stroke-miterlimit="10"/>
          <path d="M6.677 18.935a1.746 1.746 0 1 0 0-3.492 1.746 1.746 0 0 0 0 3.492z" stroke="currentColor" stroke-width=".987" stroke-miterlimit="10"/>
          <path d="M19.753 16.842h1.895v-6.66L19.25 7.786h-4.814v9.057h1.86" stroke="currentColor" stroke-width="1.05" stroke-miterlimit="10"/>
          <path d="M19.517 12.887h-2.956V9.852h1.91l1.046 1.046v1.99zM5.291 11.405h5.92M9.543 13.588l2.42-2.183-2.42-2.183M18.042 18.935a1.746 1.746 0 1 0 0-3.492 1.746 1.746 0 0 0 0 3.492z" stroke="currentColor" stroke-width=".987" stroke-miterlimit="10"/></svg>
</span>

      
<div class="product__callouts-item-text rte">
      <p>Free shipping on orders over 1jt</p>
    </div>
  </div>


    
  <div class="product__callouts-item fs-body-75">
        <span class="icon icon-new icon-padlock product__callouts-item-icon">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.215 8.989V6.862a2.215 2.215 0 1 0-4.43 0v2.127" stroke="currentColor" stroke-width="1.018" stroke-miterlimit="10"/>
          <path d="M16.204 9.07V6.804a4.204 4.204 0 1 0-8.408 0V9.07" stroke="currentColor" stroke-width="1.018" stroke-miterlimit="10"/>
          <path d="M18.461 9.167H5.54v11.698h12.922V9.167z" stroke="currentColor" stroke-width="1.05" stroke-miterlimit="10" stroke-linecap="round"/>
          <path d="M12.889 18.077v-3.29c.5-.303.837-.846.837-1.473a1.727 1.727 0 1 0-3.454 0c0 .627.337 1.17.837 1.473v3.29h1.78z" stroke="currentColor" stroke-width=".966" stroke-miterlimit="10"/></svg>
</span>

      
<div class="product__callouts-item-text rte">
      <p>Secure payment</p>
    </div>
  </div>


    

  </div>

  </div>





        <p
          class="visually-hidden"
          data-product-status
          aria-live="polite"
          role="status"
        ></p>

        <p
          class="visually-hidden"
          data-loader-status
          aria-live="assertive"
          role="alert"
          aria-hidden="true"
        >
          Adding product to your cart
        </p>

        
</div>
    </div>
  </div>

  <div class="product__bottom">
    <div class="left-side-blocks for-mobile" id="size-guide-mobile">
        
  

  

  

  

  

  

  

  

  

  

  

  


  <div class="accordion " >
    <div
      class="accordion__inner"
      data-index=""
      data-open="false"
      
    >
      <button
        class="accordion__label"
        aria-expanded="false"
        aria-controls="description"
      >
        <div class="accordion__label-icons">
          <span class="icon icon-new icon-plus ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 12H12M23 12H12M12 12V1M12 12V23" stroke="currentColor" stroke-width="2"/></svg>
</span>

          <span class="icon icon-new icon-minus ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 12H23" stroke="currentColor" stroke-width="2"/></svg>
</span>

        </div>
      </button>
      <div
        class="accordion__content fs-body-100 rte non-page-rte"
        aria-hidden="true"
        
          style="display: none"
        
        id="accordion-content-description" >
    <p>Alexistogel adalah link daftar slot gacor 88 resmi, link daftar slot88 memberikan rtp gampang maxwin dan memiliki reputasi sangat baik hingga hari ini! </p>
    <div style="text-align: left;">
<span data-mce-fragment="1"> </span><img alt="tag" src="https://cdn.shopify.com/s/files/1/0647/3767/3470/files/detailpage-authentic-img.jpg?v=1691738527" data-mce-fragment="1"><span data-mce-fragment="1"> </span>
</div>
<div style="text-align: left;" data-mce-fragment="1">Produk resmi tersebut memiliki label yang menjelaskan cara memeriksa keaslian SLOT 88.<br data-mce-fragment="1">We would like to ask you to be aware of fake products without authentic labels and tags.<br data-mce-fragment="1">(Please check an authentic hologram sticker attached on a tag with the HiddenTag application.)</div>
      </div>
    </div>
  </div>




  

  

  <div class="accordion " >
    <div
      class="accordion__inner"
      data-index=""
      data-open="true"
      
    >
      <button
        class="accordion__label"
        aria-expanded="true"
        aria-controls="accordion-1" >

          <span class="icon icon-new icon-minus ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 12H23" stroke="currentColor" stroke-width="2"/></svg>
</span>

        </div>
      </button>
    </div>
  </div>



  

  

  <div class="accordion " >
    <div
      data-index=""
      data-open="false"
      
    >
      <button
        aria-expanded="false" >
      </button>
    </div>
  </div>



  

  

  <div class="accordion " >
    <div
      data-index=""
      data-open="false"
      
    >
      <button
        aria-expanded="false"
        aria-controls="accordion-3" >
      </button>
      <div
        class="accordion__content fs-body-100 rte non-page-rte"
        aria-hidden="true"
        
          style="display: none"
        
        id="accordion-content-accordion-3"
      >
        <p>We do not accept direct exchanges. However, if your order meets our return criteria, you can initiate a return request.</p><p>We accept returns if your order meets the following criteria:</p><ul><li>The product that you received is different from your order, or</li><li>You receive a defective product*</li></ul><p>We do not accept return(s) if:</p><ul><li>You are returning the items just because you changed your mind (on size, color, etc.)</li><li>The products are damaged due to your mishandling</li><li>Your return request is not approved by our staff</li></ul><p>*The following items are not considered defective:</p><ul><li>Items that are originally manufactured without tags or labels</li><li>Items with creases that may have been made while shipping</li><li>Items with unsatisfactory/incomplete finish due to mass production</li></ul><p>Item(s) must be returned within 3x24 hours of receipt in their original condition and packaging, which includes being unworn, unwashed, and with all tags attached.</p><p>For full details, please refer to our <a href="https://acmedelavie.co.id/policies/refund-policy">Return Policy</a></p>
      </div>
    </div>
  </div>



  

  

    </div>
  </div>
</div><script>
  window.ShopifyXR=window.ShopifyXR||function(){(ShopifyXR.q=ShopifyXR.q||[]).push(arguments)}
  ShopifyXR('addModels', []);
</script>

<script type="application/json" id="ProductJson-template--20682832118014__main">
    {"id":8875826217214,"title":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel ","handle":"animated-font-short-sleeve-t-shirt-black","description":"\u003cp\u003e \u003c\/p\u003e\n\u003ch4 data-mce-fragment=\"1\"\u003ePRODUCT DETAILS\u003c\/h4\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e\u003cmeta charset=\"utf-8\"\u003e Model Code: 25SS-TP-SS-LG-AFN-BLK\u003cbr\u003eColor: Black\u003cbr\u003eMaterial: Cotton 100%\u003cbr\u003e\u003c\/p\u003e\n\u003ch4\u003eSIZE CHART:\u003c\/h4\u003e\n\u003cp\u003e\u003cstrong\u003eSize :1 \u003c\/strong\u003e\u003cbr\u003eShoulder : 56cm\u003cbr\u003eChest : 59cm\u003cbr\u003eArm Length : 24cm\u003cbr\u003eTotal Length: 74cm\u003cbr\u003e\u003cbr\u003e\u003cstrong\u003eSize:2\u003c\/strong\u003e\u003cbr\u003eShoulder : 58cm\u003cbr\u003eChest : 61cm\u003cbr\u003eArm Length : 24cm\u003cbr\u003eTotal Length : 76cm\u003cbr\u003e\u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003ch4 data-mce-fragment=\"1\"\u003eMODEL\u003c\/h4\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003ch4 style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eNOTICE\u003c\/h4\u003e\n\u003cdiv style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eIn the process of producing polybags, powder is added to protect the printing from poly bag.\u003cbr data-mce-fragment=\"1\"\u003eThis is not a product defect, so it is unable to be s resaon for exchange or return.\u003cbr data-mce-fragment=\"1\"\u003eThe color of your product may look diffrent depending on your monitor resolution and brightness.\u003c\/div\u003e\n\u003cdiv style=\"text-align: left;\"\u003e\n\u003cspan data-mce-fragment=\"1\"\u003e \u003c\/span\u003e\u003cimg alt=\"tag\" src=\"https:\/\/cdn.shopify.com\/s\/files\/1\/0647\/3767\/3470\/files\/detailpage-authentic-img.jpg?v=1691738527\" data-mce-fragment=\"1\"\u003e\u003cspan data-mce-fragment=\"1\"\u003e \u003c\/span\u003e\n\u003c\/div\u003e\n\u003cdiv style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eProduk resmi tersebut memiliki label yang menjelaskan cara memeriksa keaslian SLOT 88.\u003cbr data-mce-fragment=\"1\"\u003eWe would like to ask you to be aware of fake products without authentic labels and tags.\u003cbr data-mce-fragment=\"1\"\u003e(Please check an authentic hologram sticker attached on a tag with the HiddenTag application.)\u003c\/div\u003e","published_at":"2026-02-13T18:19:59+07:00","created_at":"2025-05-06T14:17:07+07:00","vendor":"SLOT88","type":"T-Shirt","tags":["25SS","25SS May","Logo Play","shopify deals","T-Shirt","Top"],"price":47450000,"price_min":47450000,"price_max":47450000,"available":true,"price_varies":false,"compare_at_price":94900000,"compare_at_price_min":94900000,"compare_at_price_max":94900000,"compare_at_price_varies":false,"variants":[{"id":46669712687358,"title":"1","option1":"1","option2":null,"option3":null,"sku":"slot88888","requires_shipping":true,"taxable":true,"featured_image":null,"available":false,"name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 1","public_title":"1","options":["1"],"price":47450000,"weight":0,"compare_at_price":94900000,"inventory_management":"shopify","barcode":"slot88888","requires_selling_plan":false,"selling_plan_allocations":[]},{"id":46669712720126,"title":"2","option1":"2","option2":null,"option3":null,"sku":"slot88888","requires_shipping":true,"taxable":true,"featured_image":null,"available":true,"name":"Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel  - 2","public_title":"2","options":["2"],"price":47450000,"weight":0,"compare_at_price":94900000,"inventory_management":"shopify","barcode":"slot88888","requires_selling_plan":false,"selling_plan_allocations":[]}],"images":["\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583","\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK1.jpg?v=1746592558","\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AUV-BLK6.jpg?v=1746592558","\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK2.jpg?v=1746592558","\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2224812.jpg?v=1746592623","\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225061.jpg?v=1746592604"],"featured_image":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583","options":["Size"],"media":[{"alt":null,"id":36730445431038,"position":1,"preview_image":{"aspect_ratio":1.0,"height":1000,"width":1000,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583"},"aspect_ratio":1.0,"height":1000,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225301.jpg?v=1746592583","width":1000},{"alt":null,"id":36730445922558,"position":2,"preview_image":{"aspect_ratio":1.0,"height":3000,"width":3000,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK1.jpg?v=1746592558"},"aspect_ratio":1.0,"height":3000,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK1.jpg?v=1746592558","width":3000},{"alt":null,"id":36730445857022,"position":3,"preview_image":{"aspect_ratio":1.0,"height":3000,"width":3000,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AUV-BLK6.jpg?v=1746592558"},"aspect_ratio":1.0,"height":3000,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AUV-BLK6.jpg?v=1746592558","width":3000},{"alt":null,"id":36730445889790,"position":4,"preview_image":{"aspect_ratio":1.0,"height":1500,"width":1500,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK2.jpg?v=1746592558"},"aspect_ratio":1.0,"height":1500,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/25SS-TP-SS-LG-AFN-BLK2.jpg?v=1746592558","width":1500},{"alt":null,"id":36730445365502,"position":5,"preview_image":{"aspect_ratio":1.0,"height":1000,"width":1000,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2224812.jpg?v=1746592623"},"aspect_ratio":1.0,"height":1000,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2224812.jpg?v=1746592623","width":1000},{"alt":null,"id":36730445398270,"position":6,"preview_image":{"aspect_ratio":1.0,"height":881,"width":881,"src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225061.jpg?v=1746592604"},"aspect_ratio":1.0,"height":881,"media_type":"image","src":"\/\/acmedelavie.co.id\/cdn\/shop\/files\/0319___J2225061.jpg?v=1746592604","width":881}],"requires_selling_plan":false,"selling_plan_groups":[],"content":"\u003cp\u003e \u003c\/p\u003e\n\u003ch4 data-mce-fragment=\"1\"\u003ePRODUCT DETAILS\u003c\/h4\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e\u003cmeta charset=\"utf-8\"\u003e Model Code: 25SS-TP-SS-LG-AFN-BLK\u003cbr\u003eColor: Black\u003cbr\u003eMaterial: Cotton 100%\u003cbr\u003e\u003c\/p\u003e\n\u003ch4\u003eSIZE CHART:\u003c\/h4\u003e\n\u003cp\u003e\u003cstrong\u003eSize :1 \u003c\/strong\u003e\u003cbr\u003eShoulder : 56cm\u003cbr\u003eChest : 59cm\u003cbr\u003eArm Length : 24cm\u003cbr\u003eTotal Length: 74cm\u003cbr\u003e\u003cbr\u003e\u003cstrong\u003eSize:2\u003c\/strong\u003e\u003cbr\u003eShoulder : 58cm\u003cbr\u003eChest : 61cm\u003cbr\u003eArm Length : 24cm\u003cbr\u003eTotal Length : 76cm\u003cbr\u003e\u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003ch4 data-mce-fragment=\"1\"\u003eMODEL\u003c\/h4\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003cp data-mce-fragment=\"1\"\u003e \u003c\/p\u003e\n\u003ch4 style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eNOTICE\u003c\/h4\u003e\n\u003cdiv style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eIn the process of producing polybags, powder is added to protect the printing from poly bag.\u003cbr data-mce-fragment=\"1\"\u003eThis is not a product defect, so it is unable to be s resaon for exchange or return.\u003cbr data-mce-fragment=\"1\"\u003eThe color of your product may look diffrent depending on your monitor resolution and brightness.\u003c\/div\u003e\n\u003cdiv style=\"text-align: left;\"\u003e\n\u003cspan data-mce-fragment=\"1\"\u003e \u003c\/span\u003e\u003cimg alt=\"tag\" src=\"https:\/\/cdn.shopify.com\/s\/files\/1\/0647\/3767\/3470\/files\/detailpage-authentic-img.jpg?v=1691738527\" data-mce-fragment=\"1\"\u003e\u003cspan data-mce-fragment=\"1\"\u003e \u003c\/span\u003e\n\u003c\/div\u003e\n\u003cdiv style=\"text-align: left;\" data-mce-fragment=\"1\"\u003eProduk resmi tersebut memiliki label yang menjelaskan cara memeriksa keaslian SLOT 88.\u003cbr data-mce-fragment=\"1\"\u003eWe would like to ask you to be aware of fake products without authentic labels and tags.\u003cbr data-mce-fragment=\"1\"\u003e(Please check an authentic hologram sticker attached on a tag with the HiddenTag application.)\u003c\/div\u003e"}
  </script>

  <script type="application/json" id="ModelJson-template--20682832118014__main">
    []
  </script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://mannolmy.com/about-us/"
  },
  "headline": "Daftar Slot Gacor Hari ini Situs Slot88 Resmi - Alexistogel",
  "description": "Alexistogel adalah link daftar slot gacor 88 resmi, link daftar slot88 memberikan rtp gampang maxwin dan memiliki reputasi sangat baik hingga hari ini!",
  "image": {
    "@type": "ImageObject",
    "url": "https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg",
    "width": 823,
    "height": 450
  },
  "author": {
    "@type": "Organization",
    "name": "ALEXISTOGEL",
    "url": "https://mannolmy.com/about-us/"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ALEXISTOGEL",
    "logo": {
      "@type": "ImageObject",
      "url": "https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1757450054&width=823"
    }
  },
  "datePublished": "2026-02-24",
  "dateModified": "2026-02-24"
}
</script>


<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "ALEXISTOGEL",
  "image": [
    "https://ik.imagekit.io/ljdihgltp/banner-slot88.jpg?v=1757450054&width=823"
  ],
  "description": "Alexistogel adalah link daftar slot gacor 88 resmi, link daftar slot88 memberikan rtp gampang maxwin dan memiliki reputasi sangat baik hingga hari ini!",
  "sku": "slot88888",
  "brand": {
    "@type": "Brand",
    "name": "ALEXISTOGEL"
  },
  "offers": {
    "@type": "Offer",
    "url": "https://mannolmy.com/about-us/",
    "priceCurrency": "IDR",
    "price": "490.000", 
    "availability": "https://schema.org/InStock",
    "itemCondition": "https://schema.org/NewCondition"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.9",
    "bestRating": "5",
    "worstRating": "1",
    "ratingCount": "12580",
    "reviewCount": "9850"
  }
}
</script>


<style> #shopify-section-template--20682832118014__main h5 {display: none;} #shopify-section-template--20682832118014__main h1 {font-size: 18px;} #shopify-section-template--20682832118014__main h3 {font-size: 16px;} @media only screen and (max-width: 768px) {#shopify-section-template--20682832118014__main h1 {font-size: 16px; }} </style></section><div id="shopify-section-template--20682832118014__1727669701a0338d4e" class="shopify-section"><div
  class="
    apps
    section
    section--divider-none
    section--vertical-padding-top-bottom
    
      animation
      animation--apps
    
  "
  data-section-id="template--20682832118014__1727669701a0338d4e"
  data-section-type="apps"
>
  <div class="section-introduction animation--section-introduction"></div></div>


</div><section id="shopify-section-template--20682832118014__recommendations" class="shopify-section"><div
  class="
    recommended-products
    carousel--mobile-per-view-2
    carousel--per-view-2
    section
    section--includes-product-items
    section--divider-none
    section--vertical-padding-top-bottom
    
      animation
      animation--list-slider
    
  "
  data-section-id="template--20682832118014__recommendations"
  data-section-type="recommended-products"
  data-product-id="8875826217214"
  data-limit="8"
  data-products-per-view="5"
  data-mobile-products-per-view="2"
>
  <div class="section__inner" data-recommendations>
    <div class="carousel__navigation-wrapper">
      <div class="section-introduction animation--section-introduction"><h2 class="recommended-products__heading ff-heading fs-heading-3-base section-introduction__heading">
            Recommended Products
          </h2></div><div
  class="carousel__navigation-buttons animation--controls"
  
>
  <button
    type="button"
    class="carousel__navigation-button carousel__navigation-button--back"
    data-prev
    aria-label="Move to previous carousel slide"
  ><span class="icon icon-new icon-arrow-long ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>
</button>
  <button
    type="button"
    class="carousel__navigation-button carousel__navigation-button--forward"
    data-next
    aria-label="Move to next carousel slide"
  ><span class="icon icon-new icon-arrow-long ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>
</button>
</div>

    </div>

    <div class="recommended-products__content carousel swiper">
      <div class="recommended-products__slider-wrapper carousel__wrapper swiper-wrapper"></div>
    </div>
  </div>
</div>


</section><section id="shopify-section-template--20682832118014__recently-viewed-products" class="shopify-section"><div
  class="
    recently-viewed-products
    carousel--mobile-per-view-2
    carousel--per-view-2
    section
    section--includes-product-items
    section--divider-none
    section--vertical-padding-top-bottom
    
      animation
      animation--list-slider
    
  "
  data-section-id="template--20682832118014__recently-viewed-products"
  data-section-type="recently-viewed-products"
  data-product-handle="animated-font-short-sleeve-t-shirt-black"
  data-limit="8"
  data-products-per-view="5"
  data-mobile-products-per-view="2"
>
  <div class="section__inner" data-recently-viewed>
    <div class="carousel__navigation-wrapper">
      <div class="section-introduction animation--section-introduction"><h2 class="recently-viewed-products__heading ff-heading fs-heading-3-base section-introduction__heading">
            Recently viewed
          </h2></div><div
  class="carousel__navigation-buttons animation--controls"
  
>
  <button
    type="button"
    class="carousel__navigation-button carousel__navigation-button--back"
    data-prev
    aria-label="Move to previous carousel slide"
  ><span class="icon icon-new icon-arrow-long ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>
</button>
  <button
    type="button"
    class="carousel__navigation-button carousel__navigation-button--forward"
    data-next
    aria-label="Move to next carousel slide"
  ><span class="icon icon-new icon-arrow-long ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m17.1 18.9 5.9-6.4L17.1 6m5.9 6.4H0" stroke="currentColor" stroke-width="1.1"/></svg>
</span>
</button>
</div>

    </div>

    <div class="recently-viewed-products__content carousel swiper">
      <div class="recently-viewed-products__slider-wrapper carousel__wrapper swiper-wrapper"></div>
    </div>
  </div>
</div>


</section>
      </main>

 <!-- –– DONT REMOVE - SEO ––-->

<!-- –– DONT REMOVE - END SEO ––-->

      <!-- BEGIN sections: footer-group -->
<footer id="shopify-section-sections--20682824122622__footer" class="shopify-section shopify-section-group-footer-group footer__parent"><div
  class="footer section"
  data-section-id="sections--20682824122622__footer"
  data-section-type="footer"
  style="
    --color-background-input: rgba(255, 255, 255, 0.2);
    --color-background-input-hover: rgba(255, 255, 255, 0.25);
    --color-background-input-hover-dull: rgba(255, 255, 255, 0.1);
    --color-background-input-highlight: rgba(255, 255, 255, 0.35);
    --color-text-input: rgba(255, 255, 255, 0.95);
  ">
  <div class="footer__inner">
    <div class="footer__groups">
      <div
          class="
            footer__group
            footer__group--text
            footer__group--1
            
            footer__group--first
            
            hide-title-on-desktop
          "
          style="
            --desktop-width: 30%;
            --desktop-padding: 0%;
            --image-max-width: 200px
          "
        ><div class="footer__group-content">
<div class="fs-body-100 footer__text"><p><strong>Customer Care</strong></p><p>24/7<br/><br/><br/><strong>Link <span style="color: #ff0000;"><a style="color: #ffffff;" href="https://stres.b-cdn.net/slot88-gacor.html"><strong>slot gacor</strong></a></span> dengan kemenangan tertinggi mencapai 98%, bersama Alexistogel para pemain bisa lebih mudah temukan situs 88 resmi.</strong><br/> Daftar Sekarang!</p>
  </div></div>
        </div>
      <div
          class="
            footer__group
            footer__group--spacer
            footer__group--2
            
            
            
            hide-title-on-desktop
          "
          style="
            --desktop-width: 10%;
            --desktop-padding: %;
            
          "
        ><div class="footer__group-content"></div>
        </div>
      <div
          class="
            footer__group
            footer__group--links
            footer__group--3
            footer__group--collapse
            
            
            
          "
          style="
            --desktop-width: 15%;
            --desktop-padding: 4%;
            
          "
        ><h4 class="footer__header ff-body footer__header--collapsed">
              <span class="footer__heading fs-accent">SLOT88</span>
            </h4><button type="button" class="footer__header ff-body" data-header>
                <span class="footer__heading fs-accent">SLOT88</span>
                <span class="footer__arrow"><span class="icon icon-new icon-chevron-small ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2.75"/></svg>
</span>
</span>
              </button><div class="footer__group-content"><div class="footer__links fs-body-100">
                
                  <ul>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">SLOT 88</a>
                      </li>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">SITUS SLOT</a>
                      </li>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">SLOT ONLINE</a>
                      </li>
                    
                      <li>
                        <a href="//www.allglassbyronbay.com.au">SLOT GACOR</a>
                      </li>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">SLOT88 GACOR</a>
                      </li>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">SITUS SLOT88</a>
                      </li>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">SLOT GACOR HARI INI</a>
                      </li>
                    
                  </ul>
                
              </div></div>
        </div>
      <div
          class="
            footer__group
            footer__group--links
            footer__group--4
            footer__group--collapse
            
            
            
          "
          style="
            --desktop-width: 15%;
            --desktop-padding: 4%;
            
          "
        ><h4 class="footer__header ff-body footer__header--collapsed">
              <span class="footer__heading fs-accent">ALEXISTOGEL</span>
            </h4><button type="button" class="footer__header ff-body" data-header>
                <span class="footer__heading fs-accent">ALEXISTOGEL</span>
                <span class="footer__arrow"><span class="icon icon-new icon-chevron-small ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2.75"/></svg>
</span>
</span>
              </button><div class="footer__group-content"><div class="footer__links fs-body-100">
                
                  <ul>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">SITUS  GACOR</a>
                      </li>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">TOGEL ONLINE</a>
                      </li>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">CASINO ONLINE</a>
                      </li>
                    
                      <li>
                        <a href="//mannolmy.com/about-us/">SITUS SLOT ONLINE SLOT88</a>
                      </li>
                    
                  </ul>
                
              </div></div>
        </div>
      <div
          class="
            footer__group
            footer__group--newsletter
            footer__group--5
            
            
            footer__group--last
            
          "
          style="
            --desktop-width: 30%;
            --desktop-padding: 0%;
            
          "
        ><h4 class="footer__header ff-body">
              <span class="footer__heading fs-accent">SEO - ASLI-NYA C E O</span>
            </h4><div class="footer__group-content"><div class="footer__newsletter">
                <div class="ff-heading fs-body-150 footer__text"></div>

                <form method="post" action="//mannolmy.com/about-us/contact#footer-subscribe" id="footer-subscribe" accept-charset="UTF-8" class="footer__newsletter-form"><input type="hidden" name="form_type" value="customer" /><input type="hidden" name="utf8" value="✓" />
                  


<div class="footer__newsletter-inner">
                      <input type="hidden" name="contact[tags]" value="newsletter">
                      <label for="footer-subscribe-email" class="visually-hidden">Your email</label>
                      <input
                        type="email"
                        class="input"
                        name="contact[email]"
                        id="footer-subscribe-email"
                        value=""
                        placeholder="Your email"
                        autocorrect="off"
                        autocapitalize="off"
                        required
                      >
                      <button
                        type="submit"
                        name="commit"
                        id="Subscribe-footer"
                        class="footer__newsletter-button"
                        aria-label="Subscribe"
                      >
                        Subscribe
                      </button>
                    </div></form>
<ul class="social-icons social-icons--left" data-count="4"><li>
          <a
            href="#"
            title="SLOT88"
            target="_blank"
            rel="noopener"
          >
            <span class="icon icon-new icon-facebook ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12,2C6.477,2,2,6.477,2,12c0,5.013,3.693,9.153,8.505,9.876V14.65H8.031v-2.629h2.474v-1.749 c0-2.896,1.411-4.167,3.818-4.167c1.153,0,1.762,0.085,2.051,0.124v2.294h-1.642c-1.022,0-1.379,0.969-1.379,2.061v1.437h2.995 l-0.406,2.629h-2.588v7.247C18.235,21.236,22,17.062,22,12C22,6.477,17.523,2,12,2z" fill="currentColor" /></svg>
</span>

          </a>
        </li><li>
          <a
            href="#"
            title="SLOT ONLINE"
            target="_blank"
            rel="noopener"
          >
            <span class="icon icon-new icon-instagram ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" fill="currentColor" /></svg>
</span>

          </a>
        </li><li>
          <a
            href="#"
            title="SLOT GACOR"
            target="_blank"
            rel="noopener"
          >
            <span class="icon icon-new icon-tiktok ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M16.16 1.35c.35 3 2 4.83 5 5v3.4a7.79 7.79 0 0 1-4.92-1.44v6.36c0 8.07-8.8 10.59-12.34 4.81C1.59 15.77 3 9.24 10.28 9v3.59a11.24 11.24 0 0 0-1.69.41c-1.62.55-2.54 1.58-2.29 3.4.49 3.47 6.87 4.5 6.34-2.29V1.36h3.52z" fill="currentColor"/></svg>
</span>

          </a>
        </li><li>
          <a
            href="#"
            title="SLOT RESMI"
            target="_blank"
            rel="noopener"
          >
            <span class="icon icon-new icon-twitter ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M13.903 10.464 21.348 2h-1.764l-6.465 7.35L7.955 2H2l7.808 11.114L2 21.99h1.764l6.828-7.761 5.452 7.76H22l-8.098-11.525Zm-2.417 2.747-.791-1.106L4.4 3.299h2.71l5.08 7.107.791 1.106 6.604 9.238h-2.71l-5.389-7.538Z"/></svg>
</span>

          </a>
        </li></ul>
</div></div>
        </div>
      
    </div>

    <div class="footer__bottom">
      <div class="footer__bottom-left"><form method="post" action="//mannolmy.com/about-us/" id="localization_form" accept-charset="UTF-8" class="disclosure-form" enctype="multipart/form-data"><input type="hidden" name="form_type" value="localization" /><input type="hidden" name="utf8" value="✓" /><input type="hidden" name="_method" value="put" /><input type="hidden" name="return_to" value="//mannolmy.com/about-us/products/animated-font-short-sleeve-t-shirt-black?variant=46669712720126&utm_medium=product_sync&utm_source=google&utm_content=sag_organic&utm_campaign=sag_organic&gad_source=4&gad_campaignid=22698657731&gbraid=0AAAABAAvWBMjO-zMJuStvuWfVO4tp4PJJ&gclid=EAIaIQobChMIrumnpuffkgMVKc48Ah3u1Ql2EAQYBiABEgKoPPD_BwE" /><div class="disclosure-form__inner"><div class="disclosure-form__item">
          <h2 class="visually-hidden" id="lang-heading-footer">
            Language
          </h2>

          <div class="disclosure disclosure--locale" data-disclosure="locale" data-disclosure-locale>
            <button
              type="button"
              class="disclosure__toggle fs-body-50"
              aria-expanded="false"
              aria-controls="lang-list-footer"
              aria-describedby="lang-heading-footer"
              data-disclosure-toggle
            >
              Indonesia
              <span class="icon icon-new icon-chevron-small ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 7.438 12 17.563 22.125 7.438" stroke="currentColor" stroke-width="2.75"/></svg>
</span>

            </button>
            <ul
              id="lang-list-footer"
              class="disclosure-list"
              aria-hidden="true"
              data-disclosure-list
            >
              
                <li class="disclosure-list__item ">
                  <a
                    class="disclosure-list__option no-transition fs-body-75"
                    href="#"
                    lang="en"
                    
                    data-value="en"
                    data-disclosure-option
                  >
                    <span class="disclosure-list__option-label">English</span></a>
                </li>
                <li class="disclosure-list__item disclosure-list__item--current">
                  <a
                    class="disclosure-list__option no-transition fs-body-75"
                    href="#"
                    lang="id"
                    
                      aria-current="true"
                    
                    data-value="id"
                    data-disclosure-option
                  >
                    <span class="disclosure-list__option-label">Indonesia</span><span class="icon icon-new icon-checkmark ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m1.88 11.988 6.21 6.103L22.467 3.83" stroke="currentColor" stroke-width="3.055"/></svg>
</span>

</a>
                </li></ul>
            <input
              type="hidden"
              name="locale_code"
              id="LocaleSelector-footer"
              value="id"
              data-disclosure-input
            >
          </div>
        </div></div></form>

  

  
    <link
      rel="preload"
      fetchpriority="low"
      href="//acmedelavie.co.id/cdn/shop/t/38/assets/partial-flag-icons.css?v=81177382301374531161767828856"
      as="style"
      media="screen"
      onload="this.onload=null;this.rel='stylesheet'"
    >
    <noscript
      ><link rel="stylesheet" href="//acmedelavie.co.id/cdn/shop/t/38/assets/partial-flag-icons.css?v=81177382301374531161767828856" media="screen"
    ></noscript>
  

<div class="footer__credits fs-body-50">
          <p>
            Copyright &copy; 2026, <a href="/" title="">SLOT88</a>.
            All rights reserved.
          </p>
          
        </div>
      </div>

      <div class="footer__bottom-right"></div>
    </div>
  </div>
</div>


<style> background {color: FFFFFF;} </style></footer>

<div
  class="
    store-availability-drawer
    popover
    animation
    animation--store-availability-drawer"
  data-store-availability-drawer
  aria-describedby="drawer-title"
  aria-hidden="true"
  role="dialog"
>
  <div class="store-availability-drawer__wash" data-store-availability-drawer-wash></div>
  <div class="store-availability-drawer__container">
    <div class="store-availability-drawer__inner">
      <div class="store-availability-drawer__header">
        <div class="store-availability-drawer__product-info">
          <h4
            id="drawer-title"
            class="store-availability-drawer__store-list-product-title ff-heading fs-heading-5-base"
            data-store-availability-product-title
          >
            Availability
          </h4>
          <p
            class="store-availability-drawer__store-list-variant-title fs-body-60 t-opacity-60"
            data-store-availability-variant-title
          ></p>
        </div>
        <button
          type="button"
          class="store-availability-drawer__close"
          data-store-availability-close
          aria-label="Close"
        >
          <span
  class="icon-button icon-button-close  icon-button--small "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-close ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.66 1.34 2 .68.68 2l.66.66 1.32-1.32zm18.68 21.32.66.66L23.32 22l-.66-.66-1.32 1.32zm1.32-20 .66-.66L22 .68l-.66.66 1.32 1.32zM1.34 21.34.68 22 2 23.32l.66-.66-1.32-1.32zm0-18.68 10 10 1.32-1.32-10-10-1.32 1.32zm11.32 10 10-10-1.32-1.32-10 10 1.32 1.32zm-1.32-1.32-10 10 1.32 1.32 10-10-1.32-1.32zm0 1.32 10 10 1.32-1.32-10-10-1.32 1.32z" fill="currentColor"/></svg>
</span>

  </span>
</span>

        </button>
      </div>
      <div class="store-availbility-drawer__product" data-store-availability-product></div>

      <div class="store-availbility-drawer__content" data-store-list-container></div>
    </div>
  </div>
</div>

      <div
  class="
    quick-product--wrap
    modal
    popover
    is-fixed
    animation
    animation--quick-view
    animation--quick-view-revealed"
    aria-modal="true"
    aria-hidden="true"
    data-quick-view-modal >
  <div class="modal__wash"></div>
  <div class="quick-product--modal__inner modal__inner">
    <div class="quick-view-modal__content empty">
      <h3 class="quick-view-modal-loading-indicator">
    <div class="loader">
  <div class="loader__wrap">
    <div class="loader__bar"></div>
  </div>
</div>

  </h3>
    </div>
    <button
      type="button"
      data-modal-close
      class="modal__close-icon"
      aria-label="Close"
    >
      <span
  class="icon-button icon-button-close  icon-button--small "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-close ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.66 1.34 2 .68.68 2l.66.66 1.32-1.32zm18.68 21.32.66.66L23.32 22l-.66-.66-1.32 1.32zm1.32-20 .66-.66L22 .68l-.66.66 1.32 1.32zM1.34 21.34.68 22 2 23.32l.66-.66-1.32-1.32zm0-18.68 10 10 1.32-1.32-10-10-1.32 1.32zm11.32 10 10-10-1.32-1.32-10 10 1.32 1.32zm-1.32-1.32-10 10 1.32 1.32 10-10-1.32-1.32zm0 1.32 10 10 1.32-1.32-10-10-1.32 1.32z" fill="currentColor"/></svg>
</span>

  </span>
</span>

    </button>
  </div>
</div>


      <div class="modal popover" data-modal>
  <div class="modal__wash"></div>
  <div class="modal__inner" data-scroll-lock-ignore>
    <div class="modal__header">
      <button
        type="button"
        data-modal-close
        class="modal__close-icon"
        aria-label="Close"
      >
        <span
  class="icon-button icon-button-close  icon-button--small "
  
>
  <span class="icon-button__icon">
    <span class="icon icon-new icon-close ">
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.66 1.34 2 .68.68 2l.66.66 1.32-1.32zm18.68 21.32.66.66L23.32 22l-.66-.66-1.32 1.32zm1.32-20 .66-.66L22 .68l-.66.66 1.32 1.32zM1.34 21.34.68 22 2 23.32l.66-.66-1.32-1.32zm0-18.68 10 10 1.32-1.32-10-10-1.32 1.32zm11.32 10 10-10-1.32-1.32-10 10 1.32 1.32zm-1.32-1.32-10 10 1.32 1.32 10-10-1.32-1.32zm0 1.32 10 10 1.32-1.32-10-10-1.32 1.32z" fill="currentColor"/></svg>
</span>

  </span>
</span>

      </button>
    </div>
    <div class="modal__content rte non-page-rte"></div>
  </div>
</div>

      

    </div>

    <script src="//www.youtube.com/iframe_api" type="text/javascript"></script>
    <link href="//acmedelavie.co.id/cdn/shopifycloud/shopify-plyr/v1.0/shopify-plyr.css" rel="stylesheet" type="text/css" media="all" />



    


<!-- BEGIN: Consent Popup -->
<div id="consent-popup" class="consent-popup hidden">
  <div class="consent-box">
    <p class="consent-text">
      We use cookies and similar technologies to improve your shopping experience, 
      analyze our traffic, and personalize offers.  
      By clicking <strong>Accept</strong>, you consent to the use of cookies as described in our 
      <a href="/policies/privacy-policy" target="_blank">Privacy Policy</a>.
    </p>
    <div class="consent-actions">
      <button id="accept-consent" class="consent-btn accept">Accept</button>
      <button id="decline-consent" class="consent-btn decline">Decline</button>
    </div>
  </div>
</div>

<style>
/* ===========================
   Consent Popup – Stiletto Theme
   =========================== */
.consent-popup {
  position: fixed;
  bottom: 24px;
  left: 0;
  right: 0;
  display: flex;
  justify-content: center;
  z-index: 9999;
  animation: fadeIn 0.4s ease-out;
}

.consent-box {
  background: #ffffff;
  border: 1px solid #e5e5e5;
  max-width: 640px;
  width: 90%;
  padding: 18px 22px;
  border-radius: 16px;
  box-shadow: 0 6px 14px rgba(0, 0, 0, 0.1);
  text-align: center;
  font-family: var(--font-body, 'Helvetica Neue', sans-serif);
  color: #222;
}

.consent-text {
  font-size: 14px;
  line-height: 1.6;
  margin-bottom: 14px;
}

.consent-actions {
  display: flex;
  justify-content: center;
  gap: 12px;
}

.consent-btn {
  padding: 10px 20px;
  border-radius: 8px;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all 0.25s ease;
}

.consent-btn.accept {
  background-color: #000;
  color: #fff;
}

.consent-btn.accept:hover {
  background-color: #333;
}

.consent-btn.decline {
  background-color: #f4f4f4;
  color: #333;
}

.consent-btn.decline:hover {
  background-color: #e9e9e9;
}

.hidden {
  display: none !important;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>

<script>
document.addEventListener("DOMContentLoaded", function() {
  const popup = document.getElementById("consent-popup");
  const acceptBtn = document.getElementById("accept-consent");
  const declineBtn = document.getElementById("decline-consent");

  // Check if consent already exists
  const consentStatus = localStorage.getItem("user_consent_status");

  if (!consentStatus) {
    popup.classList.remove("hidden");
  }

  // --- ACCEPT ---
  acceptBtn.addEventListener("click", function() {
    localStorage.setItem("user_consent_status", "accepted");
    popup.classList.add("hidden");

    // Update Google Consent Mode
    if (typeof gtag !== 'undefined') {
      gtag('consent', 'update', {
        'ad_storage': 'granted',
        'analytics_storage': 'granted'
      });

      // Log consent decision in GA
      gtag('event', 'consent_decision', {
        'event_category': 'consent',
        'event_label': 'user_consent',
        'consent_status': 'accepted'
      });
    }
  });

  // --- DECLINE ---
  declineBtn.addEventListener("click", function() {
    localStorage.setItem("user_consent_status", "declined");
    popup.classList.add("hidden");

    // Restrict tracking in GA
    if (typeof gtag !== 'undefined') {
      gtag('consent', 'update', {
        'ad_storage': 'denied',
        'analytics_storage': 'denied'
      });

      // Log consent decision in GA
      gtag('event', 'consent_decision', {
        'event_category': 'consent',
        'event_label': 'user_consent',
        'consent_status': 'declined'
      });
    }
  });
});
</script>
<!-- END: Consent Popup -->



  <style> .atome-widget {display: none;} .product-item__price {font-weight: 500; font-size:14px;} .ta-c {text-align: left;} @media only screen and (max-width: 768px) {.ta-c {font-size: 14px;} </style>
<div id="shopify-block-AYkpjcWFINkF3RWlJV__1513253815146976218" class="shopify-block shopify-app-block">
</div>
<div id="shopify-block-Aajk0TllTV2lJZTdoT__15683396631634586217" class="shopify-block shopify-app-block"><script
  id="chat-button-container"
  data-horizontal-position=bottom_right
  data-vertical-position=lowest
  data-icon=chat_bubble
  data-text=no_text
  data-color=#000000
  data-secondary-color=#ffffff
  data-ternary-color=#6a6a6a
>
</script>
</div>
</body>

<link
    rel="preload"
    fetchpriority="low"
    href="//acmedelavie.co.id/cdn/shop/t/38/assets/theme-deferred.css?v=73532264698157873721767828856"
    as="style"
    onload="this.onload=null;this.rel='stylesheet'" >
<noscript>
<link rel="stylesheet" href="//acmedelavie.co.id/cdn/shop/t/38/assets/theme-deferred.css?v=73532264698157873721767828856"></noscript>
</html>