<!DOCTYPE html>
<html dir="ltr" lang="id">

<head>

  <!-- Meta Tags -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <title>PMBM Online - MTsN 2 Tangerang</title>
<meta name="description" content="Website Resmi PMBM/SPMB/PPDB Online MTsN 2 Tangerang (Kab) Prov. Banten">
<meta name="keywords" content="ppdb online, psb online, web ppdb, mtsn 2 tangerang, spmb mtsn 2 tangerang, psb mtsn 2 tagerang"/>
  <meta name="author" content="MTs Negeri 2 Tangerang">
  <meta name="robots" content="index,follow" />
  <meta name="googlebot" content="index,follow" />
  <meta content='pmbm.mtsn2-tangerang.sch.id - 2026' name='copyright' />
  <meta content='noodp' name='robots' />
  <meta content='global' name='distribution' />
  <meta content='Indonesia' name='geo.placename' />
  
  <!-- Favicon and Touch Icons -->
  <link href="images/favicon.png" rel="shortcut icon" type="image/png">

  <!-- Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
  <link href="css/animate.css" rel="stylesheet" type="text/css">
  <link href="css/css-plugin-collections.css" rel="stylesheet" />
  <!-- CSS | menuzord megamenu skins -->
  <link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-border-top-bottom.css" rel="stylesheet" />
  <!-- CSS | Main style file -->
  <link href="css/style-main.css" rel="stylesheet" type="text/css">
  <!-- CSS | Preloader Styles -->
  <link href="css/preloader.css" rel="stylesheet" type="text/css">
  <!-- CSS | Custom Margin Padding Collection -->
  <link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
  <!-- CSS | Responsive media queries -->
  <link href="css/responsive.css" rel="stylesheet" type="text/css">
  <!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
  <!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

  <!-- CSS | Theme Color -->
  <link href="css/colors/theme-skin-color-green.css" rel="stylesheet" type="text/css">

  <style>
    .carousel-caption {
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;
      z-index: 10;
      padding-top: 10px;
      padding-bottom: 10px;
      color: #fff;
      text-align: center;
      background: rgba(0, 0, 0, 0.4);
    }
  </style>

  <!-- external javascripts -->
  <script src="js/jquery-2.2.4.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <!-- JS | jquery plugin collection for this theme -->
  <script src="js/jquery-plugin-collection.js"></script>

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="">
  <div id="wrapper" class="clearfix">
    <!-- preloader
    <div id="preloader">
      <div id="spinner">
        <div class="preloader-dot-loading">
          <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
        </div>
      </div>
      <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
    </div>
  -->
    <header id="header" class="header">

  <div class="header-middle p-0 bg-lightest xs-text-center">
    <div class="container pt-0 pb-0">
      <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-6">
          <div class="widget no-border m-0">
            <a class="menuzord-brand pull-left flip xs-pull-center mb-15" href="./"><img src="images/PMBM.svg"
                alt=""></a>
          </div>
        </div>
        <div class="col-xs-12 col-sm-4 col-md-3 hidden-xs">
          <div class="widget no-border pull-right sm-pull-none sm-text-center mt-10 mb-10 m-0">
            <ul class="list-inline">
              <li><i class="fa fa-phone-square text-theme-colored font-36 mt-5 sm-display-block"></i></li>
              <li>
                <a href="#" class="font-12 text-gray text-uppercase">HUBUNGI KAMI</a>
                <h5 class="font-14 m-0">
                  08521755714 (Akd) & 081313269762 (Rdw)                </h5>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-xs-12 col-sm-4 col-md-3 hidden-xs">
          <div class="widget no-border pull-right sm-pull-none sm-text-center mt-10 mb-10 m-0">
            <ul class="list-inline">
              <li><i class="fa fa-clock-o text-theme-colored font-36 mt-5 sm-display-block"></i></li>
              <li>
                <a href="#" class="font-12 text-gray text-uppercase">JAM LAYANAN</a>
                <h5 class="font-13 text-black m-0">
                  07:30 - 17:00 (Online)                </h5>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="header-nav">
    <div class="header-nav-wrapper navbar-scrolltofixed bg-theme-colored border-bottom-theme-color-2-1px">
      <div class="container">
        <nav id="menuzord" class="menuzord bg-theme-colored pull-left flip menuzord-responsive">
          <ul class="menuzord-menu">
            <li><a href="./">HOME</a></li>
            <li><a href="#">INFORMASI</a>
              <ul class="dropdown">
                                    <li><a href="//pmbm.mtsn2-tangerang.sch.id/informasi_panduan-ppdb-online_pg-41.html">
                        PANDUAN PPDB ONLINE                      </a></li>
                                  <li><a href="agenda.html">AGENDA PPDB</a></li>
                <li><a href="file-download.html">DOWNLOAD FILE</a></li>

              </ul>
            </li>


            <li><a href="#">PENDAFTARAN</a>
              <ul class="dropdown">
                <li><a href="formulir.html">ISI FORMULIR</a></li>
                <!--
          <li><a href="konfirmasi.html">KONFIRMASI TRANSFER</a></li>
          -->
                <li><a href="login.html">LOGIN KE AKUN</a></li>
              </ul>
            </li>

            <li><a href="hasil_penerimaan.html">HASIL PENERIMAAN</a></li>


            <li><a href="#footer">KONTAK</a></li>
          </ul>

          <ul class="pull-right flip hidden-sm hidden-xs">
            <li>
              <!-- Modal: Book Now Starts -->
              <a class="btn btn-colored btn-flat bg-theme-color-2 text-white font-14 mt-0 p-25 pr-15 pl-15 font-weight-600"
                href="formulir.html"><i class="fa fa-edit"></i> FORMULIR</a>
              <a class="btn btn-colored btn-flat bg-theme-colored text-white font-14 mt-0 p-25 pr-15 pl-15 font-weight-600"
                href="hasil_penerimaan.html"><i class="fa fa-bullhorn"></i> HASIL</a>
              <a class="btn btn-colored btn-flat bg-theme-colored text-white font-14 bs-modal-ajax-load mt-0 p-25 pr-15 pl-15 font-weight-600"
                data-toggle="modal" data-target="#BSParentModal" href="ajax-load/login.php"><i class="fa fa-key"></i>
                LOGIN</a>
              <!-- Modal: Book Now End -->
            </li>

          </ul>
          <div id="top-search-bar" class="collapse">
            <div class="container">
              <form role="search" action="#" class="search_form_top" method="get">
                <input type="text" placeholder="Type text and press Enter..." name="s" class="form-control"
                  autocomplete="off">
                <span class="search-close"><i class="fa fa-search"></i></span>
              </form>
            </div>
          </div>
        </nav>
      </div>
    </div>
  </div>
</header>
    <!-- Start main-content -->
    <div class="main-content">
      <marquee class="bg-theme-color-2 text-white pt-10 pb-10 pl-10 pr-10" onmousein="this.stop()">
        Selamat datang di website resmi PMBM/SPMB/PPDB Online  Madrasah Tsanawiyah Negeri (MTs) 2 Tangerang Kabupaten, Provinsi Banten. Silahkan cek informasi, alur dan syarat pendaftaran, sampai pengumuman hasil di website ini      </marquee>

      <section>
        <div class="container mt-10 mb-30 pt-10 pb-30">

          <div class="row">
            <div class="col-md-9">
              <!-- Slider Revolution Start -->
              <div class="rev_slider_wrapper">
                <div class="owl-carousel-1col" data-nav="true">
                                        <div class="item">
                                                  <img src="images/slide/jadwal-prestasi_760865518.png" alt="jadwal prestasi">
                          
                        <div class="carousel-caption hidden">
                          <h3 class="text-white font-weight-600">
                            jadwal prestasi                          </h3>
                          <p class="text-white">
                             | <a href=""><span class="badge badge-success">Lihat
                                Detail</span></a>
                          </p>

                        </div>
                      </div>
                                          <div class="item">
                                                  <img src="images/slide/prestasi_34775775.png" alt="Prestasi">
                          
                        <div class="carousel-caption hidden">
                          <h3 class="text-white font-weight-600">
                            Prestasi                          </h3>
                          <p class="text-white">
                             | <a href=""><span class="badge badge-success">Lihat
                                Detail</span></a>
                          </p>

                        </div>
                      </div>
                                          <div class="item">
                                                  <a href="https://whatsapp.com/channel/0029VbCaKcOKwqSM6kb0FM3h" target="_blank">
                                                    <img src="images/slide/chanel-wa_250656061.png" alt="Chanel WA">
                                                    </a>
                        
                        <div class="carousel-caption hidden">
                          <h3 class="text-white font-weight-600">
                            Chanel WA                          </h3>
                          <p class="text-white">
                             | <a href=""><span class="badge badge-success">Lihat
                                Detail</span></a>
                          </p>

                        </div>
                      </div>
                                          <div class="item">
                                                  <a href="https://linktr.ee/tutorialpmbmduta" target="_blank">
                                                    <img src="images/slide/tutorial-pendaftaran_295092994.png" alt="Tutorial Pendaftaran">
                                                    </a>
                        
                        <div class="carousel-caption hidden">
                          <h3 class="text-white font-weight-600">
                            Tutorial Pendaftaran                          </h3>
                          <p class="text-white">
                             | <a href=""><span class="badge badge-success">Lihat
                                Detail</span></a>
                          </p>

                        </div>
                      </div>
                                          <div class="item">
                                                  <a href="https://pmbm.mtsn2-tangerang.sch.id/download_file-21_s604262083_f=f760_Juknis-PMBM-MTsN-2-Tangerang-2026_compressed.pdf" target="_blank">
                                                    <img src="images/slide/petunjuk-teknis_889810363.png" alt="petunjuk teknis">
                                                    </a>
                        
                        <div class="carousel-caption hidden">
                          <h3 class="text-white font-weight-600">
                            petunjuk teknis                          </h3>
                          <p class="text-white">
                             | <a href=""><span class="badge badge-success">Lihat
                                Detail</span></a>
                          </p>

                        </div>
                      </div>
                                    </div>
              </div>
              <div class="row">
                <div class="col-md-4 text-center mt-20"><a href="formulir.html"
                    class="btn btn-xl btn-primary btn-block"><i class="fa fa-edit"></i> ISI FORMULIR PMBM</a></div>
                <div class="col-md-4 text-center mt-20"><a href="print_formulir.html"
                    class="btn btn-xl btn-info  btn-block"><i class="fa fa-print"></i> CETAK FORMULIR (LOGIN)</a></div>
                <div class="col-md-4 text-center mt-20"><a href="hasil_penerimaan.html"
                    class="btn btn-xl btn-success  btn-block"><i class="fa fa-bullhorn"></i> HASIL PENERIMAAN</a></div>
              </div>
              <div class="separator">
                <span>
                  MTs Negeri 2 Tangerang                </span>
              </div>
              <!-- Konten -->
              



            </div>
            <div class="col-md-3">
              <div class="sidebar sidebar-right mt-sm-30">
                <div class="widget">
                  <h5 class="widget-title line-bottom  font-weight-600">MARI SHARE INFORMASI PMBM :</h5>
                  <ul class="styled-icons icon-circled m-0">
                    <li><a href="https://www.facebook.com/sharer.php?u=https://pmbm.mtsn2-tangerang.sch.id/" data-bg-color="#3A5795"
                        style="background: rgb(58, 87, 149) none repeat scroll 0% 0% !important;"
                        onClick="window.open(this.href,'_blank','height=430,width=640');return false;" rel="nofollow"
                        title="Bagikan ke Facebook"><i class="fa fa-facebook text-white"></i></a></li>

                    <li><a href="https://twitter.com/share?url=https://pmbm.mtsn2-tangerang.sch.id/"
                        onClick="window.open(this.href,'_blank','height=430,width=640');return false;" rel="nofollow"
                        title="Bagikan ke Twitter" data-bg-color="#55ACEE"
                        style="background: rgb(85, 172, 238) none repeat scroll 0% 0% !important;"><i
                          class="fa fa-twitter text-white"></i></a></li>

                    <li>
                      <a href="javascript:void(0)"
                         onclick="copyLink()"
                         rel="nofollow"
                         title="Salin Link"
                         data-bg-color="#6c757d"
                         style="background:#6c757d none repeat scroll 0% 0% !important;">
                        <i class="fa fa-link text-white"></i>
                      </a>
                    </li>


                    <li><a href="whatsapp://send?text=PMBM Online - MTsN 2 Tangerang - https://pmbm.mtsn2-tangerang.sch.id/"
                        rel="nofollow" title="Bagikan ke Whatsapp" data-bg-color="#25d366"
                        style="background: #25d366 none repeat scroll 0% 0% !important;"><i
                          class="fa fa-whatsapp text-white"></i></a></li>
                  </ul>
                  <script>
function copyLink() {
    const link = "https://pmbm.mtsn2-tangerang.sch.id/";

    if (navigator.clipboard) {
        navigator.clipboard.writeText(link).then(function () {
            alert('Link berhasil disalin!');
        }).catch(function () {
            fallbackCopy(link);
        });
    } else {
        fallbackCopy(link);
    }
}

function fallbackCopy(text) {
    const input = document.createElement('input');
    input.value = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
    alert('Link berhasil disalin!');
}
</script>

                </div>
                <div class="widget">
                  <h5 class="widget-title line-bottom font-weight-600">ALUR PENDAFTARAN ONLINE :</h5>
                  <ul class="list-divider list-border list check text-capitalize">
                                        <li><span class="badge badge-default">1</span> Isi Formulir PMBM Online</li>
                                         <li><span class="badge badge-default">2</span> Mendapatkan ID dan PIN</li>
                                         <li><span class="badge badge-default">3</span> Login Akun PMBM Online</li>
                                         <li><span class="badge badge-default">4</span> Cek atau lengkapi formulir</li>
                                         <li><span class="badge badge-default">5</span> Upload berkas-berkas</li>
                                         <li><span class="badge badge-default">6</span> Print formulir</li>
                                         <li><span class="badge badge-default">7</span> Ikuti Tes Masuk</li>
                                         <li><span class="badge badge-default">8</span> Ikuti Informasi hasil penerimaan</li>
                                         <li><span class="badge badge-default">9</span> Daftar ulang (jika diterima)</li>
                                         <li><span class="badge badge-default">10</span> Menjadi peserta didik</li>
                                       </ul>
                </div>
                <!--
        <div class="widget">
                <h5 class="widget-title line-bottom font-weight-600">REKENING PEMBAYARAN</h5>
        <div class="panel panel-success">
  <div class="panel-body text-center"><strong></strong><br/>Biaya Pendaftaran:<br/><strong>Rp 0,-</strong></div>
</div>
-->


              </div>

            </div>
          </div>
        </div>
    </div>
    </section>
  </div>
  <!-- end main-content -->




  <!-- Start main-content -->
  <div class="main-content">

    <section class="divider parallax layer-overlay overlay-theme-colored-9">
      <div class="container">
        <div class="row">
          
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="fa fa-users mt-5 text-white"></i>
              <h2 data-animation-duration="2000"
                data-value="338"
                class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h5 class="text-white text-uppercase mb-0">TOTAL PENDAFTAR</h5>
            </div>
          </div>
          <!-- 
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="fa fa-edit mt-5 text-white"></i>
              <h2 data-animation-duration="2000"
                data-value="0"
                class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h5 class="text-white text-uppercase mb-0">DATA TERVERIFIKASI</h5>
            </div>
          </div>
          -->
           <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="fa fa-users mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="143" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h5 class="text-white text-uppercase mb-0">LAKI-LAKI</h5>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="fa fa-users mt-5 text-white"></i>
              <h2 data-animation-duration="2000" data-value="195" class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h5 class="text-white text-uppercase mb-0">PEREMPUAN</h5>
            </div>
          </div>
          
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-0">
            <div class="funfact text-center">
              <i class="fa fa-check mt-5 text-white"></i>
              <h2 data-animation-duration="2000"
                data-value="72"
                class="animate-number text-white mt-0 font-38 font-weight-500">0</h2>
              <h5 class="text-white text-uppercase mb-0">TERSELEKSI</h5>
            </div>
          </div>
        </div>
      </div>
    </section>



    <!-- end main-content -->
  </div>

  <!-- Footer -->
<footer id="footer" class="footer" data-bg-color="#1f1f1f">
  <div class="container pt-40 pb-20">
    <div class="row">
      <div class="col-md-6 col-md-offset-3 text-center">
        <img src="images/logo-white-footer.png" alt="">
        <p class="font-12 mt-20 mb-20">
          Jl. Aria Jaya Santika Tigaraksa, Kab. Tangerang,
                    Tlp. <a class="text-gray" href="tel:08521755714 (Akd) & 081313269762 (Rdw)">
            08521755714 (Akd) & 081313269762 (Rdw)          </a> - <a class="text-gray" href="//pmbm.mtsn2-tangerang.sch.id/">www.
            pmbm.mtsn2-tangerang.sch.id          </a> - <a class="text-gray" href="mailto:media.mtsn2tangerang@gmail.com">
            media.mtsn2tangerang@gmail.com          </a>
        </p>
        <ul class="styled-icons flat medium list-inline mb-40">
          <li><a href=""><i class="fa fa-facebook"></i></a></li>
          <li><a href=""><i class="fa fa-twitter"></i></a></li>
          <li><a href="  https://www.youtube.com/@mtsn2tangerang"><i class="fa fa-youtube"></i></a></li>
          <li><a href="https://www.instagram.com/mtsn2tangerang"><i class="fa fa-instagram"></i></a></li>
          <!--
          <li><a href=""><i class="fa fa-google-plus"></i></a></li>
          -->
        </ul>
      </div>
    </div>

  </div>
  <div class="footer-bottom" data-bg-color="#2f2f2f">
    <div class="container pt-15 pb-10">
      <div class="row">
        <div class="col-md-6">
          <p class="font-11 text-black-777 m-0">Copyright &copy;2026 
            pmbm.mtsn2-tangerang.sch.id. All Rights Reserved
          </p>
        </div>
        <div class="col-md-6 text-right">
          <div class="widget no-border m-0">
            <ul class="list-inline sm-text-center mt-5 font-12 hidden">
              <li>
                <a href="#">Website by</a>
              </li>

              <li>
                <a href="http://www.generasimedia.com" target="_blank">Generasi Media</a>
              </li>

            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>


<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
<style>
  a.wa-button {
    margin: 15px;
    padding: 7px;
    border: 0;
    position: fixed;
    z-index: 16000160;
    bottom: 0;
    text-align: center;
    overflow: hidden;
    font-size: 36px;
    color: #fff;
    background-color: #26a65b;
    border-radius: 50%;
    text-decoration: none;
    height: 50px;
    width: 50px;
    line-height: 1;
    box-shadow: 5px 5px 8px #888888;

  }

  a.wa-button:hover {
    box-shadow: 5px 5px 4px #888888;
  }
</style>

<div id="wa-button">
  <a href="//wa.me/+62 852-1755-7146" class="wa-button" title="Kirim pesan via Whatsapp" target="_blank">
    <i class="fa fa-whatsapp"></i>
  </a>
</div>



<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>  </div>
  <!-- end wrapper -->

  <!-- Footer Scripts -->
  <!-- JS | Custom script for all pages -->
  <script src="js/custom.js"></script>

</body>

</html>